function t(t) {
    return C.FORMDATA_XML <= t && t <= C.FORMDATA_PRESERVED;
}

function i(t, i, r) {
    null != t && ("number" == typeof t ? this.fromNumber(t, i, r) : null == i && "string" != typeof t ? this.fromString(t, 256) : this.fromString(t, i));
}

function r() {
    return new i(null);
}

function n(t) {
    return U.charAt(t);
}

function e(t, i) {
    var r = x[t.charCodeAt(i)];
    return null == r ? -1 : r;
}

function o(t) {
    var i = r();
    return i.fromInt(t), i;
}

function s(t) {
    var i, r = 1;
    return 0 != (i = t >>> 16) && (t = i, r += 16), 0 != (i = t >> 8) && (t = i, r += 8), 
    0 != (i = t >> 4) && (t = i, r += 4), 0 != (i = t >> 2) && (t = i, r += 2), 0 != (i = t >> 1) && (t = i, 
    r += 1), r;
}

function h(t) {
    this.m = t;
}

function u(t) {
    this.m = t, this.mp = t.invDigit(), this.mpl = 32767 & this.mp, this.mph = this.mp >> 15, 
    this.um = (1 << t.DB - 15) - 1, this.mt2 = 2 * t.t;
}

function a() {
    this.i = 0, this.j = 0, this.S = new Array();
}

function f() {
    !function(t) {
        j[N++] ^= 255 & t, j[N++] ^= t >> 8 & 255, j[N++] ^= t >> 16 & 255, j[N++] ^= t >> 24 & 255, 
        N >= q && (N -= q);
    }(new Date().getTime());
}

function l() {
    if (null == V) {
        for (f(), (V = new a()).init(j), N = 0; N < j.length; ++N) j[N] = 0;
        N = 0;
    }
    return V.next();
}

function c() {}

function p() {
    this.n = null, this.e = 0, this.d = null, this.p = null, this.q = null, this.dmp1 = null, 
    this.dmq1 = null, this.coeff = null;
}

var m, D, y, v, g = require("D241671384CF379CB4270F14BCA15043.js"), d = require("A1E875D684CF379CC78E1DD151225043.js"), T = require("C64A566184CF379CA02C3E66B1325043.js"), S = require("F2E3964184CF379C9485FE465AD15043.js"), b = require("7A4F598784CF379C1C29318090A15043.js"), A = require("33C32B0784CF379C55A54300DBC15043.js"), O = require("AD6E711584CF379CCB0819129F325043.js"), C = {
    FORMDATA_XML: 10,
    FORMDATA_HTML: 11,
    FORMDATA_PDF: 12,
    FORMDATA_JSON: 13,
    FORMDATA_PRESERVED: 19
}, I = !1, R = !1, w = [], P = [], B = [], E = [], M = [];

module.exports = {
    initAnySignApi: function(t, i) {
        return !(!t || !i || (!1, m = null, v = null, I = !1, R = !1, w = [], P = [], B = [], 
        M = [], m = t, v = i, b.setCallback(m), 0));
    },
    _addSignatureObj: function(t, i) {
        if (!I && i && function(t) {
            return t >= 20 && t <= 29 || t >= 200 && t <= 299;
        }(t)) {
            i.cid = t, P[t] = i;
            var r = new g.SignatureObj();
            return r.Cid = t, r.Signer = i.signer, r.SignRule = i.signRule, r.IsTSS = i.isTSS, 
            r.TimeTag = i.timeTag, w[t] = r, !0;
        }
        return !1;
    },
    _commitConfig: function() {
        return I = !0, !0;
    },
    _setTemplate: function(i, r, n, e) {
        if (!I) return console.log("mIsInitialized is false"), !1;
        if (!R && t(i)) {
            if (null == r || 0 === r.length) return console.log("contentUtf8Str must not be null or empty"), 
            !1;
            if (null == n || 0 === n.length) return console.log("businessId must not be null or empty"), 
            !1;
            if (null == e || 0 === e.length) return console.log("template_serial must not be null or empty"), 
            !1;
            D = n, y = function(t) {
                return T.encodeUint8Array(T.hexStrToUint8Array(d.hex_sha1(t) + ""));
            }(n) + "";
            var o = new g.DataObj();
            if (o.Cid = i, o.Data = r, C.FORMDATA_XML === i || C.FORMDATA_JSON === i) {
                var s = new PDFCrdRule();
                s.DocFormat = i, s.DocStyleTid = e, o.PDFCrdRule = s;
            }
            var h = new S.DataConfig();
            return h.cid = i, h.nessesary = !0, B[i] = o, E[i] = h, R = !0, !0;
        }
        return !1;
    },
    _showSignatureDialog: function(t, i) {
        if (I) {
            if (R) {
                if (null == P[t]) return "EC_WRONG_CONTEXT_ID";
                i.setData({
                    showView: !0
                });
                var r = P[t];
                return b.onloadAnysignView(r, function(i, n, e, o, s) {
                    var h = w[t];
                    if (function(t, i, r, n, e, o) {
                        t.Points || (t.Points = new g.PlainData()), t.Points.P10Data || (t.Points.P10Data = new g.P10Data()), 
                        t.Points.CertOID || (t.Points.CertOID = new g.CertOID()), t.Points.CertOID.BioFeature || (t.Points.CertOID.BioFeature = new g.BioFeature()), 
                        t.Points.CertOID.IDNumber = t.Signer.IDNumber, t.Points.CertOID.IDType = t.Signer.IDType, 
                        t.Points.CertOID.BioFeature.Script = new g.Script(), t.Points.CertOID.ClientOS = new g.ClientOS(), 
                        wx.getSystemInfo({
                            success: function(i) {
                                t.Points.CertOID.ClientOS.Name = "WeiXin_" + i.system, t.Points.CertOID.ClientOS.Edition = i.model, 
                                t.Points.CertOID.ClientOS.Version = i.version, t.Points.CertOID.ClientOS.DeviceID = i.platform;
                            }
                        });
                        var s = t.Points.CertOID.BioFeature.Script;
                        s.Color = parseInt("0x" + i.substr(1)) + "", s.Data = T.compressToB64(T.strToUint8ArrayAscII(r)), 
                        s.Count = n + "", s.Device = new g.Device(), s.Device.Width = 99999, s.Device.Height = 99999, 
                        wx.getSystemInfo({
                            success: function(t) {
                                s.Device.DeviceName = "WeiXin_" + t.system, s.Device.DeviceID = t.version;
                            }
                        }), s.RefWidth = e, s.RefHeight = o;
                    }(h, r.penColor, n, e, o, s), h.ImageSize = new g.ImageSize(o, s), h.Image = i, 
                    h.SignRule && h.SignRule instanceof S.SignRule_XYZ) {
                        var u = h.SignRule.XYZRule;
                        "dp" === u.Unit ? h.SignRule.XYZRule = {
                            Left: u.Left,
                            Top: u.Top,
                            Right: u.Left + o,
                            Bottom: u.Top - s,
                            Pageno: u.Pageno,
                            Unit: u.Unit
                        } : "pt" === u.Unit && (h.SignRule.XYZRule = {
                            Left: u.Left,
                            Top: u.Top,
                            Right: u.Left + .45 * o,
                            Bottom: u.Top - .45 * s,
                            Pageno: u.Pageno,
                            Unit: u.Unit
                        });
                    }
                }, i), "OK";
            }
            return "EC_TEMPLATE_NOT_SET";
        }
        return "EC_API_NOT_INITED";
    },
    _isReadyToUpload: function() {
        if (!I || !R) return !1;
        for (var t in P) {
            var i = (n = P[t]).cid;
            if (n.nessesary) {
                var r = w[i];
                if (null == r || null == r.Points || null == r.Points.CertOID || null == r.Points.CertOID.BioFeature || null == r.Points.CertOID.BioFeature.Script) return !1;
            }
        }
        for (t in E) {
            var n = E[t], e = B[n.cid];
            if ((null == e || null == e.Data) && n.nessesary) return !1;
        }
        return !0;
    },
    _getUploadDataGram: function() {
        if (I && this._isReadyToUpload() && R) {
            for (var t = new g.AnySignRoot(), i = new g.FormInfo(), r = new Uint8Array(24), n = 0; n < 24; n++) {
                var e = 100 * Math.random();
                r[n] = e;
            }
            t.EncKey = function(t) {
                return function(t, i, r) {
                    var n = new p();
                    n.setPublic(t, i);
                    var e = n.encryptUint8(r), o = T.hexStrToUint8Array(e);
                    return T.encodeUint8Array(o);
                }(J, H, t);
            }(r), t.EncCertSN = k;
            var o, s = [];
            for (var h in P) o = P[h], "" != w[o.cid].Image && null != w[o.cid].Image && s.push(w[o.cid]);
            var u = [];
            for (h in E) o = E[h], u.push(B[o.cid]);
            i.WONo = D, i.WOHash = y, i.Channel = v, null != M && M.length > 0 && (i.IsUnit = !0), 
            i.USignArray = s, i.DataArray = u, i.CachetArray = M, i.ExtInfo = new g.ExtInfo(), 
            i.EncAlg = getApp().sigGlobalData.EncAlg;
            var a = T.stringify(i);
            return t.EncData = function(t, i) {
                var r = O.CryptoJS.enc.Hex.parse(i);
                return O.CryptoJS.TripleDES.encrypt(t, r, {
                    mode: O.CryptoJS.mode.ECB,
                    padding: O.CryptoJS.pad.Pkcs7
                });
            }(a, T.uint8ArrayToHexStr(r)) + "", t.Digest = new g.Digest(), t.Digest.Alg = "CRC32", 
            t.Digest.Value = T.crc32(t.EncData).toString(16).toUpperCase(), T.stringify(t);
        }
        return console.log("UploadDataGram is null"), null;
    }
};

i.prototype.am = function(t, i, r, n, e, o) {
    for (var s = 16383 & i, h = i >> 14; --o >= 0; ) {
        var u = 16383 & this[t], a = this[t++] >> 14, f = h * u + a * s;
        e = ((u = s * u + ((16383 & f) << 14) + r[n] + e) >> 28) + (f >> 14) + h * a, r[n++] = 268435455 & u;
    }
    return e;
}, i.prototype.DB = 28, i.prototype.DM = 268435455, i.prototype.DV = 1 << 28;

i.prototype.FV = Math.pow(2, 52), i.prototype.F1 = 24, i.prototype.F2 = 4;

var _, F, U = "0123456789abcdefghijklmnopqrstuvwxyz", x = new Array();

for (_ = "0".charCodeAt(0), F = 0; F <= 9; ++F) x[_++] = F;

for (_ = "a".charCodeAt(0), F = 10; F < 36; ++F) x[_++] = F;

for (_ = "A".charCodeAt(0), F = 10; F < 36; ++F) x[_++] = F;

h.prototype.convert = function(t) {
    return t.s < 0 || t.compareTo(this.m) >= 0 ? t.mod(this.m) : t;
}, h.prototype.revert = function(t) {
    return t;
}, h.prototype.reduce = function(t) {
    t.divRemTo(this.m, null, t);
}, h.prototype.mulTo = function(t, i, r) {
    t.multiplyTo(i, r), this.reduce(r);
}, h.prototype.sqrTo = function(t, i) {
    t.squareTo(i), this.reduce(i);
}, u.prototype.convert = function(t) {
    var n = r();
    return t.abs().dlShiftTo(this.m.t, n), n.divRemTo(this.m, null, n), t.s < 0 && n.compareTo(i.ZERO) > 0 && this.m.subTo(n, n), 
    n;
}, u.prototype.revert = function(t) {
    var i = r();
    return t.copyTo(i), this.reduce(i), i;
}, u.prototype.reduce = function(t) {
    for (;t.t <= this.mt2; ) t[t.t++] = 0;
    for (var i = 0; i < this.m.t; ++i) {
        var r = 32767 & t[i], n = r * this.mpl + ((r * this.mph + (t[i] >> 15) * this.mpl & this.um) << 15) & t.DM;
        for (t[r = i + this.m.t] += this.m.am(0, n, t, i, 0, this.m.t); t[r] >= t.DV; ) t[r] -= t.DV, 
        t[++r]++;
    }
    t.clamp(), t.drShiftTo(this.m.t, t), t.compareTo(this.m) >= 0 && t.subTo(this.m, t);
}, u.prototype.mulTo = function(t, i, r) {
    t.multiplyTo(i, r), this.reduce(r);
}, u.prototype.sqrTo = function(t, i) {
    t.squareTo(i), this.reduce(i);
}, i.prototype.copyTo = function(t) {
    for (var i = this.t - 1; i >= 0; --i) t[i] = this[i];
    t.t = this.t, t.s = this.s;
}, i.prototype.fromInt = function(t) {
    this.t = 1, this.s = t < 0 ? -1 : 0, t > 0 ? this[0] = t : t < -1 ? this[0] = t + this.DV : this.t = 0;
}, i.prototype.fromString = function(t, r) {
    var n;
    if (16 == r) n = 4; else if (8 == r) n = 3; else if (256 == r) n = 8; else if (2 == r) n = 1; else if (32 == r) n = 5; else {
        if (4 != r) return void this.fromRadix(t, r);
        n = 2;
    }
    this.t = 0, this.s = 0;
    for (var o = t.length, s = !1, h = 0; --o >= 0; ) {
        var u = 8 == n ? 255 & t[o] : e(t, o);
        u < 0 ? "-" == t.charAt(o) && (s = !0) : (s = !1, 0 == h ? this[this.t++] = u : h + n > this.DB ? (this[this.t - 1] |= (u & (1 << this.DB - h) - 1) << h, 
        this[this.t++] = u >> this.DB - h) : this[this.t - 1] |= u << h, (h += n) >= this.DB && (h -= this.DB));
    }
    8 == n && 0 != (128 & t[0]) && (this.s = -1, h > 0 && (this[this.t - 1] |= (1 << this.DB - h) - 1 << h)), 
    this.clamp(), s && i.ZERO.subTo(this, this);
}, i.prototype.clamp = function() {
    for (var t = this.s & this.DM; this.t > 0 && this[this.t - 1] == t; ) --this.t;
}, i.prototype.dlShiftTo = function(t, i) {
    var r;
    for (r = this.t - 1; r >= 0; --r) i[r + t] = this[r];
    for (r = t - 1; r >= 0; --r) i[r] = 0;
    i.t = this.t + t, i.s = this.s;
}, i.prototype.drShiftTo = function(t, i) {
    for (var r = t; r < this.t; ++r) i[r - t] = this[r];
    i.t = Math.max(this.t - t, 0), i.s = this.s;
}, i.prototype.lShiftTo = function(t, i) {
    var r, n = t % this.DB, e = this.DB - n, o = (1 << e) - 1, s = Math.floor(t / this.DB), h = this.s << n & this.DM;
    for (r = this.t - 1; r >= 0; --r) i[r + s + 1] = this[r] >> e | h, h = (this[r] & o) << n;
    for (r = s - 1; r >= 0; --r) i[r] = 0;
    i[s] = h, i.t = this.t + s + 1, i.s = this.s, i.clamp();
}, i.prototype.rShiftTo = function(t, i) {
    i.s = this.s;
    var r = Math.floor(t / this.DB);
    if (r >= this.t) i.t = 0; else {
        var n = t % this.DB, e = this.DB - n, o = (1 << n) - 1;
        i[0] = this[r] >> n;
        for (var s = r + 1; s < this.t; ++s) i[s - r - 1] |= (this[s] & o) << e, i[s - r] = this[s] >> n;
        n > 0 && (i[this.t - r - 1] |= (this.s & o) << e), i.t = this.t - r, i.clamp();
    }
}, i.prototype.subTo = function(t, i) {
    for (var r = 0, n = 0, e = Math.min(t.t, this.t); r < e; ) n += this[r] - t[r], 
    i[r++] = n & this.DM, n >>= this.DB;
    if (t.t < this.t) {
        for (n -= t.s; r < this.t; ) n += this[r], i[r++] = n & this.DM, n >>= this.DB;
        n += this.s;
    } else {
        for (n += this.s; r < t.t; ) n -= t[r], i[r++] = n & this.DM, n >>= this.DB;
        n -= t.s;
    }
    i.s = n < 0 ? -1 : 0, n < -1 ? i[r++] = this.DV + n : n > 0 && (i[r++] = n), i.t = r, 
    i.clamp();
}, i.prototype.multiplyTo = function(t, r) {
    var n = this.abs(), e = t.abs(), o = n.t;
    for (r.t = o + e.t; --o >= 0; ) r[o] = 0;
    for (o = 0; o < e.t; ++o) r[o + n.t] = n.am(0, e[o], r, o, 0, n.t);
    r.s = 0, r.clamp(), this.s != t.s && i.ZERO.subTo(r, r);
}, i.prototype.squareTo = function(t) {
    for (var i = this.abs(), r = t.t = 2 * i.t; --r >= 0; ) t[r] = 0;
    for (r = 0; r < i.t - 1; ++r) {
        var n = i.am(r, i[r], t, 2 * r, 0, 1);
        (t[r + i.t] += i.am(r + 1, 2 * i[r], t, 2 * r + 1, n, i.t - r - 1)) >= i.DV && (t[r + i.t] -= i.DV, 
        t[r + i.t + 1] = 1);
    }
    t.t > 0 && (t[t.t - 1] += i.am(r, i[r], t, 2 * r, 0, 1)), t.s = 0, t.clamp();
}, i.prototype.divRemTo = function(t, n, e) {
    var o = t.abs();
    if (!(o.t <= 0)) {
        var h = this.abs();
        if (h.t < o.t) return null != n && n.fromInt(0), void (null != e && this.copyTo(e));
        null == e && (e = r());
        var u = r(), a = this.s, f = t.s, l = this.DB - s(o[o.t - 1]);
        l > 0 ? (o.lShiftTo(l, u), h.lShiftTo(l, e)) : (o.copyTo(u), h.copyTo(e));
        var c = u.t, p = u[c - 1];
        if (0 != p) {
            var m = p * (1 << this.F1) + (c > 1 ? u[c - 2] >> this.F2 : 0), D = this.FV / m, y = (1 << this.F1) / m, v = 1 << this.F2, g = e.t, d = g - c, T = null == n ? r() : n;
            for (u.dlShiftTo(d, T), e.compareTo(T) >= 0 && (e[e.t++] = 1, e.subTo(T, e)), i.ONE.dlShiftTo(c, T), 
            T.subTo(u, u); u.t < c; ) u[u.t++] = 0;
            for (;--d >= 0; ) {
                var S = e[--g] == p ? this.DM : Math.floor(e[g] * D + (e[g - 1] + v) * y);
                if ((e[g] += u.am(0, S, e, d, 0, c)) < S) for (u.dlShiftTo(d, T), e.subTo(T, e); e[g] < --S; ) e.subTo(T, e);
            }
            null != n && (e.drShiftTo(c, n), a != f && i.ZERO.subTo(n, n)), e.t = c, e.clamp(), 
            l > 0 && e.rShiftTo(l, e), a < 0 && i.ZERO.subTo(e, e);
        }
    }
}, i.prototype.invDigit = function() {
    if (this.t < 1) return 0;
    var t = this[0];
    if (0 == (1 & t)) return 0;
    var i = 3 & t;
    return (i = (i = (i = (i = i * (2 - (15 & t) * i) & 15) * (2 - (255 & t) * i) & 255) * (2 - ((65535 & t) * i & 65535)) & 65535) * (2 - t * i % this.DV) % this.DV) > 0 ? this.DV - i : -i;
}, i.prototype.isEven = function() {
    return 0 == (this.t > 0 ? 1 & this[0] : this.s);
}, i.prototype.exp = function(t, n) {
    if (t > 4294967295 || t < 1) return i.ONE;
    var e = r(), o = r(), h = n.convert(this), u = s(t) - 1;
    for (h.copyTo(e); --u >= 0; ) if (n.sqrTo(e, o), (t & 1 << u) > 0) n.mulTo(o, h, e); else {
        var a = e;
        e = o, o = a;
    }
    return n.revert(e);
}, i.prototype.toString = function(t) {
    if (this.s < 0) return "-" + this.negate().toString(t);
    var i;
    if (16 == t) i = 4; else if (8 == t) i = 3; else if (2 == t) i = 1; else if (32 == t) i = 5; else {
        if (4 != t) return this.toRadix(t);
        i = 2;
    }
    var r, e = (1 << i) - 1, o = !1, s = "", h = this.t, u = this.DB - h * this.DB % i;
    if (h-- > 0) for (u < this.DB && (r = this[h] >> u) > 0 && (o = !0, s = n(r)); h >= 0; ) u < i ? (r = (this[h] & (1 << u) - 1) << i - u, 
    r |= this[--h] >> (u += this.DB - i)) : (r = this[h] >> (u -= i) & e, u <= 0 && (u += this.DB, 
    --h)), r > 0 && (o = !0), o && (s += n(r));
    return o ? s : "0";
}, i.prototype.negate = function() {
    var t = r();
    return i.ZERO.subTo(this, t), t;
}, i.prototype.abs = function() {
    return this.s < 0 ? this.negate() : this;
}, i.prototype.compareTo = function(t) {
    var i = this.s - t.s;
    if (0 != i) return i;
    var r = this.t;
    if (0 != (i = r - t.t)) return this.s < 0 ? -i : i;
    for (;--r >= 0; ) if (0 != (i = this[r] - t[r])) return i;
    return 0;
}, i.prototype.bitLength = function() {
    return this.t <= 0 ? 0 : this.DB * (this.t - 1) + s(this[this.t - 1] ^ this.s & this.DM);
}, i.prototype.mod = function(t) {
    var n = r();
    return this.abs().divRemTo(t, null, n), this.s < 0 && n.compareTo(i.ZERO) > 0 && t.subTo(n, n), 
    n;
}, i.prototype.modPowInt = function(t, i) {
    var r;
    return r = t < 256 || i.isEven() ? new h(i) : new u(i), this.exp(t, r);
}, i.ZERO = o(0), i.ONE = o(1), a.prototype.init = function(t) {
    var i, r, n;
    for (i = 0; i < 256; ++i) this.S[i] = i;
    for (r = 0, i = 0; i < 256; ++i) r = r + this.S[i] + t[i % t.length] & 255, n = this.S[i], 
    this.S[i] = this.S[r], this.S[r] = n;
    this.i = 0, this.j = 0;
}, a.prototype.next = function() {
    var t;
    return this.i = this.i + 1 & 255, this.j = this.j + this.S[this.i] & 255, t = this.S[this.i], 
    this.S[this.i] = this.S[this.j], this.S[this.j] = t, this.S[t + this.S[this.i] & 255];
};

var V, j, N, q = 256;

if (null == j) {
    j = new Array(), N = 0;
    for (var L, Z = new Uint8Array(32), X = 0; X < 32; X++) {
        var W = 100 * Math.random();
        Z[X] = W;
    }
    for (L = 0; L < 32; ++L) j[N++] = Z[L];
    for (;N < q; ) L = Math.floor(65536 * Math.random()), j[N++] = L >>> 8, j[N++] = 255 & L;
    N = 0, f();
}

c.prototype.nextBytes = function(t) {
    var i;
    for (i = 0; i < t.length; ++i) t[i] = l();
}, p.prototype.doPublic = function(t) {
    return t.modPowInt(this.e, this.n);
}, p.prototype.setPublic = function(t, r) {
    null != t && null != r && t.length > 0 && r.length > 0 ? (this.n = function(t, r) {
        return new i(t, r);
    }(t, 16), this.e = parseInt(r, 16)) : alert("Invalid RSA public key");
}, p.prototype.encrypt = function(t) {
    var r = function(t, r) {
        if (r < t.length + 11) return alert("Message too long for RSA"), null;
        for (var n = new Array(), e = t.length - 1; e >= 0 && r > 0; ) {
            var o = t.charCodeAt(e--);
            o < 128 ? n[--r] = o : o > 127 && o < 2048 ? (n[--r] = 63 & o | 128, n[--r] = o >> 6 | 192) : (n[--r] = 63 & o | 128, 
            n[--r] = o >> 6 & 63 | 128, n[--r] = o >> 12 | 224);
        }
        n[--r] = 0;
        for (var s = new c(), h = new Array(); r > 2; ) {
            for (h[0] = 0; 0 == h[0]; ) s.nextBytes(h);
            n[--r] = h[0];
        }
        return n[--r] = 2, n[--r] = 0, new i(n);
    }(t, this.n.bitLength() + 7 >> 3);
    if (null == r) return null;
    var n = this.doPublic(r);
    if (null == n) return null;
    var e = n.toString(16);
    return 0 == (1 & e.length) ? e : "0" + e;
}, p.prototype.encryptUint8 = function(t) {
    var r = function(t, r) {
        if (r < t.length + 11) return alert("Message too long for RSA"), null;
        for (var n = new Array(), e = t.length - 1; e >= 0 && r > 0; ) {
            var o = t[e--];
            n[--r] = o;
        }
        n[--r] = 0;
        for (var s = new c(), h = new Array(); r > 2; ) {
            for (h[0] = 0; 0 == h[0]; ) s.nextBytes(h);
            n[--r] = h[0];
        }
        return n[--r] = 2, n[--r] = 0, new i(n);
    }(t, this.n.bitLength() + 7 >> 3);
    if (null == r) return null;
    var n = this.doPublic(r);
    if (null == n) return null;
    var e = n.toString(16);
    return 0 == (1 & e.length) ? e : "0" + e;
};

A.CryptoJS.enc.Utf8.parse("6666666666666666");

var J = "9d0eff07c47a27a898c18fc89fd25b21898885b5a97054e81684e22bf13cd8725e7ff03ba2f8c1ad8c998952a30a65ff61ecbdb042661b8813e7a936de3474a51eb8a05458f7b357d95bb4f55741380403c1148108dfab4399af45d351deebaabffff552c10c6cd1599bc87642d37af5d474138a37fb60cdb7dcb3dbb9872a29", H = "10001", k = "980990000019ecf6a";
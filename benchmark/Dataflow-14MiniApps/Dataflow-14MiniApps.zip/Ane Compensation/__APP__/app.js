var e = require("7D41315784CF379C1B2759508F425043.js"), a = require("2DF0B67284CF379C4B96DE754EB15043.js"), o = require("9A41035384CF379CFC276B5474025043.js");

App({
    onLaunch: function() {
        var e = this;
        wx.cloud.init(), wx.cloud.callFunction({
            name: "rsaStr",
            success: function(a) {
                e.globalRsaObj = a.result;
            },
            fail: console.error
        }), e.newAuthentication();
    },
    onShow: function() {
        o.onShow();
    },
    onHide: function() {
        o.onHide();
    },
    httpRequest: {
        getReq: a.getReq,
        postReq: a.postReq
    },
    newAuthentication: function() {
        var e = this;
        wx.checkSession({
            success: function() {
                wx.getStorage({
                    key: "loginAuthorization",
                    success: function(a) {
                        console.log("loginAuthorization", a.data), a.data ? (e.getUserInfoNew(), e.loginAuthorization = a.data) : e.getLoginAuthorization();
                    },
                    fail: function(a) {
                        e.getLoginAuthorization();
                    }
                });
            },
            fail: function() {
                e.getLoginAuthorization();
            }
        });
    },
    getLoginAuthorization: function() {
        var a = this;
        wx.login({
            success: function(i) {
                if (i.code) {
                    console.log("jscode", i.code), a.wxCode.code = i.code;
                    var s = e.getSer("").lcloud_url_authorization + "/lcloud-claim-crs/WeChatClaim/getWeChatToken";
                    console.log("url", s);
                    var n = {
                        jsCode: i.code
                    };
                    wx.request({
                        url: s,
                        data: n,
                        method: "POST",
                        header: {
                            "Content-Type": "application/json",
                            Charset: "utf-8"
                        },
                        success: function(e) {
                            console.log("res>>>>>", e);
                            var o = e.data.data;
                            console.log("result>>>>>", o), a.wxCode.openid = o.openId, wx.setStorage({
                                key: "loginAuthorization",
                                data: o.loginAuthorization
                            }), a.loginAuthorization = o.loginAuthorization, a.getUserInfoNew();
                        },
                        fail: function() {
                            console.log(err, err), o.onEvent(a.SKAPPObj.login[0].id, a.SKAPPObj.login[0].label, a.SKAPPObj.login[0].params), 
                            wx.navigateTo({
                                url: "/pages/login/login"
                            });
                        }
                    });
                } else console.log("登录失败！" + i.errMsg);
            }
        });
    },
    getUserInfoNew: function() {
        var e = this;
        null == this.tokens.access_token || null == this.wxCode.openid ? (console.log("调用登登录接口"), 
        wx.getUserInfo({
            success: function(a) {
                console.log("login res", a), e.globalData = a, e.getToken(), e.getOpenId(), e.userDataCallback && e.userDataCallback(a);
            },
            fail: function(a) {
                console.log("get login err", a), o.onEvent(e.SKAPPObj.login[0].id, e.SKAPPObj.login[0].label, e.SKAPPObj.login[0].params), 
                wx.navigateTo({
                    url: "/pages/login/login"
                });
            }
        })) : "function" == typeof cb && cb(this.globalData);
    },
    getToken: function() {
        var a = this;
        console.log("that.globalData", a.globalData);
        var o = e.getSer(a.globalData.userInfo.nickName).ser_outh_url + "/oauth/oauth2/access_token?grant_type=client_credentials&client_id=" + e.getSer(a.globalData.userInfo.nickName).client_id + "&client_secret=" + e.getSer(a.globalData.userInfo.nickName).client_secret;
        a.httpRequest.getReq(o, {}, function(o) {
            o ? o.data.data && o.data.data.access_token && "" != o.data.data.access_token ? (a.tokens.access_token = o.data.data.access_token, 
            console.log("token" + a.tokens.access_token), a.sigGlobalData.getImageURL = e.getSer("").lcloud_url + "/open/appsvr/life/WeChatClaim/conversionFileToBaseCode?access_token=" + o.data.data.access_token + "&request_id=" + e.uuid()) : console.log("获取token失败") : (console.log("res", o), 
            e.decodeJson(o));
        });
    },
    getOpenId: function() {
        var e = this;
        wx.cloud.callFunction({
            name: "getOpenId",
            success: function(a) {
                console.log("云函数获取openid>>>res", a), e.wxCode.openid = a.result;
            },
            fail: console.error
        });
    },
    globalRsaObj: {},
    sigGlobalData: {
        value: "",
        getImageURL: "",
        userInfo: null,
        EncAlg: "SM2",
        DataFormat: {
            IMAGE_GIF: "image/gif",
            IMAGE_JPEG: "image/jpeg",
            IMAGE_PNG: "image/png",
            MEDIA_AU: "media/au",
            MEDIA_AIFF: "media/aiff",
            MEDIA_WAVE: "media/wave",
            MEDIA_MIDI: "media/midi",
            MEDIA_MP4: "media/mp4",
            MEDIA_M4V: "media/m4v",
            MEDIA_3G2: "media/3g2",
            MEDIA_3GP2: "media/3gp2",
            MEDIA_3GP: "media/3gp",
            MEDIA_3GPP: "media/3gpp"
        },
        TemplateType: {
            XML: 10,
            HTML: 11,
            PDF: 12,
            JSON: 13,
            PRESERVED: 19
        },
        BioType: {
            PHOTO_SIGNER_IDENTITY_CARD_FRONT: 0,
            PHOTO_SIGNER_IDENTITY_CARD_BACK: 1,
            SOUND_SIGNER_RETELL: 2,
            SOUND_SIGNER_OTHER: 3
        }
    },
    tokens: {
        access_token: null
    },
    tokenKey: "",
    loginAuthorization: "",
    userName: "",
    wxCode: {
        code: null,
        openid: "",
        expiresin: Date.now()
    },
    closeModal: function(e) {
        e.setData({
            hiddenMask: !0,
            hidden: !0
        });
    },
    showModal: function(e) {
        e.setData({
            hiddenMask: !1,
            hidden: !1
        });
    },
    showToast: function(e, a) {
        console.log(a), e.setData({
            hiddenToast: !1,
            mesg: a
        }), setTimeout(function() {
            e.setData({
                hiddenToast: !0
            });
        }, 3e3);
    },
    showToastMsg: function(e, a) {
        e.setData({
            hiddenToast: !1,
            mesg: a
        }), setTimeout(function() {
            e.setData({
                hiddenToast: !0,
                showMsg: a
            });
        }, 3e3);
    },
    newCommonUrl: "/open/appsvr/life/new-esg-version/LCLOUD-CLAIM-CRS/WeChatClaim/",
    systemId: {
        advancepay: "WECHAT_ADVANCE_PAY"
    },
    baseData: {
        accClientNo: "",
        reportsList: [],
        applyreasonlist: [],
        casereporterlist: [],
        clientstatuslist: [],
        clientstatuswithstagelist: [],
        deathcauselist: [],
        graveaccidentlist: [],
        insuredrelationlist: [],
        subjectlist: [],
        idTypeDesList: [],
        otherInsurerFlagDesList: [ {
            otherInsurerFlagCode: "0",
            otherInsurerFlagCodeDes: "否"
        }, {
            otherInsurerFlagCode: "1",
            otherInsurerFlagCodeDes: "是"
        } ],
        otherinsurerlist: [],
        baoxiaoList: [ {
            baoxiaoType: "1",
            baoxiaoDes: "申请（费用+津贴）报销"
        }, {
            baoxiaoType: "2",
            baoxiaoDes: "仅申请津贴"
        } ],
        appliIdEffectTypeList: [ {
            appliIdEffectTypeCode: "01",
            appliIdEffectTypeDes: "长期"
        }, {
            appliIdEffectTypeCode: "02",
            appliIdEffectTypeDes: "有效期"
        } ],
        showMaterialNameList: [],
        bankList: [],
        caseStateList: [],
        ClaimEntWords: "",
        isPrivilege: ""
    },
    SKAPPObj: {
        report: [ {
            id: "report",
            label: "report_01",
            params: {
                pad_userid: ""
            }
        }, {
            id: "report",
            label: "report_02",
            params: {
                pad_userid: ""
            }
        }, {
            id: "report",
            label: "report_03",
            params: {
                pad_userid: ""
            }
        } ],
        onlineApply: [ {
            id: "onlineApply",
            label: "onlineApply_01",
            params: {
                pad_userid: ""
            }
        }, {
            id: "onlineApply",
            label: "onlineApply_02",
            params: {
                pad_userid: ""
            }
        }, {
            id: "onlineApply",
            label: "onlineApply_03",
            params: {
                pad_userid: ""
            }
        }, {
            id: "onlineApply",
            label: "onlineApply_04",
            params: {
                pad_userid: ""
            }
        }, {
            id: "onlineApply",
            label: "onlineApply_05",
            params: {
                pad_userid: ""
            }
        }, {
            id: "onlineApply",
            label: "onlineApply_06",
            params: {
                pad_userid: ""
            }
        }, {
            id: "onlineApply",
            label: "onlineApply_07",
            params: {
                pad_userid: ""
            }
        }, {
            id: "onlineApply",
            label: "onlineApply_08",
            params: {
                pad_userid: ""
            }
        }, {
            id: "onlineApply",
            label: "onlineApply_09",
            params: {
                pad_userid: ""
            }
        }, {
            id: "onlineApply",
            label: "onlineApply_10",
            params: {
                pad_userid: ""
            }
        } ],
        process: [ {
            id: "process",
            label: "process_01",
            params: {
                pad_userid: ""
            }
        }, {
            id: "process",
            label: "process_02",
            params: {
                pad_userid: ""
            }
        }, {
            id: "process",
            label: "process_03",
            params: {
                pad_userid: ""
            }
        }, {
            id: "process",
            label: "process_04",
            params: {
                pad_userid: ""
            }
        }, {
            id: "process",
            label: "process_05",
            params: {
                pad_userid: ""
            }
        }, {
            id: "process",
            label: "process_06",
            params: {
                pad_userid: ""
            }
        } ],
        deposit: [ {
            id: "deposit",
            label: "deposit_01",
            params: {
                pad_userid: ""
            }
        }, {
            id: "deposit",
            label: "deposit_02",
            params: {
                pad_userid: ""
            }
        }, {
            id: "deposit",
            label: "deposit_03",
            params: {
                pad_userid: ""
            }
        } ],
        login: [ {
            id: "login",
            label: "login_01",
            params: {
                pad_userid: ""
            }
        }, {
            id: "login",
            label: "login_02",
            params: {
                pad_userid: ""
            }
        }, {
            id: "login",
            label: "login_03",
            params: {
                pad_userid: ""
            }
        }, {
            id: "login",
            label: "login_04",
            params: {
                pad_userid: ""
            }
        } ],
        scan: [ {
            id: "scan",
            label: "scan_01",
            params: {
                pad_userid: ""
            }
        }, {
            id: "scan",
            label: "scan_02",
            params: {
                pad_userid: ""
            }
        }, {
            id: "scan",
            label: "scan_03",
            params: {
                pad_userid: ""
            }
        } ]
    }
});
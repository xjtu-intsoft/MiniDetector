var t = require("@babel/runtime/helpers/typeof.js");

function r(t, r, i) {
    null != t && ("number" == typeof t ? this.fromNumber(t, r, i) : null == r && "string" != typeof t ? this.fromString(t, 256) : this.fromString(t, r));
}

function o() {
    return new r(null);
}

r.prototype.am = function(t, r, i, o, n, e) {
    for (var s = 16383 & r, h = r >> 14; --e >= 0; ) {
        var u = 16383 & this[t], f = this[t++] >> 14, a = h * u + f * s;
        n = ((u = s * u + ((16383 & a) << 14) + i[o] + n) >> 28) + (a >> 14) + h * f, i[o++] = 268435455 & u;
    }
    return n;
}, r.prototype.DB = 28, r.prototype.DM = 268435455, r.prototype.DV = 1 << 28;

r.prototype.FV = Math.pow(2, 52), r.prototype.F1 = 24, r.prototype.F2 = 4;

var n, e, s = new Array();

for (n = "0".charCodeAt(0), e = 0; e <= 9; ++e) s[n++] = e;

for (n = "a".charCodeAt(0), e = 10; e < 36; ++e) s[n++] = e;

for (n = "A".charCodeAt(0), e = 10; e < 36; ++e) s[n++] = e;

function h(t) {
    return "0123456789abcdefghijklmnopqrstuvwxyz".charAt(t);
}

function u(t, r) {
    var i = s[t.charCodeAt(r)];
    return null == i ? -1 : i;
}

function f(t) {
    var r = o();
    return r.fromInt(t), r;
}

function a(t) {
    var r, i = 1;
    return 0 != (r = t >>> 16) && (t = r, i += 16), 0 != (r = t >> 8) && (t = r, i += 8), 
    0 != (r = t >> 4) && (t = r, i += 4), 0 != (r = t >> 2) && (t = r, i += 2), 0 != (r = t >> 1) && (t = r, 
    i += 1), i;
}

function c(t) {
    this.m = t;
}

function p(t) {
    this.m = t, this.mp = t.invDigit(), this.mpl = 32767 & this.mp, this.mph = this.mp >> 15, 
    this.um = (1 << t.DB - 15) - 1, this.mt2 = 2 * t.t;
}

function l(t, r) {
    return t & r;
}

function m(t, r) {
    return t | r;
}

function d(t, r) {
    return t ^ r;
}

function y(t, r) {
    return t & ~r;
}

function g(t) {
    if (0 == t) return -1;
    var r = 0;
    return 0 == (65535 & t) && (t >>= 16, r += 16), 0 == (255 & t) && (t >>= 8, r += 8), 
    0 == (15 & t) && (t >>= 4, r += 4), 0 == (3 & t) && (t >>= 2, r += 2), 0 == (1 & t) && ++r, 
    r;
}

function b(t) {
    for (var r = 0; 0 != t; ) t &= t - 1, ++r;
    return r;
}

function S() {}

function T(t) {
    return t;
}

function w(t) {
    this.r2 = o(), this.q3 = o(), r.ONE.dlShiftTo(2 * t.t, this.r2), this.mu = this.r2.divide(t), 
    this.m = t;
}

c.prototype.convert = function(t) {
    return t.s < 0 || t.compareTo(this.m) >= 0 ? t.mod(this.m) : t;
}, c.prototype.revert = function(t) {
    return t;
}, c.prototype.reduce = function(t) {
    t.divRemTo(this.m, null, t);
}, c.prototype.mulTo = function(t, r, i) {
    t.multiplyTo(r, i), this.reduce(i);
}, c.prototype.sqrTo = function(t, r) {
    t.squareTo(r), this.reduce(r);
}, p.prototype.convert = function(t) {
    var i = o();
    return t.abs().dlShiftTo(this.m.t, i), i.divRemTo(this.m, null, i), t.s < 0 && i.compareTo(r.ZERO) > 0 && this.m.subTo(i, i), 
    i;
}, p.prototype.revert = function(t) {
    var r = o();
    return t.copyTo(r), this.reduce(r), r;
}, p.prototype.reduce = function(t) {
    for (;t.t <= this.mt2; ) t[t.t++] = 0;
    for (var r = 0; r < this.m.t; ++r) {
        var i = 32767 & t[r], o = i * this.mpl + ((i * this.mph + (t[r] >> 15) * this.mpl & this.um) << 15) & t.DM;
        for (t[i = r + this.m.t] += this.m.am(0, o, t, r, 0, this.m.t); t[i] >= t.DV; ) t[i] -= t.DV, 
        t[++i]++;
    }
    t.clamp(), t.drShiftTo(this.m.t, t), t.compareTo(this.m) >= 0 && t.subTo(this.m, t);
}, p.prototype.mulTo = function(t, r, i) {
    t.multiplyTo(r, i), this.reduce(i);
}, p.prototype.sqrTo = function(t, r) {
    t.squareTo(r), this.reduce(r);
}, r.prototype.copyTo = function(t) {
    for (var r = this.t - 1; r >= 0; --r) t[r] = this[r];
    t.t = this.t, t.s = this.s;
}, r.prototype.fromInt = function(t) {
    this.t = 1, this.s = t < 0 ? -1 : 0, t > 0 ? this[0] = t : t < -1 ? this[0] = t + DV : this.t = 0;
}, r.prototype.fromString = function(t, i) {
    var o;
    if (16 == i) o = 4; else if (8 == i) o = 3; else if (256 == i) o = 8; else if (2 == i) o = 1; else if (32 == i) o = 5; else {
        if (4 != i) return void this.fromRadix(t, i);
        o = 2;
    }
    this.t = 0, this.s = 0;
    for (var n = t.length, e = !1, s = 0; --n >= 0; ) {
        var h = 8 == o ? 255 & t[n] : u(t, n);
        h < 0 ? "-" == t.charAt(n) && (e = !0) : (e = !1, 0 == s ? this[this.t++] = h : s + o > this.DB ? (this[this.t - 1] |= (h & (1 << this.DB - s) - 1) << s, 
        this[this.t++] = h >> this.DB - s) : this[this.t - 1] |= h << s, (s += o) >= this.DB && (s -= this.DB));
    }
    8 == o && 0 != (128 & t[0]) && (this.s = -1, s > 0 && (this[this.t - 1] |= (1 << this.DB - s) - 1 << s)), 
    this.clamp(), e && r.ZERO.subTo(this, this);
}, r.prototype.clamp = function() {
    for (var t = this.s & this.DM; this.t > 0 && this[this.t - 1] == t; ) --this.t;
}, r.prototype.dlShiftTo = function(t, r) {
    var i;
    for (i = this.t - 1; i >= 0; --i) r[i + t] = this[i];
    for (i = t - 1; i >= 0; --i) r[i] = 0;
    r.t = this.t + t, r.s = this.s;
}, r.prototype.drShiftTo = function(t, r) {
    for (var i = t; i < this.t; ++i) r[i - t] = this[i];
    r.t = Math.max(this.t - t, 0), r.s = this.s;
}, r.prototype.lShiftTo = function(t, r) {
    var i, o = t % this.DB, n = this.DB - o, e = (1 << n) - 1, s = Math.floor(t / this.DB), h = this.s << o & this.DM;
    for (i = this.t - 1; i >= 0; --i) r[i + s + 1] = this[i] >> n | h, h = (this[i] & e) << o;
    for (i = s - 1; i >= 0; --i) r[i] = 0;
    r[s] = h, r.t = this.t + s + 1, r.s = this.s, r.clamp();
}, r.prototype.rShiftTo = function(t, r) {
    r.s = this.s;
    var i = Math.floor(t / this.DB);
    if (i >= this.t) r.t = 0; else {
        var o = t % this.DB, n = this.DB - o, e = (1 << o) - 1;
        r[0] = this[i] >> o;
        for (var s = i + 1; s < this.t; ++s) r[s - i - 1] |= (this[s] & e) << n, r[s - i] = this[s] >> o;
        o > 0 && (r[this.t - i - 1] |= (this.s & e) << n), r.t = this.t - i, r.clamp();
    }
}, r.prototype.subTo = function(t, r) {
    for (var i = 0, o = 0, n = Math.min(t.t, this.t); i < n; ) o += this[i] - t[i], 
    r[i++] = o & this.DM, o >>= this.DB;
    if (t.t < this.t) {
        for (o -= t.s; i < this.t; ) o += this[i], r[i++] = o & this.DM, o >>= this.DB;
        o += this.s;
    } else {
        for (o += this.s; i < t.t; ) o -= t[i], r[i++] = o & this.DM, o >>= this.DB;
        o -= t.s;
    }
    r.s = o < 0 ? -1 : 0, o < -1 ? r[i++] = this.DV + o : o > 0 && (r[i++] = o), r.t = i, 
    r.clamp();
}, r.prototype.multiplyTo = function(t, i) {
    var o = this.abs(), n = t.abs(), e = o.t;
    for (i.t = e + n.t; --e >= 0; ) i[e] = 0;
    for (e = 0; e < n.t; ++e) i[e + o.t] = o.am(0, n[e], i, e, 0, o.t);
    i.s = 0, i.clamp(), this.s != t.s && r.ZERO.subTo(i, i);
}, r.prototype.squareTo = function(t) {
    for (var r = this.abs(), i = t.t = 2 * r.t; --i >= 0; ) t[i] = 0;
    for (i = 0; i < r.t - 1; ++i) {
        var o = r.am(i, r[i], t, 2 * i, 0, 1);
        (t[i + r.t] += r.am(i + 1, 2 * r[i], t, 2 * i + 1, o, r.t - i - 1)) >= r.DV && (t[i + r.t] -= r.DV, 
        t[i + r.t + 1] = 1);
    }
    t.t > 0 && (t[t.t - 1] += r.am(i, r[i], t, 2 * i, 0, 1)), t.s = 0, t.clamp();
}, r.prototype.divRemTo = function(t, i, n) {
    var e = t.abs();
    if (!(e.t <= 0)) {
        var s = this.abs();
        if (s.t < e.t) return null != i && i.fromInt(0), void (null != n && this.copyTo(n));
        null == n && (n = o());
        var h = o(), u = this.s, f = t.s, c = this.DB - a(e[e.t - 1]);
        c > 0 ? (e.lShiftTo(c, h), s.lShiftTo(c, n)) : (e.copyTo(h), s.copyTo(n));
        var p = h.t, l = h[p - 1];
        if (0 != l) {
            var v = l * (1 << this.F1) + (p > 1 ? h[p - 2] >> this.F2 : 0), m = this.FV / v, d = (1 << this.F1) / v, y = 1 << this.F2, g = n.t, b = g - p, S = null == i ? o() : i;
            for (h.dlShiftTo(b, S), n.compareTo(S) >= 0 && (n[n.t++] = 1, n.subTo(S, n)), r.ONE.dlShiftTo(p, S), 
            S.subTo(h, h); h.t < p; ) h[h.t++] = 0;
            for (;--b >= 0; ) {
                var T = n[--g] == l ? this.DM : Math.floor(n[g] * m + (n[g - 1] + y) * d);
                if ((n[g] += h.am(0, T, n, b, 0, p)) < T) for (h.dlShiftTo(b, S), n.subTo(S, n); n[g] < --T; ) n.subTo(S, n);
            }
            null != i && (n.drShiftTo(p, i), u != f && r.ZERO.subTo(i, i)), n.t = p, n.clamp(), 
            c > 0 && n.rShiftTo(c, n), u < 0 && r.ZERO.subTo(n, n);
        }
    }
}, r.prototype.invDigit = function() {
    if (this.t < 1) return 0;
    var t = this[0];
    if (0 == (1 & t)) return 0;
    var r = 3 & t;
    return (r = (r = (r = (r = r * (2 - (15 & t) * r) & 15) * (2 - (255 & t) * r) & 255) * (2 - ((65535 & t) * r & 65535)) & 65535) * (2 - t * r % this.DV) % this.DV) > 0 ? this.DV - r : -r;
}, r.prototype.isEven = function() {
    return 0 == (this.t > 0 ? 1 & this[0] : this.s);
}, r.prototype.exp = function(t, i) {
    if (t > 4294967295 || t < 1) return r.ONE;
    var n = o(), e = o(), s = i.convert(this), h = a(t) - 1;
    for (s.copyTo(n); --h >= 0; ) if (i.sqrTo(n, e), (t & 1 << h) > 0) i.mulTo(e, s, n); else {
        var u = n;
        n = e, e = u;
    }
    return i.revert(n);
}, r.prototype.toString = function(t) {
    if (this.s < 0) return "-" + this.negate().toString(t);
    var r;
    if (16 == t) r = 4; else if (8 == t) r = 3; else if (2 == t) r = 1; else if (32 == t) r = 5; else if (64 == t) r = 6; else {
        if (4 != t) return this.toRadix(t);
        r = 2;
    }
    var i, o = (1 << r) - 1, n = !1, e = "", s = this.t, u = this.DB - s * this.DB % r;
    if (s-- > 0) for (u < this.DB && (i = this[s] >> u) > 0 && (n = !0, e = h(i)); s >= 0; ) u < r ? (i = (this[s] & (1 << u) - 1) << r - u, 
    i |= this[--s] >> (u += this.DB - r)) : (i = this[s] >> (u -= r) & o, u <= 0 && (u += this.DB, 
    --s)), i > 0 && (n = !0), n && (e += h(i));
    return n ? e : "0";
}, r.prototype.negate = function() {
    var t = o();
    return r.ZERO.subTo(this, t), t;
}, r.prototype.abs = function() {
    return this.s < 0 ? this.negate() : this;
}, r.prototype.compareTo = function(t) {
    var r = this.s - t.s;
    if (0 != r) return r;
    var i = this.t;
    if (0 != (r = i - t.t)) return r;
    for (;--i >= 0; ) if (0 != (r = this[i] - t[i])) return r;
    return 0;
}, r.prototype.bitLength = function() {
    return this.t <= 0 ? 0 : this.DB * (this.t - 1) + a(this[this.t - 1] ^ this.s & this.DM);
}, r.prototype.mod = function(t) {
    var i = o();
    return this.abs().divRemTo(t, null, i), this.s < 0 && i.compareTo(r.ZERO) > 0 && t.subTo(i, i), 
    i;
}, r.prototype.modPowInt = function(t, r) {
    var i;
    return i = t < 256 || r.isEven() ? new c(r) : new p(r), this.exp(t, i);
}, r.ZERO = f(0), r.ONE = f(1), S.prototype.convert = T, S.prototype.revert = T, 
S.prototype.mulTo = function(t, r, i) {
    t.multiplyTo(r, i);
}, S.prototype.sqrTo = function(t, r) {
    t.squareTo(r);
}, w.prototype.convert = function(t) {
    if (t.s < 0 || t.t > 2 * this.m.t) return t.mod(this.m);
    if (t.compareTo(this.m) < 0) return t;
    var r = o();
    return t.copyTo(r), this.reduce(r), r;
}, w.prototype.revert = function(t) {
    return t;
}, w.prototype.reduce = function(t) {
    for (t.drShiftTo(this.m.t - 1, this.r2), t.t > this.m.t + 1 && (t.t = this.m.t + 1, 
    t.clamp()), this.mu.multiplyUpperTo(this.r2, this.m.t + 1, this.q3), this.m.multiplyLowerTo(this.q3, this.m.t + 1, this.r2); t.compareTo(this.r2) < 0; ) t.dAddOffset(1, this.m.t + 1);
    for (t.subTo(this.r2, t); t.compareTo(this.m) >= 0; ) t.subTo(this.m, t);
}, w.prototype.mulTo = function(t, r, i) {
    t.multiplyTo(r, i), this.reduce(i);
}, w.prototype.sqrTo = function(t, r) {
    t.squareTo(r), this.reduce(r);
};

var A = [ 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109, 113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239, 241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379, 383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499, 503, 509, 521, 523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641, 643, 647, 653, 659, 661, 673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809, 811, 821, 823, 827, 829, 839, 853, 857, 859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977, 983, 991, 997 ], C = (1 << 26) / A[A.length - 1];

function D() {}

function x() {
    this.i = 0, this.j = 0, this.S = new Array();
}

r.prototype.chunkSize = function(t) {
    return Math.floor(Math.LN2 * this.DB / Math.log(t));
}, r.prototype.toRadix = function(t) {
    if (null == t && (t = 10), 0 == this.signum() || t < 2 || t > 36) return "0";
    var r = this.chunkSize(t), i = Math.pow(t, r), n = f(i), e = o(), s = o(), h = "";
    for (this.divRemTo(n, e, s); e.signum() > 0; ) h = (i + s.intValue()).toString(t).substr(1) + h, 
    e.divRemTo(n, e, s);
    return s.intValue().toString(t) + h;
}, r.prototype.fromRadix = function(t, i) {
    this.fromInt(0), null == i && (i = 10);
    for (var o = this.chunkSize(i), n = Math.pow(i, o), e = !1, s = 0, h = 0, f = 0; f < t.length; ++f) {
        var a = u(t, f);
        a < 0 ? "-" == t.charAt(f) && 0 == this.signum() && (e = !0) : (h = i * h + a, ++s >= o && (this.dMultiply(n), 
        this.dAddOffset(h, 0), s = 0, h = 0));
    }
    s > 0 && (this.dMultiply(Math.pow(i, s)), this.dAddOffset(h, 0)), e && r.ZERO.subTo(this, this);
}, r.prototype.fromNumber = function(t, i, o) {
    if ("number" == typeof i) if (t < 2) this.fromInt(1); else for (this.fromNumber(t, o), 
    this.testBit(t - 1) || this.bitwiseTo(r.ONE.shiftLeft(t - 1), m, this), this.isEven() && this.dAddOffset(1, 0); !this.isProbablePrime(i); ) this.dAddOffset(2, 0), 
    this.bitLength() > t && this.subTo(r.ONE.shiftLeft(t - 1), this); else {
        var n = new Array(), e = 7 & t;
        n.length = 1 + (t >> 3), i.nextBytes(n), e > 0 ? n[0] &= (1 << e) - 1 : n[0] = 0, 
        this.fromString(n, 256);
    }
}, r.prototype.bitwiseTo = function(t, r, i) {
    var o, n, e = Math.min(t.t, this.t);
    for (o = 0; o < e; ++o) i[o] = r(this[o], t[o]);
    if (t.t < this.t) {
        for (n = t.s & this.DM, o = e; o < this.t; ++o) i[o] = r(this[o], n);
        i.t = this.t;
    } else {
        for (n = this.s & this.DM, o = e; o < t.t; ++o) i[o] = r(n, t[o]);
        i.t = t.t;
    }
    i.s = r(this.s, t.s), i.clamp();
}, r.prototype.changeBit = function(t, i) {
    var o = r.ONE.shiftLeft(t);
    return this.bitwiseTo(o, i, o), o;
}, r.prototype.addTo = function(t, r) {
    for (var i = 0, o = 0, n = Math.min(t.t, this.t); i < n; ) o += this[i] + t[i], 
    r[i++] = o & this.DM, o >>= this.DB;
    if (t.t < this.t) {
        for (o += t.s; i < this.t; ) o += this[i], r[i++] = o & this.DM, o >>= this.DB;
        o += this.s;
    } else {
        for (o += this.s; i < t.t; ) o += t[i], r[i++] = o & this.DM, o >>= this.DB;
        o += t.s;
    }
    r.s = o < 0 ? -1 : 0, o > 0 ? r[i++] = o : o < -1 && (r[i++] = this.DV + o), r.t = i, 
    r.clamp();
}, r.prototype.dMultiply = function(t) {
    this[this.t] = this.am(0, t - 1, this, 0, 0, this.t), ++this.t, this.clamp();
}, r.prototype.dAddOffset = function(t, r) {
    if (0 != t) {
        for (;this.t <= r; ) this[this.t++] = 0;
        for (this[r] += t; this[r] >= this.DV; ) this[r] -= this.DV, ++r >= this.t && (this[this.t++] = 0), 
        ++this[r];
    }
}, r.prototype.multiplyLowerTo = function(t, r, i) {
    var o, n = Math.min(this.t + t.t, r);
    for (i.s = 0, i.t = n; n > 0; ) i[--n] = 0;
    for (o = i.t - this.t; n < o; ++n) i[n + this.t] = this.am(0, t[n], i, n, 0, this.t);
    for (o = Math.min(t.t, r); n < o; ++n) this.am(0, t[n], i, n, 0, r - n);
    i.clamp();
}, r.prototype.multiplyUpperTo = function(t, r, i) {
    --r;
    var o = i.t = this.t + t.t - r;
    for (i.s = 0; --o >= 0; ) i[o] = 0;
    for (o = Math.max(r - this.t, 0); o < t.t; ++o) i[this.t + o - r] = this.am(r - o, t[o], i, 0, 0, this.t + o - r);
    i.clamp(), i.drShiftTo(1, i);
}, r.prototype.modInt = function(t) {
    if (t <= 0) return 0;
    var r = this.DV % t, i = this.s < 0 ? t - 1 : 0;
    if (this.t > 0) if (0 == r) i = this[0] % t; else for (var o = this.t - 1; o >= 0; --o) i = (r * i + this[o]) % t;
    return i;
}, r.prototype.millerRabin = function(t) {
    var i = this.subtract(r.ONE), n = i.getLowestSetBit();
    if (n <= 0) return !1;
    var e = i.shiftRight(n);
    (t = t + 1 >> 1) > A.length && (t = A.length);
    for (var s = o(), h = 0; h < t; ++h) {
        s.fromInt(A[Math.floor(Math.random() * A.length)]);
        var u = s.modPow(e, this);
        if (0 != u.compareTo(r.ONE) && 0 != u.compareTo(i)) {
            for (var f = 1; f++ < n && 0 != u.compareTo(i); ) if (0 == (u = u.modPowInt(2, this)).compareTo(r.ONE)) return !1;
            if (0 != u.compareTo(i)) return !1;
        }
    }
    return !0;
}, r.prototype.clone = function() {
    var t = o();
    return this.copyTo(t), t;
}, r.prototype.intValue = function() {
    if (this.s < 0) {
        if (1 == this.t) return this[0] - this.DV;
        if (0 == this.t) return -1;
    } else {
        if (1 == this.t) return this[0];
        if (0 == this.t) return 0;
    }
    return (this[1] & (1 << 32 - this.DB) - 1) << this.DB | this[0];
}, r.prototype.byteValue = function() {
    return 0 == this.t ? this.s : this[0] << 24 >> 24;
}, r.prototype.shortValue = function() {
    return 0 == this.t ? this.s : this[0] << 16 >> 16;
}, r.prototype.signum = function() {
    return this.s < 0 ? -1 : this.t <= 0 || 1 == this.t && this[0] <= 0 ? 0 : 1;
}, r.prototype.toByteArray = function() {
    var t = this.t, r = new Array();
    r[0] = this.s;
    var i, o = this.DB - t * this.DB % 8, n = 0;
    if (t-- > 0) for (o < this.DB && (i = this[t] >> o) != (this.s & this.DM) >> o && (r[n++] = i | this.s << this.DB - o); t >= 0; ) o < 8 ? (i = (this[t] & (1 << o) - 1) << 8 - o, 
    i |= this[--t] >> (o += this.DB - 8)) : (i = this[t] >> (o -= 8) & 255, o <= 0 && (o += this.DB, 
    --t)), 0 != (128 & i) && (i |= -256), 0 == n && (128 & this.s) != (128 & i) && ++n, 
    (n > 0 || i != this.s) && (r[n++] = i);
    return r;
}, r.prototype.equals = function(t) {
    return 0 == this.compareTo(t);
}, r.prototype.min = function(t) {
    return this.compareTo(t) < 0 ? this : t;
}, r.prototype.max = function(t) {
    return this.compareTo(t) > 0 ? this : t;
}, r.prototype.and = function(t) {
    var r = o();
    return this.bitwiseTo(t, l, r), r;
}, r.prototype.or = function(t) {
    var r = o();
    return this.bitwiseTo(t, m, r), r;
}, r.prototype.xor = function(t) {
    var r = o();
    return this.bitwiseTo(t, d, r), r;
}, r.prototype.andNot = function(t) {
    var r = o();
    return this.bitwiseTo(t, y, r), r;
}, r.prototype.not = function() {
    for (var t = o(), r = 0; r < this.t; ++r) t[r] = this.DM & ~this[r];
    return t.t = this.t, t.s = ~this.s, t;
}, r.prototype.shiftLeft = function(t) {
    var r = o();
    return t < 0 ? this.rShiftTo(-t, r) : this.lShiftTo(t, r), r;
}, r.prototype.shiftRight = function(t) {
    var r = o();
    return t < 0 ? this.lShiftTo(-t, r) : this.rShiftTo(t, r), r;
}, r.prototype.getLowestSetBit = function() {
    for (var t = 0; t < this.t; ++t) if (0 != this[t]) return t * this.DB + g(this[t]);
    return this.s < 0 ? this.t * this.DB : -1;
}, r.prototype.bitCount = function() {
    for (var t = 0, r = this.s & this.DM, i = 0; i < this.t; ++i) t += b(this[i] ^ r);
    return t;
}, r.prototype.testBit = function(t) {
    var r = Math.floor(t / this.DB);
    return r >= this.t ? 0 != this.s : 0 != (this[r] & 1 << t % this.DB);
}, r.prototype.setBit = function(t) {
    return this.changeBit(t, m);
}, r.prototype.clearBit = function(t) {
    return this.changeBit(t, y);
}, r.prototype.flipBit = function(t) {
    return this.changeBit(t, d);
}, r.prototype.add = function(t) {
    var r = o();
    return this.addTo(t, r), r;
}, r.prototype.subtract = function(t) {
    var r = o();
    return this.subTo(t, r), r;
}, r.prototype.multiply = function(t) {
    var r = o();
    return this.multiplyTo(t, r), r;
}, r.prototype.divide = function(t) {
    var r = o();
    return this.divRemTo(t, r, null), r;
}, r.prototype.remainder = function(t) {
    var r = o();
    return this.divRemTo(t, null, r), r;
}, r.prototype.divideAndRemainder = function(t) {
    var r = o(), i = o();
    return this.divRemTo(t, r, i), new Array(r, i);
}, r.prototype.modPow = function(t, r) {
    var i, n, e = t.bitLength(), s = f(1);
    if (e <= 0) return s;
    i = e < 18 ? 1 : e < 48 ? 3 : e < 144 ? 4 : e < 768 ? 5 : 6, n = e < 8 ? new c(r) : r.isEven() ? new w(r) : new p(r);
    var h = new Array(), u = 3, l = i - 1, v = (1 << i) - 1;
    if (h[1] = n.convert(this), i > 1) {
        var m = o();
        for (n.sqrTo(h[1], m); u <= v; ) h[u] = o(), n.mulTo(m, h[u - 2], h[u]), u += 2;
    }
    var d, y, g = t.t - 1, b = !0, S = o();
    for (e = a(t[g]) - 1; g >= 0; ) {
        for (e >= l ? d = t[g] >> e - l & v : (d = (t[g] & (1 << e + 1) - 1) << l - e, g > 0 && (d |= t[g - 1] >> this.DB + e - l)), 
        u = i; 0 == (1 & d); ) d >>= 1, --u;
        if ((e -= u) < 0 && (e += this.DB, --g), b) h[d].copyTo(s), b = !1; else {
            for (;u > 1; ) n.sqrTo(s, S), n.sqrTo(S, s), u -= 2;
            u > 0 ? n.sqrTo(s, S) : (y = s, s = S, S = y), n.mulTo(S, h[d], s);
        }
        for (;g >= 0 && 0 == (t[g] & 1 << e); ) n.sqrTo(s, S), y = s, s = S, S = y, --e < 0 && (e = this.DB - 1, 
        --g);
    }
    return n.revert(s);
}, r.prototype.modInverse = function(t) {
    var i = t.isEven();
    if (this.isEven() && i || 0 == t.signum()) return r.ZERO;
    for (var o = t.clone(), n = this.clone(), e = f(1), s = f(0), h = f(0), u = f(1); 0 != o.signum(); ) {
        for (;o.isEven(); ) o.rShiftTo(1, o), i ? (e.isEven() && s.isEven() || (e.addTo(this, e), 
        s.subTo(t, s)), e.rShiftTo(1, e)) : s.isEven() || s.subTo(t, s), s.rShiftTo(1, s);
        for (;n.isEven(); ) n.rShiftTo(1, n), i ? (h.isEven() && u.isEven() || (h.addTo(this, h), 
        u.subTo(t, u)), h.rShiftTo(1, h)) : u.isEven() || u.subTo(t, u), u.rShiftTo(1, u);
        o.compareTo(n) >= 0 ? (o.subTo(n, o), i && e.subTo(h, e), s.subTo(u, s)) : (n.subTo(o, n), 
        i && h.subTo(e, h), u.subTo(s, u));
    }
    return 0 != n.compareTo(r.ONE) ? r.ZERO : u.compareTo(t) >= 0 ? u.subtract(t) : u.signum() < 0 ? (u.addTo(t, u), 
    u.signum() < 0 ? u.add(t) : u) : u;
}, r.prototype.pow = function(t) {
    return this.exp(t, new S());
}, r.prototype.gcd = function(t) {
    var r = this.s < 0 ? this.negate() : this.clone(), i = t.s < 0 ? t.negate() : t.clone();
    if (r.compareTo(i) < 0) {
        var o = r;
        r = i, i = o;
    }
    var n = r.getLowestSetBit(), e = i.getLowestSetBit();
    if (e < 0) return r;
    for (n < e && (e = n), e > 0 && (r.rShiftTo(e, r), i.rShiftTo(e, i)); r.signum() > 0; ) (n = r.getLowestSetBit()) > 0 && r.rShiftTo(n, r), 
    (n = i.getLowestSetBit()) > 0 && i.rShiftTo(n, i), r.compareTo(i) >= 0 ? (r.subTo(i, r), 
    r.rShiftTo(1, r)) : (i.subTo(r, i), i.rShiftTo(1, i));
    return e > 0 && i.lShiftTo(e, i), i;
}, r.prototype.isProbablePrime = function(t) {
    var r, i = this.abs();
    if (1 == i.t && i[0] <= A[A.length - 1]) {
        for (r = 0; r < A.length; ++r) if (i[0] == A[r]) return !0;
        return !1;
    }
    if (i.isEven()) return !1;
    for (r = 1; r < A.length; ) {
        for (var o = A[r], n = r + 1; n < A.length && o < C; ) o *= A[n++];
        for (o = i.modInt(o); r < n; ) if (o % A[r++] == 0) return !1;
    }
    return i.millerRabin(t);
}, r.prototype.square = function() {
    var t = o();
    return this.squareTo(t), t;
}, function(r, i, o, n, e, s, h) {
    function u(t) {
        var r, i, o = this, n = t.length, e = 0, s = o.i = o.j = o.m = 0;
        for (o.S = [], o.c = [], n || (t = [ n++ ]); e < 256; ) o.S[e] = e++;
        for (e = 0; e < 256; e++) s = c(s + (r = o.S[e]) + t[e % n]), i = o.S[s], o.S[e] = i, 
        o.S[s] = r;
        o.g = function(t) {
            var r = o.S, i = c(o.i + 1), n = r[i], e = c(o.j + n), s = r[e];
            r[i] = s, r[e] = n;
            for (var h = r[c(n + s)]; --t; ) i = c(i + 1), s = r[e = c(e + (n = r[i]))], r[i] = s, 
            r[e] = n, h = 256 * h + r[c(n + s)];
            return o.i = i, o.j = e, h;
        }, o.g(256);
    }
    function f(r, i, o, n, e) {
        if (o = [], e = t(r), i && "object" == e) for (n in r) if (n.indexOf("S") < 5) try {
            o.push(f(r[n], i - 1));
        } catch (t) {}
        return o.length ? o : r + ("string" != e ? "\0" : "");
    }
    function a(t, r, i, o) {
        for (t += "", i = 0, o = 0; o < t.length; o++) r[c(o)] = c((i ^= 19 * r[c(o)]) + t.charCodeAt(o));
        for (o in t = "", r) t += String.fromCharCode(r[o]);
        return t;
    }
    function c(t) {
        return 255 & t;
    }
    i.seedrandom = function(t, o) {
        var n, c = [];
        return t = a(f(o ? [ t, r ] : arguments.length ? t : [ new Date().getTime(), r, window ], 3), c), 
        a((n = new u(c)).S, r), i.random = function() {
            for (var t = n.g(6), r = h, i = 0; t < e; ) t = 256 * (t + i), r *= 256, i = n.g(1);
            for (;t >= s; ) t /= 2, r /= 2, i >>>= 1;
            return (t + i) / r;
        }, t;
    }, h = i.pow(256, 6), e = i.pow(2, e), s = 2 * e, a(i.random(), r);
}([], Math, 0, 0, 52), D.prototype.nextBytes = function(t) {
    var r;
    for (r = 0; r < t.length; r++) t[r] = Math.floor(256 * Math.random());
}, x.prototype.init = function(t) {
    var r, i, o;
    for (r = 0; r < 256; ++r) this.S[r] = r;
    for (i = 0, r = 0; r < 256; ++r) i = i + this.S[r] + t[r % t.length] & 255, o = this.S[r], 
    this.S[r] = this.S[i], this.S[i] = o;
    this.i = 0, this.j = 0;
}, x.prototype.next = function() {
    var t;
    return this.i = this.i + 1 & 255, this.j = this.j + this.S[this.i] & 255, t = this.S[this.i], 
    this.S[this.i] = this.S[this.j], this.S[this.j] = t, this.S[t + this.S[this.i] & 255];
};

var B, R, E;

function M() {
    var t;
    t = new Date().getTime(), R[E++] ^= 255 & t, R[E++] ^= t >> 8 & 255, R[E++] ^= t >> 16 & 255, 
    R[E++] ^= t >> 24 & 255, E >= 256 && (E -= 256);
}

if (null == R) {
    var q;
    for (R = new Array(), E = 0; E < 256; ) q = Math.floor(65536 * Math.random()), R[E++] = q >>> 8, 
    R[E++] = 255 & q;
    E = 0, M();
}

function I() {
    if (null == B) {
        for (M(), (B = new x()).init(R), E = 0; E < R.length; ++E) R[E] = 0;
        E = 0;
    }
    return B.next();
}

function O() {}

O.prototype.nextBytes = function(t) {
    var r;
    for (r = 0; r < t.length; ++r) t[r] = I();
};

var P = {};

P.hex = function(t) {
    return function(t) {
        function r(t, r) {
            var i = (65535 & t) + (65535 & r);
            return (t >> 16) + (r >> 16) + (i >> 16) << 16 | 65535 & i;
        }
        function i(t, r) {
            return t >>> r | t << 32 - r;
        }
        function o(t, r) {
            return t >>> r;
        }
        function n(t, r, i) {
            return t & r ^ ~t & i;
        }
        function e(t, r, i) {
            return t & r ^ t & i ^ r & i;
        }
        function s(t) {
            return i(t, 2) ^ i(t, 13) ^ i(t, 22);
        }
        function h(t) {
            return i(t, 6) ^ i(t, 11) ^ i(t, 25);
        }
        function u(t) {
            return i(t, 7) ^ i(t, 18) ^ o(t, 3);
        }
        return function(t) {
            for (var r = "0123456789abcdef", i = "", o = 0; o < 4 * t.length; o++) i += r.charAt(t[o >> 2] >> 8 * (3 - o % 4) + 4 & 15) + r.charAt(t[o >> 2] >> 8 * (3 - o % 4) & 15);
            return i;
        }(function(t, f) {
            var a, c, p, l, v, m, d, y, g, b, S, T = new Array(1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909, 275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298), w = new Array(1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225), A = new Array(64);
            t[f >> 5] |= 128 << 24 - f % 32, t[15 + (f + 64 >> 9 << 4)] = f;
            for (var C = 0; C < t.length; C += 16) {
                a = w[0], c = w[1], p = w[2], l = w[3], v = w[4], m = w[5], d = w[6], y = w[7];
                for (var D = 0; D < 64; D++) A[D] = D < 16 ? t[D + C] : r(r(r(i(S = A[D - 2], 17) ^ i(S, 19) ^ o(S, 10), A[D - 7]), u(A[D - 15])), A[D - 16]), 
                g = r(r(r(r(y, h(v)), n(v, m, d)), T[D]), A[D]), b = r(s(a), e(a, c, p)), y = d, 
                d = m, m = v, v = r(l, g), l = p, p = c, c = a, a = r(g, b);
                w[0] = r(a, w[0]), w[1] = r(c, w[1]), w[2] = r(p, w[2]), w[3] = r(l, w[3]), w[4] = r(v, w[4]), 
                w[5] = r(m, w[5]), w[6] = r(d, w[6]), w[7] = r(y, w[7]);
            }
            return w;
        }(function(t) {
            for (var r = Array(), i = 0; i < 8 * t.length; i += 8) r[i >> 5] |= (255 & t.charCodeAt(i / 8)) << 24 - i % 32;
            return r;
        }(t = function(t) {
            t = t.replace(/\r\n/g, "\n");
            for (var r = "", i = 0; i < t.length; i++) {
                var o = t.charCodeAt(i);
                o < 128 ? r += String.fromCharCode(o) : o > 127 && o < 2048 ? (r += String.fromCharCode(o >> 6 | 192), 
                r += String.fromCharCode(63 & o | 128)) : (r += String.fromCharCode(o >> 12 | 224), 
                r += String.fromCharCode(o >> 6 & 63 | 128), r += String.fromCharCode(63 & o | 128));
            }
            return r;
        }(t)), 8 * t.length));
    }(t);
};

var K = {};

K.hex = function(t) {
    return function(t) {
        function r(t, r) {
            return t << r | t >>> 32 - r;
        }
        function i(t) {
            var r, i = "";
            for (r = 7; r >= 0; r--) i += (t >>> 4 * r & 15).toString(16);
            return i;
        }
        var o, n, e, s, h, u, f, a, c, p = new Array(80), l = 1732584193, v = 4023233417, m = 2562383102, d = 271733878, y = 3285377520, g = (t = function(t) {
            t = t.replace(/\r\n/g, "\n");
            for (var r = "", i = 0; i < t.length; i++) {
                var o = t.charCodeAt(i);
                o < 128 ? r += String.fromCharCode(o) : o > 127 && o < 2048 ? (r += String.fromCharCode(o >> 6 | 192), 
                r += String.fromCharCode(63 & o | 128)) : (r += String.fromCharCode(o >> 12 | 224), 
                r += String.fromCharCode(o >> 6 & 63 | 128), r += String.fromCharCode(63 & o | 128));
            }
            return r;
        }(t)).length, b = new Array();
        for (n = 0; n < g - 3; n += 4) e = t.charCodeAt(n) << 24 | t.charCodeAt(n + 1) << 16 | t.charCodeAt(n + 2) << 8 | t.charCodeAt(n + 3), 
        b.push(e);
        switch (g % 4) {
          case 0:
            n = 2147483648;
            break;

          case 1:
            n = t.charCodeAt(g - 1) << 24 | 8388608;
            break;

          case 2:
            n = t.charCodeAt(g - 2) << 24 | t.charCodeAt(g - 1) << 16 | 32768;
            break;

          case 3:
            n = t.charCodeAt(g - 3) << 24 | t.charCodeAt(g - 2) << 16 | t.charCodeAt(g - 1) << 8 | 128;
        }
        for (b.push(n); b.length % 16 != 14; ) b.push(0);
        for (b.push(g >>> 29), b.push(g << 3 & 4294967295), o = 0; o < b.length; o += 16) {
            for (n = 0; n < 16; n++) p[n] = b[o + n];
            for (n = 16; n <= 79; n++) p[n] = r(p[n - 3] ^ p[n - 8] ^ p[n - 14] ^ p[n - 16], 1);
            for (s = l, h = v, u = m, f = d, a = y, n = 0; n <= 19; n++) c = r(s, 5) + (h & u | ~h & f) + a + p[n] + 1518500249 & 4294967295, 
            a = f, f = u, u = r(h, 30), h = s, s = c;
            for (n = 20; n <= 39; n++) c = r(s, 5) + (h ^ u ^ f) + a + p[n] + 1859775393 & 4294967295, 
            a = f, f = u, u = r(h, 30), h = s, s = c;
            for (n = 40; n <= 59; n++) c = r(s, 5) + (h & u | h & f | u & f) + a + p[n] + 2400959708 & 4294967295, 
            a = f, f = u, u = r(h, 30), h = s, s = c;
            for (n = 60; n <= 79; n++) c = r(s, 5) + (h ^ u ^ f) + a + p[n] + 3395469782 & 4294967295, 
            a = f, f = u, u = r(h, 30), h = s, s = c;
            l = l + s & 4294967295, v = v + h & 4294967295, m = m + u & 4294967295, d = d + f & 4294967295, 
            y = y + a & 4294967295;
        }
        return (c = i(l) + i(v) + i(m) + i(d) + i(y)).toLowerCase();
    }(t);
};

function V(t, i) {
    return new r(t, i);
}

function k() {
    this.n = null, this.e = 0, this.d = null, this.p = null, this.q = null, this.dmp1 = null, 
    this.dmq1 = null, this.coeff = null;
}

k.prototype.doPublic = function(t) {
    return t.modPowInt(this.e, this.n);
}, k.prototype.setPublic = function(t, r) {
    null != t && null != r && t.length > 0 && r.length > 0 ? (this.n = V(t, 16), this.e = parseInt(r, 16)) : alert("Invalid RSA public key");
}, k.prototype.encrypt = function(t) {
    var i = function(t, i) {
        if (i < t.length + 11) throw "Message too long for RSA (n=" + i + ", l=" + t.length + ")";
        for (var o = new Array(), n = t.length - 1; n >= 0 && i > 0; ) {
            var e = t.charCodeAt(n--);
            e < 128 ? o[--i] = e : e > 127 && e < 2048 ? (o[--i] = 63 & e | 128, o[--i] = e >> 6 | 192) : (o[--i] = 63 & e | 128, 
            o[--i] = e >> 6 & 63 | 128, o[--i] = e >> 12 | 224);
        }
        o[--i] = 0;
        for (var s = new O(), h = new Array(); i > 2; ) {
            for (h[0] = 0; 0 == h[0]; ) s.nextBytes(h);
            o[--i] = h[0];
        }
        return o[--i] = 2, o[--i] = 0, new r(o);
    }(t, this.n.bitLength() + 7 >> 3);
    if (null == i) return null;
    var o = this.doPublic(i);
    if (null == o) return null;
    var n = o.toString(16);
    return 0 == (1 & n.length) ? n : "0" + n;
}, k.prototype.doPrivate = function(t) {
    if (null == this.p || null == this.q) return t.modPow(this.d, this.n);
    for (var r = t.mod(this.p).modPow(this.dmp1, this.p), i = t.mod(this.q).modPow(this.dmq1, this.q); r.compareTo(i) < 0; ) r = r.add(this.p);
    return r.subtract(i).multiply(this.coeff).mod(this.p).multiply(this.q).add(i);
}, k.prototype.setPrivate = function(t, r, i) {
    null != t && null != r && t.length > 0 && r.length > 0 ? (this.n = V(t, 16), this.e = parseInt(r, 16), 
    this.d = V(i, 16)) : alert("Invalid RSA private key");
}, k.prototype.setPrivateEx = function(t, r, i, o, n, e, s, h) {
    null != t && null != r && t.length > 0 && r.length > 0 ? (this.n = V(t, 16), this.e = parseInt(r, 16), 
    this.d = V(i, 16), this.p = V(o, 16), this.q = V(n, 16), this.dmp1 = V(e, 16), this.dmq1 = V(s, 16), 
    this.coeff = V(h, 16)) : alert("Invalid RSA private key");
}, k.prototype.generate = function(t, i) {
    var o = new D(), n = t >> 1;
    this.e = parseInt(i, 16);
    for (var e = new r(i, 16); ;) {
        for (;this.p = new r(t - n, 1, o), 0 != this.p.subtract(r.ONE).gcd(e).compareTo(r.ONE) || !this.p.isProbablePrime(10); ) ;
        for (;this.q = new r(n, 1, o), 0 != this.q.subtract(r.ONE).gcd(e).compareTo(r.ONE) || !this.q.isProbablePrime(10); ) ;
        if (this.p.compareTo(this.q) <= 0) {
            var s = this.p;
            this.p = this.q, this.q = s;
        }
        var h = this.p.subtract(r.ONE), u = this.q.subtract(r.ONE), f = h.multiply(u);
        if (0 == f.gcd(e).compareTo(r.ONE)) {
            this.n = this.p.multiply(this.q), this.d = e.modInverse(f), this.dmp1 = this.d.mod(h), 
            this.dmq1 = this.d.mod(u), this.coeff = this.q.modInverse(this.p);
            break;
        }
    }
}, k.prototype.decrypt = function(t) {
    var r = V(t, 16), i = this.doPrivate(r);
    return null == i ? null : function(t, r) {
        for (var i = t.toByteArray(), o = 0; o < i.length && 0 == i[o]; ) ++o;
        if (i.length - o != r - 1 || 2 != i[o]) return null;
        for (++o; 0 != i[o]; ) if (++o >= i.length) return null;
        for (var n = ""; ++o < i.length; ) {
            var e = 255 & i[o];
            e < 128 ? n += String.fromCharCode(e) : e > 191 && e < 224 ? (n += String.fromCharCode((31 & e) << 6 | 63 & i[o + 1]), 
            ++o) : (n += String.fromCharCode((15 & e) << 12 | (63 & i[o + 1]) << 6 | 63 & i[o + 2]), 
            o += 2);
        }
        return n;
    }(i, this.n.bitLength() + 7 >> 3);
};

var L = [];

L.sha1 = "3021300906052b0e03021a05000414", L.sha256 = "3031300d060960864801650304020105000420";

var N = [];

function F(t, r, i) {
    for (var o = r / 4, n = (0, N[i])(t), e = "00" + L[i] + n, s = "", h = o - "0001".length - e.length, u = 0; u < h; u += 2) s += "ff";
    return sPaddedMessageHex = "0001" + s + e, sPaddedMessageHex;
}

function j(t, r, i) {
    return function(t, r, i) {
        var o = new k();
        return o.setPublic(r, i), o.doPublic(t);
    }(t, r, i).toString(16).replace(/^1f+00/, "");
}

function Z(t) {
    for (var r in L) {
        var i = L[r], o = i.length;
        if (t.substring(0, o) == i) return [ r, t.substring(o) ];
    }
    return [];
}

N.sha1 = K.hex, N.sha256 = P.hex, k.prototype.signString = function(t, r) {
    var i = V(F(t, this.n.bitLength(), r), 16);
    return this.doPrivate(i).toString(16);
}, k.prototype.signStringWithSHA1 = function(t) {
    var r = V(F(t, this.n.bitLength(), "sha1"), 16);
    return this.doPrivate(r).toString(16);
}, k.prototype.signStringWithSHA256 = function(t) {
    var r = V(F(t, this.n.bitLength(), "sha256"), 16);
    return this.doPrivate(r).toString(16);
}, k.prototype.verifyString = function(t, r) {
    var i = V(r = r.replace(/[ \n]+/g, ""), 16), o = Z(this.doPublic(i).toString(16).replace(/^1f+00/, ""));
    if (0 == o.length) return !1;
    var n = o[0];
    return o[1] == (0, N[n])(t);
}, k.prototype.verifyHexSignatureForMessage = function(t, r) {
    return function(t, r, i, o) {
        var n = Z(j(r, i, o));
        if (0 == n.length) return !1;
        var e = n[0];
        return n[1] == (0, N[e])(t);
    }(r, V(t, 16), this.n.toString(16), this.e.toString(16));
};

var _, H = ((_ = {}).Sbox = new Array(99, 124, 119, 123, 242, 107, 111, 197, 48, 1, 103, 43, 254, 215, 171, 118, 202, 130, 201, 125, 250, 89, 71, 240, 173, 212, 162, 175, 156, 164, 114, 192, 183, 253, 147, 38, 54, 63, 247, 204, 52, 165, 229, 241, 113, 216, 49, 21, 4, 199, 35, 195, 24, 150, 5, 154, 7, 18, 128, 226, 235, 39, 178, 117, 9, 131, 44, 26, 27, 110, 90, 160, 82, 59, 214, 179, 41, 227, 47, 132, 83, 209, 0, 237, 32, 252, 177, 91, 106, 203, 190, 57, 74, 76, 88, 207, 208, 239, 170, 251, 67, 77, 51, 133, 69, 249, 2, 127, 80, 60, 159, 168, 81, 163, 64, 143, 146, 157, 56, 245, 188, 182, 218, 33, 16, 255, 243, 210, 205, 12, 19, 236, 95, 151, 68, 23, 196, 167, 126, 61, 100, 93, 25, 115, 96, 129, 79, 220, 34, 42, 144, 136, 70, 238, 184, 20, 222, 94, 11, 219, 224, 50, 58, 10, 73, 6, 36, 92, 194, 211, 172, 98, 145, 149, 228, 121, 231, 200, 55, 109, 141, 213, 78, 169, 108, 86, 244, 234, 101, 122, 174, 8, 186, 120, 37, 46, 28, 166, 180, 198, 232, 221, 116, 31, 75, 189, 139, 138, 112, 62, 181, 102, 72, 3, 246, 14, 97, 53, 87, 185, 134, 193, 29, 158, 225, 248, 152, 17, 105, 217, 142, 148, 155, 30, 135, 233, 206, 85, 40, 223, 140, 161, 137, 13, 191, 230, 66, 104, 65, 153, 45, 15, 176, 84, 187, 22), 
_.ShiftRowTab = new Array(0, 5, 10, 15, 4, 9, 14, 3, 8, 13, 2, 7, 12, 1, 6, 11), 
_.Init = function() {
    _.Sbox_Inv = new Array(256);
    for (var t = 0; t < 256; t++) _.Sbox_Inv[_.Sbox[t]] = t;
    for (_.ShiftRowTab_Inv = new Array(16), t = 0; t < 16; t++) _.ShiftRowTab_Inv[_.ShiftRowTab[t]] = t;
    for (_.xtime = new Array(256), t = 0; t < 128; t++) _.xtime[t] = t << 1, _.xtime[128 + t] = t << 1 ^ 27;
}, _.Done = function() {
    delete _.Sbox_Inv, delete _.ShiftRowTab_Inv, delete _.xtime;
}, _.ExpandKey = function(t) {
    var r, i = t.length, o = 1;
    switch (i) {
      case 16:
        r = 176;
        break;

      case 24:
        r = 208;
        break;

      case 32:
        r = 240;
        break;

      default:
        alert("my.ExpandKey: Only key lengths of 16, 24 or 32 bytes allowed!");
    }
    for (var n = i; n < r; n += 4) {
        var e = t.slice(n - 4, n);
        n % i == 0 ? (e = new Array(_.Sbox[e[1]] ^ o, _.Sbox[e[2]], _.Sbox[e[3]], _.Sbox[e[0]]), 
        (o <<= 1) >= 256 && (o ^= 283)) : i > 24 && n % i == 16 && (e = new Array(_.Sbox[e[0]], _.Sbox[e[1]], _.Sbox[e[2]], _.Sbox[e[3]]));
        for (var s = 0; s < 4; s++) t[n + s] = t[n + s - i] ^ e[s];
    }
}, _.Encrypt = function(t, r) {
    var i = r.length;
    _.AddRoundKey(t, r.slice(0, 16));
    for (var o = 16; o < i - 16; o += 16) _.SubBytes(t, _.Sbox), _.ShiftRows(t, _.ShiftRowTab), 
    _.MixColumns(t), _.AddRoundKey(t, r.slice(o, o + 16));
    _.SubBytes(t, _.Sbox), _.ShiftRows(t, _.ShiftRowTab), _.AddRoundKey(t, r.slice(o, i));
}, _.Decrypt = function(t, r) {
    var i = r.length;
    _.AddRoundKey(t, r.slice(i - 16, i)), _.ShiftRows(t, _.ShiftRowTab_Inv), _.SubBytes(t, _.Sbox_Inv);
    for (var o = i - 32; o >= 16; o -= 16) _.AddRoundKey(t, r.slice(o, o + 16)), _.MixColumns_Inv(t), 
    _.ShiftRows(t, _.ShiftRowTab_Inv), _.SubBytes(t, _.Sbox_Inv);
    _.AddRoundKey(t, r.slice(0, 16));
}, _.SubBytes = function(t, r) {
    for (var i = 0; i < 16; i++) t[i] = r[t[i]];
}, _.AddRoundKey = function(t, r) {
    for (var i = 0; i < 16; i++) t[i] ^= r[i];
}, _.ShiftRows = function(t, r) {
    for (var i = new Array().concat(t), o = 0; o < 16; o++) t[o] = i[r[o]];
}, _.MixColumns = function(t) {
    for (var r = 0; r < 16; r += 4) {
        var i = t[r + 0], o = t[r + 1], n = t[r + 2], e = t[r + 3], s = i ^ o ^ n ^ e;
        t[r + 0] ^= s ^ _.xtime[i ^ o], t[r + 1] ^= s ^ _.xtime[o ^ n], t[r + 2] ^= s ^ _.xtime[n ^ e], 
        t[r + 3] ^= s ^ _.xtime[e ^ i];
    }
}, _.MixColumns_Inv = function(t) {
    for (var r = 0; r < 16; r += 4) {
        var i = t[r + 0], o = t[r + 1], n = t[r + 2], e = t[r + 3], s = i ^ o ^ n ^ e, h = _.xtime[s], u = _.xtime[_.xtime[h ^ i ^ n]] ^ s, f = _.xtime[_.xtime[h ^ o ^ e]] ^ s;
        t[r + 0] ^= u ^ _.xtime[i ^ o], t[r + 1] ^= f ^ _.xtime[o ^ n], t[r + 2] ^= u ^ _.xtime[n ^ e], 
        t[r + 3] ^= f ^ _.xtime[e ^ i];
    }
}, _), z = function() {
    var t = {};
    H.Init();
    var r = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    return t.b256to64 = function(t) {
        var i, o, n, e = "", s = 0, h = t.length;
        for (n = 0; n < h; n++) o = t.charCodeAt(n), 0 == s ? (e += r.charAt(o >> 2 & 63), 
        i = (3 & o) << 4) : 1 == s ? (e += r.charAt(i | o >> 4 & 15), i = (15 & o) << 2) : 2 == s && (e += r.charAt(i | o >> 6 & 3), 
        1, e += r.charAt(63 & o)), 1, 3 == (s += 1) && (s = 0);
        return s > 0 && (e += r.charAt(i), 1, e += "=", 1), 1 == s && (e += "="), e;
    }, t.b64to256 = function(t) {
        var i, o, n = "", e = 0, s = 0, h = t.length;
        for (o = 0; o < h; o++) (i = r.indexOf(t.charAt(o))) >= 0 && (e && (n += String.fromCharCode(s | i >> 6 - e & 255)), 
        s = i << (e = e + 2 & 7) & 255);
        return n;
    }, t.b16to64 = function(t) {
        var i, o, n = "";
        for (t.length % 2 == 1 && (t = "0" + t), i = 0; i + 3 <= t.length; i += 3) o = parseInt(t.substring(i, i + 3), 16), 
        n += r.charAt(o >> 6) + r.charAt(63 & o);
        for (i + 1 == t.length ? (o = parseInt(t.substring(i, i + 1), 16), n += r.charAt(o << 2)) : i + 2 == t.length && (o = parseInt(t.substring(i, i + 2), 16), 
        n += r.charAt(o >> 2) + r.charAt((3 & o) << 4)); (3 & n.length) > 0; ) n += "=";
        return n;
    }, t.b64to16 = function(t) {
        var i, o, n = "", e = 0;
        for (i = 0; i < t.length && "=" != t.charAt(i); ++i) v = r.indexOf(t.charAt(i)), 
        v < 0 || (0 == e ? (n += h(v >> 2), o = 3 & v, e = 1) : 1 == e ? (n += h(o << 2 | v >> 4), 
        o = 15 & v, e = 2) : 2 == e ? (n += h(o), n += h(v >> 2), o = 3 & v, e = 3) : (n += h(o << 2 | v >> 4), 
        n += h(15 & v), e = 0));
        return 1 == e && (n += h(o << 2)), n;
    }, t.string2bytes = function(t) {
        for (var r = new Array(), i = 0; i < t.length; i++) r.push(t.charCodeAt(i));
        return r;
    }, t.bytes2string = function(t) {
        for (var r = "", i = 0; i < t.length; i++) r += String.fromCharCode(t[i]);
        return r;
    }, t.blockXOR = function(t, r) {
        for (var i = new Array(16), o = 0; o < 16; o++) i[o] = t[o] ^ r[o];
        return i;
    }, t.blockIV = function() {
        var t = new O(), r = new Array(16);
        return t.nextBytes(r), r;
    }, t.pad16 = function(t) {
        var r = t.slice(0), o = (16 - t.length % 16) % 16;
        for (i = t.length; i < t.length + o; i++) r.push(0);
        return r;
    }, t.depad = function(t) {
        for (var r = t.slice(0); 0 == r[r.length - 1]; ) r = r.slice(0, r.length - 1);
        return r;
    }, t.encryptAESCBC = function(r, i) {
        var o = i.slice(0);
        H.ExpandKey(o);
        var n = t.string2bytes(r);
        n = t.pad16(n);
        for (var e = t.blockIV(), s = 0; s < n.length / 16; s++) {
            var h = n.slice(16 * s, 16 * s + 16), u = e.slice(16 * s, 16 * s + 16);
            h = t.blockXOR(u, h), H.Encrypt(h, o), e = e.concat(h);
        }
        var f = t.bytes2string(e);
        return t.b256to64(f);
    }, t.decryptAESCBC = function(r, i) {
        var o = i.slice(0);
        H.ExpandKey(o);
        r = t.b64to256(r);
        for (var n = t.string2bytes(r), e = new Array(), s = 1; s < n.length / 16; s++) {
            var h = n.slice(16 * s, 16 * s + 16), u = n.slice(16 * (s - 1), 16 * (s - 1) + 16);
            H.Decrypt(h, o), h = t.blockXOR(u, h), e = e.concat(h);
        }
        return e = t.depad(e), t.bytes2string(e);
    }, t.wrap60 = function(t) {
        for (var r = "", i = 0; i < t.length; i++) i % 60 == 0 && 0 != i && (r += "\n"), 
        r += t[i];
        return r;
    }, t.generateAESKey = function() {
        var t = new Array(32);
        return new O().nextBytes(t), t;
    }, t.generateRSAKey = function(t, r) {
        Math.seedrandom(P.hex(t));
        var i = new k();
        return i.generate(r, "03"), i;
    }, t.publicKeyString = function(r) {
        return pubkey = t.b16to64(r.n.toString(16)), pubkey;
    }, t.publicKeyID = function(t) {
        return function(t) {
            function r(t, r) {
                return t << r | t >>> 32 - r;
            }
            function i(t, r) {
                var i, o, n, e, s;
                return n = 2147483648 & t, e = 2147483648 & r, s = (1073741823 & t) + (1073741823 & r), 
                (i = 1073741824 & t) & (o = 1073741824 & r) ? 2147483648 ^ s ^ n ^ e : i | o ? 1073741824 & s ? 3221225472 ^ s ^ n ^ e : 1073741824 ^ s ^ n ^ e : s ^ n ^ e;
            }
            function o(t, o, n, e, s, h, u) {
                return t = i(t, i(i(function(t, r, i) {
                    return t & r | ~t & i;
                }(o, n, e), s), u)), i(r(t, h), o);
            }
            function n(t, o, n, e, s, h, u) {
                return t = i(t, i(i(function(t, r, i) {
                    return t & i | r & ~i;
                }(o, n, e), s), u)), i(r(t, h), o);
            }
            function e(t, o, n, e, s, h, u) {
                return t = i(t, i(i(function(t, r, i) {
                    return t ^ r ^ i;
                }(o, n, e), s), u)), i(r(t, h), o);
            }
            function s(t, o, n, e, s, h, u) {
                return t = i(t, i(i(function(t, r, i) {
                    return r ^ (t | ~i);
                }(o, n, e), s), u)), i(r(t, h), o);
            }
            function h(t) {
                var r, i = "", o = "";
                for (r = 0; r <= 3; r++) i += (o = "0" + (t >>> 8 * r & 255).toString(16)).substr(o.length - 2, 2);
                return i;
            }
            var u, f, a, c, p, l, v, m, d, y = Array();
            for (y = function(t) {
                for (var r, i = t.length, o = i + 8, n = 16 * ((o - o % 64) / 64 + 1), e = Array(n - 1), s = 0, h = 0; h < i; ) s = h % 4 * 8, 
                e[r = (h - h % 4) / 4] = e[r] | t.charCodeAt(h) << s, h++;
                return s = h % 4 * 8, e[r = (h - h % 4) / 4] = e[r] | 128 << s, e[n - 2] = i << 3, 
                e[n - 1] = i >>> 29, e;
            }(t = function(t) {
                t = t.replace(/\r\n/g, "\n");
                for (var r = "", i = 0; i < t.length; i++) {
                    var o = t.charCodeAt(i);
                    o < 128 ? r += String.fromCharCode(o) : o > 127 && o < 2048 ? (r += String.fromCharCode(o >> 6 | 192), 
                    r += String.fromCharCode(63 & o | 128)) : (r += String.fromCharCode(o >> 12 | 224), 
                    r += String.fromCharCode(o >> 6 & 63 | 128), r += String.fromCharCode(63 & o | 128));
                }
                return r;
            }(t)), l = 1732584193, v = 4023233417, m = 2562383102, d = 271733878, u = 0; u < y.length; u += 16) f = l, 
            a = v, c = m, p = d, l = o(l, v, m, d, y[u + 0], 7, 3614090360), d = o(d, l, v, m, y[u + 1], 12, 3905402710), 
            m = o(m, d, l, v, y[u + 2], 17, 606105819), v = o(v, m, d, l, y[u + 3], 22, 3250441966), 
            l = o(l, v, m, d, y[u + 4], 7, 4118548399), d = o(d, l, v, m, y[u + 5], 12, 1200080426), 
            m = o(m, d, l, v, y[u + 6], 17, 2821735955), v = o(v, m, d, l, y[u + 7], 22, 4249261313), 
            l = o(l, v, m, d, y[u + 8], 7, 1770035416), d = o(d, l, v, m, y[u + 9], 12, 2336552879), 
            m = o(m, d, l, v, y[u + 10], 17, 4294925233), v = o(v, m, d, l, y[u + 11], 22, 2304563134), 
            l = o(l, v, m, d, y[u + 12], 7, 1804603682), d = o(d, l, v, m, y[u + 13], 12, 4254626195), 
            m = o(m, d, l, v, y[u + 14], 17, 2792965006), l = n(l, v = o(v, m, d, l, y[u + 15], 22, 1236535329), m, d, y[u + 1], 5, 4129170786), 
            d = n(d, l, v, m, y[u + 6], 9, 3225465664), m = n(m, d, l, v, y[u + 11], 14, 643717713), 
            v = n(v, m, d, l, y[u + 0], 20, 3921069994), l = n(l, v, m, d, y[u + 5], 5, 3593408605), 
            d = n(d, l, v, m, y[u + 10], 9, 38016083), m = n(m, d, l, v, y[u + 15], 14, 3634488961), 
            v = n(v, m, d, l, y[u + 4], 20, 3889429448), l = n(l, v, m, d, y[u + 9], 5, 568446438), 
            d = n(d, l, v, m, y[u + 14], 9, 3275163606), m = n(m, d, l, v, y[u + 3], 14, 4107603335), 
            v = n(v, m, d, l, y[u + 8], 20, 1163531501), l = n(l, v, m, d, y[u + 13], 5, 2850285829), 
            d = n(d, l, v, m, y[u + 2], 9, 4243563512), m = n(m, d, l, v, y[u + 7], 14, 1735328473), 
            l = e(l, v = n(v, m, d, l, y[u + 12], 20, 2368359562), m, d, y[u + 5], 4, 4294588738), 
            d = e(d, l, v, m, y[u + 8], 11, 2272392833), m = e(m, d, l, v, y[u + 11], 16, 1839030562), 
            v = e(v, m, d, l, y[u + 14], 23, 4259657740), l = e(l, v, m, d, y[u + 1], 4, 2763975236), 
            d = e(d, l, v, m, y[u + 4], 11, 1272893353), m = e(m, d, l, v, y[u + 7], 16, 4139469664), 
            v = e(v, m, d, l, y[u + 10], 23, 3200236656), l = e(l, v, m, d, y[u + 13], 4, 681279174), 
            d = e(d, l, v, m, y[u + 0], 11, 3936430074), m = e(m, d, l, v, y[u + 3], 16, 3572445317), 
            v = e(v, m, d, l, y[u + 6], 23, 76029189), l = e(l, v, m, d, y[u + 9], 4, 3654602809), 
            d = e(d, l, v, m, y[u + 12], 11, 3873151461), m = e(m, d, l, v, y[u + 15], 16, 530742520), 
            l = s(l, v = e(v, m, d, l, y[u + 2], 23, 3299628645), m, d, y[u + 0], 6, 4096336452), 
            d = s(d, l, v, m, y[u + 7], 10, 1126891415), m = s(m, d, l, v, y[u + 14], 15, 2878612391), 
            v = s(v, m, d, l, y[u + 5], 21, 4237533241), l = s(l, v, m, d, y[u + 12], 6, 1700485571), 
            d = s(d, l, v, m, y[u + 3], 10, 2399980690), m = s(m, d, l, v, y[u + 10], 15, 4293915773), 
            v = s(v, m, d, l, y[u + 1], 21, 2240044497), l = s(l, v, m, d, y[u + 8], 6, 1873313359), 
            d = s(d, l, v, m, y[u + 15], 10, 4264355552), m = s(m, d, l, v, y[u + 6], 15, 2734768916), 
            v = s(v, m, d, l, y[u + 13], 21, 1309151649), l = s(l, v, m, d, y[u + 4], 6, 4149444226), 
            d = s(d, l, v, m, y[u + 11], 10, 3174756917), m = s(m, d, l, v, y[u + 2], 15, 718787259), 
            v = s(v, m, d, l, y[u + 9], 21, 3951481745), l = i(l, f), v = i(v, a), m = i(m, c), 
            d = i(d, p);
            return (h(l) + h(v) + h(m) + h(d)).toLowerCase();
        }(t);
    }, t.publicKeyFromString = function(r) {
        var i = t.b64to16(r.split("|")[0]), o = new k();
        return o.setPublic(i, "03"), o;
    }, t.encrypt = function(r, i, o) {
        var n = "", e = t.generateAESKey();
        try {
            var s = t.publicKeyFromString(i);
            n += t.b16to64(s.encrypt(t.bytes2string(e))) + "?";
        } catch (t) {
            return {
                status: "Invalid public key"
            };
        }
        return o && (signString = z.b16to64(o.signString(r, "sha256")), r += "::52cee64bb3a38f6403386519a39ac91c::", 
        r += z.publicKeyString(o), r += "::52cee64bb3a38f6403386519a39ac91c::", r += signString), 
        {
            status: "success",
            cipher: n += t.encryptAESCBC(r, e)
        };
    }, t.decrypt = function(r, i) {
        var o = r.split("?"), n = i.decrypt(t.b64to16(o[0]));
        if (null == n) return {
            status: "failure"
        };
        n = t.string2bytes(n);
        var e = t.decryptAESCBC(o[1], n).split("::52cee64bb3a38f6403386519a39ac91c::");
        if (3 == e.length) {
            var s = t.publicKeyFromString(e[1]), h = t.b64to16(e[2]);
            return s.verifyString(e[0], h) ? {
                status: "success",
                plaintext: e[0],
                signature: "verified",
                publicKeyString: t.publicKeyString(s)
            } : {
                status: "success",
                plaintext: e[0],
                signature: "forged",
                publicKeyString: t.publicKeyString(s)
            };
        }
        return {
            status: "success",
            plaintext: e[0],
            signature: "unsigned"
        };
    }, t;
}();

module.exports = {
    RSAKey: k
};
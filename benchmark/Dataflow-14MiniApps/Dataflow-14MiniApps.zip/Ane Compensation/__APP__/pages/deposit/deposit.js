var e = getApp(), s = require("../../7D41315784CF379C1B2759508F425043.js"), a = (require("../../BA4681C684CF379CDC20E9C1FBE15043.js"), 
require("../../9A41035384CF379CFC276B5474025043.js"));

Page({
    data: {
        hospitalUserId: "",
        hospitalUserPassword: "",
        encryptInsuredNo: "",
        freeDepositHospitalCode: "",
        imagesappMobile: "../../pages/images/phonenub_2.png",
        imagesIdNo: "../../pages/images/id_2.png",
        imagesHospital: "../../pages/images/process_2.png",
        scane: "../../pages/images/scane.png",
        insuredName: "",
        insuredIdNo: "",
        freeDepositLines: "",
        hiddenToast: !0,
        showFlag: !0,
        depositFlag: !1,
        bgTips: "../../pages/images/tips.png",
        hospitalName: "",
        hospitalCode: "",
        registerNo: ""
    },
    onShow: function() {
        console.log("onshow>>>>"), a.onShow(), a.onEvent(e.SKAPPObj.deposit[0].id, e.SKAPPObj.deposit[0].label, e.SKAPPObj.deposit[0].params), 
        wx.redirectTo({
            url: "/pages/deposit/deposit"
        });
    },
    onHide: function() {
        a.onHide();
    },
    onLoad: function() {
        console.log("onload>>>>");
    },
    searchHospital: function(a) {
        var o = this, t = a.detail.value;
        console.log("hospitalName", t);
        var i = {
            hospitalKeyWord: a.detail.value
        }, n = s.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "queryClaimHospitalList?access_token=" + e.tokens.access_token + "&request_id=" + s.uuid();
        wx.cloud.callFunction({
            name: "checkUser",
            data: {
                url: n,
                data: i
            },
            success: function(e) {
                var s = JSON.parse(e.result);
                console.log("resData", s), "crs-00001" == s.returnCode ? o.setData({
                    hospitalArr: s.data
                }) : o.showToast(!1, s.message);
            },
            fail: console.error
        });
    },
    choseHospital: function(a) {
        console.log("选择医院", a);
        var o = this, t = a.target.dataset.item;
        this.setData({
            hospitalCode: t.hospitalCode,
            hospitalName: t.hospitalName,
            hospitalArr: []
        });
        var i = {
            weChatId: e.wxCode.openid,
            weChatName: e.globalData.userInfo.nickName,
            hospitalInfo: {
                hospitalCode: t.hospitalCode
            }
        }, n = s.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "checkHospitalIsFreeDeposit?access_token=" + e.tokens.access_token + "&request_id=" + s.uuid();
        wx.cloud.callFunction({
            name: "checkUser",
            data: {
                url: n,
                data: i
            },
            success: function(e) {
                var s = JSON.parse(e.result);
                console.log("resData", s), "Y" == s.data.freeDepositHospital ? o.setData({
                    isCooperationHos: !0
                }) : o.setData({
                    isCooperationHos: !1
                });
            },
            fail: console.error
        });
    },
    submit: function() {
        var o = this;
        if (o.data.hospitalUserId && o.data.hospitalUserPassword) {
            var t = {
                weChatId: e.wxCode.openid,
                weChatName: e.globalData.userInfo.nickName,
                hospitalUserInfo: {
                    hospitalUserId: o.data.hospitalUserId,
                    hospitalUserPassword: o.data.hospitalUserPassword,
                    freeDepositHospitalCode: o.data.hospitalCode
                }
            };
            a.onEvent(e.SKAPPObj.deposit[1].id, e.SKAPPObj.deposit[1].label, e.SKAPPObj.deposit[1].params);
            var i = s.getSer(e.globalData.userInfo.nickName).ser_url + e.newCommonUrl + "checkHospitalUserInfo?access_token=" + e.tokens.access_token + "&request_id=" + s.uuid();
            wx.request({
                url: i,
                data: t,
                method: "POST",
                header: {
                    "content-type": "application/json"
                },
                success: function(s) {
                    console.log("checkUser------", s);
                    var t = s.data;
                    "crs-00001" == t.returnCode ? (o.setData({
                        showFlag: !1
                    }), a.onEvent(e.SKAPPObj.scan[0].id, e.SKAPPObj.scan[0].label, e.SKAPPObj.scan[0].params)) : o.showToast(!1, t.message);
                }
            });
        } else o.showToast(!1, "账号密码不能为空");
    },
    checkUserGetClient: function(a) {
        var o = this, t = s.getSer(e.globalData.userInfo.nickName).ser_url + e.newCommonUrl + "checkUserGetClientFreeDepositLines?access_token=" + e.tokens.access_token + "&request_id=" + s.uuid();
        console.log("url", t), wx.request({
            url: t,
            data: a,
            method: "POST",
            header: {
                "content-type": "application/json"
            },
            success: function(e) {
                console.log("getClient------", e);
                var s = e.data;
                console.log("resData", s), "crs-00001" == s.returnCode ? o.setData({
                    insuredName: s.data.insuredName,
                    insuredIdNo: s.data.insuredIdNo,
                    registerNo: s.data.registerNo,
                    freeDepositLines: s.data.freeDepositLines,
                    depositFlag: !0
                }) : (console.log("resData.message", s.message), o.showToast(!1, s.message));
            },
            fail: function(e) {
                console.log("err", e);
            }
        });
    },
    inputCellPhone: function(e) {
        this.setData({
            hospitalUserId: e.detail.value
        });
    },
    inputPassWord: function(e) {
        this.setData({
            hospitalUserPassword: e.detail.value
        });
    },
    showToast: function(e, s) {
        var a = this;
        a.setData({
            hiddenToast: !1,
            mesg: s
        }), setTimeout(function() {
            a.setData({
                hiddenToast: !0
            });
        }, 2e3);
    },
    scanCode: function() {
        var s = this;
        a.onEvent(e.SKAPPObj.scan[1].id, e.SKAPPObj.scan[1].label, e.SKAPPObj.scan[1].params), 
        wx.scanCode({
            success: function(o) {
                console.log(o);
                var t = o.result, i = s.urlToObj(t);
                console.log("urlObj", i), a.onEvent(e.SKAPPObj.deposit[2].id, e.SKAPPObj.deposit[2].label, e.SKAPPObj.deposit[2].params), 
                a.onEvent(e.SKAPPObj.scan[2].id, e.SKAPPObj.scan[2].label, e.SKAPPObj.scan[2].params);
                var n = {
                    weChatId: e.wxCode.openid,
                    weChatName: e.globalData.userInfo.nickName,
                    registerNo: i.registerNo,
                    freeDepositLines: {
                        hospitalUserId: s.data.hospitalUserId,
                        hospitalUserPassword: s.data.hospitalUserPassword,
                        freeDepositHospitalCode: s.data.hospitalCode,
                        encryptInsuredNo: i.encryptInsuredNo
                    }
                };
                console.log("data", n), s.checkUserGetClient(n);
            },
            fail: function(e) {
                console.log("err", e);
            }
        });
    },
    urlToObj: function(e) {
        for (var s = {}, a = e.split("&"), o = 0; o < a.length; o++) {
            var t = a[o].split("=");
            s[t[0]] = t[1];
        }
        return s;
    }
});
var e, a, t, i = getApp(), o = require("../../7D41315784CF379C1B2759508F425043.js"), n = require("../../BA4681C684CF379CDC20E9C1FBE15043.js"), s = require("../../9A41035384CF379CFC276B5474025043.js");

function d() {
    e = new n.RSAKey(), t = i.globalRsaObj.n, a = i.globalRsaObj.a, e.setPublic(t, a);
}

Page({
    data: {
        switchFlag: !0,
        imagesClientName: [ "../../pages/images/user_1.png", "../../pages/images/user_2.png" ],
        idexName: 0,
        imagesIdNo: [ "../../pages/images/id_1.png", "../../pages/images/id_2.png" ],
        idexIdNo: 0,
        imagesApplicantType: [ "../../pages/images/applicant_1.png", "../../pages/images/applicant_2.png" ],
        idexApplicantType: 1,
        imagesIsAgency: [ "../../pages/images/commission_1.png", "../../pages/images/commission_2.png" ],
        idexIsAgency: 1,
        imagesappMobile: [ "../../pages/images/phonenub_0.png", "../../pages/images/phonenub_2.png" ],
        idexappMobile: 1,
        imagesIdentifyCode: [ "../../pages/images/code_0.png", "../../pages/images/code_1.png" ],
        idexIdentifyCode: 0,
        imageArrow: "../../pages/images/new/down.png",
        identifyCodeFlag: !0,
        queryFlag: !1,
        disabled: !1,
        disableInput: !1,
        getCodeText: "获取验证码",
        second: 60,
        hiddenMask: !0,
        hidden: !0,
        hiddenToast: !0,
        submitBtnDis: !1,
        accclientname: "",
        accClientNo: "",
        idno: "",
        idType: "",
        idTypeArr: [ "1", "2", "0", "A" ],
        idTypeDesArr: [ "身份证", "护照", "户口本", "出生证" ],
        idTypeIdx: 0,
        weChatId: "",
        appMobile: "",
        appMobileSimple: "",
        identityCode: "",
        isPrivilegeWechatId: "",
        isRequest: !1,
        encryptClientNo: "",
        verifyCode: "",
        verifyCodeImage: "",
        verifyCodeFlag: !0,
        imageTokenKey: "",
        getMessageCodeFlag: !1,
        checkIdentifyCodeFlag: !1,
        identifyCodeUuid: ""
    },
    onLaunch: function() {
        this.showToast(!1, "页面加载中"), console.log("onLaunch-----");
    },
    onLoad: function() {
        console.log("onLoad-----");
    },
    onShow: function() {
        this.setData({
            disableInput: !1,
            queryFlag: !1,
            submitBtnDis: !1,
            weChatId: i.wxCode.openid,
            userInfo: i.globalData,
            identifyCodeFlag: !0,
            verifyCodeFlag: !0
        }), s.onShow(), s.onEvent(i.SKAPPObj.onlineApply[0].id, i.SKAPPObj.onlineApply[0].label, i.SKAPPObj.onlineApply[0].params), 
        console.log("app.wxCode.openid", i.wxCode.openid), this.getSwitch(), console.log("onshow------");
    },
    onHide: function() {
        s.onHide();
    },
    onshowMethod: function() {
        this.setData({
            disabled: !1,
            disableInput: !1
        }), this.setData({
            accclientname: "",
            idno: "",
            identifyCode: "",
            identifyCodeFlag: !0,
            submitBtnDis: !1,
            disabled: !1,
            queryFlag: !1
        });
    },
    getSwitch: function() {
        var a = this;
        console.log("111111"), d(), wx.request({
            url: o.getSer(a.data.userInfo.userInfo.nickName).ser_ues_url + "/claim.getAcceptSwtichWechatClaim.do",
            method: "GET",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8"
            },
            data: {
                timestamp: e.encrypt("" + new Date().getTime())
            },
            success: function(e) {
                o.decodeJson(e), console.log("getSwitch-res----", e), "false" == e.data.weChatAcceptSwitch && (a.onshowMethod(), 
                a.setData({
                    switchFlag: !1
                }));
            }
        });
    },
    focusAccClientName: function(e) {
        this.setData({
            idexName: 1
        });
    },
    bindChangeIdType: function(e) {
        this.setData({
            idTypeIdx: e.detail.value
        });
    },
    blurAccClientName: function(e) {
        "" == e.detail.value && (this.setData({
            idexName: 0
        }), i.showToast(this, "请输入姓名！"));
    },
    inputAccClientName: function(e) {
        this.setData({
            accclientname: e.detail.value,
            idexName: 1
        });
    },
    focusIdNo: function(e) {
        this.setData({
            idexIdNo: 1
        });
    },
    blurIdNo: function(e) {
        console.log("校验身份证", o.verifyIdNo(e.detail.value)), "" == e.detail.value && (this.setData({
            idexIdNo: 0
        }), i.showToast(this, "请输入正确的证件号码！"));
    },
    inputIdNo: function(e) {
        this.setData({
            idexIdNo: 1,
            idno: e.detail.value
        });
    },
    focusIdentifyCode: function(e) {
        this.setData({
            idexIdentifyCode: 1
        });
    },
    blurIdentifyCode: function(e) {
        "" == e.detail.value && this.setData({
            idexIdentifyCode: 0
        });
    },
    inputIdentifyCode: function(e) {
        this.setData({
            idexIdentifyCode: 1,
            identifyCode: e.detail.value
        });
    },
    applyReport: function(a) {
        var t = this, n = a.detail.value;
        if ("" == a.detail.value.accClientName && "" == a.detail.value.idNo || "" == a.detail.value.applicantType || "" == a.detail.value.isAgency) i.showToast(t, "请输入姓名/证件号码！"); else if ("" == a.detail.value.accClientName) i.showToast(t, "请输入姓名！"); else if ("" == a.detail.value.idNo) i.showToast(t, "请输入正确的证件号码！"); else {
            if (console.log("that.data.isRequest", t.data.isRequest), t.data.isRequest) return;
            t.setData({
                isRequest: !0
            }), d();
            var l = {
                insuredName: e.encrypt(n.accClientName),
                insuredIdNo: e.encrypt(n.idNo),
                queryType: n.idType
            };
            console.log("formData>>>>>>>>>>>", l), s.onEvent(i.SKAPPObj.onlineApply[1].id, i.SKAPPObj.onlineApply[1].label, i.SKAPPObj.onlineApply[1].params);
            var c = o.getSer().lcloud_url + "/open/appsvr/life/new-esg-version/LCLOUD-CLAIM-CRS/WeChatClaim/checkClientInfo?access_token=" + i.tokens.access_token + "&request_id=" + o.uuid();
            wx.request({
                url: c,
                data: l,
                method: "POST",
                header: {
                    "Content-Type": "application/json",
                    Charset: "utf-8",
                    loginAuthorization: i.loginAuthorization
                },
                success: function(e) {
                    console.log("理赔受理用户校验结果", e), "crs-00001" == e.data.returnCode ? (t.setData({
                        submitBtnDis: !0,
                        queryFlag: !0,
                        disableInput: !0,
                        accClientNo: e.data.data.encryptInsuredNo,
                        appMobile: e.data.data.insuredPhone
                    }), i.tokenKey = e.data.data.tokenKey, "Y" == e.data.data.isWhiteListWeChatUser ? (i.baseData.isPrivilege = "Y", 
                    wx.navigateTo({
                        url: "/pages/recordsList/recordsList"
                    })) : (i.baseData.isPrivilege = "N", t.setData({
                        identifyCodeFlag: !1,
                        submitBtnDis: !0,
                        queryFlag: !0,
                        disableInput: !0,
                        accClientNo: e.data.data.encryptInsuredNo,
                        appMobile: e.data.data.insuredPhone,
                        appMobileSimple: e.data.data.insuredPhone,
                        encryptClientNo: e.data.data.encryptInsuredNo
                    }))) : i.showToast(t, e.data.message);
                },
                fail: function() {},
                complete: function() {
                    t.setData({
                        isRequest: !1
                    });
                }
            });
        }
    },
    getCode: function() {
        this.data.second < 60 ? i.showToast(this, "不可重复点击") : "" == this.data.appMobile ? i.showToast(this, "您在本公司留存的联系信息不完整，为保障您的信息安全与理赔权益，建议您通过其他方式办理业务，具体方式您可以拨打95511或联系保单服务人员了解") : this.getVerifyCode();
    },
    getVerifyCode: function() {
        var e = this;
        e.setData({
            verifyCodeFlag: !1
        });
        var a = o.getSer(i.globalData.userInfo.nickName).lcloud_url + "/open/appsvr/life/new-esg-version/LCLOUD-CLAIM-CRS/WeChatClaim/getImageCode?access_token=" + i.tokens.access_token + "&request_id=" + o.uuid(), t = {
            encryptInsuredNo: e.data.encryptClientNo
        };
        console.log("formData", t), wx.request({
            url: a,
            data: t,
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8"
            },
            success: function(a) {
                console.log("res", a), "crs-00001" == a.data.returnCode ? (e.setData({
                    verifyCodeImage: "data:image/jpeg;base64," + a.data.data.imageCodeStream.replace(/\n/g, ""),
                    imageTokenKey: a.data.data.imageTokenKey
                }), console.log("that.data.verifyCodeImage", e.data.verifyCodeImage)) : e.showToast(e, a.data.message);
            },
            fail: function(e) {
                console.log("获取图形验证码错误");
            }
        });
    },
    inputVerifyCode: function(e) {
        this.setData({
            verifyCode: e.detail.value
        });
    },
    getMessageCode: function() {
        var e = this;
        if (function e(a) {
            var t = a.data.second;
            if (0 != t) setTimeout(function() {
                a.setData({
                    second: t - 1,
                    getCodeText: t - 1 + "s"
                }), e(a);
            }, 1e3); else a.setData({
                second: 60,
                getCodeText: "重新获取"
            });
        }(e), !e.data.getVerifyCodeFlag) {
            e.setData({
                getVerifyCodeFlag: !0
            });
            var a = {
                encryptInsuredNo: e.data.encryptClientNo,
                imageTokenKey: e.data.imageTokenKey,
                verifyCode: e.data.verifyCode,
                validateType: "accept"
            }, t = o.getSer(i.globalData.userInfo.nickName).lcloud_url + i.newCommonUrl + "sendIdentifyCodeToClientMobile?access_token=" + i.tokens.access_token + "&request_id=" + o.uuid();
            wx.request({
                url: t,
                data: a,
                method: "POST",
                header: {
                    "Content-Type": "application/json",
                    Charset: "utf-8"
                },
                success: function(a) {
                    console.log("res", a), e.setData({
                        getVerifyCodeFlag: !1
                    }), "crs-00001" == a.data.returnCode ? e.setData({
                        verifyCodeFlag: !0,
                        identifyCodeUuid: a.data.data.identifyCodeUuid
                    }) : wx.showToast({
                        title: a.data.message,
                        icon: "none",
                        duration: 2e3
                    });
                },
                fail: function(a) {
                    i.showToast(e, a.data.message), e.setData({
                        getVerifyCodeFlag: !1
                    });
                }
            });
        }
    },
    CheckIdentifyCode: function(e) {
        var a = this;
        if (console.log("e.detail.value", e.detail.value), !a.data.checkIdentifyCodeFlag) {
            a.setData({
                checkIdentifyCodeFlag: !0
            });
            var t = {
                identifyCode: e.detail.value.identifyCode,
                weChatId: e.detail.value.weChatId,
                encryptClientNo: a.data.encryptClientNo,
                tokenKey: i.tokenKey
            };
            if (console.log("data", t), "" == e.detail.value.identifyCode) i.showToast(a, "请输入验证码！"); else {
                var n = {
                    encryptInsuredNo: a.data.encryptClientNo,
                    identifyCode: e.detail.value.identifyCode,
                    identifyCodeUuid: a.data.identifyCodeUuid
                }, s = o.getSer(i.globalData.userInfo.nickName).lcloud_url + i.newCommonUrl + "validateClientIdentifyCode?access_token=" + i.tokens.access_token + "&request_id=" + o.uuid();
                wx.request({
                    url: s,
                    data: n,
                    method: "POST",
                    header: {
                        "Content-Type": "application/json",
                        Charset: "utf-8",
                        loginAuthorization: i.loginAuthorization
                    },
                    success: function(e) {
                        console.log("校验短信", e), a.setData({
                            checkIdentifyCodeFlag: !1
                        }), "crs-00001" == e.data.returnCode ? (i.baseData.validateSmsCodeKey = e.data.data.validateSmsCodeKey, 
                        wx.navigateTo({
                            url: "/pages/recordsList/recordsList"
                        })) : i.showToast(a, e.data.message);
                    },
                    fail: function(e) {
                        a.setData({
                            checkIdentifyCodeFlag: !1
                        });
                    }
                });
            }
        }
    },
    closeModal: function() {
        i.closeModal(this);
    }
});
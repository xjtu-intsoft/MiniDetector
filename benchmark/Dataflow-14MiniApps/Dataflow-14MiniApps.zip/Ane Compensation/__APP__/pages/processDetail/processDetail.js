var e = getApp(), a = require("../../7D41315784CF379C1B2759508F425043.js"), t = require("../../9A41035384CF379CFC276B5474025043.js"), o = [ {
    value: "01",
    name: "不需要"
}, {
    value: "02",
    name: "金额少"
}, {
    value: "03",
    name: "要提交的资料多"
}, {
    value: "04",
    name: "手续复杂"
}, {
    value: "99",
    name: "其他"
} ];

Page({
    data: {
        imageArrow: "../../pages/images/icon_arrow_1.png",
        Loadinghidden: !0,
        weChatId: "",
        registerNo: "",
        accClientNo: "",
        claimEnt: "",
        hiddenToast: !0,
        mesg: "",
        inferiorFlag: "",
        isShowinferior: !0,
        isWhiteWeChatId: "",
        hiddenTip: !1,
        tipTxt: "该案件理赔实物资料尚未提交，请您尽快提交!",
        isFreeDepositFlag: "",
        notFreeDepositSignature: "",
        encryptInsuredNo: "",
        insuredPhone: "",
        qreffectDateValidate: "",
        processDetailObj: {},
        isShowAdvancePay: !0,
        isShowAdvancePayAgain: !0,
        loading: !1,
        chooseEmpNo: "",
        chooseEmpRegion: "",
        hiddenPolicyServicePerson: !0,
        advancePayUndoReasonList: [],
        undoReasonId: "",
        undoReasonTxt: ""
    },
    onLaunch: function() {},
    onLoad: function(e) {
        this.setData({
            Loadinghidden: !1,
            registerNo: e.registerNo
        });
    },
    onShow: function() {
        t.onShow(), t.onEvent(e.SKAPPObj.process[1].id, e.SKAPPObj.process[1].label, e.SKAPPObj.process[1].params), 
        this.setData({
            weChatId: e.wxCode.openid,
            userInfo: e.globalData,
            Loadinghidden: !0,
            isShowinferior: !0,
            isShowAdvancePay: !0,
            isShowAdvancePayAgain: !0,
            advancePayUndoReasonList: o
        }), this.queryProcessDetail();
    },
    onHide: function() {
        t.onHide();
    },
    queryProcessDetail: function() {
        var t = this, o = a.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "queryCaseClaimProgressDetailInfo?access_token=" + e.tokens.access_token + "&request_id=" + a.uuid();
        wx.request({
            url: o,
            data: {
                registerNo: t.data.registerNo
            },
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: e.loginAuthorization
            },
            success: function(a) {
                console.log("查询详情", a), t.setData({
                    Loadinghidden: !0
                }), "crs-00001" == a.data.returnCode ? (t.setData({
                    processDetailObj: a.data.data,
                    claimEnt: a.data.data.claimEnt,
                    loading: !0
                }), "NORMAL_PAY" != a.data.data.caseHasProblemType && "ADVANCE_PAY" != a.data.data.caseHasProblemType || t.setData({
                    inferiorFlag: "Y",
                    isShowinferior: !1
                })) : (e.showToast(t, a.data.message), t.setData({
                    loading: !0
                }));
            },
            fail: function() {
                t.setData({
                    loading: !0
                });
            }
        });
    },
    goToRecordDetail: function(e) {
        wx.navigateTo({
            url: "/pages/casesState/casesState?registerNo=" + this.data.registerNo
        });
    },
    goToUploadDetail: function(e) {
        wx.navigateTo({
            url: "/pages/uploadFiles/uploadFiles?registerNo=" + this.data.registerNo + "&submitType=02&inferiorFlag=" + this.data.inferiorFlag + "&isWhiteWeChatId=" + this.data.isWhiteWeChatId
        });
    },
    goToPaperDetail: function(e) {
        wx.navigateTo({
            url: "/pages/physicalFiles/physicalFiles?registerNo=" + this.data.registerNo + "&type=1"
        });
    },
    chooseIsApplyFreedeposit: function() {
        var t = this, o = {
            isChooseFreedeposit: "Y",
            registerNo: t.data.registerNo,
            systemId: e.systemId.advancepay,
            tokenKey: e.tokenKey
        }, s = a.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "chooseIsApplyFreedeposit?access_token=" + e.tokens.access_token + "&request_id=" + a.uuid();
        wx.request({
            url: s,
            data: o,
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: e.loginAuthorization
            },
            success: function(e) {
                if ("crs-00001" == e.data.returnCode) {
                    var a = e.data.data;
                    t.setData({
                        encryptInsuredNo: a.encryptInsuredNo,
                        insuredPhone: a.insuredPhone,
                        notFreeDepositSignature: a.notFreeDepositSignature
                    }), t.goDeposit();
                } else t.showToast(!1, e.data.message);
            },
            fail: function() {}
        });
    },
    goDeposit: function() {
        var e = this.data.registerNo, a = this.data.encryptInsuredNo, t = this.data.insuredPhone;
        "Y" == this.data.notFreeDepositSignature ? wx.navigateTo({
            url: "/pages/checkAndCode/checkAndCode?encryptInsuredNo=" + a + "&insuredPhone=" + t + "&registerNo=" + e
        }) : wx.navigateTo({
            url: "/pages/freeDeposit/freeDeposit?registerNo=" + e
        });
    },
    goCheckCode: function() {
        var e = this, a = e.data.registerNo, t = this.data.processDetailObj.qreffectDateValidate, o = this.data.processDetailObj.encryptInsuredNo, s = this.data.processDetailObj.insuredPhone;
        "Y" == t ? wx.showModal({
            title: "提示",
            content: "二维码已经失效,是否重新生成",
            success: function(a) {
                a.confirm ? wx.navigateTo({
                    url: "/pages/checkAndCode/checkAndCode?encryptInsuredNo=" + o + "&insuredPhone=" + s + "&registerNo=" + e.data.registerNo
                }) : a.cancel && console.log("用户点击取消");
            }
        }) : wx.navigateTo({
            url: "/pages/checkAndCode/checkAndCode?registerNo=" + a + "&type=02"
        });
    },
    goProcessDeposit: function(e) {
        var a = this.data.registerNo;
        wx.navigateTo({
            url: "/pages/processDeposit/processDeposit?registerNo=" + a
        });
    },
    goToClaimEnt: function(a) {
        "null" == this.data.claimEnt || null == this.data.claimEnt ? e.baseData.ClaimEntWords = "暂无通知书数据!" : e.baseData.ClaimEntWords = this.data.claimEnt, 
        wx.navigateTo({
            url: "/pages/physicalFiles/physicalFiles?registerNo=" + this.data.registerNo + "&type=2"
        });
    },
    goAdvancePay: function() {
        this.setData({
            isShowAdvancePay: !1
        });
    },
    cancelAdvancePay: function() {
        this.setData({
            isShowAdvancePay: !0,
            isShowAdvancePayAgain: !1
        });
    },
    enSureCancelAdvancePay: function() {
        if (this.data.undoReasonId) if ("99" != this.data.undoReasonId || this.data.undoReasonTxt) {
            var a = {
                isCancelAdvancePay: "Y",
                undoReasonId: this.data.undoReasonId,
                undoReasonTxt: this.data.undoReasonTxt,
                registerNo: this.data.registerNo,
                systemId: e.systemId.advancepay,
                tokenKey: e.tokenKey
            };
            this.isApplyAndvancepay(a, "Y");
        } else e.showToast(this, "请输入描述"); else e.showToast(this, "请选择一项原因");
    },
    noCancelAdvancePay: function() {
        this.setData({
            isShowAdvancePayAgain: !0,
            isShowAdvancePay: !1
        });
    },
    radioChange: function(e) {
        console.log("radio发生change事件，携带value值为：", e.detail.value);
        for (var a = this.data.advancePayUndoReasonList, t = 0, o = a.length; t < o; ++t) a[t].checked = a[t].value === e.detail.value;
        this.setData({
            advancePayUndoReasonList: a,
            undoReasonId: e.detail.value
        });
    },
    inputUndoReasonTxt: function(e) {
        this.setData({
            undoReasonTxt: e.detail.value
        });
    },
    dealAdvancePay: function() {
        wx.navigateTo({
            url: "/pages/advancePay/advancePay?registerNo=" + this.data.registerNo + "&tokenKey=" + e.tokenKey
        });
        var a = {
            isChooseAdvancePay: "Y",
            registerNo: this.data.registerNo,
            systemId: e.systemId.advancepay,
            tokenKey: e.tokenKey
        };
        this.isApplyAndvancepay(a, "N");
    },
    closeAdvancePay: function() {
        this.setData({
            isShowAdvancePay: !0
        });
    },
    closeAdvancePayAgain: function() {
        this.setData({
            isShowAdvancePayAgain: !0
        });
    },
    isApplyAndvancepay: function(t, o) {
        var s = this, i = a.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "chooseIsApplyAdvancePay?access_token=" + e.tokens.access_token + "&request_id=" + a.uuid();
        wx.request({
            url: i,
            data: t,
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: e.loginAuthorization
            },
            success: function(e) {
                "crs-00001" == e.data.returnCode && s.onShow();
            },
            fail: function() {}
        });
    },
    goAdvancePayNormal: function() {
        e.baseData.accClientNo = this.data.processDetailObj.insuredNo, console.log("app.baseData.accClientNo", e.baseData.accClientNo), 
        this.getBaseData();
    },
    getBaseData: function() {
        var t = this;
        console.log("app.wxCode.openid", e.wxCode.openid), wx.request({
            url: a.getSer(e.globalData.userInfo.nickName).ser_url + "/open/appsvr/life/getIdentifyCode?access_token=" + e.tokens.access_token + "&request_id=" + a.uuid(),
            data: {
                type: "1",
                weChatId: e.wxCode.openid
            },
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8"
            },
            success: function(o) {
                console.log("res", o), a.decodeJson(o), e.baseData.applyreasonlist = o.data.applyreasonlist, 
                e.baseData.casereporterlist = o.data.casereporterlist, e.baseData.clientstatuslist = o.data.clientstatuslist, 
                e.baseData.clientstatuswithstagelist = o.data.clientstatuswithstagelist, e.baseData.deathcauselist = o.data.deathcauselist, 
                e.baseData.graveaccidentlist = o.data.graveaccidentlist, e.baseData.insuredrelationlist = o.data.insuredrelationlist, 
                e.baseData.subjectlist = o.data.subjectlist, e.baseData.idTypeDesList = o.data.idtypelist, 
                e.baseData.otherinsurerlist = o.data.otherinsurerlist, e.baseData.isPrivilege = o.data.isprivilegewechatid ? o.data.isprivilegewechatid : "", 
                e.baseData.claimTaxReasonList = o.data.claimtaxreasonlist, e.baseData.isoCountryInfoList = o.data.isocountryinfolist, 
                wx.navigateTo({
                    url: "/pages/recordDetail/recordDetail?regsNo=" + t.data.registerNo + "&type=2"
                });
            },
            fail: function(a) {
                console.log("err", a), e.showToast(t, "查询信息失败");
            }
        });
    },
    closePopTips: function() {
        this.setData({
            isShowinferior: !0
        });
    },
    goAdvancePayUpload: function() {
        var e = this.data.processDetailObj.caseHasProblemType;
        wx.navigateTo({
            url: "/pages/advancePayInferiorUpload/advancePayInferiorUpload?registerNo=" + this.data.registerNo + "&caseHasProblemType=" + e
        });
    },
    openPolicyService: function() {
        this.setData({
            hiddenPolicyServicePerson: !1
        });
    },
    closePolicyService: function() {
        this.setData({
            hiddenPolicyServicePerson: !0
        });
    },
    policyServiceChange: function(e) {
        console.log("保单服务人员value", e.detail.value), this.setData({
            chooseEmpNo: e.detail.value
        });
        var a, t = e.detail.value, o = this.data.processDetailObj.policyServicePersonList;
        for (var s in o) o[s].agentNo == t && (a = o[s].agentRegion);
        this.setData({
            chooseEmpRegion: a
        });
    },
    cancelNotice: function() {
        this.setData({
            hiddenPolicyServicePerson: !0
        });
    },
    ensureNotice: function() {
        if ("" != this.data.chooseEmpNo) {
            var a = {
                chooseEmpNo: this.data.chooseEmpNo,
                chooseEmpRegion: this.data.chooseEmpRegion,
                chooseOperationType: "notice",
                registerNo: this.data.registerNo,
                tokenKey: e.tokenKey,
                systemId: e.systemId.advancepay,
                requestModule: "history"
            };
            this.notice(a);
        } else e.showToast(this, "请勾选一位保单服务人员!");
    },
    notice: function(t) {
        var o = this, s = a.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "choosePolicyServicePersonOperationCase?access_token=" + e.tokens.access_token + "&request_id=" + a.uuid();
        wx.request({
            url: s,
            data: t,
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: e.loginAuthorization
            },
            success: function(e) {
                "crs-00001" == e.data.returnCode && (o.onShow(), o.setData({
                    hiddenPolicyServicePerson: !0
                }));
            },
            fail: function() {}
        });
    }
});
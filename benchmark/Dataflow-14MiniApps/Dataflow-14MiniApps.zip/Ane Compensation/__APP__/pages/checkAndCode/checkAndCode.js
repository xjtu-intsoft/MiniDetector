var e = getApp(), t = require("../../7D41315784CF379C1B2759508F425043.js");

require("../../BA4681C684CF379CDC20E9C1FBE15043.js");

Page({
    data: {
        identifyCode: "",
        insuredPhone: "",
        appMobileSimple: "",
        encryptInsuredNo: "",
        qrcodeUrl: "",
        imagesIdentifyCode: "../../pages/images/code_1.png",
        getCodeText: "获取短信验证码",
        second: 60,
        hiddenToast: !0,
        qrbaseCodeEffectDate: "",
        isShowQrcode: !0,
        hiddenIndentifyCode: !1,
        registerNo: "",
        verifyCode: "",
        verifyCodeImage: "",
        verifyCodeFlag: !0,
        imageTokenKey: "",
        identifyCodeUuid: "",
        getVerifyCodeFlag: !1
    },
    onLoad: function(e) {
        if (console.log("options", e), this.setData({
            encryptInsuredNo: e.encryptInsuredNo,
            insuredPhone: e.insuredPhone,
            registerNo: e.registerNo,
            type: e.type ? e.type : ""
        }), "02" == this.data.type) this.setData({
            hiddenIndentifyCode: !0
        }), this.getQrcode(); else {
            var t = this.data.insuredPhone;
            this.setData({
                appMobileSimple: t
            });
        }
    },
    getCode: function() {
        if (this.data.second < 60) e.showToast(this, "不可重复点击"); else if ("" == this.data.insuredPhone) e.showToast(this, "您在本公司留存的联系信息不完整，为保障您的信息安全与理赔权益，建议您通过其他方式办理业务，具体方式您可以拨打95511或联系保单服务人员了解"); else {
            if (!this.data.isShowQrcode) return;
            this.getVerifyCode();
        }
    },
    closeCode: function() {
        this.setData({
            verifyCodeFlag: !0
        });
    },
    getVerifyCode: function() {
        var a = this;
        a.setData({
            verifyCodeFlag: !1
        });
        var o = t.getSer(e.globalData.userInfo.nickName).lcloud_url + "/open/appsvr/life/new-esg-version/LCLOUD-CLAIM-CRS/WeChatClaim/getImageCode?access_token=" + e.tokens.access_token + "&request_id=" + t.uuid(), s = {
            encryptInsuredNo: a.data.encryptInsuredNo
        };
        console.log("formData", s), wx.request({
            url: o,
            data: s,
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8"
            },
            success: function(e) {
                console.log("res", e), "crs-00001" == e.data.returnCode ? a.setData({
                    verifyCodeImage: "data:image/jpeg;base64," + e.data.data.imageCodeStream.replace(/\n/g, ""),
                    imageTokenKey: e.data.data.imageTokenKey
                }) : a.showToast(!1, e.data.message);
            },
            fail: function(e) {
                console.log("获取图形验证码错误");
            }
        });
    },
    inputVerifyCode: function(e) {
        this.setData({
            verifyCode: e.detail.value
        });
    },
    getMessageCode: function() {
        var a = this;
        if (!a.data.getVerifyCodeFlag) {
            a.setData({
                getVerifyCodeFlag: !0
            });
            var o = {
                encryptInsuredNo: a.data.encryptInsuredNo,
                imageTokenKey: a.data.imageTokenKey,
                verifyCode: a.data.verifyCode,
                validateType: "freeDeposit"
            }, s = t.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "sendIdentifyCodeToClientMobile?access_token=" + e.tokens.access_token + "&request_id=" + t.uuid();
            wx.request({
                url: s,
                data: o,
                method: "POST",
                header: {
                    "Content-Type": "application/json",
                    Charset: "utf-8"
                },
                success: function(e) {
                    console.log("res", e), a.setData({
                        getVerifyCodeFlag: !1
                    }), "crs-00001" == e.data.returnCode ? (!function e(t) {
                        var a = t.data.second;
                        if (0 != a) setTimeout(function() {
                            t.setData({
                                second: a - 1,
                                getCodeText: a - 1 + "s"
                            }), e(t);
                        }, 1e3); else t.setData({
                            second: 60,
                            getCodeText: "重新获取"
                        });
                    }(a), a.setData({
                        verifyCodeFlag: !0,
                        identifyCodeUuid: e.data.data.identifyCodeUuid
                    })) : (wx.showToast({
                        title: e.data.message,
                        icon: "none",
                        duration: 2e3
                    }), a.setData({
                        getCodeText: "重新获取"
                    }));
                },
                fail: function(t) {
                    a.setData({
                        getVerifyCodeFlag: !1
                    }), e.showToast(a, t.data.message);
                }
            });
        }
    },
    submit: function() {
        wx.showLoading({
            title: "加载中",
            mask: !0
        });
        var a = this, o = {
            weChatId: e.wxCode.openid,
            weChatName: e.globalData.userInfo.nickName,
            registerNo: a.data.registerNo,
            validateIdentifyCode: {
                identifyCode: a.data.identifyCode,
                encryptInsuredNo: a.data.encryptInsuredNo,
                identifyCodeUuid: a.data.identifyCodeUuid
            }
        };
        console.log("onshow------", o);
        var s = t.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "validateIdentifyCodeAndPolicy?access_token=" + e.tokens.access_token + "&request_id=" + t.uuid();
        wx.cloud.callFunction({
            name: "checkUser",
            data: {
                url: s,
                data: o
            },
            success: function(e) {
                var t = JSON.parse(e.result);
                wx.hideLoading(), console.log("resData", t), "crs-00001" == t.returnCode ? a.setData({
                    qrcodeUrl: "data:image/jpg;base64," + t.data.qrbaseCode,
                    qrbaseCodeEffectDate: t.data.qrbaseCodeEffectDate,
                    isShowQrcode: !1
                }) : a.showToast(!1, t.message);
            },
            fail: function() {
                wx.hideLoading();
            }
        });
    },
    getQrcode: function() {
        var a = this, o = {
            weChatId: e.wxCode.openid,
            weChatName: e.globalData.userInfo.nickName,
            registerNo: a.data.registerNo
        };
        console.log("onshow------", o);
        var s = t.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "queryHospitalFreedepositQrCode?access_token=" + e.tokens.access_token + "&request_id=" + t.uuid();
        wx.cloud.callFunction({
            name: "checkUser",
            data: {
                url: s,
                data: o
            },
            success: function(e) {
                var t = JSON.parse(e.result);
                console.log("resData", t), "crs-00001" == t.returnCode ? a.setData({
                    qrcodeUrl: "data:image/jpg;base64," + t.data.qrbaseCode,
                    qrbaseCodeEffectDate: t.data.qrbaseCodeEffectDate,
                    isShowQrcode: !1
                }) : a.showToast(!1, t.message);
            },
            fail: console.error
        });
    },
    goProcess: function() {
        wx.reLaunch({
            url: "/pages/process/process"
        });
    },
    inputIdentifyCode: function(e) {
        this.setData({
            identifyCode: e.detail.value
        });
    },
    showToast: function(e, t) {
        var a = this;
        a.setData({
            hiddenToast: !1,
            mesg: t
        }), setTimeout(function() {
            a.setData({
                hiddenToast: !0
            });
        }, 2e3);
    }
});
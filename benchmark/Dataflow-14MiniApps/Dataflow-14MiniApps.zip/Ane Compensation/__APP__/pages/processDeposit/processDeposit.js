var e = getApp(), t = require("../../7D41315784CF379C1B2759508F425043.js");

Page({
    data: {
        clientName: "",
        hospitalName: "",
        freeDepositLines: "",
        registerNo: ""
    },
    onLoad: function(e) {
        this.setData({
            registerNo: e.registerNo
        }), this.queryInfo();
    },
    queryInfo: function() {
        this.getDepositInfo();
    },
    getDepositInfo: function() {
        var a = this, o = {
            weChatId: e.wxCode.openid,
            weChatName: e.globalData.userInfo.nickName,
            registerNo: a.data.registerNo
        };
        console.log("onshow------", o);
        var s = t.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "queryHospitalFreedepositInfo?access_token=" + e.tokens.access_token + "&request_id=" + t.uuid();
        wx.cloud.callFunction({
            name: "checkUser",
            data: {
                url: s,
                data: o
            },
            success: function(e) {
                var t = JSON.parse(e.result);
                console.log("resData", t), "crs-00001" == t.returnCode ? a.setData({
                    clientName: t.data.clientName,
                    hospitalName: t.data.hospitalName,
                    freeDepositLines: t.data.freeDepositLines
                }) : a.showToast(!1, t.message);
            },
            fail: console.error
        });
    },
    showToast: function(e, t) {
        var a = this;
        a.setData({
            hiddenToast: !1,
            mesg: t
        }), setTimeout(function() {
            a.setData({
                hiddenToast: !0
            });
        }, 2e3);
    }
});
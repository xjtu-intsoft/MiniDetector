var e = require("../../@babel/runtime/helpers/slicedToArray"), a = require("../../@babel/runtime/helpers/createForOfIteratorHelper");

require("../../C5492FB784CF379CA32F47B0E5F15043.js");

var t = require("../../8340FCA384CF379CE52694A481125043.js"), s = getApp(), o = require("../../7D41315784CF379C1B2759508F425043.js");

Page({
    data: {
        registerNo: "",
        parentMaterialCode: "",
        materialCode: "",
        uploadDetails: [],
        tempFilePaths: null,
        baseImg: [],
        uploadIcon: "../../pages/images/new/bg.png",
        delIcon: "../../pages/images/new/close.png",
        tipsIcon: "../../pages/images/new/dengpao.png",
        hiddenMoadl: !0,
        hiddenToast: !0,
        sampleDescriptionList: [],
        noneSampleData: !1,
        tipsTextList: {}
    },
    onLoad: function(e) {
        this.setData({
            registerNo: e.registerNo,
            parentMaterialCode: e.parentMaterialCode,
            tokenKey: e.tokenKey ? e.tokenKey : ""
        }), wx.setNavigationBarTitle({
            title: e.title
        });
    },
    onShow: function() {
        console.log("****111122222"), this.initData();
    },
    initData: function() {
        console.log("*******1111");
        var e = this;
        wx.showLoading(), wx.request({
            url: o.getSer(s.globalData.userInfo.nickName).lcloud_url + s.newCommonUrl + "queryClaimUploadMaterialInfo?access_token=" + s.tokens.access_token + "&request_id=" + o.uuid(),
            data: {
                parentMaterialCode: this.data.parentMaterialCode,
                registerNo: this.data.registerNo,
                systemId: s.systemId.advancepay,
                caseBusinessType: "ADVANCE_PAY",
                tokenKey: this.data.tokenKey
            },
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: s.loginAuthorization
            },
            success: function(a) {
                if (console.log("****", a), "crs-00001" === a.data.returnCode) {
                    var t = e.base64Img(a.data.data);
                    e.setData({
                        uploadDetails: t,
                        previewImgArr: []
                    }), e.setSampleOfsampleDescription(a.data.data);
                } else s.showToast(e, a.data.message);
            },
            fail: function(a) {
                s.showToast(e, a.data.message || "查询异常");
            },
            complete: function(e) {
                wx.hideLoading();
            }
        });
    },
    base64Img: function(e) {
        for (var a = 0; a < e.length; a++) if (null !== e[a].compressAndNormalImages && 0 !== e[a].compressAndNormalImages.length) for (var t = 0; t < e[a].compressAndNormalImages.length; t++) e[a].compressAndNormalImages[t].compressImageStream = "data:image/jpg;base64," + e[a].compressAndNormalImages[t].compressImageStream.replace(/\n/g, ""), 
        e[a].compressAndNormalImages[t].normalImageStream = "data:image/jpg;base64," + e[a].compressAndNormalImages[t].normalImageStream.replace(/\n/g, "");
        return e;
    },
    chooseImgInWechat: function(e) {
        var a = this;
        a.setData({
            materialCode: e.currentTarget.dataset.materialcode
        }), wx.chooseImage({
            count: 9,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var t = e.tempFilePaths;
                a.setData({
                    tempFilePaths: t
                }), console.log(a.data.tempFilePaths), a.conversionImgToBase64();
            }
        });
    },
    conversionImgToBase64: function() {
        var e = this;
        if (0 !== e.data.tempFilePaths.length) {
            e.setData({
                baseImg: []
            });
            for (var a = 0; a < e.data.tempFilePaths.length; a++) wx.getFileSystemManager().readFile({
                filePath: e.data.tempFilePaths[a],
                encoding: "base64",
                success: function(a) {
                    e.data.baseImg.push(a.data), e.data.tempFilePaths.length == e.data.baseImg.length && e.uploadImgs();
                }
            });
        } else s.showToast(e, "请先选择图片！");
    },
    uploadImgs: function() {
        for (var e = this, a = [], t = 0; t < e.data.tempFilePaths.length; t++) {
            var r = new Promise(function(a, r) {
                wx.request({
                    url: o.getSer(s.globalData.userInfo.nickName).lcloud_url + s.newCommonUrl + "uploadCaseClaimImage?access_token=" + s.tokens.access_token + "&request_id=" + o.uuid(),
                    method: "POST",
                    data: {
                        businessOperation: "claimAdvancePay",
                        materialCode: e.data.materialCode,
                        registerNo: e.data.registerNo,
                        uploadImageStream: e.data.baseImg[t]
                    },
                    header: {
                        "Content-Type": "application/json",
                        Charset: "utf-8",
                        loginAuthorization: s.loginAuthorization
                    },
                    success: function(o) {
                        return "crs-00001" !== o.data.returnCode ? (s.showToast(e, o.data.message), r(o)) : (console.log(t), 
                        a(o));
                    },
                    fail: function(e) {
                        return e;
                    },
                    complete: function(e) {
                        return e;
                    }
                });
            });
            a.push(r);
        }
        Promise.all(a).then(function(a) {
            console.log("promisea====>", a), e.initData();
        }).catch(function(a) {
            console.log("err ==== ", a), s.showToast(e, a.data.message);
        });
    },
    delImg: function(e) {
        var a = this;
        wx.showModal({
            title: "提示",
            content: "确定要删除此图片吗？",
            success: function(t) {
                if (t.confirm) console.log("确定删除"), new Promise(function(t, r) {
                    wx.request({
                        url: o.getSer(s.globalData.userInfo.nickName).lcloud_url + s.newCommonUrl + "deleteCaseClaimImage?access_token=" + s.tokens.access_token + "&request_id=" + o.uuid(),
                        method: "POST",
                        data: {
                            imageFileName: e.currentTarget.dataset.imagefilename,
                            materialCode: e.currentTarget.dataset.materialcode,
                            registerNo: a.data.registerNo
                        },
                        header: {
                            "Content-Type": "application/json",
                            Charset: "utf-8",
                            loginAuthorization: s.loginAuthorization
                        },
                        success: function(e) {
                            "crs-00001" === e.data.returnCode ? (s.showToast(a, e.data.message), t(e)) : (s.showToast(a, e.data.message || "删除异常"), 
                            r(e));
                        },
                        fail: function(t) {
                            s.showToast(a, e.data.message || "删除异常"), r(t);
                        }
                    });
                }).then(function(e) {
                    a.initData();
                }).catch(function(e) {
                    s.showToast(a, e.data.message || "删除异常");
                }); else if (t.cancel) return console.log("取消删除"), !1;
            }
        });
    },
    tabPreview: function(e) {
        e.currentTarget.dataset.url;
        var a = e.currentTarget.dataset.imagefilename, t = e.currentTarget.dataset.materialcode, s = [], o = this.data.uploadDetails.find(function(e) {
            return e.materialCode === t;
        }), r = null;
        for (var n in o.compressAndNormalImages) a === o.compressAndNormalImages[n].imageFileName && (r = o.compressAndNormalImages[n].normalImageStream), 
        s.push(o.compressAndNormalImages[n].normalImageStream);
        wx.previewImage({
            current: r,
            urls: s
        });
    },
    prevSample: function(e) {
        var a = this;
        wx.showLoading(), a.setData({
            sampleDescriptionList: [],
            noneSampleData: !1
        }), wx.request({
            url: o.getSer(s.globalData.userInfo.nickName).lcloud_url + s.newCommonUrl + "queryUploadMaterialSampleImage?access_token=" + s.tokens.access_token + "&request_id=" + o.uuid(),
            method: "POST",
            data: {
                materialCode: e.currentTarget.dataset.materialcode,
                registerNo: a.data.registerNo
            },
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: s.loginAuthorization
            },
            success: function(e) {
                wx.hideLoading(), "crs-00001" === e.data.returnCode ? a.setData({
                    sampleDescriptionList: a.sampleImgToBase64(e.data.data),
                    noneSampleData: 0 === e.data.data.length,
                    hiddenMoadl: !1
                }) : s.showToast(a, e.data.message || "请求异常");
            },
            fail: function(t) {
                s.showToast(a, e.data.message || "请求异常"), reject(t);
            }
        });
    },
    sampleImgToBase64: function(e) {
        for (var a in e) e[a].materialImageStream = "data:image/jpg;base64," + e[a].materialImageStream;
        return e;
    },
    setSampleOfsampleDescription: function(e) {
        var a = new Map();
        for (var t in e) a.set(e[t].materialCode, this.getSampleOfsampleDescription(e[t].materialCode));
        this.setData({
            tipsTextList: this.strMapToObj(a)
        });
    },
    strMapToObj: function(t) {
        var s, o = Object.create(null), r = a(t);
        try {
            for (r.s(); !(s = r.n()).done; ) {
                var n = e(s.value, 2), i = n[0], l = n[1];
                o[i] = l;
            }
        } catch (e) {
            r.e(e);
        } finally {
            r.f();
        }
        return o;
    },
    getSampleOfsampleDescription: function(e) {
        console.log("code", e);
        var a = [];
        for (var s in t.sampleDescription) {
            var o = t.sampleDescription[s].materialCode.indexOf(e);
            if (console.log(o), o >= 0) {
                console.log("说明****", t.sampleDescription[s].description), a = t.sampleDescription[s].description;
                break;
            }
        }
        return a;
    },
    returnPrev: function(e) {
        wx.navigateBack({
            delta: 1
        });
    },
    closeModal: function(e) {
        this.setData({
            hiddenMoadl: !0
        });
    }
});
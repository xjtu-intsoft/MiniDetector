var e, t = require("../../@babel/runtime/helpers/defineProperty"), a = require("../../9A41035384CF379CFC276B5474025043.js"), s = getApp();

console.log("app", s);

var i = require("../../7D41315784CF379C1B2759508F425043.js"), o = require("../../BA4681C684CF379CDC20E9C1FBE15043.js"), n = new Date(), r = i.formatDate(new Date(n)), d = {
    insuredName: "",
    insuredIdNo: "",
    insuredNameStar: "",
    insuredIdNoStar: "",
    queryType: "",
    queryTypeArr: [ "1", "2", "0", "A" ],
    queryTypeDesArr: [ "身份证", "护照", "户口本", "出生证" ],
    queryTypeIdx: 0,
    imageArrow1: "../../pages/images/new/down.png",
    imageArrow: "../../pages/images/new/right.png",
    isRequest: !1,
    showDetail: !0,
    reporterName: "",
    reporterCellPhone: "",
    hiddenToast: !0,
    mesg: "",
    casereporterlist: [],
    caseReporterTypeList: [],
    caseReporterDesList: [],
    caseReporterTypeIndex: 0,
    insuredRelationList: [],
    insuredRelationTypeList: [],
    insuredRelationcDesList: [],
    insuredRelationIndex: 0,
    deathHidden: !0,
    clientCauseList: [],
    clientStatusDesList: [],
    clientStatusCodeList: [],
    clientStatusIndex: 0,
    clientStatusWithStageList: [],
    clientStatusStageCodeList: [],
    clientStatusStageDesList: [],
    clientStatusStageIndex: 3,
    maxDate: r,
    deathDateData: r,
    region: [ "广东省", "深圳市", "福田区" ],
    regionStr: "",
    accidentPlace: "",
    comment: "",
    isOverSea: "N",
    isOverSeaList: [ {
        value: "N",
        name: "否",
        checked: !0
    }, {
        value: "Y",
        name: "是",
        checked: !1
    } ],
    accidengDesc: "",
    hospitalCode: "",
    hospitalName: "",
    hospitalArr: [],
    diagnosis: "",
    registerNo: "",
    isAdvancePayFlag: "",
    isShowAdvancePay: !0,
    isFreeDepositFlag: "",
    isShowFreeDeposit: !0,
    isNoticePolicyServicePersonFlag: "",
    hiddenPolicyServicePerson: !0,
    chooseEmpNo: "",
    chooseEmpRegion: "",
    policyServicePersonList: []
};

Page((t(e = {
    data: d,
    onLoad: function() {
        var e = this;
        wx.showLoading({
            title: "页面加载中",
            mask: !0
        }), s.globalData ? (console.log("nickName", s.globalData.nickName), wx.hideLoading()) : s.userDataCallback = function(t) {
            console.log("nickName", t.userInfo.nickName), e.initSkyapp(t.userInfo.nickName), 
            wx.hideLoading();
        };
    },
    onShow: function() {
        a.onShow(), s.wxCode.openid && (wx.hideLoading(), this.setData(d), console.log("nickName", s.globalData.userInfo.nickName), 
        this.initSkyapp(s.globalData.userInfo.nickName), this.setData({
            wxCode: s.wxCode.code,
            wechatid: s.wxCode.openid,
            userInfo: s.globalData
        }));
    },
    onHide: function() {
        a.onHide();
    },
    initSkyapp: function(e) {
        for (var t in s.SKAPPObj) Array.from(s.SKAPPObj[t], function(t) {
            t.params.pad_userid = e;
        });
        a.onEvent(s.SKAPPObj.report[0].id, s.SKAPPObj.report[0].label, s.SKAPPObj.report[0].params);
    },
    initData: function(e) {
        console.log("init data", e), this.setData({
            clientCauseList: e.clientStatusList,
            reporterTypeList: e.reporterTypeList,
            relationInReporterInsuredList: e.relationInReporterInsuredList,
            deathCauseList: e.deathCauseList,
            caseCauseList: e.caseCauseList,
            graveAccidentList: e.graveAccidentList
        }), this.setData({
            clientStatusCodeList: i.resetArray(this.data.clientCauseList, "clientStatus"),
            clientStatusIndex: i.resetArray(this.data.clientCauseList, "clientStatus").indexOf("14"),
            clientStatusDesList: i.resetArray(this.data.clientCauseList, "description"),
            caseReporterTypeList: i.resetArray(this.data.reporterTypeList, "caseReporterType"),
            caseReporterDesList: i.resetArray(this.data.reporterTypeList, "description"),
            insuredRelationTypeList: i.resetArray(this.data.relationInReporterInsuredList, "relationship"),
            insuredRelationcDesList: i.resetArray(this.data.relationInReporterInsuredList, "description")
        }), this.setData({
            clientStatusStageDesList: i.resetArray(i.getClientStatusWithStage(this.data.clientCauseList, this.data.clientStatusCodeList[this.data.clientStatusIndex]), "description"),
            clientStatusStageCodeList: i.resetArray(i.getClientStatusWithStage(this.data.clientCauseList, this.data.clientStatusCodeList[this.data.clientStatusIndex]), "statusStage")
        }), "01" == this.data.clientStatusCodeList[this.data.clientStatusIndex] ? (this.setData({
            deathHidden: !0
        }), this.setData({
            deathCauseDescList: i.resetArray(this.data.deathCauseList, "description"),
            deathCauseTypeList: i.resetArray(this.data.deathCauseList, "deathCause")
        })) : this.setData({
            deathHidden: !1
        });
    },
    inputInsuredName: function(e) {
        var t = e.detail.value, a = t.substr(0, 1) + new Array(t.substr(1).length + 1).join("*");
        this.setData({
            insuredName: t,
            insuredNameStar: a
        });
    },
    inputInsuredIdNo: function(e) {
        var t = e.detail.value, a = t.substr(0, 4) + new Array(t.substr(1).length + 1).join("*");
        this.setData({
            insuredIdNo: t,
            insuredIdNoStar: a
        });
    },
    bindChangeQueryType: function(e) {
        this.setData({
            queryTypeIdx: e.detail.value
        });
    },
    applyReport: function(e) {
        var t = this;
        if ("" != e.detail.value.insuredName) if (e.detail.value.insuredIdNo) if ("" != e.detail.value.insuredName || "" != e.detail.value.insuredIdNo) {
            if (!t.data.isRequest) {
                a.onEvent(s.SKAPPObj.report[1].id, s.SKAPPObj.report[1].label, s.SKAPPObj.report[1].params), 
                t.setData({
                    isRequest: !0
                });
                e.detail.value;
                var n = new o.RSAKey(), r = s.globalRsaObj.n, d = s.globalRsaObj.a;
                n.setPublic(r, d);
                var l = e.detail.value.insuredName, c = e.detail.value.insuredIdNo, u = e.detail.value.queryType, h = {
                    insuredName: n.encrypt(l),
                    insuredIdNo: n.encrypt(c),
                    queryType: u
                };
                console.log("formData>>>>>>>>>>>", h);
                var p = i.getSer().lcloud_url + s.newCommonUrl + "checkClientInfo?access_token=" + s.tokens.access_token + "&request_id=" + i.uuid();
                wx.request({
                    url: p,
                    data: h,
                    method: "POST",
                    header: {
                        "Content-Type": "application/json",
                        Charset: "utf-8",
                        loginAuthorization: s.loginAuthorization
                    },
                    success: function(e) {
                        console.log("理赔报案用户校验结果", e), "crs-00001" == e.data.returnCode ? (s.tokenKey = e.data.data.tokenKey, 
                        t.setData({
                            showDetail: !1
                        }), t.queryClaimRegister(e.data.data)) : t.showToast(!1, e.data.message);
                    },
                    fail: function() {
                        t.showToast(!1, "查询失败，请重新确认信息！");
                    },
                    complete: function() {
                        t.setData({
                            isRequest: !1
                        });
                    }
                });
            }
        } else this.showToast(!1, "请输入姓名/证件号码！"); else this.showToast(!1, "请输入正确的证件号码！"); else this.showToast(!1, "请输入姓名！");
    },
    queryClaimRegister: function(e) {
        var t = this, a = i.getSer().lcloud_url + "/open/appsvr/life/new-esg-version/LCLOUD-CLAIM-CRS/WeChatClaim/queryClaimRegisterAccidentInfo?access_token=" + s.tokens.access_token + "&request_id=" + i.uuid(), o = {
            tokenKey: s.tokenKey
        };
        wx.request({
            url: a,
            data: o,
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: s.loginAuthorization
            },
            success: function(e) {
                if (console.log("query res>>>>", e), "crs-00001" == e.data.returnCode) {
                    if (t.initData(e.data.data), "Y" == e.data.data.isExistHighMedicalFlag) {
                        s.showToast(t, "温馨提示：该客户保单项下包含臻享医疗保险产品，如本次申请医疗费用赔付，根据险种条款中预申请相关约定，拟接受下列医疗项目前，应于检查或治疗前至少2天提出预申请（紧急情况下，需在开始接受下列医疗项目后48小时之内）。请及时通过金管家APP，或拨打服务热线95511进行预申请，谢谢。（1）单价大于5000元的单项检查；（2）所有住院治疗；（3）全麻门诊手术。");
                    }
                } else t.showToast(!1, e.data.message);
            },
            fail: function() {}
        });
    },
    rewrite: function() {
        this.setData({
            showDetail: !0
        });
    },
    checkReporterCellPhone: function(e) {
        var t = new RegExp("1[3|4|5|7|8][0-9]{9}", "g");
        "" == e.detail.value || null == e.detail.value ? this.showToast(!1, "联系电话不能为空！") : null == t.exec(e.detail.value) && this.showToast(!1, "联系电话输入有误！");
    },
    inputName: function(e) {
        this.setData({
            reporterName: e.detail.value
        });
    },
    inputPhone: function(e) {
        this.setData({
            reporterCellPhone: e.detail.value
        });
    },
    checkPhone: function(e) {
        var t = new RegExp("1[3|4|5|7|8][0-9]{9}", "g");
        "" == e.detail.value || null == e.detail.value ? this.showToast(!1, "联系电话不能为空！") : null == t.exec(e.detail.value) && this.showToast(!1, "联系电话输入有误！");
    },
    bindChangeCaseReporterType: function(e) {
        this.setData({
            caseReporterTypeIndex: e.detail.value
        });
    },
    bindChangeInsuredRelationType: function(e) {
        this.setData({
            insuredRelationIndex: e.detail.value
        });
    },
    bindChangeClientStatus: function(e) {
        this.setData({
            clientStatusIndex: e.detail.value
        }), console.log("that.data.clientStatusWithStageList", this.data.clientStatusWithStageList), 
        this.setData({
            clientStatusStageDesList: i.resetArray(i.getClientStatusWithStage(this.data.clientCauseList, this.data.clientStatusCodeList[this.data.clientStatusIndex]), "description"),
            clientStatusStageCodeList: i.resetArray(i.getClientStatusWithStage(this.data.clientCauseList, this.data.clientStatusCodeList[this.data.clientStatusIndex]), "statusStage")
        }), "01" == this.data.clientStatusCodeList[this.data.clientStatusIndex] ? (this.setData({
            deathHidden: !0
        }), this.setData({
            deathCauseDescList: i.resetArray(this.data.deathCauseList, "description"),
            deathCauseTypeList: i.resetArray(this.data.deathCauseList, "deathCause")
        })) : this.setData({
            deathHidden: !1
        });
    },
    bindChangeClientStatusStage: function(e) {
        this.setData({
            clientStatusStageIndex: e.detail.value
        });
    },
    bindChangeAccidentDate: function(e) {
        this.setData({
            accidentDateData: e.detail.value
        });
    },
    bindChangeDeathDate: function(e) {
        this.setData({
            deathDateData: e.detail.value
        });
    },
    bindChangeDeathCause: function(e) {
        this.setData({
            deathCauseIndex: e.detail.value
        });
    },
    bindRegionChange: function(e) {
        this.setData({
            region: e.detail.value
        }), -1 != e.detail.value[0].indexOf("市") && e.detail.value.splice(1, 1), this.setData({
            regionStr: e.detail.value.toString().replace(/,/g, "/")
        });
    },
    radioChange: function(e) {
        this.setData({
            isOverSea: e.detail.value
        });
    },
    checkAccidentDesc: function(e) {
        "" != e.detail.value && null != e.detail.value || this.showToast(!1, "出险经过不能为空！");
    },
    inputDiagnosis: function(e) {
        this.setData({
            diagnosis: e.detail.value
        });
    },
    searchHospital: function(e) {
        var t = this, a = e.detail.value;
        console.log("hospitalName", a);
        var o = {
            hospitalKeyWord: e.detail.value
        }, n = i.getSer(s.globalData.userInfo.nickName).lcloud_url + s.newCommonUrl + "queryClaimHospitalList?access_token=" + s.tokens.access_token + "&request_id=" + i.uuid();
        wx.cloud.callFunction({
            name: "checkUser",
            data: {
                url: n,
                data: o
            },
            success: function(e) {
                var a = JSON.parse(e.result);
                console.log("resData", a), "crs-00001" == a.returnCode ? t.setData({
                    hospitalArr: a.data
                }) : t.showToast(!1, a.message);
            },
            fail: console.error
        });
    },
    choseHospital: function(e) {
        console.log("选择医院", e);
        var t = e.target.dataset.item;
        this.setData({
            hospitalCode: t.hospitalCode,
            hospitalName: t.hospitalName,
            hospitalArr: []
        });
    },
    submitReport: function(e) {
        var t = e.detail.value, o = t.reporterCellPhone;
        if (console.log("formData", t), "" == t.reporterName) this.showToast(!1, "请输入报案人姓名!"); else if ("" != o && i.checkMobilePhone(o)) if ("" == t.clientStatus || "" == t.clientStatusStage) this.showToast(!1, "请选择事故者状况!"); else if ("" == t.accidentDate) this.showToast(!1, "请选择出险时间!"); else if (this.data.deathHidden && "" == t.deathDate) this.showToast(!1, "请选择死亡时间!"); else if (this.data.deathHidden && "" == t.deathCause) this.showToast(!1, "请选择死亡原因!"); else if ("" == t.regionStr) this.showToast(!1, "请选择出险地点!"); else if ("" == t.accidentPlace) this.showToast(!1, "请输入出险详址!"); else if ("" == t.accidengDesc) this.showToast(!1, "请输入出险经过!"); else if ("" == t.diagnosis) this.showToast(!1, "请输入临床诊断!"); else if (0 == t.caseCauseList.length) this.showToast(!1, "请选择申请原因!"); else {
            t.accidentPlace = i.trimIllegal(t.accidentPlace), t.accidengDesc = i.trimIllegal(t.accidengDesc), 
            t.comment = i.trimIllegal(t.comment), wx.showLoading({
                title: "提交中。。。",
                mask: !0
            });
            var n = this.data.regionStr;
            t.accidentPlace = n + "," + t.accidentPlace, a.onEvent(s.SKAPPObj.report[2].id, s.SKAPPObj.report[2].label, s.SKAPPObj.report[2].params), 
            this.submitData(t);
        } else this.showToast(!1, "请输入合法的电话号码!");
    },
    submitData: function(e) {
        console.log("formData", e);
        var t = this, a = {
            registerSubmitDetailInfo: {
                accidentAddress: e.accidentPlace,
                accidentDate: e.accidentDate,
                accidentDetail: e.accidengDesc,
                caseCause: e.caseCauseList,
                clientStatus: e.clientStatus,
                clientStatusStage: e.clientStatusStage,
                comment: e.comment,
                deathCause: e.deathCause,
                deathDate: e.deathDate,
                graveAccident: e.graveAccidentList,
                hospitalCode: e.hospitalCode,
                hospitalName: e.hospitalName,
                isOverSea: e.isOverSea,
                relationInReporterInsured: e.insuredRelationType,
                reporterCellPhone: e.reporterCellPhone,
                reporterName: e.reporterName,
                reporterType: e.caseReporterType,
                diseaseList: [ {
                    diagnosis: t.data.diagnosis,
                    diseaseCode: t.data.diseaseCode,
                    diseaseName: t.data.diseaseName
                } ]
            },
            tokenKey: s.tokenKey,
            weChatId: s.wxCode.openid,
            weChatName: "string"
        }, o = i.getSer().lcloud_url + s.newCommonUrl + "submitRegisterInfo?access_token=" + s.tokens.access_token + "&request_id=" + i.uuid();
        wx.request({
            url: o,
            data: a,
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: s.loginAuthorization
            },
            success: function(e) {
                console.log("submitRegisterInfo res>>>>", e), "crs-00001" == e.data.returnCode ? (t.setData({
                    registerNo: e.data.data.registerNo,
                    isAdvancePayFlag: e.data.data.isAdvancePayFlag,
                    isFreeDepositFlag: e.data.data.isFreeDepositFlag,
                    isNoticePolicyServicePersonFlag: e.data.data.isNoticePolicyServicePersonFlag,
                    policyServicePersonList: e.data.data.policyServicePersonList
                }), "Y" == e.data.data.isAdvancePayFlag ? t.setData({
                    isShowAdvancePay: !1
                }) : "Y" == e.data.data.isNoticePolicyServicePersonFlag ? t.setData({
                    hiddenPolicyServicePerson: !1
                }) : t.setData({
                    isShowFreeDeposit: !1
                })) : t.showToast(!1, e.data.message);
            },
            fail: function() {},
            complete: function() {
                wx.hideLoading();
            }
        });
    }
}, "checkPhone", function(e) {
    return new RegExp("1[3|4|5|7|8][0-9]{9}", "g").test(e);
}), t(e, "closePolicyService", function() {
    this.setData(d);
}), t(e, "policyServiceChange", function(e) {
    console.log("保单服务人员value", e.detail.value), this.setData({
        chooseEmpNo: e.detail.value
    });
    var t, a = e.detail.value, s = this.data.policyServicePersonList;
    for (var i in s) s[i].agentNo == a && (t = s[i].agentRegion);
    this.setData({
        chooseEmpRegion: t
    });
}), t(e, "cancelNotice", function() {
    this.setData(d);
}), t(e, "ensureNotice", function() {
    if ("" != this.data.chooseEmpNo) {
        var e = {
            chooseEmpNo: this.data.chooseEmpNo,
            chooseEmpRegion: this.data.chooseEmpRegion,
            chooseOperationType: "notice",
            registerNo: this.data.registerNo,
            tokenKey: s.tokenKey,
            requestModule: "register"
        };
        this.notice(e), this.setData(d);
    } else this.showToast(!1, "请勾选一位保单服务人员!");
}), t(e, "notice", function(e) {
    var t = i.getSer(s.globalData.userInfo.nickName).lcloud_url + s.newCommonUrl + "choosePolicyServicePersonOperationCase?access_token=" + s.tokens.access_token + "&request_id=" + i.uuid();
    wx.request({
        url: t,
        data: e,
        method: "POST",
        header: {
            "Content-Type": "application/json",
            Charset: "utf-8",
            loginAuthorization: s.loginAuthorization
        },
        success: function(e) {},
        fail: function() {}
    });
}), t(e, "closeModal", function() {
    this.setData(d);
}), t(e, "chooseIsApplyFreedeposit", function() {
    var e = this, t = {
        isChooseFreedeposit: "Y",
        registerNo: e.data.registerNo,
        systemId: s.systemId.advancepay,
        tokenKey: s.tokenKey
    }, a = i.getSer(s.globalData.userInfo.nickName).lcloud_url + s.newCommonUrl + "chooseIsApplyFreedeposit?access_token=" + s.tokens.access_token + "&request_id=" + i.uuid();
    wx.request({
        url: a,
        data: t,
        method: "POST",
        header: {
            "Content-Type": "application/json",
            Charset: "utf-8",
            loginAuthorization: s.loginAuthorization
        },
        success: function(t) {
            if ("crs-00001" == t.data.returnCode) {
                var a = t.data.data;
                e.setData({
                    encryptInsuredNo: a.encryptInsuredNo,
                    insuredName: a.insuredName,
                    insuredPhone: a.insuredPhone,
                    notFreeDepositSignature: a.notFreeDepositSignature
                }), e.goDeposit();
            } else e.showToast(!1, t.data.message);
        },
        fail: function() {}
    });
}), t(e, "goDeposit", function() {
    var e = this.data.registerNo, t = this.data.notfreedepositsignature, a = this.data.encryptInsuredNo, s = this.data.insuredPhone;
    "Y" == t ? wx.navigateTo({
        url: "/pages/checkAndCode/checkAndCode?encryptInsuredNo=" + a + "&insuredPhone=" + s + "&registerNo=" + e
    }) : wx.navigateTo({
        url: "/pages/freeDeposit/freeDeposit?registerNo=" + e + "&accClientNo=" + a
    });
}), t(e, "closePopTips", function() {
    this.setData(d);
}), t(e, "closeAdvancePay", function() {
    this.isApplyAndvancepay(this.data.registerNo, "N"), this.setData(d);
}), t(e, "goAdvancePay", function() {
    var e = this.data.registerNo;
    wx.navigateTo({
        url: "/pages/advancePay/advancePay?registerNo=" + e + "&tokenKey=" + s.tokenKey
    }), this.isApplyAndvancepay(e, "Y");
}), t(e, "isApplyAndvancepay", function(e, t) {
    var a = {
        isChooseAdvancePay: t,
        registerNo: e,
        systemId: s.systemId.advancepay,
        tokenKey: s.tokenKey
    }, o = i.getSer(s.globalData.userInfo.nickName).lcloud_url + s.newCommonUrl + "chooseIsApplyAdvancePay?access_token=" + s.tokens.access_token + "&request_id=" + i.uuid();
    wx.request({
        url: o,
        data: a,
        method: "POST",
        header: {
            "Content-Type": "application/json",
            Charset: "utf-8",
            loginAuthorization: s.loginAuthorization
        },
        success: function(e) {},
        fail: function() {}
    });
}), t(e, "showToast", function(e, t) {
    var a = this;
    a.setData({
        hiddenToast: !1,
        mesg: t
    }), setTimeout(function() {
        a.setData({
            hiddenToast: !0
        });
    }, 2e3);
}), e));
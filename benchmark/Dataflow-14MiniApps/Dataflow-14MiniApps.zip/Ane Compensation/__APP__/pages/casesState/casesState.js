var e = getApp(), t = require("../../7D41315784CF379C1B2759508F425043.js"), o = require("../../9A41035384CF379CFC276B5474025043.js");

Page({
    data: {
        registerNo: "",
        Loadinghidden: !0,
        img: [ "../../pages/images/icon_circle.png", "../../pages/images/icon_circle_1.png" ],
        caseStateList: []
    },
    onLaunch: function() {},
    onLoad: function(e) {
        this.setData({
            Loadinghidden: !1,
            registerNo: e.registerNo
        }), console.log(this.data.registerNo);
    },
    onShow: function() {
        o.onShow(), o.onEvent(e.SKAPPObj.process[2].id, e.SKAPPObj.process[2].label, e.SKAPPObj.process[2].params);
        var a = this, s = {
            registerNo: a.data.registerNo
        }, i = t.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "queryCaseClaimProgressCaseStateProcess?access_token=" + e.tokens.access_token + "&request_id=" + t.uuid();
        wx.request({
            url: i,
            data: s,
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: e.loginAuthorization
            },
            success: function(t) {
                if (console.log("案件状态", t), "crs-00001" == t.data.returnCode) {
                    var o = t.data.data;
                    o.reverse(), a.setData({
                        caseStateList: o,
                        Loadinghidden: !0,
                        userInfo: e.globalData
                    });
                }
            },
            fail: function() {}
        });
    },
    onHide: function() {
        o.onHide();
    }
});
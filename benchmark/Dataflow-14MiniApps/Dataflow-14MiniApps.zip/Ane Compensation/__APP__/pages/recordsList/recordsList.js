var e, t, a, o = getApp(), s = require("../../7D41315784CF379C1B2759508F425043.js"), n = require("../../9A41035384CF379CFC276B5474025043.js"), i = require("../../BA4681C684CF379CDC20E9C1FBE15043.js"), l = new Date(), r = s.formatDate(new Date(l));

function c(e, t) {
    "N" == o.baseData.isPrivilege && (t.validateSmsCodeKey = o.baseData.validateSmsCodeKey), 
    console.log("app.baseData", o.baseData), console.log("data", t);
    var a = s.getSer(o.globalData.userInfo.nickName).lcloud_url + o.newCommonUrl + "queryClaimAcceptUnCompleteCaseList?access_token=" + o.tokens.access_token + "&request_id=" + s.uuid();
    wx.request({
        url: a,
        data: t,
        method: "POST",
        header: {
            "Content-Type": "application/json",
            Charset: "utf-8",
            loginAuthorization: o.loginAuthorization
        },
        success: function(t) {
            wx.hideLoading(), console.log("res list>>>", t), "crs-00001" == t.data.returnCode ? e.setData({
                reports: t.data.data.registerCaseList
            }) : o.showToast(e, t.data.message);
        },
        fail: function() {
            wx.hideLoading();
        }
    });
}

Page({
    data: {
        maxDate: r,
        page: 1,
        size: 20,
        hasMore: !1,
        hasRefesh: !1,
        scrollTop: 0,
        scr_height: 0,
        arrow: "../../pages/images/icon_arrow_1.png",
        hiddenToast: !0,
        showMsg: "",
        accClientName: "",
        accClientNo: "",
        weChatId: "",
        notiDateStart: s.formatDate(new Date(l.getTime() - 7776e6)),
        notiDateEnd: r,
        reports: [],
        reportsFlag: 0,
        hiddenPrivilege: !0,
        goDetailFlag: !1
    },
    onLoad: function(e) {
        this.setData({
            accClientNo: o.baseData.accClientNo
        }), wx.showLoading({
            title: "加载中..."
        }), this.getBaseData();
    },
    onShow: function() {
        n.onShow(), n.onEvent(o.SKAPPObj.onlineApply[2].id, o.SKAPPObj.onlineApply[2].label, o.SKAPPObj.onlineApply[2].params);
        var e = wx.getSystemInfoSync();
        console.log("app", o.baseData), this.setData({
            accClientNo: o.baseData.accClientNo,
            scr_height: e.windowHeight - 79,
            weChatId: o.wxCode.openid,
            userInfo: o.globalData
        });
        var t = {
            tokenKey: o.tokenKey,
            unCompleteDate: {
                reporterStartDate: this.data.notiDateStart,
                reporterEndDate: this.data.notiDateEnd
            }
        };
        "Y" == o.baseData.isPrivilege ? this.setData({
            hiddenPrivilege: !1
        }) : this.setData({
            hiddenPrivilege: !0
        }), c(this, t);
    },
    onHide: function() {
        n.onHide();
    },
    setRsa: function() {
        e = new i.RSAKey(), a = o.globalRsaObj.a, t = o.globalRsaObj.n, e.setPublic(t, a);
    },
    initData: function(e) {
        this.setData({
            reportsFlag: e
        });
    },
    bindChangeNotiDateStart: function(e) {
        this.setData({
            notiDateStart: e.detail.value
        }), s.compareDate(this.data.notiDateStart, this.data.notiDateEnd) && o.showToast(this, "开始时间不能大于结束时间");
    },
    bindChangeNotiDateEnd: function(e) {
        this.setData({
            notiDateEnd: e.detail.value
        }), s.compareDate(this.data.notiDateStart, this.data.notiDateEnd) && o.showToast(this, "结束时间不能小于开始时间");
    },
    queryRecordList: function(e) {
        e.detail.value.tokenKey = o.tokenKey;
        s.compareDate(e.detail.value.notiDateStart, e.detail.value.notiDateEnd) ? o.showToast(this, "结束时间不能小于开始时间") : (wx.showLoading({
            title: "加载中..."
        }), c(this, {
            tokenKey: o.tokenKey,
            unCompleteDate: {
                reporterStartDate: this.data.notiDateStart,
                reporterEndDate: this.data.notiDateEnd
            }
        }));
    },
    gotoRecordDetail: function(e) {
        n.onEvent(o.SKAPPObj.onlineApply[3].id, o.SKAPPObj.onlineApply[3].label, o.SKAPPObj.onlineApply[3].params), 
        console.log("e", e);
        var t = e.currentTarget.dataset.item;
        o.baseData.accClientNo = t.insuredNo, "" == t.caseTips ? "Y" != t.isCancelAgentAuth ? this.data.goDetailFlag || (this.setData({
            goDetailFlag: !0
        }), this.queryDetail(t)) : this.cancelAgentAuth(t) : o.showToast(this, t.caseTips);
    },
    cancelAgentAuth: function(e) {
        console.log("item", e);
        var t = this;
        wx.showModal({
            title: "温馨提示",
            content: "您好，该案件已通知服务人员".concat(e.cancelAgentAuthName, "跟进服务，可联系服务人员进行代办，请问是否继续操作？"),
            showCancel: !0,
            success: function(a) {
                console.log("success res", a), a.confirm && console.log("点击确定"), a.cancel && (console.log("点击取消"), 
                t.cancelAgentStatus(e));
            },
            fail: function(e) {},
            complete: function() {}
        });
    },
    cancelAgentStatus: function(e) {
        var t = {
            chooseEmpNo: e.cancelAgentNo,
            chooseEmpRegion: e.cancelAgentRegion,
            chooseOperationType: "cancel",
            registerNo: e.registerNo,
            tokenKey: o.tokenKey
        }, a = s.getSer(o.globalData.userInfo.nickName).lcloud_url + o.newCommonUrl + "choosePolicyServicePersonOperationCase?access_token=" + o.tokens.access_token + "&request_id=" + s.uuid();
        wx.request({
            url: a,
            data: t,
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: o.loginAuthorization
            },
            success: function(t) {
                wx.hideLoading(), console.log("res list>>>", t), "crs-00001" == t.data.returnCode ? wx.navigateTo({
                    url: "/pages/recordDetail/recordDetail?regsNo=" + e.registerNo + "&type=1"
                }) : that.showToast(that, t.data.message);
            },
            fail: function() {
                wx.hideLoading();
            }
        });
    },
    queryDetail: function(e) {
        var t = this, a = e.insuredNo, n = e.registerNo;
        wx.request({
            url: s.getSer(t.data.userInfo.userInfo.nickName).ser_url + "/open/appsvr/life/queryUnCompleteClaimDetail?access_token=" + o.tokens.access_token + "&request_id=" + s.uuid(),
            data: {
                regsNo: n,
                accClientNo: a,
                weChatId: t.data.weChatId,
                tokenKey: o.tokenKey
            },
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8"
            },
            success: function(e) {
                s.decodeJson(e), console.log("res", e), t.setData({
                    goDetailFlag: !1
                }), "life-10004" == e.data.returnCode ? o.showToast(t, e.data.message) : "life-10008" == e.data.returnCode ? wx.showModal({
                    title: "提示",
                    content: "本案件为预赔案件,是否终止预赔申请正式理赔",
                    success: function(e) {
                        e.confirm ? t.isApplyAndvancepay(e.data.advancePayRegisteNo, "N") : e.cancel && o.showToast(t, "请完成预赔申请后再进行正式理赔申请");
                    }
                }) : wx.navigateTo({
                    url: "/pages/recordDetail/recordDetail?regsNo=" + n + "&type=1"
                });
            },
            fail: function(e) {
                o.showToast(t, "请求失败"), t.setData({
                    goDetailFlag: !1
                });
            }
        });
    },
    isApplyAndvancepay: function(e, t) {
        var a = {
            isChooseAdvancePay: t,
            registerNo: e,
            systemId: o.systemId.advancepay,
            tokenKey: o.tokenKey
        }, n = s.getSer(o.globalData.userInfo.nickName).lcloud_url + o.newCommonUrl + "chooseIsApplyAdvancePay?access_token=" + o.tokens.access_token + "&request_id=" + s.uuid();
        wx.request({
            url: n,
            data: a,
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: o.loginAuthorization
            },
            success: function(t) {
                wx.navigateTo({
                    url: "/pages/recordDetail/recordDetail?regsNo=" + e + "&type=1"
                });
            },
            fail: function() {}
        });
    },
    getBaseData: function() {
        var e = this;
        console.log("app.wxCode.openid", o.wxCode.openid), wx.request({
            url: s.getSer(o.globalData.userInfo.nickName).ser_url + "/open/appsvr/life/getIdentifyCode?access_token=" + o.tokens.access_token + "&request_id=" + s.uuid(),
            data: {
                type: "1",
                weChatId: o.wxCode.openid
            },
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8"
            },
            success: function(e) {
                console.log("res", e), s.decodeJson(e), o.baseData.applyreasonlist = e.data.applyreasonlist, 
                o.baseData.casereporterlist = e.data.casereporterlist, o.baseData.clientstatuslist = e.data.clientstatuslist, 
                o.baseData.clientstatuswithstagelist = e.data.clientstatuswithstagelist, o.baseData.deathcauselist = e.data.deathcauselist, 
                o.baseData.graveaccidentlist = e.data.graveaccidentlist, o.baseData.insuredrelationlist = e.data.insuredrelationlist, 
                o.baseData.subjectlist = e.data.subjectlist, o.baseData.idTypeDesList = e.data.idtypelist, 
                o.baseData.otherinsurerlist = e.data.otherinsurerlist, o.baseData.claimTaxReasonList = e.data.claimtaxreasonlist, 
                o.baseData.isoCountryInfoList = e.data.isocountryinfolist;
            },
            fail: function(t) {
                console.log("err", t), o.showToast(e, "查询信息失败");
            }
        });
    },
    closeModal: function(e) {
        this.setData({
            hiddenPrivilege: !0
        });
    }
});
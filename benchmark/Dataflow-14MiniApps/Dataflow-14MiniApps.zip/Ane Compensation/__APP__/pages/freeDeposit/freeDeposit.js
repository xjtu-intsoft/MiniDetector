var e, t, a, o, n = require("../../@babel/runtime/helpers/defineProperty"), i = getApp(), s = require("../../7D41315784CF379C1B2759508F425043.js"), c = require("../../BA4681C684CF379CDC20E9C1FBE15043.js"), l = require("../../2A98DAA084CF379C4CFEB2A7BE815043.js"), r = require("../../F2E3964184CF379C9485FE465AD15043.js");

Page({
    data: (e = {
        text: "请投保人李明签字",
        hidden: !0,
        showView: !0,
        bgUrl: "../../pages/images/newSignBg.png",
        bgTips: "../../pages/images/tips.png",
        bgPicture: "../../pages/images/profilePicture.png",
        examplePageIshow: !1,
        clearBgUrl: "../../pages/images/icon_default_up.png",
        clearIcon: "../../pages/images/new_clear_icon.png",
        registerNo: "",
        guildPageIsshow: !0,
        radioIsCheck: !1,
        hideinstructone: !0,
        hideinstructtwo: !0,
        hideinstructthree: !0,
        hideinstructfour: !0,
        isAllChecked: !1,
        toastMeg: "请选择住院押金减免规则、郑重提示、服务授权和用户授权协议",
        hiddenToast: !0
    }, n(e, "showView", !0), n(e, "imageUrl", ""), n(e, "clientPhotoImageStream", ""), 
    n(e, "electronicSignatureImageStream", ""), n(e, "electronicSignatureEncryptStream", ""), 
    e),
    onLoad: function(e) {
        console.log("options", e), this.setData({
            registerNo: e.registerNo
        }), console.log("onload------", e);
    },
    setRsa: function() {
        t = new c.RSAKey(), a = i.globalRsaObj.n, o = i.globalRsaObj.a, t.setPublic(a, o);
    },
    radioChange: function(e) {
        this.data.radioIsCheck || this.setData({
            radioIsCheck: !0,
            isAllChecked: !0
        });
    },
    openInstructone: function() {
        this.setData({
            hideinstructone: !1
        });
    },
    closeInstructone: function() {
        this.setData({
            hideinstructone: !0
        });
    },
    openInstructtwo: function() {
        this.setData({
            hideinstructtwo: !1
        });
    },
    closeInstructtwo: function() {
        this.setData({
            hideinstructtwo: !0
        });
    },
    openInstructthree: function() {
        this.setData({
            hideinstructthree: !1
        });
    },
    closeInstructthree: function() {
        this.setData({
            hideinstructthree: !0
        });
    },
    openInstructfour: function() {
        this.setData({
            hideinstructfour: !1
        });
    },
    closeInstructfour: function() {
        this.setData({
            hideinstructfour: !0
        });
    },
    checkboxChange: function(e) {
        console.log("checkbox发生change事件，携带value值为：", e.detail.value);
        var t = e.detail.value.toString();
        console.log("resultVal.indexOf(one)", t.indexOf("one")), console.log("resultVal.indexOf(two)", t.indexOf("two")), 
        -1 != t.indexOf("one") && -1 != t.indexOf("two") && -1 != t.indexOf("three") && -1 != t.indexOf("four") ? this.setData({
            isAllChecked: !0
        }) : this.setData({
            isAllChecked: !1
        });
    },
    nextStep: function() {
        this.data.isAllChecked ? this.setData({
            guildPageIsshow: !1,
            examplePageIshow: !0
        }) : i.showToast(this, this.data.toastMeg);
    },
    take_photo: function() {
        this.chooseWeixinImage();
    },
    chooseWeixinImage: function() {
        var e = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "camera" ],
            success: function(t) {
                console.log("res", t), e.uploadImgs(t.tempFilePaths[0], "01"), wx.showLoading({
                    title: "上传中..."
                });
            },
            fail: function(e) {
                console.log("选择照片取消"), wx.navigateBack({
                    delta: 1
                });
            }
        });
    },
    uploadImgs: function(e, t) {
        var a = this, o = e, n = {
            submitType: "conversion",
            fileName: o,
            weChatId: i.wxCode.openid
        }, c = s.getSer(i.globalData.userInfo.nickName).ser_ues_url + "/claim.uploadImageWechatClaim.do";
        wx.uploadFile({
            url: c,
            filePath: o,
            name: "file",
            formData: n,
            header: {
                "Content-Type": "multipart/form-data",
                Charset: "utf-8"
            },
            success: function(e) {
                console.log("客户上传自拍", e);
                var o = JSON.parse(e.data);
                console.log("resData", o), "life-00001" == o.returnCode ? "01" == t ? a.setData({
                    clientPhotoImageStream: o.filebase64code,
                    photoUploadRes: !0
                }) : "02" == t && (a.setData({
                    electronicSignatureImageStream: o.filebase64code
                }), a.signupload()) : i.showToast(a, "图片上传失败");
            },
            fail: function(e) {
                console.log("图片上传失败", e), i.showToast(a, "图片上传失败！上传图片的大小不能超过2M");
            },
            complete: function() {
                wx.hideLoading(), a.setData({
                    examplePageIshow: !1
                }), wx.showLoading({
                    title: "初始化中..."
                }), a.testAnySign();
            }
        });
    },
    signupload: function() {
        var e = this;
        wx.showLoading({
            title: "上传免押金流"
        });
        var t = {
            weChatId: i.wxCode.openid,
            weChatName: i.globalData.userInfo.nickName,
            saveClientPhotoAndElectronicSignature: {
                businessFunction: "claimFreeDeposit",
                module: "claimRegister",
                scenesId: "claimWeChat",
                registerNo: e.data.registerNo,
                clientPhotoImageStream: e.data.clientPhotoImageStream,
                electronicSignatureImageStream: e.data.electronicSignatureImageStream,
                electronicSignatureEncryptStream: e.data.electronicSignatureEncryptStream
            }
        }, a = s.getSer(i.globalData.userInfo.nickName).ser_url + i.newCommonUrl + "saveClientPhotoAndElectronicSignature?access_token=" + i.tokens.access_token + "&request_id=" + s.uuid();
        wx.request({
            url: a,
            data: t,
            method: "POST",
            header: {
                "content-type": "application/json"
            },
            dataType: "json",
            success: function(t) {
                wx.hideLoading(), console.log("电子签名上传结果", t);
                var a = t.data;
                if ("crs-00001" == a.returnCode) {
                    var o = a.data.insuredPhone, n = a.data.encryptInsuredNo, s = e.data.registerNo;
                    wx.showModal({
                        title: "提示",
                        content: "签名成功，进行短信验证",
                        showCancel: !1,
                        success: function(e) {
                            wx.navigateTo({
                                url: "/pages/checkAndCode/checkAndCode?encryptInsuredNo=" + n + "&insuredPhone=" + o + "&registerNo=" + s
                            });
                        },
                        fail: function(e) {}
                    });
                } else console.log("影像上传失败"), i.showToast(e, a.message), e.signFail();
            },
            fail: function(t) {
                console.log("图片上传失败", t), i.showToast(e, "图片上传失败！上传图片的大小不能超过2M"), e.signFail();
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    navigateBackFunc: function() {
        var e = getCurrentPages();
        e[e.length - 2].setData({
            signSuccess: !0
        }), wx.navigateBack({
            delta: 1
        });
    },
    signFail: function() {
        var e = this;
        wx.showModal({
            title: "提示",
            content: "签名失败，请重新开始",
            showCancel: !0,
            success: function(t) {
                console.log("success res", t), t.confirm && e.chooseWeixinImage(), t.cancel && wx.navigateBack({
                    delta: 1
                });
            },
            fail: function(e) {},
            complete: function() {}
        });
    },
    testAnySign: function(e) {
        if (console.log("初始化开始"), e) var t = e.currentTarget.id; else t = "112321321";
        console.log("channel", t);
        var a = this;
        (i.sigGlobalData.EncAlg = "SM2", l.init(function(e, t, o) {
            "CALLBACK_TYPE_SIGNATURE" == t && 20 == e && (wx.showLoading({
                title: "上传中..."
            }), console.log("签名图片", o), a.setData({
                imageUrl: o
            }), console.log("context_id:" + e + ";" + t + ";" + o), setTimeout(function() {
                a.testGenData();
            }, 5e3));
        }, t)) ? function(e) {
            var t = e, a = new r.signer("李明", "11011111111"), o = new r.SignRule_KeyWordV2("签名：", 50, 0, 1, 1), n = new r.SignatureConfig(a, o);
            new r.TimeTag(1, "yyMMdd hh:mm;ss");
            return n.singleWidth = 200, n.singleHeight = 200, n.penColor = "#000000", n.isTSS = !1, 
            n.signatureImgRatio = 3, n.nessesary = !0, l.addSignatureObj(t, n);
        }(20) ? l.commitConfig() ? (console.log("初始化成功"), a.testSetTemplateData()) : wx.showModal({
            title: "提示",
            content: "初始化失败！"
        }) : wx.showToast({
            title: "testAddSignatureObj error",
            duration: 2e3
        }) : wx.showToast({
            title: "init error",
            duration: 2e3
        });
    },
    testSetTemplateData: function() {
        console.log("开始设置表单数据");
        var e = this.data.registerNo;
        l.setTemplate(i.sigGlobalData.TemplateType.HTML, "<HTML></HTML>", e, "4000") ? (console.log("设置表单成功"), 
        this.testPopupDialog()) : wx.showModal({
            title: "提示",
            content: "设置表单数据失败！"
        });
    },
    testPopupDialog: function(e) {
        if (e) var t = e.currentTarget.id; else t = "20";
        l || wx.showModal({
            title: "提示",
            content: "信手书接口没有初始化！"
        });
        switch (wx.hideLoading(), l.showSignatureDialog(t, this)) {
          case "OK":
            console.log("OK");
            break;

          case "EC_API_NOT_INITED":
            console.log("信手书接口没有初始化");
            break;

          case "EC_WRONG_CONTEXT_ID":
            console.log("没有配置相应context_id的签字对象");
        }
    },
    testIsReadyToUpload: function() {
        wx.showModal({
            title: "提示",
            content: "testIsReadyToUpload:" + l.isReadyToUpload()
        });
    },
    testGenData: function() {
        if (l.isReadyToUpload()) {
            var e = l.getUploadDataGram();
            i.sigGlobalData.value = e, console.log("app.sigGlobalData.value", i.sigGlobalData.value), 
            this.setData({
                electronicSignatureEncryptStream: e
            }), this.uploadImgs(this.data.imageUrl, "02");
        } else wx.showModal({
            title: "提示",
            content: "testIsReadyToUpload:false！"
        });
    },
    canvasStart: function(e) {
        l.canvasStart(e);
    },
    canvasMove: function(e) {
        l.canvasMove(e);
    },
    canvasEnd: function(e) {
        l.canvasEnd(e);
    },
    sign_confirm: function() {
        l.sign_confirm();
    },
    clear_canvas: function() {
        l.clear_canvas();
    },
    cancel_sign: function() {
        wx.navigateBack({
            delta: 1
        });
    }
});
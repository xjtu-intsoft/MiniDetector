var e, t, a, o, n = require("../../@babel/runtime/helpers/defineProperty"), i = getApp(), s = require("../../7D41315784CF379C1B2759508F425043.js"), l = require("../../9A41035384CF379CFC276B5474025043.js"), c = require("../../BA4681C684CF379CDC20E9C1FBE15043.js"), r = require("../../2A98DAA084CF379C4CFEB2A7BE815043.js"), g = require("../../F2E3964184CF379C9485FE465AD15043.js");

Page({
    data: (e = {
        text: "请投保人李明签字",
        hidden: !0,
        showView: !0,
        bgUrl: "../../pages/images/newSignBg.png",
        bgTips: "../../pages/images/tips.png",
        bgPicture: "../../pages/images/profilePicture.png",
        examplePageIshow: !1,
        clearBgUrl: "../../pages/images/icon_default_up.png",
        clearIcon: "../../pages/images/new_clear_icon.png",
        regsNo: "",
        inferiorFlag: "",
        submitType: "",
        guildPageIsshow: !0,
        radioIsCheck: !1,
        hideinstructone: !0,
        hideinstructtwo: !0,
        hideinstructthree: !0,
        isAllChecked: !1,
        toastMeg: "请选择反保险欺诈提示、声明及授权和税收居民身份声明",
        hiddenToast: !0
    }, n(e, "showView", !0), n(e, "imageUrl", ""), e),
    onLoad: function(e) {
        console.log("options", e), this.setData({
            regsNo: e.regsNo,
            inferiorFlag: e.inferiorFlag,
            submitType: e.submitType
        }), console.log("that.data.inferiorFlag", this.data.inferiorFlag), "N" == this.data.inferiorFlag ? this.setData({
            showView: !1
        }) : "Y" == this.data.inferiorFlag && (this.setData({
            guildPageIsshow: !1,
            showView: !1,
            examplePageIshow: !1
        }), this.testAnySign()), console.log("onload------", e);
    },
    onShow: function() {
        l.onShow(), l.onEvent(i.SKAPPObj.onlineApply[7].id, i.SKAPPObj.onlineApply[7].label, i.SKAPPObj.onlineApply[7].params);
    },
    onHide: function() {
        l.onHide();
    },
    setRsa: function() {
        t = new c.RSAKey(), a = i.globalRsaObj.n, o = i.globalRsaObj.a, t.setPublic(a, o);
    },
    radioChange: function(e) {
        this.data.radioIsCheck || this.setData({
            radioIsCheck: !0,
            isAllChecked: !0
        });
    },
    openInstructone: function() {
        this.setData({
            hideinstructone: !1
        });
    },
    closeInstructone: function() {
        this.setData({
            hideinstructone: !0
        });
    },
    openInstructtwo: function() {
        this.setData({
            hideinstructtwo: !1
        });
    },
    closeInstructtwo: function() {
        this.setData({
            hideinstructtwo: !0
        });
    },
    openInstructthree: function() {
        this.setData({
            hideinstructthree: !1
        });
    },
    closeInstructthree: function() {
        this.setData({
            hideinstructthree: !0
        });
    },
    checkboxChange: function(e) {
        console.log("checkbox发生change事件，携带value值为：", e.detail.value);
        var t = e.detail.value.toString();
        console.log("resultVal.indexOf(one)", t.indexOf("one")), console.log("resultVal.indexOf(two)", t.indexOf("two")), 
        -1 != t.indexOf("one") && -1 != t.indexOf("two") && -1 != t.indexOf("three") ? this.setData({
            isAllChecked: !0
        }) : this.setData({
            isAllChecked: !1
        });
    },
    nextStep: function() {
        this.data.isAllChecked ? this.setData({
            guildPageIsshow: !1,
            examplePageIshow: !0
        }) : i.showToast(this, this.data.toastMeg);
    },
    take_photo: function() {
        this.chooseWeixinImage();
    },
    chooseWeixinImage: function() {
        var e = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "camera" ],
            success: function(t) {
                e.uploadImgs(t.tempFilePaths[0]), wx.showLoading({
                    title: "上传中..."
                });
            },
            fail: function(e) {
                console.log("选择照片取消"), wx.navigateBack({
                    delta: 1
                });
            }
        });
    },
    uploadImgs: function(e) {
        l.onEvent(i.SKAPPObj.onlineApply[8].id, i.SKAPPObj.onlineApply[8].label, i.SKAPPObj.onlineApply[8].params);
        var a = this, o = e;
        a.setRsa();
        var n = {
            regsNo: a.data.regsNo,
            fileName: "CustomerPhoto.jpg",
            documentCode: "3003",
            documentName: "客户电子签名照片",
            materialCode: "24",
            inferiorFlag: "N",
            operateType: "A",
            timestamp: "123",
            weChatId: i.wxCode.openid
        };
        console.log("formData", n), console.log("new Date().getTime()", new Date().getTime()), 
        console.log("rsa.encrypt(''+new Date().getTime())", t.encrypt("" + new Date().getTime())), 
        wx.uploadFile({
            url: s.getSer(i.globalData.userInfo.nickName).ser_ues_url + "/claim.saveCustomerInfoPhotoWechatClaim.do",
            filePath: o,
            name: "file",
            formData: n,
            header: {
                "Content-Type": "multipart/form-data",
                Charset: "utf-8"
            },
            success: function(e) {
                console.log("客户上传自拍", e), s.decodeJson(e), e.data = JSON.stringify(e.data), -1 != e.data.indexOf("life-00001") ? a.setData({
                    photoUploadRes: !0
                }) : console.log("影像上传失败");
            },
            fail: function(e) {
                console.log("图片上传失败", e), i.showToast(a, "图片上传失败！上传图片的大小不能超过2M");
            },
            complete: function() {
                wx.hideLoading(), a.setData({
                    examplePageIshow: !1
                }), wx.showLoading({
                    title: "初始化中..."
                }), a.testAnySign();
            }
        });
    },
    signupload: function(e) {
        var a = this, o = a.data.imageUrl;
        e = e;
        a.setRsa();
        var n = {
            regsNo: a.data.regsNo,
            fileName: "CustomerPhoto.jpg",
            documentCode: "3003",
            documentName: "客户电子签名照片",
            materialCode: "24",
            inferiorFlag: "N",
            operateType: "B",
            value: e,
            timestamp: t.encrypt("" + new Date().getTime()),
            weChatId: i.wxCode.openid
        };
        wx.uploadFile({
            url: s.getSer(i.globalData.userInfo.nickName).ser_ues_url + "/claim.saveCustomerInfoPhotoWechatClaim.do",
            filePath: o,
            name: "file",
            formData: n,
            header: {
                "Content-Type": "multipart/form-data",
                Charset: "utf-8"
            },
            success: function(e) {
                wx.hideLoading(), console.log("电子签名上传结果", e), s.decodeJson(e), e.data = JSON.stringify(e.data), 
                -1 != e.data.indexOf("life-00001") ? (console.log("_self.data", a.data), console.log("_self.data.inferiorFlag", a.data.inferiorFlag), 
                "N" == a.data.inferiorFlag ? a.data.photoUploadRes ? wx.showModal({
                    title: "提示",
                    content: "签名成功，返回上一页",
                    showCancel: !1,
                    success: function(e) {
                        a.navigateBackFunc();
                    },
                    fail: function(e) {}
                }) : (console.log("照片上传失败"), a.signFail()) : "Y" == a.data.inferiorFlag ? wx.redirectTo({
                    url: "/pages/uploadFiles/uploadFiles?registerNo=" + a.data.regsNo + "&isWhiteWeChatId=" + a.data.isWhiteWeChatId + "&submitType=" + a.data.submitType + "&inferiorFlag=" + a.data.inferiorFlag
                }) : console.log("业务类型不是正常签名跟次品回销")) : (console.log("影像上传失败"), console.log("_self", a), 
                a.signFail());
            },
            fail: function(e) {
                console.log("图片上传失败", e), i.showToast(that, "图片上传失败！上传图片的大小不能超过2M"), that.signFail();
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    navigateBackFunc: function() {
        var e = getCurrentPages();
        e[e.length - 2].setData({
            signSuccess: !0
        }), wx.navigateBack({
            delta: 1
        });
    },
    signFail: function() {
        var e = this;
        wx.showModal({
            title: "提示",
            content: "签名失败，请重新开始",
            showCancel: !0,
            success: function(t) {
                console.log("success res", t), t.confirm && e.chooseWeixinImage(), t.cancel && wx.navigateBack({
                    delta: 1
                });
            },
            fail: function(e) {},
            complete: function() {}
        });
    },
    testAnySign: function(e) {
        if (console.log("初始化开始"), e) var t = e.currentTarget.id; else t = "112321321";
        console.log("channel", t);
        var a = this;
        (i.sigGlobalData.EncAlg = "SM2", r.init(function(e, t, o) {
            "CALLBACK_TYPE_SIGNATURE" == t && 20 == e && (wx.showLoading({
                title: "上传中..."
            }), a.setData({
                imageUrl: o
            }), console.log("context_id:" + e + ";" + t + ";" + o), setTimeout(function() {
                a.testGenData();
            }, 5e3));
        }, t)) ? function(e) {
            var t = e, a = new g.signer("李明", "11011111111"), o = new g.SignRule_KeyWordV2("签名：", 50, 0, 1, 1), n = new g.SignatureConfig(a, o);
            new g.TimeTag(1, "yyMMdd hh:mm;ss");
            return n.singleWidth = 200, n.singleHeight = 200, n.penColor = "#000000", n.isTSS = !1, 
            n.signatureImgRatio = 3, n.nessesary = !0, r.addSignatureObj(t, n);
        }(20) ? r.commitConfig() ? (console.log("初始化成功"), a.testSetTemplateData()) : wx.showModal({
            title: "提示",
            content: "初始化失败！"
        }) : wx.showToast({
            title: "testAddSignatureObj error",
            duration: 2e3
        }) : wx.showToast({
            title: "init error",
            duration: 2e3
        });
    },
    testSetTemplateData: function() {
        console.log("开始设置表单数据");
        var e = this.data.regsNo;
        r.setTemplate(i.sigGlobalData.TemplateType.HTML, "<HTML></HTML>", e, "4000") ? (console.log("设置表单成功"), 
        this.testPopupDialog()) : wx.showModal({
            title: "提示",
            content: "设置表单数据失败！"
        });
    },
    testPopupDialog: function(e) {
        if (e) var t = e.currentTarget.id; else t = "20";
        r || wx.showModal({
            title: "提示",
            content: "信手书接口没有初始化！"
        });
        switch (wx.hideLoading(), r.showSignatureDialog(t, this)) {
          case "OK":
            console.log("OK");
            break;

          case "EC_API_NOT_INITED":
            console.log("信手书接口没有初始化");
            break;

          case "EC_WRONG_CONTEXT_ID":
            console.log("没有配置相应context_id的签字对象");
        }
    },
    testIsReadyToUpload: function() {
        wx.showModal({
            title: "提示",
            content: "testIsReadyToUpload:" + r.isReadyToUpload()
        });
    },
    testGenData: function() {
        if (r.isReadyToUpload()) {
            var e = r.getUploadDataGram();
            console.log("value", e), i.sigGlobalData.value = e, console.log("app.sigGlobalData.value", i.sigGlobalData.value), 
            this.signupload(e);
        } else wx.showModal({
            title: "提示",
            content: "testIsReadyToUpload:false！"
        });
    },
    canvasStart: function(e) {
        r.canvasStart(e);
    },
    canvasMove: function(e) {
        r.canvasMove(e);
    },
    canvasEnd: function(e) {
        r.canvasEnd(e);
    },
    sign_confirm: function() {
        r.sign_confirm();
    },
    clear_canvas: function() {
        r.clear_canvas();
    },
    cancel_sign: function() {
        wx.navigateBack({
            delta: 1
        });
    }
});
var n = getApp(), o = require("../../9A41035384CF379CFC276B5474025043.js");

Page({
    data: {},
    getUserInfo: function(e) {
        console.log("e.detail", e.detail), e.detail.userInfo ? (o.onEvent(n.SKAPPObj.login[2].id, n.SKAPPObj.login[2].label, n.SKAPPObj.login[2].params), 
        n.globalData = e.detail, n.getToken(), wx.navigateBack({
            delta: 1
        })) : (console.log("getuserinfo fail"), o.onEvent(n.SKAPPObj.login[3].id, n.SKAPPObj.login[3].label, n.SKAPPObj.login[3].params), 
        n.showToast(this, "请重新点击按钮进行授权，并同意授权"));
    },
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {
        o.onShow(), o.onEvent(n.SKAPPObj.login[1].id, n.SKAPPObj.login[1].label, n.SKAPPObj.login[1].params);
    },
    onHide: function() {
        o.onHide();
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});
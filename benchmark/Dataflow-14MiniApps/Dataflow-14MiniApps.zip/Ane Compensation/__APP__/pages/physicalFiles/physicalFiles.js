var e = getApp(), t = require("../../7D41315784CF379C1B2759508F425043.js"), o = require("../../9A41035384CF379CFC276B5474025043.js");

Page({
    data: {
        registerNo: "",
        Loadinghidden: !0,
        filesList: [],
        dtype: "",
        words: ""
    },
    onLaunch: function() {},
    onLoad: function(e) {
        console.log("options", e), this.setData({
            Loadinghidden: !1,
            registerNo: e.registerNo,
            dtype: e.type
        }), console.log(this.data.dtype);
    },
    onShow: function() {
        o.onShow(), 1 == this.data.dtype ? (this.quertMaterialList(), o.onEvent(e.SKAPPObj.process[5].id, e.SKAPPObj.process[5].label, e.SKAPPObj.process[5].params)) : (o.onEvent(e.SKAPPObj.process[3].id, e.SKAPPObj.process[3].label, e.SKAPPObj.process[3].params), 
        this.setData({
            Loadinghidden: !0,
            words: e.baseData.ClaimEntWords.replace(/\u21b5/g, "\n")
        }));
    },
    onHide: function() {
        o.onHide();
    },
    quertMaterialList: function() {
        var o = this, s = {
            registerNo: o.data.registerNo
        }, a = t.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "queryCaseClaimProgressPhysicalMaterialDetail?access_token=" + e.tokens.access_token + "&request_id=" + t.uuid();
        wx.request({
            url: a,
            data: s,
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: e.loginAuthorization
            },
            success: function(e) {
                console.log("理赔资料提交明细", e), "crs-00001" == e.data.returnCode && o.setData({
                    Loadinghidden: !0,
                    filesList: e.data.data
                });
            },
            fail: function() {}
        });
    }
});
var a = getApp(), e = require("../../7D41315784CF379C1B2759508F425043.js"), t = new Date(), i = e.formatDate(new Date(t)), n = {
    advancePay: {
        registerNo: "",
        name: "",
        idType: "",
        idNo: "",
        insuredIsAdult: "",
        idExpireDate: "",
        phone: "",
        accountName: "",
        accountNo: "",
        bankName: "",
        bankNo: "",
        no: "",
        systemId: a.systemId.advancepay,
        tokenKey: ""
    },
    hiddenToast: !0,
    Loadinghidden: !1,
    loadingText: "加载中",
    idExpireDateType: "",
    idExpireDateTypeList: [ {
        value: "01",
        name: "有效时间",
        checked: !1
    }, {
        value: "02",
        name: "长期",
        checked: !1
    } ],
    bankList: [],
    bankNameList: [],
    bankNoList: [],
    bankIndex: null,
    idTypeList: [],
    idTypeNameList: [],
    idTypeNoList: [],
    idTypeIndex: null,
    confirmAccountNo: "",
    isShowConfirmAccountNo: !0,
    imageArrow: "../../pages/images/new/right.png",
    isChangePhoneFlag: !1,
    isChangeIdNoFlag: !1,
    nameEditFlag: !0,
    arrTips: [ {
        value: "请填写证件号码",
        errValue: "请输入正确的证件号码"
    }, {
        value: "请填写电话",
        errValue: "请输入正确的电话"
    }, {
        value: "请选择证件有效期",
        errValue: "请填写证件到期日期"
    }, {
        value: "请填写户名"
    }, {
        value: "请填写银行账号",
        errValue: "请确认银行账号"
    }, {
        value: "请填写开户银行"
    } ]
};

Page({
    data: n,
    onLoad: function(a) {
        console.log(a), this.setData({
            "advancePay.registerNo": a.registerNo,
            tokenKey: a.tokenKey ? a.tokenKey : ""
        });
    },
    onShow: function() {
        this.initData();
    },
    initData: function() {
        var t = this;
        wx.request({
            url: e.getSer(a.globalData.userInfo.nickName).lcloud_url + a.newCommonUrl + "queryClaimAdvancePayClientBasicInfo?access_token=" + a.tokens.access_token + "&request_id=" + e.uuid(),
            data: {
                registerNo: this.data.advancePay.registerNo,
                systemId: a.systemId.advancepay,
                tokenKey: this.data.tokenKey
            },
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: a.loginAuthorization
            },
            success: function(i) {
                if (t.setData({
                    Loadinghidden: !0
                }), console.log(i), "crs-00001" === i.data.returnCode) {
                    var n = i.data.data;
                    t.setData({
                        "advancePay.name": n.name,
                        "advancePay.idType": n.idType,
                        "advancePay.idNo": n.idNo,
                        "advancePay.accountName": n.accountName,
                        "advancePay.accountNo": n.accountNo.replace(/(\d{4})(?=\d)/g, "$1 "),
                        bankList: n.bankList,
                        idTypeList: n.idTypeList,
                        "advancePay.bankName": n.bankName,
                        "advancePay.bankNo": n.bankNo,
                        "advancePay.idExpireDate": e.formatDate(new Date(n.idExpireDate)),
                        idExpireDateType: "2300-01-01" === n.idExpireDate || "9999-12-31" === n.idExpireDate ? "02" : "01",
                        "advancePay.phone": n.phone,
                        "advancePay.registerNo": n.registerNo,
                        "advancePay.no": n.no,
                        nameEditFlag: "Y" == n.insuredIsAdult
                    }), t.setData({
                        bankNameList: e.resetArray(t.data.bankList, "bankName"),
                        bankNoList: e.resetArray(t.data.bankList, "bankNo"),
                        idTypeNameList: e.resetArray(t.data.idTypeList, "description"),
                        idTypeNoList: e.resetArray(t.data.idTypeList, "idType")
                    }), "01" === t.data.idExpireDateType ? t.setData({
                        "idExpireDateTypeList[0].checked": !0,
                        "idExpireDateTypeList[1].checked": !1
                    }) : t.setData({
                        "idExpireDateTypeList[0].checked": !1,
                        "idExpireDateTypeList[1].checked": !0
                    }), t.setData({
                        bankIndex: e.queryDesByList(t.data.bankList, "bankNo", "", t.data.advancePay.bankNo, "index")
                    });
                    var o = e.queryDesByList(t.data.idTypeList, "idType", "", t.data.advancePay.idType, "index");
                    console.log("index", o), t.setData({
                        idTypeIndex: e.queryDesByList(t.data.idTypeList, "idType", "", t.data.advancePay.idType, "index")
                    });
                } else a.showToast(t, i.data.message || "查询失败");
            },
            fail: function() {
                a.showToast(t, "查询失败");
            },
            complete: function() {}
        });
    },
    tabBlur: function(t) {
        "3" !== t.currentTarget.dataset.idx || e.checkMobilePhone(t.detail.value) || (console.log("校验手机号", e.checkMobilePhone(t.detail.value)), 
        a.showToast(this, "请输入正确的电话号码"));
    },
    changeIdNo: function(a) {
        this.setData({
            "advancePay.idNo": a.detail.value,
            isChangeIdNoFlag: !0
        });
    },
    changePhone: function(a) {
        this.setData({
            "advancePay.phone": a.detail.value,
            isChangePhoneFlag: !0
        });
    },
    radioChange: function(a) {
        console.log(a), this.setData({
            idExpireDateType: a.detail.value,
            "advancePay.idExpireDate": "01" === a.detail.value ? i : "9999-12-31"
        });
    },
    bindIdExpireDate: function(t) {
        console.log("date===", t.detail.value), e.compareDate(i, t.detail.value) ? a.showToast(this, "证件有效期日期不能小于当前日期！") : this.setData({
            "advancePay.idExpireDate": t.detail.value
        });
    },
    inputAccountNo: function(a) {
        this.setData({
            "advancePay.accountNo": a.detail.value.replace(/(\d{4})(?=\d)/g, "$1 "),
            isShowConfirmAccountNo: !1
        });
    },
    blurAccountNo: function(a) {
        this.setData({
            "advancePay.accountNo": a.detail.value.replace(/(\d{4})(?=\d)/g, "$1 ")
        });
    },
    inputconfirmAccountNo: function(a) {
        this.setData({
            confirmAccountNo: a.detail.value.replace(/(\d{4})(?=\d)/g, "$1 ")
        });
    },
    blurconfirmAccountNo: function(e) {
        this.setData({
            confirmAccountNo: e.detail.value.replace(/(\d{4})(?=\d)/g, "$1 ")
        }), this.data.confirmAccountNo !== this.data.advancePay.accountNo && a.showToast(this, this.data.arrTips[parseInt(e.currentTarget.dataset.idx) - 1].errValue);
    },
    changeBank: function(a) {
        this.setData({
            bankIndex: a.detail.value,
            "advancePay.bankName": this.data.bankNameList[a.detail.value],
            "advancePay.bankNo": this.data.bankNoList[a.detail.value]
        });
    },
    changeIdType: function(a) {
        this.setData({
            idTypeIndex: a.detail.value
        });
    },
    bindToSubmit: function(t) {
        var n = this;
        if (n.data.isChangeIdNoFlag || n.data.advancePay.idNo) if (!n.data.isChangeIdNoFlag || e.verifyNumLetter(n.data.advancePay.idNo)) if (n.data.isChangePhoneFlag || n.data.advancePay.phone) if (!n.data.isChangePhoneFlag || e.checkMobilePhone(n.data.advancePay.phone)) {
            if ("01" === this.data.idExpireDateType) {
                if ("" === this.data.advancePay.idExpireDate || null === this.data.advancePay.idExpireDate) return void a.showToast(this, this.data.arrTips[2].errValue);
                if (e.compareDate(i, this.data.advancePay.idExpireDate)) return void a.showToast(this, "证件有效期日期不能小于当前日期！");
            }
            this.isShowConfirmAccountNo && "" === this.confirmAccountNo ? a.showToast(this, this.data.arrTips[4].errValue) : "" !== this.data.advancePay.accountNo ? "" !== this.data.advancePay.bankName ? (n.setData({
                Loadinghidden: !1,
                loadingText: "提交中..."
            }), wx.request({
                url: e.getSer(a.globalData.userInfo.nickName).lcloud_url + a.newCommonUrl + "saveClaimAdvancePayClientBasicInfo?access_token=" + a.tokens.access_token + "&request_id=" + e.uuid(),
                data: n.data.advancePay,
                method: "POST",
                header: {
                    "Content-Type": "application/json",
                    Charset: "utf-8",
                    loginAuthorization: a.loginAuthorization
                },
                success: function(e) {
                    n.setData({
                        Loadinghidden: !0,
                        loadingText: ""
                    }), "crs-00001" === e.data.returnCode ? wx.navigateTo({
                        url: "/pages/advancePayUpload/advancePayUpload?registerNo=" + n.data.advancePay.registerNo + "&tokenKey=" + n.data.tokenKey
                    }) : a.showToast(n, e.data.message || e.data.msg);
                },
                fail: function(a) {},
                complete: function(a) {}
            })) : a.showToast(this, this.data.arrTips[5].value) : a.showToast(this, this.data.arrTips[4].value);
        } else a.showToast(this, this.data.arrTips[1].errValue); else a.showToast(this, this.data.arrTips[1].value); else a.showToast(this, this.data.arrTips[0].errValue); else a.showToast(this, this.data.arrTips[0].value);
    }
});
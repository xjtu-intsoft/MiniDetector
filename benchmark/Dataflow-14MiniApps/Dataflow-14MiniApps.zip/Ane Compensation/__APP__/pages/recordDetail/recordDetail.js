var a, e, t, i, s = require("../../@babel/runtime/helpers/defineProperty"), d = getApp(), n = require("../../7D41315784CF379C1B2759508F425043.js"), r = require("../../9A41035384CF379CFC276B5474025043.js"), o = require("../../BA4681C684CF379CDC20E9C1FBE15043.js"), l = (require("../../2A98DAA084CF379C4CFEB2A7BE815043.js"), 
new Date()), p = n.formatDate(new Date(l)), c = n.formatDate(new Date(l.getTime() + 31536e6)), h = {}, u = {};

function g(a) {
    var e = {};
    return a.reduce(function(a, t) {
        return !e[t.key] && (e[t.key] = a.push(t)), a;
    }, []);
}

function D(a, e) {
    for (var t = 0; t < a.length; t++) a[t].value == e ? a[t].checked = !0 : a[t].checked = !1;
    return a;
}

function y(a) {
    console.log("queryDetail-app", d.tokens.access_token);
    var e = {
        regsNo: a.data.regsNo,
        accClientNo: a.data.accClientNo,
        weChatId: a.data.weChatId,
        tokenKey: d.tokenKey ? d.tokenKey : "",
        type: "2" == a.data.type ? "apply_formal_pay" : ""
    };
    console.log("dataObj", e), wx.request({
        url: n.getSer(a.data.userInfo.userInfo.nickName).ser_url + "/open/appsvr/life/queryUnCompleteClaimDetail?access_token=" + d.tokens.access_token + "&request_id=" + n.uuid(),
        data: e,
        method: "POST",
        header: {
            "Content-Type": "application/json",
            Charset: "utf-8"
        },
        success: function(e) {
            if (n.decodeJson(e), console.log("res", e), console.log("app.baseData", d.baseData), 
            console.log("app.baseData.appliRelation", d.baseData.appliRelation), "life-00001" != e.data.returnCode) console.log("res.data.message", e.data.message), 
            d.showToast(a, e.data.message); else {
                var t = e.data.registDetail.occurDate.split(" ");
                a.setData({
                    accBirthDate: e.data.registDetail.accBirthDate,
                    accIsAdult: e.data.registDetail.accIsAdult,
                    accClientName: e.data.registDetail.accClientName,
                    accSex: e.data.registDetail.accSex,
                    accProf: e.data.registDetail.accProf,
                    accTel: e.data.registDetail.accTel ? e.data.registDetail.accTel : "",
                    accIdType: e.data.registDetail.accIdType,
                    accIdNo: e.data.registDetail.accIdNo,
                    accIdExpireType: e.data.registDetail.accIdExpireType,
                    accIdExpireDate: e.data.registDetail.accIdExpireDate,
                    accAddr: e.data.registDetail.accAddr,
                    accAddrList: e.data.registDetail.accAddrList.length > 0 ? e.data.registDetail.accAddrList : [ "", "", "" ],
                    accAddrIsOverSea: e.data.registDetail.accAddrIsOverSea,
                    accCountryCode: e.data.registDetail.accCountryCode ? e.data.registDetail.accCountryCode : "",
                    accCountryName: e.data.registDetail.accCountryName ? e.data.registDetail.accCountryName : "",
                    idTypeIndex: n.queryDesByList(d.baseData.idTypeDesList, "idtype", "idtypedes", e.data.registDetail.idType, "index"),
                    idNo: e.data.registDetail.idNo,
                    occurDate: t[0],
                    occurDddr: e.data.registDetail.occurDddr,
                    caseDesc: e.data.registDetail.caseDesc,
                    hospitalName: e.data.registDetail.hospitalName,
                    baoxiaoTypeDesList: n.resetArray(d.baseData.baoxiaoList, "baoxiaoDes"),
                    baoxiaoTypeCodeList: n.resetArray(d.baseData.baoxiaoList, "baoxiaoType"),
                    otherInsurerFlagDesList: n.resetArray(d.baseData.otherInsurerFlagDesList, "otherInsurerFlagCodeDes"),
                    otherInsurerFlagCodeList: n.resetArray(d.baseData.otherInsurerFlagDesList, "otherInsurerFlagCode"),
                    otherInsurerFlagIndex: n.queryDesByList(d.baseData.otherInsurerFlagDesList, "otherInsurerFlagCode", "otherInsurerFlagCodeDes", e.data.registDetail.otherInsurerFlag, "index"),
                    otherInsurerDesList: n.resetArray(d.baseData.otherinsurerlist, "otherinsurerflagcodedes"),
                    otherInsurerCodeList: n.resetArray(d.baseData.otherinsurerlist, "otherinsurerflagcode"),
                    otherRelationDesc: e.data.registDetail.otherRelationDesc,
                    policyIdType: e.data.registDetail.policyIdType,
                    policyIdNo: e.data.registDetail.policyIdNo,
                    appliName: e.data.registDetail.appliName,
                    appliGender: e.data.registDetail.appliGender,
                    profDesc: e.data.registDetail.profDesc,
                    appliMobile: e.data.registDetail.appliMobilePhone ? e.data.registDetail.appliMobilePhone : "",
                    appliTdTypeDesList: n.resetArray(d.baseData.idTypeDesList, "idtypedes"),
                    appliTdTypeCodeList: n.resetArray(d.baseData.idTypeDesList, "idtype"),
                    appliTdTypeIndex: n.queryDesByList(d.baseData.idTypeDesList, "idtype", "idtypedes", e.data.registDetail.appliTdType, "index"),
                    appliIdEffectTypeDesList: n.resetArray(d.baseData.appliIdEffectTypeList, "appliIdEffectTypeDes"),
                    appliIdEffectTypeCodeList: n.resetArray(d.baseData.appliIdEffectTypeList, "appliIdEffectTypeCode"),
                    appliIdNo: e.data.registDetail.appliIdNo,
                    appliNotiAddr: e.data.registDetail.appliNotiAddr,
                    appliNotiAddrList: e.data.registDetail.appliNotiAddrList.length > 0 ? e.data.registDetail.appliNotiAddrList : [ "", "", "" ],
                    appliNotiAddrIsOverSea: e.data.registDetail.appliNotiAddrIsOverSea,
                    appliPostCode: e.data.registDetail.appliPostCode,
                    appliIdDateExpire: e.data.registDetail.appliIdDateExpire,
                    appliCountryCode: e.data.registDetail.appliCountryCode ? e.data.registDetail.appliCountryCode : "",
                    appliCountryName: e.data.registDetail.appliCountryName ? e.data.registDetail.appliCountryName : "",
                    appliCountryList: e.data.countryList,
                    hasNursingGold: e.data.registDetail.hasNursingGold,
                    nursingGoldGetWay: e.data.registDetail.nursingGoldGetWay ? e.data.registDetail.nursingGoldGetWay : "",
                    appliAccountName: e.data.registDetail.appliName,
                    appliAccountNo: e.data.registDetail.appliAccountNo,
                    appliBankNo: e.data.registDetail.appliBankNo,
                    drawModeDesList: [ "转账" ],
                    drawModeCodeList: [ "1" ],
                    appliAccountNoDesList: n.resetArray(e.data.registDetail.historyAccountList, "appliAccountNo"),
                    appliAccountNoCodeList: n.resetArray(e.data.registDetail.historyAccountList, "appliBankNo"),
                    appliBankNameDesList: n.resetArray(e.data.registDetail.BANK_LIST, "BANK_NAME"),
                    appliBankNameCodeList: n.resetArray(e.data.registDetail.BANK_LIST, "BANKENO"),
                    assigneeName: e.data.registDetail.assigneeName,
                    assigneeIdType: n.queryDesByList(d.baseData.idTypeDesList, "idtype", "idtypedes", e.data.registDetail.assigneeIdType, "des"),
                    assigneeIdNo: e.data.registDetail.assigneeIdNo,
                    assigneePostcode: e.data.registDetail.assigneePostcode,
                    assigneeTel: e.data.registDetail.assigneeTel,
                    assigneeAddr: e.data.registDetail.assigneeAddr,
                    authorityList: e.data.registDetail.authorityList,
                    consigneeStartDate: e.data.registDetail.consigneeStartDate ? e.data.registDetail.consigneeStartDate : p,
                    consigneeEndDate: e.data.registDetail.consigneeEndDate ? e.data.registDetail.consigneeEndDate : n.formatDate(new Date(l.getTime() + 5184e6)),
                    advancePayFlag: e.data.materialRuleMap.advancePayFlag
                }), console.log("res.data.registDetail.idType", e.data.registDetail.idType), "A" != e.data.registDetail.idType && "0" != e.data.registDetail.idType || a.setData(s({
                    accIdExpireDateShowFlag: !1
                }, "accIdExpireDateShowFlag", !1)), console.log("that.data", a.data), e.data.registDetail.appliRelation ? a.setData({
                    appliRelationIndex: parseInt(e.data.registDetail.appliRelation)
                }) : a.setData({
                    appliRelationIndex: 1
                }), console.log("that.data.appliMobile", a.data.appliMobile), null != a.data.hospitalName && "null" != a.data.hospitalName || a.setData({
                    hospitalName: ""
                });
                for (var i = [], r = 0; r < d.baseData.applyreasonlist.length; r++) i.push({
                    applyreason: d.baseData.applyreasonlist[r].applyreason,
                    applyreasondes: d.baseData.applyreasonlist[r].applyreasondes,
                    checked: !1
                });
                for (r = 0; r < e.data.registDetail.applyReasonList.length; r++) for (var o = 0; o < i.length; o++) e.data.registDetail.applyReasonList[r] == i[o].applyreason && (i[o].checked = !0);
                if (a.setData({
                    applyReasonList: i
                }), e.data.registDetail.baoxiaoType ? (a.setData({
                    baoxiaoTypeIndex: n.queryDesByList(d.baseData.baoxiaoList, "baoxiaoType", "baoxiaoDes", e.data.registDetail.baoxiaoType, "index")
                }), "1" == e.data.registDetail.baoxiaoType ? a.setData({
                    baoxiaoVal: !0,
                    invoiceAmount: e.data.registDetail.invoiceAmount,
                    hospitalDay: e.data.registDetail.hospitalDay
                }) : a.setData({
                    baoxiaoVal: !1,
                    hospitalDay: e.data.registDetail.hospitalDay,
                    invoiceAmount: e.data.registDetail.invoiceAmount
                })) : a.setData({
                    baoxiaoTypeIndex: 0,
                    baoxiaoVal: !0
                }), null != e.data.registDetail.invoiceAmount && "null" != e.data.registDetail.invoiceAmount || a.setData({
                    invoiceAmount: ""
                }), "null" != e.data.registDetail.hospitalDay && "" != e.data.registDetail.hospitalDay && null != e.data.registDetail.hospitalDay || a.setData({
                    hospitalDay: ""
                }), "1" == e.data.registDetail.otherInsurerFlag && a.setData({
                    otherInsurerIndex: n.queryDesByList(d.baseData.otherinsurerlist, "otherinsurerflagcode", "otherinsurerflagcodedes", e.data.registDetail.otherInsurer, "index")
                }), d.baseData.bankList = e.data.registDetail.BANK_LIST, null != e.data.registDetail.appliAccountNo && "" != e.data.registDetail.appliAccountNo && null != e.data.registDetail.appliAccountNo || a.setData({
                    appliAccountNo: a.data.appliAccountNoDesList[a.data.appliAccountNoIndex],
                    appliBankNo: a.data.appliAccountNoCodeList[a.data.appliAccountNoIndex]
                }), console.log("res.data.registDetail.accIdExpireDate", e.data.registDetail.accIdExpireDate), 
                e.data.registDetail.accIdExpireDate) "2300-01-01" == e.data.registDetail.accIdExpireDate || "9999-12-31" == e.data.registDetail.accIdExpireDate ? (console.log(n.queryDesByList(d.baseData.appliIdEffectTypeList, "appliIdEffectTypeCode", "appliIdEffectTypeDes", "01", "index")), 
                a.setData({
                    accIdEffectTypeIndex: n.queryDesByList(d.baseData.appliIdEffectTypeList, "appliIdEffectTypeCode", "appliIdEffectTypeDes", "01", "index"),
                    accIdExpireDate: e.data.registDetail.accIdExpireDate,
                    accDateExpireHide: !1
                })) : a.setData({
                    accIdEffectTypeIndex: n.queryDesByList(d.baseData.appliIdEffectTypeList, "appliIdEffectTypeCode", "appliIdEffectTypeDes", "02", "index"),
                    accIdExpireDate: e.data.registDetail.accIdExpireDate,
                    accIdExpireDateSelect: e.data.registDetail.accIdExpireDate,
                    accDateExpireHide: !0
                }); else if (a.setData({
                    accIdEffectTypeIndex: n.queryDesByList(d.baseData.appliIdEffectTypeList, "appliIdEffectTypeCode", "appliIdEffectTypeDes", "02", "index"),
                    accIdExpireDate: "2037-01-01",
                    accIdExpireDateSelect: p,
                    accDateExpireHide: !0
                }), "02" == a.data.appliIdEffectTypeCodeList[a.data.accIdEffectTypeIndex]) {
                    var c = {
                        key: "accIdExpireDate",
                        value: "2037-01-01",
                        name: "被保险人证件有效期",
                        checked: !0,
                        disabled: !0
                    };
                    (u = a.data.infoArr).push(c), u = g(u), a.setData({
                        infoArr: u
                    });
                }
                if (console.log("res.data.registDetail.appliIdDateExpire", e.data.registDetail.appliIdDateExpire), 
                e.data.registDetail.appliIdDateExpire) "2300-01-01" == e.data.registDetail.appliIdDateExpire || "9999-12-31" == e.data.registDetail.appliIdDateExpire ? (console.log(n.queryDesByList(d.baseData.appliIdEffectTypeList, "appliIdEffectTypeCode", "appliIdEffectTypeDes", "01", "index")), 
                a.setData({
                    appliIdEffectTypeIndex: n.queryDesByList(d.baseData.appliIdEffectTypeList, "appliIdEffectTypeCode", "appliIdEffectTypeDes", "01", "index"),
                    appliIdDateExpire: e.data.registDetail.appliIdDateExpire,
                    DateExpireHide: !1
                })) : a.setData({
                    appliIdEffectTypeIndex: n.queryDesByList(d.baseData.appliIdEffectTypeList, "appliIdEffectTypeCode", "appliIdEffectTypeDes", "02", "index"),
                    appliIdDateExpire: e.data.registDetail.appliIdDateExpire,
                    appliIdDateExpireSelect: e.data.registDetail.appliIdDateExpire,
                    DateExpireHide: !0
                }); else if (a.setData({
                    appliIdEffectTypeIndex: n.queryDesByList(d.baseData.appliIdEffectTypeList, "appliIdEffectTypeCode", "appliIdEffectTypeDes", "02", "index"),
                    appliIdDateExpire: "2037-01-01",
                    appliIdDateExpireSelect: p,
                    DateExpireHide: !0
                }), "02" == a.data.appliIdEffectTypeCodeList[a.data.appliIdEffectTypeIndex]) {
                    var u;
                    c = {
                        key: "appliIdDateExpire",
                        value: "2037-01-01",
                        name: "申请人证件有效期",
                        checked: !0,
                        disabled: !0
                    };
                    (u = a.data.infoArr).push(c), u = g(u), a.setData({
                        infoArr: u
                    });
                }
                var D = e.data.registDetail.insuranceGetWayInfo;
                D && JSON.stringify(D).length > 2 ? a.setData({
                    isInsuranceGetWayInfo: !0,
                    insuranceGetWay: D.insuranceGetWay ? D.insuranceGetWay : "",
                    insurancePolicyNo: D.insurancePolicyNo,
                    insurancePolicyPlanCode: D.insurancePolicyPlanCode,
                    insurancePolicyBrno: D.insurancePolicyBrno
                }) : a.setData({
                    isInsuranceGetWayInfo: !1
                }), a.setData({
                    isTaxRegionCodeFlag: e.data.registDetail.isTaxRegionCodeFlag,
                    taxReasonList: e.data.registDetail.taxReasonList ? e.data.registDetail.taxReasonList : [],
                    taxOtherReason: e.data.registDetail.taxOtherReason ? e.data.registDetail.taxOtherReason : "",
                    residentsType: e.data.registDetail.residentsType ? e.data.registDetail.residentsType : "A",
                    firstName: e.data.registDetail.firstName ? e.data.registDetail.firstName : "",
                    lastName: e.data.registDetail.lastName ? e.data.registDetail.lastName : "",
                    birthDate: e.data.registDetail.birthDate ? e.data.registDetail.birthDate : p,
                    presentAddrChinese1: e.data.registDetail.presentAddrChinese1 ? e.data.registDetail.presentAddrChinese1 : "",
                    presentAddrChinese2: e.data.registDetail.presentAddrChinese2 ? e.data.registDetail.presentAddrChinese2 : "",
                    presentAddrChinese3: e.data.registDetail.presentAddrChinese3 ? e.data.registDetail.presentAddrChinese3 : "",
                    presentAddrChinese4: e.data.registDetail.presentAddrChinese4 ? e.data.registDetail.presentAddrChinese4 : "",
                    presentAddrEnglish1: e.data.registDetail.presentAddrEnglish1 ? e.data.registDetail.presentAddrEnglish1 : "",
                    presentAddrEnglish2: e.data.registDetail.presentAddrEnglish2 ? e.data.registDetail.presentAddrEnglish2 : "",
                    presentAddrEnglish3: e.data.registDetail.presentAddrEnglish3 ? e.data.registDetail.presentAddrEnglish3 : "",
                    presentAddrEnglish4: e.data.registDetail.presentAddrEnglish4 ? e.data.registDetail.presentAddrEnglish4 : "",
                    birthAddrChinese1: e.data.registDetail.birthAddrChinese1 ? e.data.registDetail.birthAddrChinese1 : "",
                    birthAddrChinese2: e.data.registDetail.birthAddrChinese2 ? e.data.registDetail.birthAddrChinese2 : "",
                    birthAddrChinese3: e.data.registDetail.birthAddrChinese3 ? e.data.registDetail.birthAddrChinese3 : "",
                    birthAddrChinese4: e.data.registDetail.birthAddrChinese4 ? e.data.registDetail.birthAddrChinese4 : "",
                    birthAddrEnglish1: e.data.registDetail.birthAddrEnglish1 ? e.data.registDetail.birthAddrEnglish1 : "",
                    birthAddrEnglish2: e.data.registDetail.birthAddrEnglish2 ? e.data.registDetail.birthAddrEnglish2 : "",
                    birthAddrEnglish3: e.data.registDetail.birthAddrEnglish3 ? e.data.registDetail.birthAddrEnglish3 : "",
                    birthAddrEnglish4: e.data.registDetail.birthAddrEnglish4 ? e.data.registDetail.birthAddrEnglish4 : "",
                    taxType: e.data.registDetail.taxType ? e.data.registDetail.taxType : "",
                    taxIdentifyUsa: e.data.registDetail.taxIdentifyUsa ? e.data.registDetail.taxIdentifyUsa : "",
                    taxContryOne: e.data.registDetail.taxContryOne ? e.data.registDetail.taxContryOne : "",
                    taxContryTwo: e.data.registDetail.taxContryTwo ? e.data.registDetail.taxContryTwo : "",
                    taxIdentifyOne: e.data.registDetail.taxIdentifyOne ? e.data.registDetail.taxIdentifyOne : "",
                    taxIdentifyTwo: e.data.registDetail.taxIdentifyTwo ? e.data.registDetail.taxIdentifyTwo : "",
                    reason: e.data.registDetail.reason ? e.data.registDetail.reason : "",
                    reasonAdd: e.data.registDetail.reasonAdd ? e.data.registDetail.reasonAdd : "",
                    reasondetInput1: e.data.registDetail.reasondetInput1 ? e.data.registDetail.reasondetInput1 : "",
                    reasondetInput2: e.data.registDetail.reasondetInput2 ? e.data.registDetail.reasondetInput2 : "",
                    taxCounts: e.data.registDetail.taxCounts ? e.data.registDetail.taxCounts : "0"
                }), a.setData({
                    birthAddrChineseIndex: n.queryDesByList(d.baseData.isoCountryInfoList, "countryid", "", e.data.registDetail.birthAddrChinese1, "index"),
                    birthAddrEnglishIndex: n.queryDesByList(d.baseData.isoCountryInfoList, "countryid", "", e.data.registDetail.birthAddrEnglish1, "index"),
                    taxContryOneIndex: n.queryDesByList(d.baseData.isoCountryInfoList, "countryid", "", e.data.registDetail.taxContryOne, "index"),
                    taxContryTwoIndex: n.queryDesByList(d.baseData.isoCountryInfoList, "countryid", "", e.data.registDetail.taxContryTwo, "index")
                });
                var y = e.data.registDetail.appliTdType, I = e.data.registDetail.appliCountryCode;
                ("0" == y || "6" == y || "" != I && "VRC" != I) && a.setData({
                    isShowTaxReasonList: !0
                }), a.data.taxReasonList && a.data.taxReasonList.length > 0 && a.setTaxReasonList(a.data.taxReasonList), 
                "2" == e.data.registDetail.taxCounts && a.setData({
                    taxAdd: !1
                }), "1" == e.data.registDetail.taxType ? a.setData({
                    taxIdentifyOne: "",
                    taxContryOne: ""
                }) : a.setData({
                    taxIdentifyUsa: ""
                }), e.data.registDetail.presentAddrEnglish1 && e.data.registDetail.presentAddrEnglish2 && e.data.registDetail.presentAddrEnglish3 && e.data.registDetail.presentAddrEnglish4 ? a.setData({
                    typeOfChina: "off",
                    curAddressType: "英文或拼音"
                }) : a.setData({
                    typeOfChina: "on",
                    curAddressType: "中文"
                }), e.data.registDetail.birthAddrEnglish1 ? a.setData({
                    birthPlacetype: "off",
                    birthPlaceType: "英文或拼音"
                }) : a.setData({
                    birthPlacetype: "on",
                    birthPlaceType: "中文"
                });
                var f = a.data.appliBankNo;
                a.setData({
                    appliBankNameIndex: n.queryDesByList(e.data.registDetail.BANK_LIST, "BANKENO", "BANKE_NAME", f, "index"),
                    appliAccountNoDesList: n.resetArray(e.data.registDetail.historyAccountList, "appliAccountNo")
                });
                var A = e.data.materialRuleMap.documentCodeList, C = e.data.materialRuleMap.documentTypeList, x = e.data.materialRuleMap.isNeededList, T = e.data.materialRuleMap.materialCodeList, m = e.data.materialRuleMap.materialNameList, v = e.data.materialRuleMap.passMaterialCodeList, N = new Array(), b = !1, E = !1;
                for (r = 0; r < a.data.applyReasonList.length; r++) if ("03" == a.data.applyReasonList[r].applyreason || "05" == a.data.applyReasonList[r].applyreason) {
                    if (1 == a.data.applyReasonList[r].checked) {
                        E = !0;
                        break;
                    }
                    E = !1;
                } else E = !1;
                for (r = 0; r < A.length; r++) if ("900" != T[r] || E) if ("Y" == a.data.advancePayFlag && "100" == T[r]) ; else if (v) if (console.log("passMaterialCodeList", v), 
                0 != v.length) {
                    var L = "../../pages/images/imglist" + T[r] + ".png";
                    b = !1;
                    for (o = 0; o < v.length; o++) T[r] == v[o] && (L = "../../pages/images/imglist" + T[r] + "_1.png", 
                    b = !0);
                    N.push({
                        img: L,
                        documentCode: A[r],
                        documentType: C[r],
                        isNeeded: x[r],
                        materialCode: T[r],
                        materialName: m[r],
                        pass: b
                    });
                } else N.push({
                    img: "../../pages/images/imglist" + T[r] + ".png",
                    documentCode: A[r],
                    documentType: C[r],
                    isNeeded: x[r],
                    materialCode: T[r],
                    materialName: m[r],
                    pass: b
                }); else N.push({
                    img: "../../pages/images/imglist" + T[r] + ".png",
                    documentCode: A[r],
                    documentType: C[r],
                    isNeeded: x[r],
                    materialCode: T[r],
                    materialName: m[r],
                    pass: b
                }); else ;
                a.setData({
                    imgList: N,
                    passMaterialCodeList: e.data.materialRuleMap.passMaterialCodeList
                }), 1 == a.data.reportsFlag && wx.getStorage({
                    key: d.wxCode.openid + "_" + a.data.regsNo + "_detail",
                    success: function(t) {
                        a.setData({
                            occurDate: t.data.occurDate,
                            occurDddr: t.data.occurDddr,
                            caseDesc: t.data.caseDesc,
                            hospitalName: t.data.hospitalName,
                            invoiceAmount: t.data.invoiceAmount,
                            other_insurer: t.data.other_insurer,
                            appliIdDateExpire: t.data.appliIdDateExpire,
                            appliMobile: t.data.appliMobile,
                            appliTdTypeIndex: t.data.appliTdTypeIndex,
                            appliIdNo: t.data.appliIdNo,
                            appliBankNameIndex: t.data.appliBankNameIndex,
                            appliAccountNoIndex: t.data.appliAccountNoIndex,
                            appliAccountNo: t.data.appliAccountNo
                        }), t.data.baoxiaoType && (a.setData({
                            baoxiaoTypeIndex: n.queryDesByList(d.baseData.baoxiaoList, "baoxiaoType", "baoxiaoDes", t.data.baoxiaoType, "index")
                        }), "1" == t.data.baoxiaoType ? a.setData({
                            baoxiaoVal: !0,
                            invoiceAmount: t.data.invoiceAmount,
                            hospitalDay: t.data.hospitalDay
                        }) : a.setData({
                            baoxiaoVal: !1,
                            hospitalDay: t.data.hospitalDay,
                            invoiceAmount: t.data.invoiceAmount
                        })), "1" == t.data.otherInsurerFlag && a.setData({
                            otherInsurerFlagIndex: t.data.otherInsurerFlagIndex,
                            otherInsurerIndex: t.data.otherInsurerIndex
                        });
                        t.data.appliIdDateExpire;
                        t.data.appliIdDateExpire ? ("9999-12-31" == t.data.appliIdDateExpire ? (p, a.setData({
                            DateExpireHide: !1
                        })) : a.setData({
                            DateExpireHide: !0
                        }), a.setData({
                            appliIdEffectTypeIndex: t.data.appliIdEffectTypeIndex,
                            appliIdDateExpire: t.data.appliIdDateExpire,
                            appliIdDateExpireSelect: t.data.appliIdDateExpire
                        })) : a.setData({
                            appliIdEffectTypeIndex: n.queryDesByList(d.baseData.appliIdEffectTypeList, "appliIdEffectTypeCode", "appliIdEffectTypeDes", "02", "index"),
                            appliIdDateExpire: "2023-01-01",
                            appliIdDateExpireSelect: p,
                            DateExpireHide: !0
                        }), a.setData({
                            residentsType: t.data.residentsType,
                            firstName: t.data.firstName,
                            lastName: t.data.lastName,
                            birthDate: t.data.birthDate,
                            presentAddrChinese1: t.data.presentAddrChinese1,
                            presentAddrChinese2: t.data.presentAddrChinese2,
                            presentAddrChinese3: t.data.presentAddrChinese3,
                            presentAddrChinese4: t.data.presentAddrChinese4,
                            presentAddrEnglish1: t.data.presentAddrEnglish1,
                            presentAddrEnglish2: t.data.presentAddrEnglish2,
                            presentAddrEnglish3: t.data.presentAddrEnglish3,
                            presentAddrEnglish4: t.data.presentAddrEnglish4,
                            birthAddrChinese1: t.data.birthAddrChinese1,
                            birthAddrChinese2: t.data.birthAddrChinese2,
                            birthAddrChinese3: t.data.birthAddrChinese3,
                            birthAddrChinese4: t.data.birthAddrChinese4,
                            birthAddrEnglish1: t.data.birthAddrEnglish1,
                            birthAddrEnglish2: t.data.birthAddrEnglish2,
                            birthAddrEnglish3: t.data.birthAddrEnglish3,
                            birthAddrEnglish4: t.data.birthAddrEnglish4,
                            taxType: t.data.taxType,
                            taxIdentifyUsa: t.data.taxIdentifyUsa,
                            taxContryOne: t.data.taxContryOne,
                            taxContryTwo: t.data.taxContryTwo,
                            taxIdentifyOne: t.data.taxIdentifyOne,
                            taxIdentifyTwo: t.data.taxIdentifyTwo,
                            reason: t.data.reason,
                            reasonAdd: t.data.reasonAdd,
                            reasondetInput1: t.data.reasondetInput1,
                            reasondetInput2: t.data.reasondetInput2,
                            taxCounts: t.data.taxCounts
                        }), "2" == t.data.taxCounts && a.setData({
                            taxAdd: !1
                        }), "1" == e.data.taxType ? a.setData({
                            taxIdentifyOne: "",
                            taxContryOne: ""
                        }) : a.setData({
                            taxIdentifyUsa: ""
                        }), t.data.presentAddrChinese1 && t.data.presentAddrChinese2 && t.data.presentAddrChinese3 && t.data.presentAddrChinese4 ? a.setData({
                            curAddressType: "on"
                        }) : a.setData({
                            curAddressType: "off"
                        }), t.data.birthAddrChinese1 ? a.setData({
                            birthPlacetype: "on"
                        }) : a.setData({
                            birthPlacetype: "off"
                        });
                    },
                    fail: function(e) {
                        d.showToast(a, "请求失败");
                    }
                });
            }
            a.setData({
                Loadinghidden: !0,
                tab2: !0
            }), h.accCountryName = a.data.accCountryName, h.accCountryCode = a.data.accCountryCode, 
            h.accIdExpireDate = a.data.accIdExpireDate, h.accTel = a.data.accTel, h.accAddrList = a.data.accAddrList, 
            h.appliCountryName = a.data.appliCountryName, h.appliCountryCode = a.data.appliCountryCode, 
            h.appliIdDateExpire = a.data.appliIdDateExpire, h.appliMobile = a.data.appliMobile, 
            h.appliNotiAddrList = a.data.appliNotiAddrList, console.log("oldInfoObj", h);
        },
        fail: function(e) {
            d.showToast(a, "请求失败");
        }
    });
}

function I(a) {
    console.log("获取用户所有信息", a), console.log("获取用户所有信息that.data.appliAccountNo", a.data.appliAccountNo), 
    console.log("insuranceGetWay", a.data.insuranceGetWay);
    var e = {
        accClientNo: a.data.accClientNo,
        accBirthDate: a.data.accBirthDate,
        accClientName: a.data.accClientName,
        accIsAdult: a.data.accIsAdult,
        accIdNo: a.data.accIdNo,
        idNo: a.data.idNo,
        idTypeIndex: n.queryDesByList(d.baseData.idTypeDesList, "idtype", "idtypedes", a.data.idType, "code"),
        weChatId: a.data.weChatId,
        regsNo: a.data.regsNo,
        isPrivilegeWechatId: a.data.isPrivilegeWechatId,
        occurDate: a.data.occurDate,
        applyReasonList: a.data.applyReasonList,
        occurDddr: n.trim(a.data.occurDddr),
        caseDesc: n.trim(a.data.caseDesc),
        hospitalDay: n.trim(a.data.hospitalDay),
        hospitalName: n.trim(a.data.hospitalName),
        invoiceAmount: n.trim(a.data.invoiceAmount),
        baoxiaoType: a.data.baoxiaoTypeCodeList[a.data.baoxiaoTypeIndex],
        otherInsurerFlag: a.data.otherInsurerFlagCodeList[a.data.otherInsurerFlagIndex],
        other_insurer: a.data.other_insurer,
        otherInsurerFlagIndex: a.data.otherInsurerFlagIndex,
        otherInsurerIndex: a.data.otherInsurerIndex,
        appliName: a.data.appliName,
        appliGender: a.data.appliGender,
        profDesc: a.data.profDesc,
        appliMobile: a.data.appliMobile,
        appliTdType: a.data.appliTdTypeCodeList[a.data.appliTdTypeIndex],
        appliTdTypeIndex: a.data.appliTdTypeIndex,
        appliIdNo: a.data.appliIdNo,
        appliIdDateExpire: a.data.appliIdDateExpire,
        appliIdEffectTypeIndex: a.data.appliIdEffectTypeIndex,
        appliNotiAddr: n.trim(a.data.appliNotiAddr),
        appliPostCode: n.trim(a.data.appliPostCode),
        hasNursingGold: a.data.hasNursingGold,
        nursingGoldGetWay: a.data.nursingGoldGetWay,
        residentsType: n.trim(a.data.residentsType),
        firstName: n.trim(a.data.firstName),
        lastName: n.trim(a.data.lastName),
        birthDate: a.data.birthDate,
        presentAddrChinese1: n.trim(a.data.presentAddrChinese1),
        presentAddrChinese2: n.trim(a.data.presentAddrChinese2),
        presentAddrChinese3: n.trim(a.data.presentAddrChinese3),
        presentAddrChinese4: n.trim(a.data.presentAddrChinese4),
        presentAddrEnglish1: n.trim(a.data.presentAddrEnglish1),
        presentAddrEnglish2: n.trim(a.data.presentAddrEnglish2),
        presentAddrEnglish3: n.trim(a.data.presentAddrEnglish3),
        presentAddrEnglish4: n.trim(a.data.presentAddrEnglish4),
        birthAddrChinese1: n.trim(a.data.birthAddrChinese1),
        birthAddrChinese2: n.trim(a.data.birthAddrChinese2),
        birthAddrChinese3: n.trim(a.data.birthAddrChinese3),
        birthAddrChinese4: n.trim(a.data.birthAddrChinese4),
        birthAddrEnglish1: n.trim(a.data.birthAddrEnglish1),
        birthAddrEnglish2: n.trim(a.data.birthAddrEnglish2),
        birthAddrEnglish3: n.trim(a.data.birthAddrEnglish3),
        birthAddrEnglish4: n.trim(a.data.birthAddrEnglish4),
        taxType: a.data.taxType,
        taxIdentifyUsa: n.trim(a.data.taxIdentifyUsa),
        taxContryOne: n.trim(a.data.taxContryOne),
        taxContryTwo: n.trim(a.data.taxContryTwo),
        taxIdentifyOne: n.trim(a.data.taxIdentifyOne),
        taxIdentifyTwo: n.trim(a.data.taxIdentifyTwo),
        reason: a.data.reason,
        reasonAdd: a.data.reasonAdd,
        reasondetInput1: n.trim(a.data.reasondetInput1),
        reasondetInput2: n.trim(a.data.reasondetInput2),
        taxCounts: a.data.taxCounts,
        drawMode: a.data.drawModeCodeList[a.data.drawModeIndex],
        appliAccountName: a.data.appliAccountName,
        appliAccountNo: a.data.appliAccountNo,
        appliBankName: a.data.appliBankNameDesList[a.data.appliBankNameIndex],
        appliBankNo: a.data.appliBankNameCodeList[a.data.appliBankNameIndex],
        appliBankNameIndex: a.data.appliBankNameIndex,
        appliAccountNoIndex: a.data.appliAccountNoIndex,
        submitType: "01",
        advancePayFlag: ""
    };
    return "Y" == a.data.isPrivilegeWechatId && (e.assigneeAddr = a.data.assigneeAddr, 
    e.assigneeIdNo = a.data.assigneeIdNo, e.assigneeIdType = n.queryDesByList(d.baseData.idTypeDesList, "idtype", "idtypedes", a.data.assigneeIdType, "code"), 
    e.assigneeName = a.data.assigneeName, e.assigneePostcode = a.data.assigneePostcode, 
    e.assigneeTel = a.data.assigneeTel, e.authorityList = [ "01", "02", "03" ], e.consigneeEndDate = a.data.consigneeEndDate, 
    e.consigneeStartDate = a.data.consigneeStartDate, e.empNo = a.data.empNo), e;
}

function f(a, t) {
    r.onEvent(d.SKAPPObj.onlineApply[9].id, d.SKAPPObj.onlineApply[9].label, d.SKAPPObj.onlineApply[9].params), 
    A();
    var i = encodeURIComponent(a.accClientName);
    a.accClientName = e.encrypt(i), a.accTel = e.encrypt(a.accTel), a.regsNo = e.encrypt(a.regsNo), 
    a.idNo = e.encrypt(a.idNo), a.appliMobile = e.encrypt(a.appliMobile), a.appliName = e.encrypt(encodeURIComponent(a.appliName)), 
    "6" == a.accIdType && (a.accIdNo = a.accIdNo.replace("号", "").replace("(", "").replace(")", "").replace("（", "").replace("）", "")), 
    "6" == a.appliTdType && (a.appliIdNo = a.appliIdNo.replace("号", "").replace("(", "").replace(")", "").replace("（", "").replace("）", "")), 
    a.appliIdNo = e.encrypt(a.appliIdNo), a.accIdNo = e.encrypt(a.accIdNo), a.profDescCode = t.data.profDescCode, 
    a.accProfCode = t.data.accProfCode, a.accIsAdult = t.data.accIsAdult, a.accBirthDate = t.data.accBirthDate, 
    a.policyIdType = t.data.policyIdType, a.policyIdNo = t.data.policyIdNo, a.appliAccountName = e.encrypt(encodeURIComponent(a.appliAccountName)), 
    a.appliAccountNo = e.encrypt(a.appliAccountNo), a.appliBankName = e.encrypt(encodeURIComponent(a.appliBankName)), 
    a.appliBankNo = e.encrypt(a.appliBankNo), "Y" == t.data.isPrivilegeWechatId && (a.assigneeName = e.encrypt(encodeURIComponent(a.assigneeName)), 
    a.assigneeIdNo = e.encrypt(a.assigneeIdNo), a.assigneeTel = e.encrypt(a.assigneeTel)), 
    a.occurDddr = n.trim(a.occurDddr), a.caseDesc = n.trim(a.caseDesc), a.hospitalName = n.trim(a.hospitalName), 
    a.hospitalDay = n.trim(a.hospitalDay), a.invoiceAmount = n.trim(a.invoiceAmount), 
    a.appliNotiAddr = n.trim(a.appliNotiAddr), a.accAddrIsOverSea = t.data.accAddrIsOverSea, 
    a.appliNotiAddrIsOverSea = t.data.appliNotiAddrIsOverSea, a.insuranceGetWay = t.data.insuranceGetWay, 
    a.nursingGoldGetWay = t.data.nursingGoldGetWay, "Y" == t.data.accAddrIsOverSea ? a.accAddr = ",,," + a.accAddr : a.accAddr = a.accAddrList + "," + a.accAddr, 
    "Y" == t.data.appliNotiAddrIsOverSea ? a.appliNotiAddr = ",,," + a.appliNotiAddr : a.appliNotiAddr = a.appliNotiAddrList + "," + a.appliNotiAddr, 
    a.residentsType = t.data.residentsType, a.firstName = n.trim(t.data.firstName), 
    a.lastName = n.trim(t.data.lastName), a.birthDate = t.data.birthDate, a.presentAddrChinese1 = n.trim(t.data.presentAddrChinese1), 
    a.presentAddrChinese2 = n.trim(t.data.presentAddrChinese2), a.presentAddrChinese3 = n.trim(t.data.presentAddrChinese3), 
    a.presentAddrChinese4 = n.trim(t.data.presentAddrChinese4), a.presentAddrEnglish1 = n.trim(t.data.presentAddrEnglish1), 
    a.presentAddrEnglish2 = n.trim(t.data.presentAddrEnglish2), a.presentAddrEnglish3 = n.trim(t.data.presentAddrEnglish3), 
    a.presentAddrEnglish4 = n.trim(t.data.presentAddrEnglish4), a.birthAddrChinese1 = n.trim(t.data.birthAddrChinese1), 
    a.birthAddrChinese2 = n.trim(t.data.birthAddrChinese2), a.birthAddrChinese3 = n.trim(t.data.birthAddrChinese3), 
    a.birthAddrChinese4 = n.trim(t.data.birthAddrChinese4), a.birthAddrEnglish1 = n.trim(t.data.birthAddrEnglish1), 
    a.birthAddrEnglish2 = n.trim(t.data.birthAddrEnglish2), a.birthAddrEnglish3 = n.trim(t.data.birthAddrEnglish3), 
    a.birthAddrEnglish4 = n.trim(t.data.birthAddrEnglish4), a.taxType = t.data.taxType, 
    a.taxIdentifyUsa = n.trim(t.data.taxIdentifyUsa), a.taxContryOne = n.trim(t.data.taxContryOne), 
    a.taxContryTwo = n.trim(t.data.taxContryTwo), a.taxIdentifyOne = n.trim(t.data.taxIdentifyOne), 
    a.taxIdentifyTwo = n.trim(t.data.taxIdentifyTwo), a.reason = t.data.reason, a.reasonAdd = t.data.reasonAdd, 
    a.reasondetInput1 = n.trim(t.data.reasondetInput1), a.reasondetInput2 = n.trim(t.data.reasondetInput2), 
    a.taxCounts = t.data.taxCounts, a.value = d.sigGlobalData.value, a.tokenKey = d.tokenKey, 
    a.accAddr = n.trimIllegal(a.accAddr), a.occurDddr = n.trimIllegal(a.occurDddr), 
    a.caseDesc = n.trimIllegal(a.caseDesc), a.appliNotiAddr = n.trimIllegal(a.appliNotiAddr), 
    a.type = "2" == t.data.type ? "apply_formal_pay" : "", console.log("提交数据 formdata", a), 
    wx.request({
        url: n.getSer(t.data.userInfo.userInfo.nickName).ser_url + "/open/appsvr/life/submitWeChatAcceptInfo?access_token=" + d.tokens.access_token + "&request_id=" + n.uuid(),
        data: a,
        method: "POST",
        header: {
            "Content-Type": "application/json",
            Charset: "utf-8"
        },
        success: function(a) {
            if (n.decodeJson(a), console.log(a), "life-00001" == a.data.returnCode) {
                "01" == t.data.submitType ? d.showToast(t, a.data.returnMsg) : (t.setData({
                    hiddenResult: !1,
                    resultText: a.data.returnMsg
                }), d.baseData.showMaterialNameList = a.data.showMaterialNameList, t.setData({
                    showMaterialNameList: d.baseData.showMaterialNameList
                }));
                var e = getCurrentPages();
                if (console.log("pages", e), "1" == t.data.type) if (e.length > 1) e[e.length - 2].initData(1);
            } else console.log("res.data.returnMsg", a.data.returnMsg), d.showToast(t, a.data.returnMsg);
        },
        fail: function() {
            d.showToast(t, "请求失败");
        },
        complete: function() {}
    });
}

function A() {
    e = new o.RSAKey(), i = d.globalRsaObj.n, t = d.globalRsaObj.a, e.setPublic(i, t);
}

Page({
    data: (a = {
        imageArrow: "../../pages/images/icon_arrow.png",
        arrow_1: "../../pages/images/icon_arrow_1.png",
        arrowTab: [ "../../pages/images/icon_arrow1.png", "../../pages/images/icon_arrow1_2.png" ],
        tab1: !1,
        tab2: !0,
        tab3: !0,
        tab4: !0,
        tab5: !0,
        tab6: !0,
        maxDate: p,
        minDate: p,
        endDate: n.formatDate(new Date(l.getTime() + 283824e7)),
        imgList: [],
        passMaterialCodeList: [],
        hiddenToast: !0,
        Loadinghidden: !1,
        accIsWarn: !1,
        accidentIsWarn: !1,
        appliIsWarn: !1,
        bankTransferIsWarn: !1,
        entrustIsWarn: !1,
        uploadIsWarn: !1,
        isComplete: !1,
        flagTax: !1,
        regsNo: "",
        accClientNo: "",
        weChatId: "",
        signSuccess: !1,
        accClientName: "",
        idTypeIndex: "",
        idNo: "",
        accSex: "",
        accCountryCode: "",
        accCountryName: "",
        accPickCountryList: [],
        accProf: "",
        accProfArr: [],
        profDescArr: [],
        accIdType: "",
        accIdNo: "",
        accIdExpireType: "",
        accIdExpireDate: "",
        accIdEffectType: ""
    }, s(a, "accIdExpireDate", ""), s(a, "accIdExpireDateSelect", p), s(a, "accAddr", ""), 
    s(a, "accAddrList", [ "", "", "" ]), s(a, "accTel", ""), s(a, "accTelisTrue", !0), 
    s(a, "accIdExpireDateShowFlag", !0), s(a, "appliIdDateExpireShowFlag", !0), s(a, "baoxiaoVal", !0), 
    s(a, "occurDate", ""), s(a, "occurDddr", ""), s(a, "applyReasonList", []), s(a, "caseDesc", ""), 
    s(a, "hospitalName", ""), s(a, "hospitalDay", ""), s(a, "invoiceAmount", ""), s(a, "other_insurer", ""), 
    s(a, "other_insurer_hidden", !0), s(a, "appliRelationIndex", 1), s(a, "appliRelationArr", [ "0", "1", "2", "3", "4" ]), 
    s(a, "appliRelationDescArr", [ "其他", "本人", "配偶", "父母", "子女" ]), s(a, "appliRelation", ""), 
    s(a, "otherRelationDesc", ""), s(a, "baoxiaoTypeDesList", []), s(a, "baoxiaoTypeCodeList", []), 
    s(a, "baoxiaoTypeIndex", 0), s(a, "otherInsurerFlagDesList", []), s(a, "otherInsurerFlagCodeList", []), 
    s(a, "otherInsurerFlagIndex", 0), s(a, "otherInsurerDesList", []), s(a, "otherInsurerCodeList", []), 
    s(a, "otherInsurerIndex", 0), s(a, "appliName", ""), s(a, "appliGender", ""), s(a, "profDesc", ""), 
    s(a, "appliMobile", ""), s(a, "appliMobileisTrue", !0), s(a, "appliTdType", ""), 
    s(a, "appliIdNo", ""), s(a, "appliIdEffectType", ""), s(a, "appliIdDateExpire", ""), 
    s(a, "appliIdDateExpireSelect", p), s(a, "appliNotiAddr", ""), s(a, "appliNotiAddrList", ""), 
    s(a, "appliPostCode", ""), s(a, "appliCountryCode", ""), s(a, "appliCountryName", ""), 
    s(a, "appliCountryList", []), s(a, "appliPickCountryList", []), s(a, "hasNursingGold", ""), 
    s(a, "nursingGoldGetWay", ""), s(a, "residentsType", "A"), s(a, "isTaxRegionCodeFlag", ""), 
    s(a, "taxReasonList", []), s(a, "isShowTaxReasonList", !1), s(a, "isTaxOtherReason", !1), 
    s(a, "taxOtherReason", ""), s(a, "isoCountryInfoDesList", []), s(a, "isoCountryInfoCodeList", []), 
    s(a, "birthAddrChineseIndex", ""), s(a, "birthAddrEnglishIndex", ""), s(a, "isoCountryNoCnaDesList", []), 
    s(a, "isoCountryNoCnaCodeList", []), s(a, "taxContryOneIndex", ""), s(a, "taxContryTwoIndex", ""), 
    s(a, "taxContryOneFlag", !1), s(a, "taxContryTwoFlag", !1), s(a, "firstName", ""), 
    s(a, "lastName", ""), s(a, "birthDate", ""), s(a, "curAddressType", "中文"), s(a, "typeOfChina", "on"), 
    s(a, "presentAddrChinese1", ""), s(a, "presentAddrChinese2", ""), s(a, "presentAddrChinese3", ""), 
    s(a, "presentAddrChinese4", ""), s(a, "presentAddrEnglish1", ""), s(a, "presentAddrEnglish2", ""), 
    s(a, "presentAddrEnglish3", ""), s(a, "presentAddrEnglish4", ""), s(a, "birthPlacetype", "on"), 
    s(a, "birthPlaceType", "中文"), s(a, "taxType", "1"), s(a, "taxContryOne", ""), s(a, "taxIdentifyOne", ""), 
    s(a, "taxAdd", !0), s(a, "taxIdentifyUsa", ""), s(a, "taxContryOne", ""), s(a, "taxIdentifyOne", ""), 
    s(a, "reason", ""), s(a, "reasondetInput1", ""), s(a, "hidereasondetInput1", !0), 
    s(a, "taxContryTwo", ""), s(a, "taxIdentifyTwo", ""), s(a, "reasonAdd", ""), s(a, "reasondetInput2", ""), 
    s(a, "hidereasondetInput2", !0), s(a, "taxCounts", "0"), s(a, "DateExpireHide", !0), 
    s(a, "appliTdTypeDesList", []), s(a, "appliTdTypeCodeList", []), s(a, "appliTdTypeIndex", 0), 
    s(a, "appliIdEffectTypeDesList", []), s(a, "appliIdEffectTypeCodeList", []), s(a, "appliIdEffectTypeIndex", 0), 
    s(a, "countryPickDesList", []), s(a, "countryPickCodeList", []), s(a, "birthCountryIndex", ""), 
    s(a, "taxContryOneIndex", ""), s(a, "taxContryTwoIndex", ""), s(a, "drawMode", ""), 
    s(a, "appliAccountName", ""), s(a, "appliAccountNo", ""), s(a, "appliBankName", ""), 
    s(a, "appliBankNo", ""), s(a, "drawModeDesList", []), s(a, "drawModeCodeList", []), 
    s(a, "drawModeIndex", 0), s(a, "appliBankNameDesList", []), s(a, "appliBankNameCodeList", []), 
    s(a, "appliBankNameIndex", 0), s(a, "appliAccountNoDesList", []), s(a, "appliAccountNoCodeList", []), 
    s(a, "appliAccountNoIndex", 0), s(a, "hideConsignee", !1), s(a, "assigneeName", ""), 
    s(a, "assigneeIdType", ""), s(a, "assigneeIdNo", ""), s(a, "empNo", ""), s(a, "assigneePostcode", ""), 
    s(a, "assigneeTel", ""), s(a, "assigneeAddr", ""), s(a, "consigneeStartDate", ""), 
    s(a, "consigneeEndDate", ""), s(a, "authorityList", []), s(a, "submitType", ""), 
    s(a, "hiddenResult", !0), s(a, "resultText", ""), s(a, "iconImg", "../images/icon_ok.png"), 
    s(a, "question_one_list", [ {
        name: "是",
        value: "201",
        checked: "true"
    }, {
        name: "否",
        value: "0"
    } ]), s(a, "question_two_list", [ {
        name: "是",
        value: "202",
        checked: "true"
    }, {
        name: "否",
        value: "0"
    } ]), s(a, "question_three_list", [ {
        name: "是",
        value: "203",
        checked: "true"
    }, {
        name: "否",
        value: "0"
    } ]), s(a, "question_four_list", [ {
        name: "是",
        value: "204",
        checked: "true"
    }, {
        name: "否",
        value: "0"
    } ]), s(a, "hiddenMedical", !0), s(a, "isPrivilegeWechatId", ""), s(a, "reportsFlag", 2), 
    s(a, "DateExpireStart", l), s(a, "hideAnnotation", !0), s(a, "type", ""), s(a, "dvancePayFlag", ""), 
    s(a, "infoArr", []), s(a, "hiddenInfo", !0), s(a, "hiddenInfoCancel", !0), s(a, "infoChangeFlag", !1), 
    a),
    onLoad: function(a) {
        this.setData({
            regsNo: a.regsNo,
            accClientNo: a.accClientNo ? a.accClientNo : d.baseData.accClientNo,
            weChatId: d.wxCode.openid,
            type: a.type
        });
    },
    onShow: function() {
        r.onShow(), r.onEvent(d.SKAPPObj.onlineApply[4].id, d.SKAPPObj.onlineApply[4].label, d.SKAPPObj.onlineApply[4].params), 
        this.setData({
            userInfo: d.globalData
        }), this.setData({
            Loadinghidden: !1,
            weChatId: d.wxCode.openid,
            isPrivilegeWechatId: d.baseData.isPrivilege,
            minDate: p,
            infoArr: []
        }), console.log("app.baseData.isPrivilege", d.baseData.isPrivilege), y(this);
        var a = d.baseData.isoCountryInfoList.concat([]), e = d.baseData.isoCountryInfoList.concat([]), t = e.findIndex(function(a) {
            return "CN" == a.countryid;
        });
        e.splice(t, 1);
        var i = n.resetArray(a, "countryname"), s = n.resetArray(a, "countryid"), o = n.resetArray(e, "countryname"), l = n.resetArray(a, "countryid");
        this.setData({
            isoCountryInfoDesList: i,
            isoCountryInfoCodeList: s,
            isoCountryNoCnaDesList: o,
            isoCountryNoCnaCodeList: l,
            claimTaxReasonList: d.baseData.claimTaxReasonList
        }), "Y" != d.baseData.isPrivilege ? this.setData({
            hideConsignee: !0
        }) : this.setData({
            hideConsignee: !1
        });
        var c = getCurrentPages();
        (console.log("pages", c), "1" == this.data.type) && (c.length > 1 && c[c.length - 2].initData(1));
    },
    onHide: function() {
        r.onHide();
    },
    initData: function(a) {
        this.setData({
            reportsFlag: a
        });
    },
    tabBox: function(a) {
        if (0 == a.currentTarget.dataset.name) switch (a.currentTarget.dataset.idx) {
          case "tab1":
            this.setData({
                tab1: !0
            });
            break;

          case "tab2":
            this.setData({
                tab2: !0
            });
            break;

          case "tab3":
            this.setData({
                tab3: !0
            });
            break;

          case "tab4":
            this.setData({
                tab4: !0
            });
            break;

          case "tab5":
            this.setData({
                tab5: !0
            });
            break;

          case "tab6":
          default:
            this.setData({
                tab6: !0
            });
        } else switch (a.currentTarget.dataset.idx) {
          case "tab1":
            this.setData({
                tab1: !1
            });
            break;

          case "tab2":
            this.setData({
                tab2: !1
            });
            break;

          case "tab3":
            this.setData({
                tab3: !1
            });
            break;

          case "tab4":
            this.setData({
                tab4: !1
            });
            break;

          case "tab5":
            this.setData({
                tab5: !1
            });
            break;

          case "tab6":
          default:
            this.setData({
                tab6: !1
            });
        }
    },
    bindAccAddrChange: function(a) {
        console.log("accAddrList", a.detail.value), this.setData({
            accAddrList: a.detail.value,
            infoChangeFlag: !0
        });
        var e = {
            key: "accAddrList",
            value: a.detail.value,
            name: "被保险人地址",
            checked: !(h.accAddrList[0] || h.accAddrList[1] || h.accAddrList[2]),
            disabled: !(h.accAddrList[0] || h.accAddrList[1] || h.accAddrList[2])
        }, t = this.data.infoArr;
        t.push(e), t = g(t), this.setData({
            infoArr: t
        }), console.log("infoArr", this.data.infoArr);
    },
    bindAppAddrChange: function(a) {
        console.log("appliNotiAddrList", a.detail.value), this.setData({
            appliNotiAddrList: a.detail.value,
            infoChangeFlag: !0
        });
        var e = {
            key: "appliNotiAddrList",
            value: a.detail.value,
            name: "申请人地址",
            checked: !(h.appliNotiAddrList[0] || h.appliNotiAddrList[1] || h.appliNotiAddrList[2]),
            disabled: !(h.appliNotiAddrList[0] || h.appliNotiAddrList[1] || h.appliNotiAddrList[2])
        }, t = this.data.infoArr;
        t.push(e), t = g(t), this.setData({
            infoArr: t
        }), console.log("infoArr", this.data.infoArr);
    },
    accRadioChange: function(a) {
        this.setData({
            accAddrIsOverSea: a.detail.value
        });
    },
    appRadioChange: function(a) {
        this.setData({
            appliNotiAddrIsOverSea: a.detail.value
        });
    },
    goSignature: function() {
        var a = this.data.regsNo, e = this.data.accClientNo;
        wx.navigateTo({
            url: "/pages/anySign/anySign?regsNo=" + a + "&accClientNo=" + e + "&inferiorFlag=N"
        });
    },
    bindChangeOccurDate: function(a) {
        this.setData({
            occurDate: a.detail.value
        });
    },
    changeReason: function(a) {
        this.setData({
            applyReasonList: a.detail.value
        }), null == this.data.otherInsurerFlag ? this.data.other_insurer = "" : this.setData({
            other_insurer: this.data.otherInsurerCodeList[this.data.otherInsurerIndex]
        }), "01" == this.data.appliIdEffectTypeCodeList[this.data.appliIdEffectTypeIndex] && (this.data.appliIdDateExpire = "9999-12-31"), 
        "01" == this.data.appliIdEffectTypeCodeList[this.data.accIdEffectTypeIndex] && (this.data.accIdExpireDate = "9999-12-31");
        var t = {
            accClientNo: this.data.accClientNo,
            accClientName: this.data.accClientName,
            idNo: this.data.idNo,
            idTypeIndex: n.queryDesByList(d.baseData.idTypeDesList, "idtype", "idtypedes", this.data.idType, "code"),
            weChatId: this.data.weChatId,
            regsNo: this.data.regsNo,
            isPrivilegeWechatId: this.data.isPrivilegeWechatId,
            occurDate: this.data.occurDate,
            applyReasonList: a.detail.value,
            occurDddr: this.data.occurDddr,
            caseDesc: this.data.caseDesc,
            hospitalDay: this.data.hospitalDay,
            hospitalName: this.data.hospitalName,
            invoiceAmount: this.data.invoiceAmount,
            baoxiaoType: this.data.baoxiaoTypeCodeList[this.data.baoxiaoTypeIndex],
            otherInsurerFlag: this.data.otherInsurerFlagCodeList[this.data.otherInsurerFlagIndex],
            other_insurer: this.data.other_insurer,
            appliName: this.data.appliName,
            appliGender: this.data.appliGender,
            profDesc: this.data.profDesc,
            appliMobile: this.data.appliMobile,
            appliTdType: this.data.appliTdTypeCodeList[this.data.appliTdTypeIndex],
            appliIdNo: this.data.appliIdNo,
            appliIdDateExpire: this.data.appliIdDateExpire,
            appliNotiAddr: this.data.appliNotiAddr,
            appliNotiAddrList: this.data.appliNotiAddrList,
            appliPostCode: this.data.appliPostCode,
            drawMode: this.data.drawModeCodeList[this.data.drawModeIndex],
            appliAccountName: this.data.appliAccountName,
            appliAccountNo: this.data.appliAccountNo,
            appliBankName: this.data.appliBankNameDesList[this.data.appliBankNameIndex],
            appliBankNo: this.data.appliBankNameCodeList[this.data.appliBankNameIndex],
            submitType: "01"
        };
        "Y" == this.data.isPrivilegeWechatId && (t.assigneeAddr = this.data.assigneeAddr, 
        t.assigneeIdNo = this.data.assigneeIdNo, t.assigneeIdType = n.queryDesByList(d.baseData.idTypeDesList, "idtype", "idtypedes", this.data.assigneeIdType, "code"), 
        t.assigneeName = this.data.assigneeName, t.assigneePostcode = this.data.assigneePostcode, 
        t.assigneeTel = this.data.assigneeTel, t.authorityList = [ "01", "02", "03" ], t.consigneeEndDate = this.data.consigneeEndDate, 
        t.consigneeStartDate = this.data.consigneeStartDate, t.empNo = this.data.empNo), 
        function(a, t) {
            A();
            var i = encodeURIComponent(a.accClientName);
            a.accClientName = e.encrypt(i), a.accBirthDate = t.data.accBirthDate, a.policyIdType = t.data.policyIdType, 
            a.policyIdNo = t.data.policyIdNo, a.tokenKey = d.tokenKey, a.idNo = e.encrypt(a.idNo), 
            a.regsNo = e.encrypt(a.regsNo), "6" == a.accIdType && (a.accIdNo = a.accIdNo.replace("号", "").replace("(", "").replace(")", "").replace("（", "").replace("）", "")), 
            "6" == a.appliTdType && (a.appliIdNo = a.appliIdNo.replace("号", "").replace("(", "").replace(")", "").replace("（", "").replace("）", "")), 
            a.accIdNo = e.encrypt(a.accIdNo), a.appliMobile = e.encrypt(a.appliMobile), a.appliName = e.encrypt(encodeURIComponent(a.appliName)), 
            a.appliIdNo = e.encrypt(a.appliIdNo), a.appliAccountName = e.encrypt(encodeURIComponent(a.appliAccountName)), 
            a.appliAccountNo = e.encrypt(a.appliAccountNo), a.appliBankName = e.encrypt(encodeURIComponent(a.appliBankName)), 
            a.appliBankNo = e.encrypt(a.appliBankNo), a.nursingGoldGetWay = t.data.nursingGoldGetWay, 
            "Y" == t.data.isPrivilegeWechatId && (a.assigneeName = e.encrypt(encodeURIComponent(a.assigneeName)), 
            a.assigneeIdNo = e.encrypt(a.assigneeIdNo), a.assigneeTel = e.encrypt(a.assigneeTel)), 
            t.setData({
                tab2: !0,
                Loadinghidden: !1
            }), a.accAddr = n.trimIllegal(a.accAddr), a.occurDddr = n.trimIllegal(a.occurDddr), 
            a.caseDesc = n.trimIllegal(a.caseDesc), a.appliNotiAddr = n.trimIllegal(a.appliNotiAddr), 
            a.type = "2" == t.data.type ? "apply_formal_pay" : "", console.log("formdata", a), 
            wx.request({
                url: n.getSer(t.data.userInfo.userInfo.nickName).ser_url + "/open/appsvr/life/submitWeChatAcceptInfo?access_token=" + d.tokens.access_token + "&request_id=" + n.uuid(),
                data: a,
                method: "POST",
                header: {
                    "Content-Type": "application/json",
                    Charset: "utf-8"
                },
                success: function(a) {
                    n.decodeJson(a), console.log(a), a.data.returnCode, d.showToast(t, a.data.returnMsg);
                },
                fail: function() {
                    console.log("fail");
                },
                complete: function() {
                    y(t);
                }
            });
        }(I(this), this);
    },
    blurOccurDddr: function(a) {
        "" != a.detail.value && null != a.detail.value || d.showToast(this, "请输入出险地点"), 
        this.setData({
            occurDddr: a.detail.value
        });
    },
    blurCaseDesc: function(a) {
        "" != a.detail.value && null != a.detail.value || d.showToast(this, "请输入详细经过"), 
        this.setData({
            caseDesc: a.detail.value
        });
    },
    inputHospitalName: function(a) {
        this.setData({
            hospitalName: a.detail.value
        });
    },
    changeBaoXiaoType: function(a) {
        console.log("e.detail.value", a.detail.value);
        this.setData({
            baoxiaoTypeIndex: a.detail.value
        }), "1" == a.detail.value && d.showToast(this, "是否确认本次仅申请日额津贴"), "1" == this.data.baoxiaoTypeCodeList[this.data.baoxiaoTypeIndex] ? this.setData({
            baoxiaoVal: !0
        }) : this.setData({
            baoxiaoVal: !1
        });
    },
    inputInvoiceAmount: function(a) {
        this.setData({
            invoiceAmount: a.detail.value
        });
    },
    blurInvoiceAmount: function(a) {
        "" == a.detail.value ? d.showToast(this, "请输入发票总额！") : this.setData({
            invoiceAmount: a.detail.value
        });
    },
    changehospitalDay: function(a) {
        "" == a.detail.value ? d.showToast(this, "请输入累计住院天数！") : this.setData({
            hospitalDay: a.detail.value
        });
    },
    changeOtherInsurerFlag: function(a) {
        this.setData({
            otherInsurerFlagIndex: a.detail.value
        });
    },
    changeOtherInsurer: function(a) {
        this.setData({
            otherInsurerIndex: a.detail.value
        });
    },
    changeAppliRelation: function(a) {
        console.log("e.detail.value", a.detail.value), this.setData({
            appliRelationIndex: a.detail.value
        });
    },
    inputOtherRelationDesc: function(a) {
        console.log("input otherRelationDesc", a.detail.value), this.setData({
            otherRelationDesc: a.detail.value
        });
    },
    blurOtherRelationDesc: function(a) {
        console.log("blur otherRelationDesc", a.detail.value), this.setData({
            otherRelationDesc: a.detail.value
        });
    },
    blurAccTel: function(a) {
        if ("" != a.detail.value) if ("1" == a.detail.value.substring(0, 1)) if (n.checkMobilePhone(a.detail.value)) {
            this.setData({
                accTel: a.detail.value,
                accTelisTrue: !0,
                infoChangeFlag: !0
            });
            var e = {
                key: "accTel",
                value: a.detail.value,
                name: "被保险人电话",
                checked: !h.accTel,
                disabled: !h.accTel
            };
            (t = this.data.infoArr).push(e), t = g(t), this.setData({
                infoArr: t
            });
        } else d.showToast(this, "请输入正确的联系电话！"), this.setData({
            accTelisTrue: !1
        }); else if (n.checkPhone(a.detail.value)) {
            this.setData({
                accTel: a.detail.value,
                accTelisTrue: !0,
                infoChangeFlag: !0
            });
            var t;
            e = {
                key: "accTel",
                value: a.detail.value,
                name: "被保险人电话",
                checked: !h.accTel,
                disabled: !h.accTel
            };
            (t = this.data.infoArr).push(e), t = g(t), this.setData({
                infoArr: t
            });
        } else d.showToast(this, "请输入正确的联系电话！"), this.setData({
            accTelisTrue: !1
        }); else this.setData({
            accTelisTrue: !1
        }), d.showToast(this, "请输入正确的联系电话！");
    },
    blurAppliMobile: function(a) {
        if ("" != a.detail.value) if ("1" == a.detail.value.substring(0, 1)) if (n.checkMobilePhone(a.detail.value)) {
            var e;
            this.setData({
                appliMobile: a.detail.value,
                appliMobileisTrue: !0,
                infoChangeFlag: !0
            });
            var t = (e = {
                key: "appliMobile",
                value: a.detail.value,
                name: "申请人电话",
                checked: !1
            }, s(e, "checked", !h.appliMobile), s(e, "disabled", !h.appliMobile), e);
            (i = this.data.infoArr).push(t), i = g(i), this.setData({
                infoArr: i
            });
        } else d.showToast(this, "请输入正确的联系电话！"), this.setData({
            appliMobileisTrue: !1
        }); else if (n.checkPhone(a.detail.value)) {
            this.setData({
                appliMobile: a.detail.value,
                appliMobileisTrue: !0,
                infoChangeFlag: !0
            });
            var i;
            t = {
                key: "appliMobile",
                value: a.detail.value,
                name: "申请人电话",
                checked: !h.appliMobile,
                disabled: !h.appliMobile
            };
            (i = this.data.infoArr).push(t), i = g(i), this.setData({
                infoArr: i
            });
        } else d.showToast(this, "请输入正确的联系电话！"), this.setData({
            appliMobileisTrue: !1
        }); else this.setData({
            appliMobileisTrue: !1
        }), d.showToast(this, "请输入正确的联系电话！");
    },
    searchAccProf: function(a) {
        console.log("e", a);
        var e = a.target.dataset.type, t = this;
        if (a.detail.value) {
            var i = {
                professionKeyWord: a.detail.value
            }, s = n.getSer(d.globalData.userInfo.nickName).lcloud_url + "/open/appsvr/life/new-esg-version/LCLOUD-CLAIM-CRS/WeChatClaim/queryClaimProfessionList?access_token=" + d.tokens.access_token + "&request_id=" + n.uuid();
            wx.request({
                url: s,
                data: i,
                method: "POST",
                success: function(a) {
                    console.log("职业搜索结果res", a);
                    var i = a.data;
                    "crs-00001" == i.returnCode ? "1" == e ? t.setData({
                        accProfArr: i.data
                    }) : "2" == e && t.setData({
                        profDescArr: i.data
                    }) : d.showToast(t, i.message);
                },
                fail: function() {}
            });
        }
    },
    choseAccProf: function(a) {
        console.log("被保险人 选择职业", a);
        var e = a.target.dataset.item;
        this.setData({
            accProfCode: e.professionCode,
            accProf: e.professionName,
            accProfArr: []
        }), console.log("this.data", this.data), console.log("this.data.accProfCode", this.data.accProfCode);
    },
    choseProfDesc: function(a) {
        console.log("申请人选择职业", a);
        var e = a.target.dataset.item;
        this.setData({
            profDescCode: e.professionCode,
            profDesc: e.professionName,
            profDescArr: []
        }), console.log("this.data", this.data), console.log("this.data.profDescCode", this.data.profDescCode);
    },
    blurAccProf: function(a) {
        this.setData({
            accProf: a.detail.value
        });
    },
    blurAppliprofDesc: function(a) {
        this.setData({
            profDesc: a.detail.value
        });
    },
    changeAppliTdType: function(a) {
        console.log("e.detail.value", a.detail.value), "1" == a.currentTarget.dataset.type ? (this.setData({
            idTypeIndex: a.detail.value
        }), "5" == a.detail.value || "0" == a.detail.value ? this.setData({
            accIdExpireDateShowFlag: !1
        }) : this.setData({
            accIdExpireDateShowFlag: !0
        })) : "2" == a.currentTarget.dataset.type && (this.setData({
            appliTdTypeIndex: a.detail.value
        }), "5" == a.detail.value || "0" == a.detail.value ? this.setData({
            appliIdDateExpireShowFlag: !1
        }) : this.setData({
            appliIdDateExpireShowFlag: !0
        })), "3" == a.detail.value && d.showToast(this, "未办理居民身份证，仍以军人证申请理赔的，请提供军人保障卡或所在单位出具的未办理身份证的证明材料");
    },
    blurAccliIdNo: function(a) {
        if ("" != a.detail.value) {
            console.log("that.data.idTypeIndex", this.data.idTypeIndex);
            var e = this.data.appliTdTypeCodeList[this.data.idTypeIndex];
            console.log("被保险人>>>>type", e), this.checkCertificate(e, a.detail.value);
        } else d.showToast(this, "请输入正确的证件号码！");
    },
    blurAppliIdNo: function(a) {
        console.log("e", a);
        if ("" != a.detail.value) {
            console.log("that.data.appliTdTypeIndex", this.data.appliTdTypeIndex);
            var e = this.data.appliTdTypeCodeList[this.data.appliTdTypeIndex];
            console.log("申请人>>>>type", e), this.checkCertificate(e, a.detail.value);
        } else d.showToast(this, "请输入正确的证件号码！");
    },
    checkCertificate: function(a, e) {
        switch (console.log("type", a), console.log("value", e), a) {
          case "0":
            n.verifyIdNo(e) || d.showToast(this, "请输入合法的18位户口本号码");
            break;

          case "1":
            n.verifyIdNo(e) || d.showToast(this, "请输入合法的18位身份证号码");
            break;

          case "2":
            n.verifyPassport(e) || d.showToast(this, "请输入合法的护照号码");
            break;

          case "3":
            d.showToast(this, "未办理居民身份证，仍以军人证申请理赔的，请提供军人保障卡或所在单位出具的未办理身份证的证明材料");
            break;

          case "6":
            n.verifyHongKongMacauCard(e) || d.showToast(this, "请输入合法的港澳台证件号码");
            break;

          case "A":
            n.verifyBirthCard(e) || d.showToast(this, "请输入合法的出生证号码");
            break;

          case "C":
            n.foreignerPermanentLiveCart(e) || d.showToast(this, "请输入合法的外国居留证号码");
            break;

          case "D":
            n.verifyHongKongMacauLiveCard(e) || d.showToast(this, "请输入合法的港澳台居民居住证号码");
        }
    },
    bindAccIdExpireDate: function(a) {
        if (n.compareDate(p, a.detail.value)) d.showToast(this, "证件有效期日期不能小于当前日期！"); else {
            this.setData({
                accIdExpireDate: a.detail.value,
                accIdExpireDateSelect: a.detail.value,
                infoChangeFlag: !0
            });
            var e = {
                key: "accIdExpireDate",
                value: a.detail.value,
                name: "被保险人证件有效期",
                checked: !h.accIdExpireDate,
                disabled: !h.accIdExpireDate
            }, t = this.data.infoArr;
            t.push(e), t = g(t), this.setData({
                infoArr: t
            });
        }
    },
    choseCountry: function(a) {
        console.log("申请人国籍e", a);
        var e = a.detail.value, t = this.data.appliCountryList, i = [];
        if ("" !== e && void 0 !== e) for (var s in t) for (var d in e) {
            if (-1 === t[s].countryName.indexOf(e[d])) break;
            d == e.length - 1 && i.push(t[s]);
        }
        "2" == a.currentTarget.dataset.idx ? this.setData({
            appliPickCountryList: i
        }) : "1" == a.currentTarget.dataset.idx ? this.setData({
            accPickCountryList: i
        }) : console.log("国籍错误");
    },
    pickCountry: function(a) {
        if (console.log("e", a), "1" == a.currentTarget.dataset.idx) {
            this.setData({
                accCountryName: a.currentTarget.dataset.country.countryName,
                accCountryCode: a.currentTarget.dataset.country.countryCode,
                accPickCountryList: [],
                infoChangeFlag: !0
            });
            var e = {
                key: "accCountryName",
                value: a.currentTarget.dataset.country.countryName,
                name: "被保险人国籍",
                checked: !h.accCountryName,
                disabled: !h.accCountryName
            };
            (t = this.data.infoArr).push(e), t = g(t), this.setData({
                infoArr: t
            });
        } else if ("2" == a.currentTarget.dataset.idx) {
            this.setData({
                appliCountryName: a.currentTarget.dataset.country.countryName,
                appliCountryCode: a.currentTarget.dataset.country.countryCode,
                appliPickCountryList: [],
                infoChangeFlag: !0
            });
            var t;
            e = {
                key: "appliCountryName",
                value: a.currentTarget.dataset.country.countryName,
                name: "申请人国籍",
                checked: !h.appliCountryName,
                disabled: !h.appliCountryName
            };
            (t = this.data.infoArr).push(e), t = g(t), this.setData({
                infoArr: t
            }), "VRC" == a.currentTarget.dataset.country.countryCode ? this.setData({
                isShowTaxReasonList: !1
            }) : this.setData({
                isShowTaxReasonList: !0
            });
        }
    },
    countryBlur: function(a) {
        "" != a.detail.value && "undefined" != a.detail.value || d.showToast(this, "请填写国籍");
    },
    changeAppliIdEffectType: function(a) {
        if ("1" == a.currentTarget.dataset.type) if (this.setData({
            accIdEffectTypeIndex: a.detail.value
        }), "01" == this.data.appliIdEffectTypeCodeList[this.data.accIdEffectTypeIndex]) {
            this.setData({
                accIdExpireDate: "9999-12-31",
                accIdExpireDateSelect: "9999-12-31",
                accDateExpireHide: !1,
                infoChangeFlag: !0
            });
            var e = {
                key: "accIdExpireDate",
                value: "9999-12-31",
                name: "被保险人证件有效期",
                checked: !h.accIdExpireDate,
                disabled: !h.accIdExpireDate
            };
            (t = this.data.infoArr).push(e), t = g(t), this.setData({
                infoArr: t
            });
        } else {
            this.setData({
                accIdExpireDate: "2023-01-01",
                accIdExpireDateSelect: c,
                accDateExpireHide: !0,
                infoChangeFlag: !0
            });
            e = {
                key: "accIdExpireDate",
                value: "2023-01-01",
                name: "被保险人证件有效期",
                checked: !h.accIdExpireDate,
                disabled: !h.accIdExpireDate
            };
            (t = this.data.infoArr).push(e), t = g(t), this.setData({
                infoArr: t
            });
        } else if ("2" == a.currentTarget.dataset.type) if (this.setData({
            appliIdEffectTypeIndex: a.detail.value
        }), "01" == this.data.appliIdEffectTypeCodeList[this.data.appliIdEffectTypeIndex]) {
            this.setData({
                appliIdDateExpire: "9999-12-31",
                appliIdDateExpireSelect: "9999-12-31",
                DateExpireHide: !1,
                infoChangeFlag: !0
            });
            e = {
                key: "appliIdDateExpire",
                value: "9999-12-31",
                name: "申请人证件有效期",
                checked: !h.appliIdDateExpire,
                disabled: !h.appliIdDateExpire
            };
            (t = this.data.infoArr).push(e), t = g(t), this.setData({
                infoArr: t
            });
        } else {
            this.setData({
                appliIdDateExpire: "2023-01-01",
                appliIdDateExpireSelect: c,
                DateExpireHide: !0,
                infoChangeFlag: !0
            });
            var t;
            e = {
                key: "appliIdDateExpire",
                value: "2023-01-01",
                name: "申请人证件有效期",
                checked: !h.appliIdDateExpire,
                disabled: !h.appliIdDateExpire
            };
            (t = this.data.infoArr).push(e), t = g(t), this.setData({
                infoArr: t
            });
        } else console.log("错误");
    },
    bindAppliIdDateExpire: function(a) {
        if (n.compareDate(p, a.detail.value)) d.showToast(this, "证件有效期日期不能小于当前日期！"); else {
            this.setData({
                appliIdDateExpire: a.detail.value,
                appliIdDateExpireSelect: a.detail.value,
                infoChangeFlag: !0
            });
            var e = {
                key: "appliIdDateExpire",
                value: a.detail.value,
                name: "申请人证件有效期",
                checked: !h.appliIdDateExpire,
                disabled: !h.appliIdDateExpire
            }, t = this.data.infoArr;
            t.push(e), t = g(t), this.setData({
                infoArr: t
            });
        }
    },
    changeDrawMode: function(a) {
        this.setData({
            drawModeIndex: a.detail.value
        });
    },
    changeAppliAccountNo: function(a) {
        this.setData({
            appliAccountNoIndex: a.detail.value,
            appliAccountNo: this.data.appliAccountNoDesList[a.detail.value],
            appliBankNo: this.data.appliAccountNoCodeList[a.detail.value]
        });
        var e = this.data.appliBankNo;
        this.setData({
            appliBankNameIndex: n.queryDesByList(d.baseData.bankList, "BANKENO", "BANKE_NAME", e, "index")
        });
    },
    inputAppliAccountNo: function(a) {
        this.setData({
            appliAccountNo: a.detail.value
        });
    },
    changeAppliBankName: function(a) {
        console.log("e.detail.value", a.detail.value);
        this.setData({
            appliBankNameIndex: a.detail.value
        });
        var e = this.data.appliBankNameDesList[a.detail.value];
        console.log("des", e), "-1" != e.indexOf("邮") && (console.log("包含邮"), d.showToast(this, "因为邮储银行系统原因,理赔款可能到账不及时,建议您选择其他银行"));
    },
    toImgLink: function(a) {
        var e = this;
        !function(a, e) {
            wx.setStorage({
                key: d.wxCode.openid + "_" + a.data.regsNo + "_detail",
                data: e
            });
        }(e, I(e)), "200" == a.currentTarget.dataset.materialcode ? (e.setData({
            hiddenMedical: !1
        }), wx.setStorage({
            key: e.data.regsNo + "_200",
            data: a.currentTarget.dataset
        }), wx.getStorage({
            key: d.wxCode.openid + "_" + e.data.regsNo,
            success: function(a) {
                console.log("res", a), e.setData({
                    question_one_list: D(e.data.question_one_list, a.data[0]),
                    question_two_list: D(e.data.question_two_list, a.data[1]),
                    question_three_list: D(e.data.question_three_list, a.data[2]),
                    question_four_list: D(e.data.question_four_list, a.data[3])
                });
            },
            fail: function(a) {
                console.log(a);
            }
        })) : (console.log("open uploadImg----"), wx.navigateTo({
            url: "/pages/UploadImg/UploadImg?regsNo=" + e.data.regsNo + "&isPrivilegeWechatId=" + e.data.isPrivilegeWechatId + "&appliMobile=" + e.data.appliMobile + "&accClientNo=" + e.data.accClientNo + "&materialCode=" + a.currentTarget.dataset.materialcode + "&documentType=" + a.currentTarget.dataset.documenttype + "&isNeeded=" + a.currentTarget.dataset.isneeded + "&materialName=" + a.currentTarget.dataset.materialname + "&inferiorFlag=N&submitType=01"
        }));
    },
    closeModal: function(a) {
        this.setData({
            hiddenMedical: !0
        });
    },
    sureSelect: function(a) {
        var e = this, t = [];
        for (var i in a.detail.value) t.push(a.detail.value[i]);
        wx.setStorage({
            key: d.wxCode.openid + "_" + e.data.regsNo,
            data: t
        }), wx.getStorage({
            key: e.data.regsNo + "_200",
            success: function(a) {
                console.log("res", a), wx.navigateTo({
                    url: "/pages/UploadImg/UploadImg?regsNo=" + e.data.regsNo + "&isPrivilegeWechatId=" + e.data.isPrivilegeWechatId + "&accClientNo=" + e.data.accClientNo + "&materialCode=" + a.data.materialcode + "&documentType=" + a.data.documenttype + "&isNeeded=" + a.data.isneeded + "&materialName=" + a.data.materialname + "&inferiorFlag=N&submitType=01"
                });
            },
            fail: function(a) {
                console.log(a);
            }
        }), e.setData({
            hiddenMedical: !0
        });
    },
    bindToTemporary: function(a) {
        this.setData({
            submitType: a.currentTarget.dataset.type
        });
    },
    bindToSubmit: function(a) {
        this.setData({
            submitType: a.currentTarget.dataset.type
        });
    },
    submitApply: function(a) {
        console.log("e.detail.value.accIdExpireDate", a.detail.value.accIdExpireDate);
        var e = this;
        e.setData({
            isComplete: !1,
            bankTransferIsWarn: !1,
            accidentIsWarn: !1,
            accIsWarn: !1,
            appliIsWarn: !1,
            entrustIsWarn: !1,
            flagTax: !1
        }), setTimeout(function() {
            var t, i;
            a.detail.value.submitType = e.data.submitType, a.detail.value.authorityList = e.data.authorityList, 
            i = "on" == a.detail.value.curAddressType ? "" == a.detail.value.presentAddrChinese1 || "" == a.detail.value.presentAddrChinese2 || "" == a.detail.value.presentAddrChinese3 || "" == a.detail.value.presentAddrChinese4 : "" == a.detail.value.presentAddrEnglish1 || "" == a.detail.value.presentAddrEnglish2 || "" == a.detail.value.presentAddrEnglish3 || "" == a.detail.value.presentAddrEnglish4, 
            t = "on" == a.detail.value.birthPlaceType ? "" == a.detail.value.birthAddrChinese1 || "" == a.detail.value.birthAddrChinese2 || "" == a.detail.value.birthAddrChinese3 || "" == a.detail.value.birthAddrChinese4 : "" == a.detail.value.birthAddrEnglish1 || "" == a.detail.value.birthAddrEnglish2 || "" == a.detail.value.birthAddrEnglish3 || "" == a.detail.value.birthAddrEnglish4;
            var s = !1, r = !1, o = !1;
            if ("A" != a.detail.value.residentsType && (s = "" == a.detail.value.taxType || "" == a.detail.value.taxIdentifyUsa), 
            "2" == a.detail.value.taxType && ("2" == a.detail.value.taxCounts ? ("" == a.detail.value.taxContryOne || "" == a.detail.value.taxContryTwo, 
            "" == a.detail.value.taxIdentifyTwo && (o = "" == a.detail.value.reasonAdd || "1" != a.detail.value.reasonAdd && "" == a.detail.value.reasondetInput2)) : "" == a.detail.value.taxContryOne, 
            "" == a.detail.value.taxIdentifyOne && (r = "" == a.detail.value.reason || "1" != a.detail.value.reason && "" == a.detail.value.reasondetInput1)), 
            ("" == a.detail.value.caseDesc || "" == a.detail.value.occurDddr || "1" == a.detail.value.baoxiaoType && "" == a.detail.value.invoiceAmount || "2" == a.detail.value.baoxiaoType && "" == a.detail.value.hospitalDay || "0" == a.detail.value.appliRelation && "" == a.detail.value.otherRelationDesc) && (console.log("事故者信息不全"), 
            e.setData({
                accidentIsWarn: !0,
                isComplete: !0
            })), "0" != a.detail.value.appliRelation && (a.detail.value.otherRelationDesc = ""), 
            console.log("e.detail.value.accCountryName", a.detail.value.accCountryName), ("" == a.detail.value.appliMobile && e.data.appliMobileisTrue || "" == a.detail.value.appliIdNo || "" == a.detail.value.appliIdDateExpire || n.compareDate(p, a.detail.value.appliIdDateExpire) || "" == a.detail.value.accCountryName || "" == a.detail.appliNotiAddrList) && e.setData({
                appliIsWarn: !0,
                isComplete: !0
            }), ("" == a.detail.value.accProf || "" == a.detail.value.accTel || "" == a.detail.value.accIdNo || "" == a.detail.value.accIdExpireDate || n.compareDate(p, a.detail.value.accIdExpireDate) || "" == a.detail.value.accCountryName || "" == a.detail.accAddrList) && e.setData({
                accIsWarn: !0,
                isComplete: !0
            }), "Y" != e.data.hideConsignee || "" != a.detail.value.assigneeName && "" != a.detail.value.assigneeIdNo || e.setData({
                entrustIsWarn: !0,
                isComplete: !0
            }), "" == a.detail.value.appliAccountNo && e.setData({
                bankTransferIsWarn: !0,
                isComplete: !0
            }), "" != a.detail.value.firstName && "" != a.detail.value.lastName && "" != a.detail.value.birthDate || e.setData({
                appliIsWarn: !0,
                isComplete: !0
            }), i && e.setData({
                appliIsWarn: !0,
                isComplete: !0
            }), t && e.setData({
                appliIsWarn: !0,
                isComplete: !0
            }), s && e.setData({
                appliIsWarn: !0,
                isComplete: !0
            }), (r || o) && e.setData({
                isComplete: !0,
                flagTax: !0
            }), console.log("that.data.isComplete", e.data.isComplete), console.log("e.detail.value.taxReasonList", a.detail.value.taxReasonList), 
            "A" == e.data.residentsType && e.data.isShowTaxReasonList && (a.detail.value.taxReasonList == [] || a.detail.value.taxReasonList.length <= 0)) d.showToast(e, "请选择税收原因,可多选"); else if ("A" != e.data.residentsType || !e.data.isTaxOtherReason || a.detail.value.taxOtherReason) {
                var l = /[\u4E00-\u9FA5]/g;
                console.log("e.detail.value.taxOtherReason", a.detail.value.taxOtherReason);
                var c = a.detail.value.taxOtherReason ? a.detail.value.taxOtherReason.match(l) : "";
                if (console.log("len", c), "Y" == e.data.isTaxRegionCodeFlag && "A" == e.data.residentsType && e.data.isTaxOtherReason && (!c || c.length < 5)) d.showToast(e, "其他原因描述至少包含5个汉字"); else {
                    var h = a.detail.value.reasondetInput1 ? a.detail.value.reasondetInput1.match(l) : "";
                    if ("Y" != e.data.isTaxRegionCodeFlag || "A" === e.data.residentsType || "2" != e.data.reason || h && !(h.length < 5)) {
                        var g = a.detail.value.reasondetInput2 ? a.detail.value.reasondetInput2.match(l) : "";
                        if ("Y" != e.data.isTaxRegionCodeFlag || "A" === e.data.residentsType || "2" != e.data.reasonAdd || g && !(g.length < 5)) if (e.data.accTelisTrue) if (e.data.appliMobileisTrue) if ("Y" != e.data.isTaxRegionCodeFlag || "A" === e.data.residentsType || !e.data.taxContryOneFlag || e.data.reason || n.veifyHongkongTaxNo(a.detail.value.taxIdentifyOne)) if ("Y" != e.data.isTaxRegionCodeFlag || "A" === e.data.residentsType || e.data.taxContryOneFlag || e.data.reason || !n.hasHanzi(a.detail.value.taxIdentifyOne)) if ("Y" != e.data.isTaxRegionCodeFlag || "A" === e.data.residentsType || !e.data.taxContryTwoFlag || e.data.reasonAdd || n.veifyHongkongTaxNo(a.detail.value.taxIdentifyTwo)) if ("Y" != e.data.isTaxRegionCodeFlag || "A" === e.data.residentsType || e.data.taxContryTwoFlag || e.data.reasonAdd || !n.hasHanzi(a.detail.value.taxIdentifyTwo)) if ("1" == e.data.taxType && n.hasHanzi(a.detail.value.taxIdentifyUsa)) d.showToast(e, "纳税人识别号不能含有中文"); else {
                            if (e.data.isComplete) return console.log("请补全资料"), void d.showToast(e, "请补全资料");
                            if ("Y" != e.data.hasNursingGold || e.data.nursingGoldGetWay) {
                                a.detail.value.idTypeIndex = n.queryDesByList(d.baseData.idTypeDesList, "idtype", "idtypedes", a.detail.value.idType, "code"), 
                                a.detail.value.assigneeIdType = n.queryDesByList(d.baseData.idTypeDesList, "idtype", "idtypedes", a.detail.value.assigneeIdType, "code");
                                a.detail.value.authorityList;
                                for (var D = 0; D < a.detail.value.authorityList.length; D++) a.detail.value.authorityList[D] = "0" + (D + 1);
                                a.detail.value.appliMobile = a.detail.value.appliMobile;
                                var y = !0, I = "请核对:";
                                if ("02" == e.data.submitType) for (D = 0; D < e.data.imgList.length; D++) "01" == e.data.imgList[D].isNeeded && 0 == e.data.imgList[D].pass && (y = !1, 
                                I += e.data.imgList[D].materialName);
                                console.log("e.detail.valie", a.detail.value), "0" != a.detail.value.appliRelation || "" != a.detail.value.otherRelationDesc ? y ? "02" == e.data.submitType ? e.data.signSuccess ? e.data.infoChangeFlag ? (e.setData({
                                    hiddenInfo: !1
                                }), u = a.detail.value) : f(a.detail.value, e) : d.showToast(e, "请完成电子签名") : (console.log("e.detail.value", a.detail.value), 
                                e.data.infoChangeFlag ? (e.setData({
                                    hiddenInfo: !1
                                }), u = a.detail.value, console.log("保存saveDetailData", u)) : f(a.detail.value, e)) : d.showToast(e, I + "材料上传情况！") : d.showToast(e, "请填写具体关系");
                            } else d.showToast(e, "请选择护理金领取方式");
                        } else d.showToast(e, "纳税人识别号不能含有中文"); else d.showToast(e, "请输入合法的香港纳税人识别号"); else d.showToast(e, "纳税人识别号不能含有中文"); else d.showToast(e, "请输入合法的香港纳税人识别号"); else d.showToast(e, "请输入合法的申请人电话号码"); else d.showToast(e, "请输入合法的被保险人电话号码"); else d.showToast(e, "账户持有人未能取得纳税人识别号时其他原因描述至少包含5个汉字");
                    } else d.showToast(e, "账户持有人未能取得纳税人识别号时其他原因描述至少包含5个汉字");
                }
            } else d.showToast(e, "请输入其他原因描述");
        }, 500);
    },
    checkPhone: function() {},
    addTaxInfo: function() {
        this.setData({
            taxAdd: !1,
            taxCounts: "2"
        });
    },
    delTaxInfo: function() {
        this.setData({
            taxAdd: !0,
            taxCounts: "1",
            taxContryTwo: "",
            taxIdentifyTwo: "",
            reasonAdd: "",
            reasondetInput2: ""
        });
    },
    bindChangeTaxReason1: function(a) {
        if ("" == this.data.taxIdentifyOne) {
            if (console.log("that.data.taxContryOneIndex", this.data.taxContryOneIndex), "0" == this.data.taxContryOneIndex && "1" == a.currentTarget.dataset.value) return;
            this.setData({
                reason: a.currentTarget.dataset.value
            }), "2" == a.currentTarget.dataset.value ? this.setData({
                hidereasondetInput1: !1
            }) : this.setData({
                hidereasondetInput1: !0,
                reasondetInput1: ""
            });
        }
    },
    bindChangeTaxReason2: function(a) {
        if ("" == this.data.taxIdentifyTwo) {
            if ("0" == this.data.taxContryTwoIndex && "1" == a.currentTarget.dataset.value) return;
            this.setData({
                reasonAdd: a.currentTarget.dataset.value
            }), "2" == a.currentTarget.dataset.value ? this.setData({
                hidereasondetInput2: !1
            }) : this.setData({
                hidereasondetInput2: !0,
                reasondetInput2: ""
            });
        }
    },
    changeInsuranceGetWayType: function(a) {
        this.setData({
            insuranceGetWay: a.currentTarget.dataset.value
        });
    },
    changeNursingGoldGetWayType: function(a) {
        this.setData({
            nursingGoldGetWay: a.currentTarget.dataset.value
        });
    },
    changeResidentsType: function(a) {
        this.setData({
            residentsType: a.currentTarget.dataset.value
        }), "A" == a.currentTarget.dataset.value ? this.setData({
            firstName: "",
            lastName: "",
            birthDate: "",
            taxCounts: "0",
            presentAddrChinese1: "",
            presentAddrChinese2: "",
            presentAddrChinese3: "",
            presentAddrChinese4: "",
            presentAddrEnglish1: "",
            presentAddrEnglish2: "",
            presentAddrEnglish3: "",
            presentAddrEnglish4: "",
            birthAddrChinese1: "",
            birthAddrChinese2: "",
            birthAddrChinese3: "",
            birthAddrChinese4: "",
            birthAddrEnglish1: "",
            birthAddrEnglish2: "",
            birthAddrEnglish3: "",
            birthAddrEnglish4: "",
            taxType: "",
            taxIdentifyUsa: "",
            taxContryOne: "",
            taxContryTwo: "",
            taxIdentifyOne: "",
            taxIdentifyTwo: "",
            reason: "",
            reasonAdd: "",
            reasondetInput1: "",
            reasondetInput2: ""
        }) : this.setData({
            taxType: "1"
        });
    },
    inputFirstName: function(a) {
        this.setData({
            firstName: a.detail.value
        });
    },
    blurFirstName: function(a) {
        "" != a.detail.value && "undefined" != a.detail.value || d.showToast(this, "请输入纳税人的姓！");
    },
    inputLastName: function(a) {
        this.setData({
            lastName: a.detail.value
        });
    },
    blurLastName: function(a) {
        "" != a.detail.value && "undefined" != a.detail.value || d.showToast(this, "请输入纳税人的名！");
    },
    bindchangeBirthDate: function(a) {
        this.setData({
            birthDate: a.detail.value
        });
    },
    bindchangeAddressType: function(a) {
        console.log(a), this.setData({
            typeOfChina: a.currentTarget.dataset.code,
            curAddressType: a.currentTarget.dataset.des
        });
    },
    bindchangeBirthPlacetype: function(a) {
        console.log(a), this.setData({
            birthPlacetype: a.currentTarget.dataset.code,
            birthPlaceType: a.currentTarget.dataset.des
        });
    },
    inputPresentAddrChinese1: function(a) {
        this.setData({
            presentAddrChinese1: a.detail.value
        });
    },
    inputPresentAddrChinese2: function(a) {
        this.setData({
            presentAddrChinese2: a.detail.value
        });
    },
    inputPresentAddrChinese3: function(a) {
        this.setData({
            presentAddrChinese3: a.detail.value
        });
    },
    inputPresentAddrChinese4: function(a) {
        this.setData({
            presentAddrChinese4: a.detail.value
        });
    },
    inputPresentAddrEnglish1: function(a) {
        this.setData({
            presentAddrEnglish1: a.detail.value
        });
    },
    inputPresentAddrEnglish2: function(a) {
        this.setData({
            presentAddrEnglish2: a.detail.value
        });
    },
    inputPresentAddrEnglish3: function(a) {
        this.setData({
            presentAddrEnglish3: a.detail.value
        });
    },
    inputPresentAddrEnglish4: function(a) {
        this.setData({
            presentAddrEnglish4: a.detail.value
        });
    },
    blurPresentAddr: function(a) {
        "" != a.detail.value && "undefined" != a.detail.value || d.showToast(this, "请输入完整的(中文或英文)现居地址！");
    },
    inputBirthAddrChinese1: function(a) {
        this.setData({
            birthAddrChinese1: a.detail.value
        });
    },
    inputBirthAddrChinese2: function(a) {
        this.setData({
            birthAddrChinese2: a.detail.value
        });
    },
    inputBirthAddrChinese3: function(a) {
        this.setData({
            birthAddrChinese3: a.detail.value
        });
    },
    inputBirthAddrChinese4: function(a) {
        this.setData({
            birthAddrChinese4: a.detail.value
        });
    },
    inputBirthAddrEnglish1: function(a) {
        this.setData({
            birthAddrEnglish1: a.detail.value
        });
    },
    inputBirthAddrEnglish2: function(a) {
        this.setData({
            birthAddrEnglish2: a.detail.value
        });
    },
    inputBirthAddrEnglish3: function(a) {
        this.setData({
            birthAddrEnglish3: a.detail.value
        });
    },
    inputBirthAddrEnglish4: function(a) {
        this.setData({
            birthAddrEnglish4: a.detail.value
        });
    },
    blurBirthAddr: function(a) {
        "" != a.detail.value && "undefined" != a.detail.value || d.showToast(this, "请输入完整的(中文或英文)出生地地址！");
    },
    changeTaxType: function(a) {
        this.setData({
            taxType: a.currentTarget.dataset.value
        }), "1" == a.currentTarget.dataset.value ? this.setData({
            taxCounts: "0",
            taxContryOne: "",
            taxContryTwo: "",
            taxIdentifyOne: "",
            taxIdentifyTwo: "",
            reason: "",
            reasonAdd: "",
            reasondetInput1: "",
            reasondetInput2: "",
            taxContryOneFlag: !1,
            taxContryTwoFlag: !1,
            taxContryOneIndex: "",
            taxContryTwoIndex: ""
        }) : (this.setData({
            taxCounts: "1",
            taxIdentifyUsa: ""
        }), "0" == this.data.taxContryOneIndex && this.setData({
            taxContryOneFlag: !0
        }), "0" == this.data.taxContryTwoIndex && this.setData({
            taxContryTwoFlag: !0
        }));
    },
    inputTaxIdentifyUsa: function(a) {
        this.setData({
            taxIdentifyUsa: a.detail.value
        });
    },
    inputTaxContryOne: function(a) {
        this.setData({
            taxContryOne: a.detail.value
        });
    },
    inputTaxIdentifyOne: function(a) {
        this.setData({
            taxIdentifyOne: a.detail.value
        }), "" != a.detail.value && this.setData({
            reason: "",
            reasondetInput1: "",
            hidereasondetInput1: !0
        });
    },
    blurReasondetInput1: function(a) {
        this.setData({
            reasondetInput1: a.detail.value
        });
    },
    inputTaxContryTwo: function(a) {
        this.setData({
            taxContryTwo: a.detail.value
        });
    },
    inputTaxIdentifyTwo: function(a) {
        this.setData({
            taxIdentifyTwo: a.detail.value
        }), "" != a.detail.value && this.setData({
            reasonAdd: "",
            reasondetInput2: "",
            hidereasondetInput2: !0
        });
    },
    blurReasondetInput2: function(a) {
        this.setData({
            reasondetInput2: a.detail.value
        });
    },
    showAnnotation: function(a) {
        this.setData({
            hideAnnotation: !1
        });
    },
    closeAnnotationModal: function(a) {
        this.setData({
            hideAnnotation: !0
        });
    },
    ensureChange: function() {
        var a = this.data.infoArr;
        for (var e in console.log("oldInfoObj", h), console.log("infoArr", a), a) a[e].checked || ("accCountryName" == a[e].key && (u.accCountryCode = h.accCountryCode), 
        "appliCountryName" == a[e].key && (u.appliCountryCode = h.appliCountryCode), u[a[e].key] = h[a[e].key]);
        this.setData({
            hiddenInfo: !0
        }), f(u, this);
    },
    cancelChange: function() {
        this.setData({
            hiddenInfo: !0,
            hiddenInfoCancel: !1
        });
    },
    changeCancel: function() {
        this.setData({
            hiddenInfoCancel: !0
        });
    },
    changeKnow: function() {
        var a = this.data.infoArr;
        for (var e in console.log("oldInfoObj", h), console.log("infoArr", a), a) "accCountryName" == a[e].key && (u.accCountryCode = h.accCountryCode ? h.accCountryCode : this.data.accCountryCode), 
        "appliCountryName" == a[e].key && (u.appliCountryCode = h.appliCountryCode ? h.appliCountryCode : this.data.appliCountryCode), 
        "accAddrList" == a[e].key || "appliNotiAddrList" == a[e].key ? "" == h[a[e].key][0] ? u[a[e].key] = this.data[a[e].key] : u[a[e].key] = h[a[e].key] : "accIdExpireDate" == a[e].key || "appliIdDateExpire" == a[e].key ? "2037-01-01" == h[a[e].key] ? u[a[e].key] = this.data[a[e].key] : u[a[e].key] = h[a[e].key] : u[a[e].key] = h[a[e].key] ? h[a[e].key] : this.data[a[e].key];
        this.setData({
            hiddenInfoCancel: !0
        }), f(u, this);
    },
    infoChange: function(a) {
        for (var e = this.data.infoArr, t = a.detail.value, i = 0, s = e.length; i < s; ++i) {
            e[i].checked = !1;
            for (var d = 0, n = t.length; d < n; ++d) if (e[i].key === t[d]) {
                e[i].checked = !0;
                break;
            }
        }
        this.setData({
            infoArr: e
        }), console.log("infoArr", this.data.infoArr);
    },
    showInfoPop: function() {
        wx.showModal({
            title: "提示",
            content: "客户身份信息无法直接修改。根据反洗钱相关要求,请通过保全更新正确的身份信息",
            showCancel: !1
        });
    },
    taxReasonListChange: function(a) {
        console.log("税收原因选项", a);
        var e = a.detail.value.findIndex(function(a) {
            return "5" == a;
        });
        console.log("index", e), -1 != e ? this.setData({
            isTaxOtherReason: !0
        }) : this.setData({
            isTaxOtherReason: !1
        });
    },
    setTaxReasonList: function(a) {
        for (var e = a, t = this.data.claimTaxReasonList, i = 0, s = t.length; i < s; ++i) {
            t[i].checked = !1;
            for (var d = 0, n = e.length; d < n; ++d) if (t[i].reasonid === e[d]) {
                t[i].checked = !0;
                break;
            }
        }
        var r = a.findIndex(function(a) {
            return "5" == a;
        });
        console.log("index", r), -1 != r ? this.setData({
            isTaxOtherReason: !0
        }) : this.setData({
            isTaxOtherReason: !1
        }), this.setData({
            claimTaxReasonList: t
        });
    },
    birthChineseCountry: function(a) {
        console.log("e", a);
        switch (a.currentTarget.dataset.type) {
          case "1":
            this.setData({
                birthAddrChineseIndex: a.detail.value,
                birthAddrChinese1: this.data.isoCountryInfoCodeList[a.detail.value]
            });
            break;

          case "2":
            this.setData({
                birthAddrEnglishIndex: a.detail.value,
                birthAddrEnglish1: this.data.isoCountryInfoCodeList[a.detail.value]
            });
            break;

          case "3":
            this.setData({
                taxContryOneIndex: a.detail.value,
                taxContryOne: this.data.isoCountryNoCnaCodeList[a.detail.value],
                reason: ""
            }), "0" == a.detail.value ? this.setData({
                taxContryOneFlag: !0
            }) : this.setData({
                taxContryOneFlag: !1
            });
            break;

          case "4":
            this.setData({
                taxContryTwoIndex: a.detail.value,
                taxContryTwo: this.data.isoCountryNoCnaCodeList[a.detail.value],
                reasonAdd: ""
            }), "0" == a.detail.value ? this.setData({
                taxContryTwoFlag: !0
            }) : this.setData({
                taxContryTwoFlag: !1
            });
        }
    }
});
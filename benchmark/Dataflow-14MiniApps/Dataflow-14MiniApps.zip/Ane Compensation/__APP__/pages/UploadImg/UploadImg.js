var e, t, a, i = require("../../@babel/runtime/helpers/defineProperty"), o = getApp(), r = require("../../7D41315784CF379C1B2759508F425043.js"), d = require("../../BA4681C684CF379CDC20E9C1FBE15043.js"), s = require("../../9A41035384CF379CFC276B5474025043.js");

function l() {
    e = new d.RSAKey(), a = o.globalRsaObj.n, t = o.globalRsaObj.a, e.setPublic(a, t);
}

function n(t) {
    l();
    var a = {
        submitType: t.data.submitType,
        regsNo: e.encrypt(t.data.regsNo),
        accClientNo: e.encrypt(t.data.accClientNo),
        materialCode: e.encrypt(t.data.materialCode),
        fileName: t.data.materialName,
        isPrivilegeWechatId: e.encrypt(t.data.isPrivilegeWechatId),
        timestamp: e.encrypt("" + new Date().getTime()),
        weChatId: o.wxCode.openid
    };
    console.log("rsa.encrypt(new Date().getTime())", e.encrypt("" + new Date().getTime())), 
    console.log("that.data", t.data), wx.request({
        url: r.getSer(o.globalData.userInfo.nickName).ser_ues_url + "/claim.queryUploadMaterialWechatClaim.do",
        data: a,
        method: "GET",
        header: {
            "Content-Type": "application/json",
            Charset: "utf-8"
        },
        success: function(e) {
            r.decodeJson(e), console.log(" queryImgListres", e), e.data.isAdult && t.setData({
                isAdult: e.data.isAdult
            });
            var a = [];
            if ("life-00001" == e.data.returnCode) {
                for (var i = function(e) {
                    for (var t = [], a = 0; a < e.length; a++) -1 == t.indexOf(e[a]) && t.push(e[a]);
                    return t;
                }(e.data.showMaterialList), d = 0; d < i.length; d++) for (var s = 0; s < e.data.gradeMapList.length; s++) i[d] == e.data.gradeMapList[s].material_code && (a[d] = e.data.gradeMapList[s], 
                a[d].materialsList = [], a[d].imgLength = 0);
                for (d = 0; d < e.data.materialsList.length; d++) for (s = 0; s < a.length; s++) {
                    if (e.data.materialsList[d][0].materialCode == a[s].material_code) for (var l = 0; l < e.data.materialsList[d].length; l++) {
                        var n = e.data.materialsList[d][l].buffer;
                        e.data.materialsList[d][l].buffer = n.replace(/\n/g, ""), a[s].materialsList.push(e.data.materialsList[d][l]);
                    }
                    a[s].imgLength = a[s].materialsList.length;
                }
                !function(e, t) {
                    var a;
                    if ("100" == e.data.materialCode) a = [ {
                        text: "1.需审核资料原件后拍照."
                    }, {
                        text: "2.常见身份证明：居民身份证、港澳居民往来内地通行证、台湾居民来往大陆通行证、护照、由公安机关户籍管理部门出具的带照片的身份证明文件等."
                    } ], "Y" == e.data.isAdult && a.push({
                        text: "3.常见身份关系证明：结婚证、出生医学证明书、独生子女证、居民户口簿、公证书、公安部门出具的亲属关系证明及监护证明等."
                    }), e.setData({
                        demoTextList: a
                    }); else for (var i = 0; i < t.length; i++) "201" == t[i].material_code ? (a = [ {
                        text: "1.需审核资料原件."
                    }, {
                        text: "2.包括门诊病历封面、与本次事故有关的所有门诊就诊病历."
                    }, {
                        text: "3.注意按治疗时间的先后顺序拍照上传."
                    } ], t[i].demoTextList = a) : "202" == t[i].material_code ? (a = [ {
                        text: "1.需审核资料原件."
                    }, {
                        text: "2.包括出院小结（出院记录）、疾病诊断证明书、住院病历."
                    } ], t[i].demoTextList = a) : "203" == t[i].material_code ? (a = [ {
                        text: "1.需审核资料原件."
                    }, {
                        text: "2.包括病理报告、化验报告、放射检查报告等."
                    } ], t[i].demoTextList = a) : "204" == t[i].material_code ? (a = [ {
                        text: "1.需审核资料原件后拍照上传."
                    } ], t[i].demoTextList = a) : "601" == t[i].material_code ? (a = [ {
                        text: "1.需审核资料原件或复印件."
                    }, {
                        text: "2.没有医保报销或其他先期报销的，需拍照上传原件；有医保报销或其他先期报销的，有原件拍照上传原件，没有原件可拍照上传复印件."
                    }, {
                        text: "3.注意按治疗时间的先后顺序拍照上传."
                    } ], t[i].demoTextList = a) : "602" == t[i].material_code ? (a = [ {
                        text: "1.包括城镇职工医保、城镇居民医保、新农合、医疗救助等政府举办的基本医疗保障项目."
                    }, {
                        text: "2.需审核并提供医保报销单原件，并注明报销金额与比例，加盖报销单位印章."
                    }, {
                        text: "3.注意按治疗时间的先后顺序拍照上传."
                    } ], t[i].demoTextList = a) : "603" == t[i].material_code ? (a = [ {
                        text: "1.包括其他保险公司、工作单位等的费用报销."
                    }, {
                        text: "2.需审核并提供报销单原件，并注明报销金额与比例，加盖报销单位印章."
                    }, {
                        text: "3.注意按治疗时间的先后顺序拍照上传."
                    } ], t[i].demoTextList = a) : "23" == t[i].material_code ? (a = [ {
                        text: "1.需审核资料原件."
                    }, {
                        text: "2.注意按治疗时间的先后顺序拍照上传."
                    }, {
                        text: "3.注意提供与医疗费用发票相对应的费用明细清单."
                    } ], t[i].demoTextList = a) : "19" == t[i].material_code ? (a = [ {
                        text: "1.需对资料原件审核后拍照上传."
                    }, {
                        text: "2.银行帐户须为申请人名下，包括银行存折、银行卡."
                    } ], t[i].demoTextList = a) : "30" == t[i].material_code ? (a = [ {
                        text: "1.需审核资料原件后拍照上传."
                    }, {
                        text: "2.重大疾病诊断证明：申请重大疾病保险金，应提供相关诊断证明、检查/检验结果等医学资料；如恶性肿瘤原则上应提供病理报告（如客户未行病理检查，应提供相关影像学等医学检查记录）."
                    } ], t[i].demoTextList = a) : "31" == t[i].material_code ? (a = [ {
                        text: "1.需审核资料原件后拍照上传."
                    }, {
                        text: "2.残疾鉴定证明：指由保险公司、理赔申请人双方认可的医疗机构或有资质的鉴定机构根据客户购买的意外伤害保险条款中关于残疾程度的约定项目及标准出具的被保险人残疾程度的资料或身体残疾程度评定书."
                    } ], t[i].demoTextList = a) : "32" == t[i].material_code ? (a = [ {
                        text: "1.客户有可见伤残的，请上传客户的伤残部位照片."
                    }, {
                        text: "2.伤残照片需包含一张全身照，以便确认是客户本人出险；另根据需要上传一张或一张以上局部照，以便判断客户的伤残程度."
                    } ], t[i].demoTextList = a) : "25" == t[i].material_code ? (a = [ {
                        text: "1.需对资料原件审核后拍照上传."
                    }, {
                        text: "2.常见社保证明资料包括：社会保障卡、农合手册、社保结算单、商业保险结算单、其他第三方赔付证明等."
                    } ], t[i].demoTextList = a) : "901" == t[i].material_code ? (a = [ {
                        text: "1.需对资料原件审核后拍照上传."
                    }, {
                        text: "2.意外事故证明指说明意外事故经过的证明资料:"
                    }, {
                        text: "a.交通事故提供交警部门出具的《交通事故责任认定书》、《交通事故责任调解书》、《交通事故简易程序处理书》、机动车驾驶证与行驶证（正、副本）等材料;"
                    }, {
                        text: "b.因遭受不法侵害受伤的可提供公安部门的“事故证明”等材料;"
                    }, {
                        text: "c.无第三方见证的原则上可由申请人提供说明意外经过的书面材料等;"
                    }, {
                        text: "3.对于索赔金额在3000元以下个人医疗保险小额理赔中，除有公安机关等第三方介入的情况外，无需提供意外事故证明;"
                    } ], t[i].demoTextList = a) : (a = [ {
                        text: "1.需对资料原件审核后拍照上传."
                    } ], t[i].demoTextList = a);
                    if (console.log("that.data.materialCode", e.data.materialCode), console.log("data", t), 
                    "200" == e.data.materialCode) wx.getStorage({
                        key: o.wxCode.openid + "_" + e.data.regsNo,
                        success: function(a) {
                            for (var i in console.log("regsNo-----------res", a.data), t) -1 == a.data.indexOf(t[i].material_code) ? t[i].isShow = !1 : t[i].isShow = !0;
                            console.log("data", t), e.setData({
                                gradeMapList: t
                            });
                        }
                    }); else {
                        for (var i in t) t[i].isShow = !0;
                        e.setData({
                            gradeMapList: t
                        });
                    }
                }(t, a);
            } else {
                console.log("请求数据失败", e.data.returnMsg);
                var m = e.data.returnMsg;
                null == m && (m = "请求数据失败！请重试！"), o.showToast(t, m);
            }
        },
        fail: function() {},
        complete: function() {}
    });
}

Page({
    data: {
        hidden: !0,
        hiddenMask: !0,
        Loadinghidden: !0,
        maskText: "是否确定删除",
        regsNo: "",
        accClientNo: "",
        imgtype: "",
        item: {},
        item2: {},
        demotem: {},
        pictures: [],
        title: "",
        imgs: [],
        demoimgList: [],
        demoTextList: [],
        tiptxt: "",
        delimgIndex: "",
        hiddenToast: !0,
        inferiorFlag: "",
        materialCode: "",
        documentType: "",
        documentName: "",
        documentCode: "",
        materialName: "",
        fileName: "",
        isNeeded: "",
        submitType: "",
        gradeMapList: [],
        tempFilePaths: "",
        pageUrl: "",
        isAdult: "N",
        oldmaterialCode: "",
        hiddenPrevImg: !0,
        previmgUrls: [],
        failMsg: "",
        previmgIsReq: !1
    },
    onLoad: function(e) {
        var t = this;
        console.log("options222", e), "02" == e.submitType ? t.setData({
            regsNo: e.regsNo,
            materialCode: e.materialCode,
            oldmaterialCode: e.materialCode,
            inferiorFlag: e.inferiorFlag,
            documentType: e.documentType,
            materialName: e.materialName,
            submitType: e.submitType,
            isPrivilegeWechatId: e.isPrivilegeWechatId
        }) : (t.setData({
            regsNo: e.regsNo,
            accClientNo: e.accClientNo,
            materialCode: e.materialCode,
            oldmaterialCode: e.materialCode,
            inferiorFlag: e.inferiorFlag,
            documentType: e.documentType,
            materialName: e.materialName,
            isNeeded: e.isNeeded,
            submitType: e.submitType,
            pageUrl: e,
            isPrivilegeWechatId: e.isPrivilegeWechatId
        }), e.pagetype && wx.getStorage({
            key: "uploadFailCount",
            success: function(e) {
                0 == e.data.failcount ? o.showToast(t, "影像上传成功！") : o.showToast(t, e.data.failcount + e.data.mesg);
            },
            fail: function() {}
        })), n(t), t.setData({
            pictures: t.data.item.imgs,
            demoimgList: [ {
                img: "../../pages/images/demo1.png"
            }, {
                img: "../../pages/images/demo2.png"
            }, {
                img: "../../pages/images/demo3.png"
            }, {
                img: "../../pages/images/demo4.png"
            } ]
        });
    },
    onShow: function() {
        s.onShow(), s.onEvent(o.SKAPPObj.onlineApply[5].id, o.SKAPPObj.onlineApply[5].label, o.SKAPPObj.onlineApply[5].params);
        var e = getCurrentPages();
        e.length > 1 && e[e.length - 2].initData(1);
    },
    onHide: function() {
        s.onHide();
    },
    chooseImgInWechat: function(e) {
        var t = this;
        t.setData({
            documentCode: e.currentTarget.dataset.documentcode,
            materialCode: e.currentTarget.dataset.materialcode,
            documentName: e.currentTarget.dataset.documentname,
            documentType: e.currentTarget.dataset.documenttype
        }), wx.chooseImage({
            count: 9,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var a = e.tempFilePaths;
                t.setData({
                    textHidden: !0,
                    photoHidden: !1,
                    tempFilePaths: a
                }), t.setData({
                    item: {
                        title: t.data.title,
                        imgs: t.data.imgs
                    }
                }), t.uploadImgs();
            }
        });
    },
    uploadImgs: function() {
        s.onEvent(o.SKAPPObj.onlineApply[6].id, o.SKAPPObj.onlineApply[6].label, o.SKAPPObj.onlineApply[6].params);
        var t = this;
        t.setData({
            Loadinghidden: !1
        }), l();
        for (var a = 0, i = 0, d = 0; d < t.data.tempFilePaths.length; d++) {
            var n = {
                regsNo: e.encrypt(t.data.regsNo),
                fileName: t.data.tempFilePaths[d],
                documentCode: t.data.documentCode,
                documentName: t.data.documentName,
                materialCode: t.data.materialCode,
                inferiorFlag: t.data.inferiorFlag,
                weChatId: o.wxCode.openid
            };
            console.log("formData", n), wx.uploadFile({
                url: r.getSer(o.globalData.userInfo.nickName).ser_ues_url + "/claim.uploadImageWechatClaim.do",
                filePath: t.data.tempFilePaths[d],
                name: "file",
                formData: n,
                header: {
                    "Content-Type": "multipart/form-data",
                    Charset: "utf-8"
                },
                success: function(e) {
                    r.decodeJson(e), console.log("res", e), -1 != e.data.indexOf("life-00001") ? t.setData({
                        failMsg: e.data.returnMsg ? e.data.returnMsg : e.data.message
                    }) : i++;
                },
                fail: function(e) {
                    console.log(e), i++;
                },
                complete: function() {
                    a++, wx.setStorage({
                        key: "uploadFailCount",
                        data: {
                            failcount: i,
                            mesg: "张影像上传失败。" + t.data.failMsg
                        }
                    }), setTimeout(function() {
                        a == t.data.tempFilePaths.length && (console.log("that.data.isPrivilegeWechatId", t.data.isPrivilegeWechatId), 
                        wx.redirectTo({
                            url: "/pages/UploadImg/UploadImg?regsNo=" + t.data.pageUrl.regsNo + "&accClientNo=" + t.data.pageUrl.accClientNo + "&materialCode=" + t.data.pageUrl.materialCode + "&documentType=" + t.data.pageUrl.documentType + "&isNeeded=" + t.data.pageUrl.isneeded + "&materialName=" + t.data.pageUrl.materialName + "&inferiorFlag=" + t.data.pageUrl.inferiorFlag + "&isPrivilegeWechatId=" + t.data.isPrivilegeWechatId + "&submitType=" + t.data.pageUrl.submitType + "&pagetype=1"
                        }));
                    }, 1e3);
                }
            });
        }
    },
    delImg: function(e) {
        this.setData(i({
            delimgIndex: e.currentTarget.dataset.index,
            fileName: e.currentTarget.dataset.filename,
            materialCode: e.currentTarget.dataset.materialcode
        }, "delimgIndex", e.currentTarget.dataset.index)), o.showModal(this);
    },
    sureDelImg: function() {
        var e = this;
        wx.request({
            url: r.getSer(o.globalData.userInfo.nickName).ser_url + "/open/appsvr/life/deleteWeChatImage?access_token=" + o.tokens.access_token + "&request_id=" + r.uuid(),
            data: {
                regsNo: e.data.regsNo,
                materialCode: e.data.materialCode,
                fileName: e.data.fileName,
                inferiorFlag: e.data.inferiorFlag,
                weChatId: o.wxCode.openid
            },
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8"
            },
            success: function(t) {
                if (r.decodeJson(t), "life-00001" != t.data.returnCode) o.showToast(e, t.data.returnMsg); else {
                    var a, i;
                    o.showToast(e, t.data.returnMsg);
                    for (var d = 0; d < e.data.gradeMapList.length; d++) e.data.materialCode == e.data.gradeMapList[d].material_code && (a = e.data.gradeMapList[d].materialsList, 
                    i = d);
                    e.data.gradeMapList[i].materialsList = r.removeArr(a, e.data.delimgIndex), e.data.gradeMapList[i].imgLength = e.data.gradeMapList[i].materialsList.length, 
                    e.setData({
                        gradeMapList: e.data.gradeMapList
                    });
                }
            },
            fail: function(e) {
                console.log("fail");
            }
        }), o.closeModal(e);
    },
    closeModal: function() {
        o.closeModal(this);
    },
    bindPreviewImage: function(t) {
        var a = this;
        if (!a.data.previmgIsReq) {
            a.setData({
                previmgIsReq: !0
            });
            var i = [], d = t.currentTarget.dataset.materialcode, s = t.currentTarget.dataset.index, n = s + 4, m = a.data.gradeMapList;
            console.log("filesList", m);
            for (var g = [], c = 0; c < m.length; c++) m[c].material_code == d && (g = m[c].materialsList);
            console.log("currentFiles", g), function t(d) {
                d = d;
                if (console.log("OcurrentFiles", d), !d) return void a.setData({
                    hiddenPrevImg: !1,
                    previmgUrls: i
                });
                l(), console.log("OcurrentFiles", d);
                var m = {
                    regsNo: e.encrypt(a.data.regsNo),
                    materialCode: d.materialCode,
                    fileName: d.chsFileName,
                    timestamp: e.encrypt("" + new Date().getTime()),
                    weChatId: o.wxCode.openid
                };
                wx.request({
                    url: r.getSer(o.globalData.userInfo.nickName).ser_ues_url + "/claim.queryImageDetailWechatClaim.do",
                    data: m,
                    method: "GET",
                    header: {
                        "Content-Type": "application/json",
                        Charset: "utf-8"
                    },
                    success: function(e) {
                        console.log("queryImage    res", e), r.decodeJson(e), "life-00001" != e.data.returnCode ? o.showToast(a, e.data.message) : (i.push("data:image/jpg;base64," + e.data.BUFFER.replace(/\n/g, "")), 
                        s < n ? (s++, t(g[s])) : a.setData({
                            hiddenPrevImg: !1,
                            previmgUrls: i
                        }));
                    },
                    fail: function() {
                        console.log("提交失败");
                    },
                    complete: function() {
                        a.setData({
                            previmgIsReq: !1
                        });
                    }
                });
            }(g[s]);
        }
    },
    cancelSubmit: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    closePrevImg: function() {
        this.setData({
            hiddenPrevImg: !0
        });
    },
    imgScale: function(e) {},
    resetScale: function(e) {}
});
var e = getApp(), a = require("../../7D41315784CF379C1B2759508F425043.js");

Page({
    data: {
        registerNo: "",
        isProblemFlag: "",
        isProblemMaterialUploadOk: "",
        claimUploadImageInfos: [],
        uploadIcon: "../../pages/images/new/iconCamera.png",
        hasUploadIcon: "../../pages/images/new/success.png",
        delIcon: "../../pages/images/new/close.png",
        previewImgArr: [],
        hiddenToast: !0,
        tempFilePaths: [],
        materialCode: "",
        loading: !1,
        caseHasProblemType: ""
    },
    onLoad: function(e) {
        this.setData({
            registerNo: e.registerNo,
            caseHasProblemType: e.caseHasProblemType
        }), "ADVANCE_PAY" !== this.data.caseHasProblemType && this.initData();
    },
    onShow: function() {
        "ADVANCE_PAY" == this.data.caseHasProblemType && this.initData();
    },
    initData: function() {
        var t = this;
        wx.showLoading({
            title: "加载中..."
        }), wx.request({
            url: a.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "queryClaimHasUploadMaterialInfo?access_token=" + e.tokens.access_token + "&request_id=" + a.uuid(),
            data: {
                registerNo: this.data.registerNo,
                systemId: e.systemId.advancepay
            },
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: e.loginAuthorization
            },
            success: function(a) {
                if (console.log("****", a), wx.hideLoading(), "crs-00001" === a.data.returnCode) {
                    t.base64Img(a.data.data.claimUploadImageInfos);
                    t.setData({
                        registerNo: a.data.data.registerNo,
                        isProblemFlag: a.data.data.isProblemFlag,
                        isProblemMaterialUploadOk: a.data.data.isProblemMaterialUploadOk,
                        claimUploadImageInfos: a.data.data.claimUploadImageInfos,
                        previewImgArr: [],
                        loading: !0
                    });
                } else t.setData({
                    loading: !0
                }), e.showToast(t, a.data.message);
            },
            fail: function(a) {
                wx.hideLoading(), t.setData({
                    loading: !0
                }), e.showToast(t, a.data.message || "查询异常");
            },
            complete: function(e) {}
        });
    },
    base64Img: function(e) {
        for (var a = 0; a < e.length; a++) if (null !== e[a].compressAndNormalImage && 0 !== e[a].compressAndNormalImage.length) for (var t = 0; t < e[a].compressAndNormalImage.length; t++) e[a].compressAndNormalImage[t].compressImageStream = "data:image/jpg;base64," + e[a].compressAndNormalImage[t].compressImageStream.replace(/\n/g, ""), 
        e[a].compressAndNormalImage[t].normalImageStream = "data:image/jpg;base64," + e[a].compressAndNormalImage[t].normalImageStream.replace(/\n/g, "");
        return e;
    },
    chooseImgInWechat: function(e) {
        var a = this;
        a.setData({
            materialCode: e.currentTarget.dataset.materialcode
        }), "24" == e.currentTarget.dataset.materialcode ? wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "camera" ],
            success: function(e) {
                var t = e.tempFilePaths;
                a.setData({
                    tempFilePaths: t
                }), console.log(a.data.tempFilePaths), a.conversionImgToBase64("Y");
            }
        }) : wx.chooseImage({
            count: 9,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var t = e.tempFilePaths;
                a.setData({
                    tempFilePaths: t
                }), console.log(a.data.tempFilePaths), a.conversionImgToBase64("N");
            }
        });
    },
    conversionImgToBase64: function(a) {
        var t = this, o = [];
        if (0 !== t.data.tempFilePaths.length) for (var s = 0; s < t.data.tempFilePaths.length; s++) wx.getFileSystemManager().readFile({
            filePath: t.data.tempFilePaths[s],
            encoding: "base64",
            success: function(e) {
                o.push(e.data), t.data.tempFilePaths.length == o.length && t.uploadAgain(o, a);
            }
        }); else e.showToast(t, "请先选择图片！");
    },
    uploadAgain: function(t, o) {
        for (var s = this, n = [], r = 0; r < s.data.tempFilePaths.length; r++) {
            var i = new Promise(function(o, n) {
                wx.request({
                    url: a.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "uploadCaseClaimImage?access_token=" + e.tokens.access_token + "&request_id=" + a.uuid(),
                    method: "POST",
                    data: {
                        businessOperation: "claimAdvancePay",
                        materialCode: s.data.materialCode,
                        registerNo: s.data.registerNo,
                        uploadImageStream: t[r]
                    },
                    header: {
                        "Content-Type": "application/json",
                        Charset: "utf-8",
                        loginAuthorization: e.loginAuthorization
                    },
                    success: function(a) {
                        return console.log("上传图片====》", a), "crs-00001" !== a.data.returnCode ? (e.showToast(s, a.data.message), 
                        n(a)) : (console.log(r), o(a));
                    },
                    fail: function(e) {
                        return e;
                    },
                    complete: function(e) {
                        return e;
                    }
                });
            });
            n.push(i);
        }
        console.log("promisearr", n), Promise.all(n).then(function(e) {
            console.log("res====>", e), "Y" == o ? wx.navigateTo({
                url: "/pages/advancePaySign/advancePaySign?registerNo=" + s.data.registerNo + "&advancePayInferiorFlag=Y"
            }) : s.initData();
        }).catch(function(a) {
            console.log("err ==== ", a), e.showToast(s, a.data.message);
        });
    },
    delImg: function(t) {
        var o = this;
        wx.showModal({
            title: "提示",
            content: "确定要删除此图片吗？",
            success: function(s) {
                if (s.confirm) console.log("确定删除"), new Promise(function(s, n) {
                    wx.request({
                        url: a.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "deleteCaseClaimImage?access_token=" + e.tokens.access_token + "&request_id=" + a.uuid(),
                        method: "POST",
                        data: {
                            imageFileName: t.currentTarget.dataset.imagefilename,
                            materialCode: t.currentTarget.dataset.materialcode,
                            registerNo: o.data.registerNo
                        },
                        header: {
                            "Content-Type": "application/json",
                            Charset: "utf-8",
                            loginAuthorization: e.loginAuthorization
                        },
                        success: function(a) {
                            "crs-00001" === a.data.returnCode ? (e.showToast(o, a.data.message), s(a)) : (e.showToast(o, a.data.message || "删除异常"), 
                            n(a));
                        },
                        fail: function(a) {
                            e.showToast(o, t.data.message || "删除异常"), n(a);
                        }
                    });
                }).then(function(e) {
                    o.initData();
                }).catch(function(a) {
                    e.showToast(o, a.data.message || "删除异常");
                }); else if (s.cancel) return console.log("取消删除"), !1;
            }
        });
    },
    tabPreview: function(e) {
        e.currentTarget.dataset.url;
        var a = e.currentTarget.dataset.imagefilename, t = e.currentTarget.dataset.materialcode, o = [], s = this.data.claimUploadImageInfos.find(function(e) {
            return e.materialCode === t;
        }), n = null;
        for (var r in s.compressAndNormalImage) a === s.compressAndNormalImage[r].imageFileName && (n = s.compressAndNormalImage[r].normalImageStream), 
        o.push(s.compressAndNormalImage[r].normalImageStream);
        wx.previewImage({
            current: n,
            urls: o
        });
    },
    returnPrev: function(t) {
        var o = this;
        wx.request({
            url: a.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "submitClaimProblemCaseReturn?access_token=" + e.tokens.access_token + "&request_id=" + a.uuid(),
            method: "POST",
            data: {
                registerNo: o.data.registerNo,
                businessOperation: "claimAdvancePay",
                systemId: e.systemId.advancepay
            },
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: e.loginAuthorization
            },
            success: function(a) {
                "crs-00001" === a.data.returnCode ? (e.showToast(o, a.data.message), wx.navigateBack({
                    delta: 1
                })) : e.showToast(o, a.data.message || "处理失败");
            },
            fail: function(a) {
                e.showToast(o, t.data.message || "处理失败");
            }
        });
    }
});
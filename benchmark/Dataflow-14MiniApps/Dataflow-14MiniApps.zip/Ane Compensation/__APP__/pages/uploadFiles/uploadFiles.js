var e, a, t, i = getApp(), o = require("../../7D41315784CF379C1B2759508F425043.js"), s = require("../../BA4681C684CF379CDC20E9C1FBE15043.js"), r = require("../../9A41035384CF379CFC276B5474025043.js");

Page({
    data: {
        regsNo: "",
        accClientNo: "",
        submitType: "",
        inferiorFlag: "",
        weChatId: "",
        Loadinghidden: !1,
        loadingMsg: "",
        hiddenToast: !0,
        filesList: [],
        inferiorInfo: [],
        imgs: [],
        baseData: "",
        imgbase64: "",
        maskText: "是否确定删除",
        hidden: !0,
        fileName: "",
        documentCode: "",
        documentName: "",
        materialCode: "",
        datamesg: "",
        hiddenPrevImg: !0,
        previmgUrls: [],
        isWhiteWeChatId: "",
        failMsg: "",
        previmgIsReq: !1,
        indicatorDots: !1,
        autoplay: !1,
        interval: 5e3,
        duration: 1e3,
        isShowinferior: !0,
        inferiorIsOK: "",
        bigInferiorInfo: [],
        checkedInferiorInfo: []
    },
    onLaunch: function() {},
    onLoad: function(e) {
        var a;
        (a = this).setData({
            loadingMsg: "加载中...",
            regsNo: e.registerNo,
            accClientNo: e.accClientNo,
            submitType: e.submitType,
            isWhiteWeChatId: e.isWhiteWeChatId,
            inferiorFlag: e.inferiorFlag
        }), console.log("options", e), e.pagetype && wx.getStorage({
            key: "FailCount",
            success: function(e) {
                0 == e.data.failcount ? i.showToast(a, "影像上传成功！") : i.showToast(a, e.data.failcount + e.data.mesg);
            },
            fail: function() {}
        }), (a = this).setData({
            userInfo: i.globalData,
            weChatId: i.wxCode.openid
        });
    },
    onShow: function() {
        var a = this;
        r.onShow(), r.onEvent(i.SKAPPObj.process[4].id, i.SKAPPObj.process[4].label, i.SKAPPObj.process[4].params), 
        a.setRsa(), console.log("that.data.isWhiteWeChatId", a.data.isWhiteWeChatId), console.log("that.data.regsNo", a.data.regsNo), 
        console.log("that.data.inferiorFlag", a.data.inferiorFlag);
        var t = {
            submitType: a.data.submitType,
            regsNo: e.encrypt(a.data.regsNo),
            inferiorFlag: e.encrypt(a.data.inferiorFlag),
            isWhiteWeChatId: e.encrypt(a.data.isWhiteWeChatId),
            timestamp: e.encrypt("" + new Date().getTime()),
            weChatId: i.wxCode.openid
        };
        wx.request({
            url: o.getSer(i.globalData.userInfo.nickName).ser_ues_url + "/claim.queryUploadMaterialWechatClaim.do",
            data: t,
            method: "GET",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8"
            },
            success: function(e) {
                o.decodeJson(e), console.log("res", e);
                e.data.materialList;
                var t = e.data.chsFileList;
                if (e.data.inferiorInfo) var i = e.data.inferiorInfo.materialList ? e.data.inferiorInfo.materialList : [], s = e.data.inferiorInfo.inferiorMsg ? e.data.inferiorInfo.inferiorMsg : [];
                var r = e.data.materialsAllList ? e.data.materialsAllList : [];
                if (t) {
                    for (var n = 0; n < t.length; n++) for (var d = 0; d < t[n].length; d++) t[n][d].buffer = t[n][d].buffer.replace(/\n/g, "");
                    for (n = 0; n < r.length; n++) {
                        for (d = 0; d < t.length; d++) r[n].material_code == t[d][0].materialCode && (r[n].materialList = t[d]);
                        r[n].setShow = !1;
                    }
                } else for (n = 0; n < r.length; n++) r[n].materialList = [], r[n].setShow = !1;
                var l = [];
                if (e.data.inferiorInfo && "Y" == a.data.inferiorFlag) {
                    for (n = 0; n < e.data.inferiorInfo.inferiorMaterialCodeList.length; n++) if (-1 != e.data.inferiorInfo.inferiorMaterialCodeList[n].indexOf(",")) {
                        var c = e.data.inferiorInfo.inferiorMaterialCodeList[n].split(",");
                        for (d = 0; d < c.length; d++) l.push(c[d]);
                    } else l.push(e.data.inferiorInfo.inferiorMaterialCodeList[n]);
                    for (var n in r) -1 != l.indexOf(r[n].material_code) ? r[n].isInferior = !0 : r[n].isInferior = !1, 
                    -1 != i.indexOf(r[n].material_code) ? r[n].isInferiorCheck = !0 : r[n].isInferiorCheck = !1;
                    a.setData({
                        inferiorIsOK: e.data.inferiorInfo.inferiorIsOK
                    });
                }
                console.log("处理后的materialsAllList", r), a.setData({
                    filesList: r,
                    checkedInferiorInfo: i,
                    bigInferiorInfo: s
                }), 0 == a.data.filesList.length && a.setData({
                    datamesg: "暂无数据！"
                });
            },
            fail: function() {
                console.log("fail");
            },
            complete: function() {
                a.setData({
                    Loadinghidden: !0
                });
            }
        });
    },
    onHide: function() {
        r.onHide();
    },
    bindSetShow: function(e) {
        this.data.filesList[e.currentTarget.dataset.index].setShow = !0, this.setData({
            filesList: this.data.filesList
        });
    },
    setRsa: function() {
        e = new s.RSAKey(), a = i.globalRsaObj.n, t = i.globalRsaObj.a, e.setPublic(a, t);
    },
    chooseImgInWechat: function(e) {
        var a = this;
        a.setData({
            documentCode: e.currentTarget.dataset.documentcode,
            documentName: e.currentTarget.dataset.documentname,
            materialCode: e.currentTarget.dataset.materialcode
        }), "24" == e.currentTarget.dataset.materialcode ? wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "camera" ],
            success: function(e) {
                var t = e.tempFilePaths;
                a.setData({
                    textHidden: !0,
                    photoHidden: !1,
                    imgs: t,
                    Loadinghidden: !1,
                    loadingMsg: "上传中..."
                }), a.signImgs(t[0]);
            }
        }) : wx.chooseImage({
            count: 9,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var t = e.tempFilePaths;
                a.setData({
                    textHidden: !0,
                    photoHidden: !1,
                    imgs: t,
                    Loadinghidden: !1,
                    loadingMsg: "上传中..."
                }), a.uploadImgs();
            }
        });
    },
    uploadImgs: function() {
        var a = this, t = 0, s = 0;
        a.setRsa();
        for (var r = 0; r < a.data.imgs.length; r++) {
            var n = {
                regsNo: e.encrypt(a.data.regsNo),
                fileName: a.data.imgs[r],
                documentCode: a.data.documentCode,
                documentName: a.data.documentName,
                materialCode: a.data.materialCode,
                inferiorFlag: a.data.inferiorFlag,
                weChatId: i.wxCode.openid
            };
            console.log("formData", n), wx.uploadFile({
                url: o.getSer(a.data.userInfo.userInfo.nickName).ser_ues_url + "/claim.uploadImageWechatClaim.do",
                filePath: a.data.imgs[r],
                name: "file",
                header: {
                    "Content-Type": "multipart/form-data",
                    Charset: "utf-8"
                },
                formData: n,
                success: function(e) {
                    o.decodeJson(e), console.log("res--------", e), -1 != e.data.indexOf("life-00001") ? a.setData({
                        failMsg: e.data.returnMsg ? e.data.returnMsg : e.data.message
                    }) : s++;
                },
                fail: function(e) {
                    s++;
                },
                complete: function(e) {
                    t++, a.setData({
                        Loadinghidden: !0
                    }), wx.setStorage({
                        key: "FailCount",
                        data: {
                            failcount: s,
                            mesg: "张影像上传失败。" + a.data.failMsg
                        }
                    }), t == a.data.imgs.length && setTimeout(function() {
                        wx.redirectTo({
                            url: "/pages/uploadFiles/uploadFiles?registerNo=" + a.data.regsNo + "&accClientNo=" + a.data.accClientNo + "&submitType=" + a.data.submitType + "&inferiorFlag=" + a.data.inferiorFlag + "&isWhiteWeChatId=" + a.data.isWhiteWeChatId + "&pagetype=0"
                        });
                    }, 1e3);
                }
            });
        }
    },
    signImgs: function(a) {
        var t = this;
        a = a;
        t.setRsa();
        var s = {
            regsNo: t.data.regsNo,
            fileName: "CustomerPhoto.jpg",
            documentCode: "3003",
            documentName: "客户电子签名照片",
            materialCode: "24",
            inferiorFlag: "Y",
            operateType: "A",
            timestamp: e.encrypt("" + new Date().getTime()),
            weChatId: i.wxCode.openid
        };
        wx.uploadFile({
            url: o.getSer(t.data.userInfo.userInfo.nickName).ser_ues_url + "/claim.saveCustomerInfoPhotoWechatClaim.do",
            filePath: a,
            name: "file",
            header: {
                "Content-Type": "multipart/form-data",
                Charset: "utf-8"
            },
            formData: s,
            success: function(e) {
                o.decodeJson(e), e.data = JSON.stringify(e.data), -1 != e.data.indexOf("life-00001") ? wx.navigateTo({
                    url: "/pages/anySign/anySign?regsNo=" + t.data.regsNo + "&accClientNo=" + t.data.accClientNo + "&isWhiteWeChatId=" + t.data.isWhiteWeChatId + "&inferiorFlag=Y&submitType=" + t.data.submitType
                }) : console.log("影像上传失败");
            },
            fail: function(e) {},
            complete: function() {
                t.setData({
                    Loadinghidden: !0
                });
            }
        });
    },
    delImg: function(e) {
        this.setData({
            delimgIndex: e.currentTarget.dataset.index,
            fileName: e.currentTarget.dataset.filename,
            materialCode: e.currentTarget.dataset.materialcode,
            delimgDocumentCode: e.currentTarget.dataset.document_code
        }), i.showModal(this);
    },
    sureDelImg: function() {
        var e = this;
        wx.request({
            url: o.getSer(e.data.userInfo.userInfo.nickName).ser_url + "/open/appsvr/life/deleteWeChatImage?access_token=" + i.tokens.access_token + "&request_id=" + o.uuid(),
            data: {
                regsNo: e.data.regsNo,
                materialCode: e.data.materialCode,
                fileName: e.data.fileName,
                inferiorFlag: e.data.inferiorFlag,
                weChatId: i.wxCode.openid
            },
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8"
            },
            success: function(a) {
                if (o.decodeJson(a), console.log("res", a), "life-00001" != a.data.returnCode) i.showToast(e, a.data.returnMsg); else {
                    if (e.data.inferiorFlag) return void setTimeout(function() {
                        wx.redirectTo({
                            url: "/pages/uploadFiles/uploadFiles?registerNo=" + e.data.regsNo + "&accClientNo=" + e.data.accClientNo + "&isWhiteWeChatId=" + e.data.isWhiteWeChatId + "&submitType=" + e.data.submitType + "&inferiorFlag=" + e.data.inferiorFlag + "&pagetype=0"
                        });
                    }, 1e3);
                    var t, s;
                    i.showToast(e, a.data.returnMsg);
                    for (var r = 0; r < e.data.filesList.length; r++) e.data.materialCode == e.data.filesList[r].material_code && (t = e.data.filesList[r].materialList, 
                    s = r);
                    e.data.filesList[s].materialsList = o.removeArr(t, e.data.delimgIndex), e.data.filesList[s].imgLength = e.data.filesList[s].materialsList.length, 
                    e.setData({
                        filesList: e.data.filesList
                    });
                }
            },
            fail: function(e) {
                console.log("fail");
            }
        }), i.closeModal(e);
    },
    closeModal: function() {
        i.closeModal(this);
    },
    bindPreviewImage: function(a) {
        var t = this;
        if (!t.data.previmgIsReq) {
            t.setData({
                previmgIsReq: !0
            });
            for (var s = [], r = a.currentTarget.dataset.materialcode, n = a.currentTarget.dataset.index, d = n + 4, l = t.data.filesList, c = [], f = 0; f < l.length; f++) l[f].material_code == r && (c = l[f].materialList);
            !function a(r) {
                if (!(r = r)) return void t.setData({
                    hiddenPrevImg: !1,
                    previmgUrls: s
                });
                t.setRsa();
                var l = {
                    regsNo: e.encrypt(t.data.regsNo),
                    materialCode: r.materialCode,
                    fileName: r.chsFileName,
                    timestamp: e.encrypt("" + new Date().getTime()),
                    weChatId: i.wxCode.openid
                };
                wx.request({
                    url: o.getSer(t.data.userInfo.userInfo.nickName).ser_ues_url + "/claim.queryImageDetailWechatClaim.do",
                    data: l,
                    method: "GET",
                    header: {
                        "Content-Type": "application/json",
                        Charset: "utf-8"
                    },
                    success: function(e) {
                        o.decodeJson(e), "life-00001" != e.data.returnCode ? i.showToast(t, e.data.message) : (s.push("data:image/jpg;base64," + e.data.BUFFER.replace(/\n/g, "")), 
                        n < d ? (n++, a(c[n])) : t.setData({
                            hiddenPrevImg: !1,
                            previmgUrls: s
                        }));
                    },
                    fail: function() {
                        console.log("提交失败");
                    },
                    complete: function() {
                        t.setData({
                            previmgIsReq: !1
                        });
                    }
                });
            }(c[n]);
        }
    },
    cancelSubmit: function() {
        wx.navigateBack({
            delta: 1
        });
    },
    submit: function() {
        var e = this, a = e.data.inferiorIsOK;
        if (console.log("inferiorIsOK", a), "Y" == a) {
            var t = {
                regsNo: e.data.regsNo,
                accClientNo: e.data.accClientNo,
                wechatid: e.data.weChatId,
                value: i.sigGlobalData.value,
                weChatId: i.wxCode.openid
            };
            console.log("formData", t), wx.request({
                url: o.getSer(e.data.userInfo.userInfo.nickName).ser_url + "/open/appsvr/life/submitInferiorCaseWeChat?access_token=" + i.tokens.access_token + "&request_id=" + o.uuid(),
                data: t,
                method: "POST",
                header: {
                    "Content-Type": "application/json",
                    Charset: "utf-8"
                },
                success: function(a) {
                    o.decodeJson(a), console.log("res", a), "life-00001" != a.data.returnCode ? a.data.message ? i.showToast(e, a.data.message) : i.showToast(e, a.data.returnMsg) : (i.showToast(e, a.data.returnMsg), 
                    setTimeout(function() {
                        wx.navigateTo({
                            url: "/pages/processDetail/processDetail?registerNo=" + e.data.regsNo
                        });
                    }, 1e3));
                },
                fail: function() {
                    i.showToast(e, "提交失败");
                },
                complete: function() {}
            });
        } else this.setData({
            isShowinferior: !1
        });
    },
    closePrevImg: function() {
        this.setData({
            hiddenPrevImg: !0,
            previmgUrls: []
        });
    },
    imgScale: function(e) {},
    resetScale: function(e) {},
    closePopTips: function() {
        this.setData({
            isShowinferior: !0
        });
    }
});
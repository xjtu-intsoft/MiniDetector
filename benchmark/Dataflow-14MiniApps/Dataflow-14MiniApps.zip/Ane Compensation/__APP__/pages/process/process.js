var e = getApp(), a = require("../../7D41315784CF379C1B2759508F425043.js"), t = require("../../9A41035384CF379CFC276B5474025043.js");

function s(t) {
    var s = a.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "queryCaseClaimProgressList?access_token=" + e.tokens.access_token + "&request_id=" + a.uuid();
    wx.request({
        url: s,
        data: {
            pageNum: t.data.pageNum
        },
        method: "POST",
        header: {
            "Content-Type": "application/json",
            Charset: "utf-8",
            loginAuthorization: e.loginAuthorization
        },
        success: function(e) {
            console.log("进度查询列表res", e), t.setData({
                Loadinghidden: !0,
                hiddenToast: !0,
                DataBody: !1,
                isLoadmore: !1
            }), "crs-00001" == e.data.returnCode ? (t.setData({
                pageNum: e.data.data.currentPage + 1,
                hasNextPage: e.data.data.hasNextPage,
                reports: t.data.prevreports.concat(e.data.data.weChatClaimProgressList)
            }), t.setData({
                prevreports: t.data.reports
            })) : t.showToast(!1, "1", e.data.message || "暂无数据");
        },
        fail: function() {}
    });
}

Page({
    data: {
        reports: [],
        prevreports: [],
        Loadinghidden: !1,
        hidden: !0,
        size: 10,
        hasMore: !1,
        hasRefesh: !1,
        arrow: "../../pages/images/icon_arrow_1.png",
        hiddenToast: !0,
        mesg: "暂无数据",
        noData: !0,
        DataBody: !1,
        token: "",
        scrollTop: 0,
        scr_height: 0,
        isRefresh: !1,
        isLoadmore: !1,
        pageNum: "1",
        hasNextPage: "Y"
    },
    onLaunch: function() {},
    onPullDownRefresh: function() {
        this.data.isRefresh || (this.setData({
            prevreports: [],
            reports: [],
            isRefresh: !0,
            pageNum: "1",
            hasNextPage: "Y"
        }), s(this), console.log("开始下拉刷新"));
    },
    onReachBottom: function() {
        console.log("onReachBottom>>>>");
        this.data.isLoadmore || "N" != this.data.hasNextPage && (this.setData({
            isLoadmore: !0
        }), this.showToast(!1, "1", "加载中.."), s(this));
    },
    onShow: function() {
        this.setData({
            userInfo: e.globalData
        });
        var a = wx.getSystemInfoSync();
        this.setData({
            scr_height: a.windowHeight,
            DataBody: !0,
            noData: !0,
            reports: [],
            prevreports: [],
            isRefresh: !1,
            isLoadmore: !1,
            pageNum: "1",
            hasNextPage: "Y"
        }), s(this), t.onShow(), t.onEvent(e.SKAPPObj.process[0].id, e.SKAPPObj.process[0].label, e.SKAPPObj.process[0].params);
    },
    onHide: function() {
        t.onHide();
    },
    showToast: function(e, a, t) {
        var s = this;
        s.setData({
            hiddenToast: !1,
            mesg: t
        }), "0" != a && setTimeout(function() {
            s.setData({
                hiddenToast: !0
            }), "2" == a && s.showNoData(!1, t);
        }, 2e3);
    },
    showNoData: function(e, a) {
        this.setData({
            noData: !1,
            DataBody: !0,
            mesg: a
        });
    },
    queryDetail: function(e) {
        console.log("e", e), console.log(e.currentTarget.dataset.registerno), wx.navigateTo({
            url: "/pages/processDetail/processDetail?registerNo=" + e.currentTarget.dataset.registerno + "&accclientno=" + e.currentTarget.dataset.accclientno
        });
    }
});
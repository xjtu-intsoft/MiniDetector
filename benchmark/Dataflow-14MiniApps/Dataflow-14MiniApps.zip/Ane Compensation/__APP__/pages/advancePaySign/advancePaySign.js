var e, t, a, o = getApp(), n = require("../../7D41315784CF379C1B2759508F425043.js"), s = require("../../BA4681C684CF379CDC20E9C1FBE15043.js"), i = require("../../2A98DAA084CF379C4CFEB2A7BE815043.js"), c = require("../../F2E3964184CF379C9485FE465AD15043.js");

Page({
    data: {
        text: "请投保人李明签字",
        hidden: !0,
        bgUrl: "../../pages/images/newSignBg.png",
        bgTips: "../../pages/images/tips.png",
        bgPicture: "../../pages/images/profilePicture.png",
        examplePageIshow: !1,
        clearBgUrl: "../../pages/images/icon_default_up.png",
        clearIcon: "../../pages/images/new/clear.png",
        registerNo: "",
        guildPageIsshow: !1,
        radioIsCheck: !1,
        hideinstructone: !0,
        hideinstructtwo: !0,
        hideinstructthree: !0,
        hideinstructfour: !0,
        isAllChecked: !1,
        toastMeg: "请选择反保险欺诈提示、声明及授权和税收居民身份声明",
        signPageShow: !1,
        hiddenToast: !0,
        imageUrl: "",
        clientPhotoImageStream: "",
        electronicSignatureImageStream: "",
        electronicSignatureEncryptStream: "",
        advancePayInferiorFlag: "",
        tokenKey: ""
    },
    onLoad: function(e) {
        console.log("options", e), this.setData({
            registerNo: e.registerNo,
            tokenKey: e.tokenKey ? e.tokenKey : ""
        }), this.setData({
            registerNo: e.registerNo,
            advancePayInferiorFlag: e.advancePayInferiorFlag ? e.advancePayInferiorFlag : "N"
        }), "N" == this.data.advancePayInferiorFlag ? this.setData({
            guildPageIsshow: !0
        }) : "Y" == this.data.advancePayInferiorFlag && (this.setData({
            signPageShow: !0
        }), this.testAnySign()), console.log("onload------", e);
    },
    setRsa: function() {
        e = new s.RSAKey(), t = o.globalRsaObj.n, a = o.globalRsaObj.a, e.setPublic(t, a);
    },
    radioChange: function(e) {
        this.data.radioIsCheck || this.setData({
            radioIsCheck: !0,
            isAllChecked: !0
        });
    },
    openInstructone: function() {
        this.setData({
            hideinstructone: !1
        });
    },
    closeInstructone: function() {
        this.setData({
            hideinstructone: !0
        });
    },
    openInstructtwo: function() {
        this.setData({
            hideinstructtwo: !1
        });
    },
    closeInstructtwo: function() {
        this.setData({
            hideinstructtwo: !0
        });
    },
    openInstructthree: function() {
        this.setData({
            hideinstructthree: !1
        });
    },
    closeInstructthree: function() {
        this.setData({
            hideinstructthree: !0
        });
    },
    checkboxChange: function(e) {
        console.log("checkbox发生change事件，携带value值为：", e.detail.value);
        var t = e.detail.value.toString();
        console.log("resultVal.indexOf(one)", t.indexOf("one")), console.log("resultVal.indexOf(two)", t.indexOf("two")), 
        -1 != t.indexOf("one") && -1 != t.indexOf("two") && -1 != t.indexOf("three") ? this.setData({
            isAllChecked: !0
        }) : this.setData({
            isAllChecked: !1
        });
    },
    nextStep: function() {
        this.data.isAllChecked ? this.setData({
            guildPageIsshow: !1,
            examplePageIshow: !0
        }) : o.showToast(this, this.data.toastMeg);
    },
    take_photo: function() {
        this.chooseWeixinImage();
    },
    chooseWeixinImage: function() {
        var e = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "camera" ],
            success: function(t) {
                console.log("res", t), e.uploadImgs(t.tempFilePaths[0], "01"), wx.showLoading({
                    title: "上传中..."
                });
            },
            fail: function(e) {
                console.log("选择照片取消"), wx.navigateBack({
                    delta: 1
                });
            }
        });
    },
    uploadImgs: function(e, t) {
        var a = this, s = e, i = {
            submitType: "conversion",
            fileName: s,
            weChatId: o.wxCode.openid
        }, c = n.getSer(o.globalData.userInfo.nickName).ser_ues_url + "/claim.uploadImageWechatClaim.do";
        wx.uploadFile({
            url: c,
            filePath: s,
            name: "file",
            formData: i,
            header: {
                "Content-Type": "multipart/form-data",
                Charset: "utf-8"
            },
            success: function(e) {
                console.log("客户上传自拍", e);
                var n = JSON.parse(e.data);
                console.log("resData", n), "life-00001" == n.returnCode ? "01" == t ? a.setData({
                    clientPhotoImageStream: n.filebase64code,
                    photoUploadRes: !0
                }) : "02" == t && (a.setData({
                    electronicSignatureImageStream: n.filebase64code
                }), a.signupload()) : o.showToast(a, "图片上传失败");
            },
            fail: function(e) {
                console.log("图片上传失败", e), o.showToast(a, "图片上传失败！上传图片的大小不能超过2M");
            },
            complete: function() {
                wx.hideLoading(), a.setData({
                    examplePageIshow: !1,
                    signPageShow: !0
                }), wx.showLoading({
                    title: "初始化中..."
                }), a.testAnySign();
            }
        });
    },
    signupload: function() {
        var e = this;
        wx.showLoading({
            title: "上传签名"
        });
        var t = {
            businessOperation: "claimAdvancePay",
            isProblemFlag: e.data.advancePayInferiorFlag,
            registerNo: e.data.registerNo,
            systemId: o.systemId.advancepay,
            tokenKey: e.data.tokenKey,
            clientPhotoImageStream: e.data.clientPhotoImageStream,
            electronicSignatureImageStream: e.data.electronicSignatureImageStream,
            electronicSignatureEncryptStream: e.data.electronicSignatureEncryptStream
        }, a = n.getSer(o.globalData.userInfo.nickName).lcloud_url + o.newCommonUrl + "saveClientPhotoAndElectronicSignatureNew?access_token=" + o.tokens.access_token + "&  request_id=" + n.uuid();
        wx.request({
            url: a,
            data: t,
            method: "POST",
            header: {
                "content-type": "application/json",
                loginAuthorization: o.loginAuthorization
            },
            dataType: "json",
            success: function(t) {
                wx.hideLoading(), console.log("电子签名上传结果", t);
                var a = t.data;
                "crs-00001" == a.returnCode ? "Y" == e.data.advancePayInferiorFlag ? wx.navigateBack({
                    delta: 1
                }) : wx.showModal({
                    title: "电子签名上传成功",
                    content: "是否提交预赔受理信息",
                    showCancel: !0,
                    success: function(t) {
                        console.log("success res", t), t.confirm && (console.log("点击确定"), e.submitAdvancePay()), 
                        t.cancel && (console.log("点击取消"), e.setData({
                            guildPageIsshow: !1,
                            examplePageIshow: !0
                        }));
                    },
                    fail: function(e) {},
                    complete: function() {}
                }) : (console.log("影像上传失败"), o.showToast(e, a.message), e.signFail());
            },
            fail: function(t) {
                console.log("图片上传失败", t), o.showToast(e, "图片上传失败！上传图片的大小不能超过2M"), e.signFail();
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    submitAdvancePay: function() {
        var e = {
            registerNo: this.data.registerNo,
            systemId: o.systemId.advancepay,
            tokenKey: ""
        }, t = n.getSer(o.globalData.userInfo.nickName).lcloud_url + o.newCommonUrl + "submitAdvancePayAcceptInfo?access_token=" + o.tokens.access_token + "&request_id=" + n.uuid();
        wx.request({
            url: t,
            data: e,
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: o.loginAuthorization
            },
            success: function(e) {
                "crs-00001" == e.data.returnCode && wx.showModal({
                    title: "提示",
                    content: "预赔信息提交成功",
                    showCancel: !1,
                    success: function(e) {
                        e.confirm && (console.log("用户点击确定"), wx.reLaunch({
                            url: "/pages/process/process"
                        }));
                    },
                    fail: function(e) {}
                });
            },
            fail: function() {}
        });
    },
    navigateBackFunc: function() {
        var e = getCurrentPages();
        e[e.length - 2].setData({
            signSuccess: !0
        }), wx.navigateBack({
            delta: 1
        });
    },
    signFail: function() {
        var e = this;
        wx.showModal({
            title: "提示",
            content: "签名失败，请重新开始",
            showCancel: !0,
            success: function(t) {
                console.log("success res", t), t.confirm && e.chooseWeixinImage(), t.cancel && wx.navigateBack({
                    delta: 1
                });
            },
            fail: function(e) {},
            complete: function() {}
        });
    },
    testAnySign: function(e) {
        if (console.log("初始化开始"), e) var t = e.currentTarget.id; else t = "112321321";
        console.log("channel", t);
        var a = this;
        (o.sigGlobalData.EncAlg = "SM2", i.init(function(e, t, o) {
            "CALLBACK_TYPE_SIGNATURE" == t && 20 == e && (wx.showLoading({
                title: "上传中..."
            }), console.log("签名图片", o), a.setData({
                imageUrl: o
            }), console.log("context_id:" + e + ";" + t + ";" + o), setTimeout(function() {
                a.testGenData();
            }, 5e3));
        }, t)) ? function(e) {
            var t = e, a = new c.signer("李明", "11011111111"), o = new c.SignRule_KeyWordV2("签名：", 50, 0, 1, 1), n = new c.SignatureConfig(a, o);
            new c.TimeTag(1, "yyMMdd hh:mm;ss");
            return n.singleWidth = 200, n.singleHeight = 200, n.penColor = "#000000", n.isTSS = !1, 
            n.signatureImgRatio = 3, n.nessesary = !0, console.log("签名配置项signatureConfig", n), 
            i.addSignatureObj(t, n);
        }(20) ? i.commitConfig() ? (console.log("初始化成功"), a.testSetTemplateData()) : wx.showModal({
            title: "提示",
            content: "初始化失败！"
        }) : wx.showToast({
            title: "testAddSignatureObj error",
            duration: 2e3
        }) : wx.showToast({
            title: "init error",
            duration: 2e3
        });
    },
    testSetTemplateData: function() {
        console.log("开始设置表单数据");
        var e = this.data.registerNo;
        i.setTemplate(o.sigGlobalData.TemplateType.HTML, "<HTML></HTML>", e, "4000") ? (console.log("设置表单成功"), 
        this.testPopupDialog()) : wx.showModal({
            title: "提示",
            content: "设置表单数据失败！"
        });
    },
    testPopupDialog: function(e) {
        if (e) var t = e.currentTarget.id; else t = "20";
        i || wx.showModal({
            title: "提示",
            content: "信手书接口没有初始化！"
        });
        switch (wx.hideLoading(), i.showSignatureDialog(t, this)) {
          case "OK":
            console.log("OK");
            break;

          case "EC_API_NOT_INITED":
            console.log("信手书接口没有初始化");
            break;

          case "EC_WRONG_CONTEXT_ID":
            console.log("没有配置相应context_id的签字对象");
        }
    },
    testIsReadyToUpload: function() {
        wx.showModal({
            title: "提示",
            content: "testIsReadyToUpload:" + i.isReadyToUpload()
        });
    },
    testGenData: function() {
        if (i.isReadyToUpload()) {
            var e = i.getUploadDataGram();
            o.sigGlobalData.value = e, console.log("app.sigGlobalData.value", o.sigGlobalData.value), 
            this.setData({
                electronicSignatureEncryptStream: e
            }), this.uploadImgs(this.data.imageUrl, "02");
        } else wx.showModal({
            title: "提示",
            content: "testIsReadyToUpload:false！"
        });
    },
    canvasStart: function(e) {
        i.canvasStart(e);
    },
    canvasMove: function(e) {
        i.canvasMove(e);
    },
    canvasEnd: function(e) {
        i.canvasEnd(e);
    },
    sign_confirm: function() {
        i.sign_confirm();
    },
    clear_canvas: function() {
        i.clear_canvas();
    },
    cancel_sign: function() {
        wx.navigateBack({
            delta: 1
        });
    }
});
var e = getApp(), t = require("../../7D41315784CF379C1B2759508F425043.js");

Page({
    data: {
        registerNo: "",
        tokenKey: "",
        uloadList: [],
        icon: "../../pages/images/new/icon_files_",
        hiddenToast: !0
    },
    onLoad: function(e) {
        this.setData({
            registerNo: e.registerNo,
            tokenKey: e.tokenKey ? e.tokenKey : ""
        });
    },
    onShow: function() {
        this.initData();
    },
    initData: function(a) {
        var o = this;
        wx.request({
            url: t.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "queryClaimUploadMaterialList?access_token=" + e.tokens.access_token + "&request_id=" + t.uuid(),
            data: {
                registerNo: this.data.registerNo,
                systemId: e.systemId.advancepay,
                caseBusinessType: "ADVANCE_PAY",
                tokenKey: this.data.tokenKey
            },
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: e.loginAuthorization
            },
            success: function(t) {
                console.log("****", t), "crs-00001" === t.data.returnCode ? o.setData({
                    uloadList: t.data.data
                }) : e.showToast(o, t.data.message);
            },
            fail: function(t) {
                e.showToast(o, t.data.message || "查询异常");
            },
            complete: function(e) {}
        });
    },
    bindClick: function(e) {
        wx.navigateTo({
            url: "/pages/advancePayUploadDetail/advancePayUploadDetail?registerNo=" + this.data.registerNo + "&parentMaterialCode=" + e.currentTarget.dataset.child.parentMaterialCode + "&title=" + e.currentTarget.dataset.child.materialName + "&tokenKey=" + this.data.tokenKey
        });
    },
    bindToSubmit: function(a) {
        var o = this;
        wx.request({
            url: t.getSer(e.globalData.userInfo.nickName).lcloud_url + e.newCommonUrl + "checkClaimUploadMaterialList?access_token=" + e.tokens.access_token + "&request_id=" + t.uuid(),
            data: {
                registerNo: this.data.registerNo,
                systemId: e.systemId.advancepay,
                caseBusinessType: "ADVANCE_PAY",
                tokenKey: this.data.tokenKey
            },
            method: "POST",
            header: {
                "Content-Type": "application/json",
                Charset: "utf-8",
                loginAuthorization: e.loginAuthorization
            },
            success: function(t) {
                "crs-00001" !== t.data.returnCode ? e.showToast(o, t.data.data.uploadMaterialTips) : wx.navigateTo({
                    url: "/pages/advancePaySign/advancePaySign?registerNo=" + o.data.registerNo + "&tokenKey=" + o.data.tokenKey
                });
            },
            fail: function(e) {},
            complete: function(e) {}
        });
    }
});
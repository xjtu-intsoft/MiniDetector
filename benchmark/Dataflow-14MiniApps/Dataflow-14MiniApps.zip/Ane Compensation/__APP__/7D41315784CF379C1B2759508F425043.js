var e = require("@babel/runtime/helpers/typeof.js");

function t(e) {
    return (e = e.toString())[1] ? e : "0" + e;
}

module.exports = {
    formatTime: function(e) {
        var r = e.getFullYear(), n = e.getMonth() + 1, o = e.getDate(), a = e.getHours(), i = e.getMinutes(), c = e.getSeconds();
        return [ r, n, o ].map(t).join("/") + " " + [ a, i, c ].map(t).join(":");
    },
    formatNumber: t,
    formatDate: function(e) {
        return [ e.getFullYear(), e.getMonth() + 1, e.getDate() ].map(t).join("-");
    },
    verifyIdNo: function(e) {
        return /(^\d{17}(\d|X|x)$)/.test(e);
    },
    verifyBirthCard: function(e) {
        return /^[A-Z][A-Z0-9]{9}$/.test(e);
    },
    verifyHongKongMacauCard: function(e) {
        return /^[0-9|M|H][0-9]{7,8}$/.test(e);
    },
    verifyPassport: function(e) {
        return /^[0-9a-zA-Z]{6,}$/.test(e);
    },
    foreignerPermanentLiveCart: function(e) {
        return /^[0-9A-Z]{15}$/.test(e);
    },
    verifyHongKongMacauLiveCard: function(e) {
        var t = /^[8][1,2,3][0]{4}[0-9]{11}[0-9X]$/;
        return console.log("data", e), console.log("reg.test(data)", t.test(e)), t.test(e);
    },
    verifyPolicyNo: function(e) {
        return 16 == e.length && "P" == e[0];
    },
    verifyNumLetter: function(e) {
        return /^[A-Za-z0-9]+$/.test(e);
    },
    showToast: function(e, t) {
        var r = new Array();
        return r.push({
            msg: e,
            flag: t
        }), r;
    },
    resetArray: function(e, t) {
        console.log("arr>>>>", e);
        var r = new Array();
        if ("" == e) r = []; else for (var n = 0; n < e.length; n++) e[n][t] && "" != e[n][t] && (r[n] = e[n][t]);
        return r;
    },
    getClientStatusWithStage: function(e, t) {
        if (console.log("list>>>>>", e), "" == e) return [];
        for (var r = 0; r < e.length; r++) if (e[r].clientStatus == t) return e[r].stageList;
    },
    uuid: function() {
        var e = new Date().getTime();
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(t) {
            var r = (e + 16 * Math.random()) % 16 | 0;
            return e = Math.floor(e / 16), ("x" == t ? r : 3 & r | 8).toString(16);
        });
    },
    getSer: function(e) {
        return "平安人寿测试用户" == e ? {
            ser_outh_url: "https://wxtest-api.pingan.com.cn",
            ser_url: "https://wxtest-api.pingan.com.cn",
            ser_ues_url: "https://test-elis-ues-stg2.pa18.com",
            client_id: "P_CHS_CORE_AN_E_PEI",
            client_secret: "CU24gWr1"
        } : {
            ser_outh_url: "https://api.pingan.com.cn",
            ser_url: "https://api.pingan.com.cn",
            ser_ues_url: "https://elis-ues.pa18.com",
            client_id: "P_CHS_CORE_AN_E_PEI",
            client_secret: "6RYzj84u",
            lcloud_url: "https://api.pingan.com.cn",
            lcloud_url_authorization: "https://lcloud-api.pingan.com"
        };
    },
    decodeJson: function t(r) {
        if (r) for (var n in r) r[n] && "object" == e(r[n]) ? t(r[n]) : (r[n] = decodeURIComponent(r[n]), 
        n && "docudate" == n && r[n] && "" != r[n] && (r[n] = r[n].replace("+", " ")), "noti_date" != n && "occurDate" != n && "register_date" != n && "assist_date" != n && "conclusion_date" != n && "noti_proc_date" != n && "cash_date" != n && "claim_source" != n && "case_state_tmp" != n || n && r[n] && "" != r[n] && (r[n] = r[n].replace("+", " ")));
    },
    removeArr: function(e, t) {
        if (!(t <= e.length - 1)) throw new Error("超出最大索引！");
        for (var r = t; r < e.length; r++) e[r] = e[r + 1];
        return e.length = e.length - 1, e;
    },
    checkMobilePhone: function(e) {
        return !!/^0?(13[0-9]|14[0-9]|15[012356789]|16[0-9]|18[0-9]|17[0-9]|19[0-9])[0-9]{8}$/.test(e);
    },
    checkPhone: function(e) {
        var t = e.substring(0, 3);
        return "400" == t || "800" == t ? !!/^[8,4][0]{2}[0-9]{7}$/.test(e) : !!/^[0-9]{2,3}-?\d{7,8}$/.test(e);
    },
    checkPostCode: function(e) {
        return /^[0-9]{6}$/.test(e);
    },
    isChar: function(e) {
        var t = /^.*[a-zA-Z].*$/;
        return console.log("字母reg.test(val)", t.test(e)), t.test(e);
    },
    isTChar: function(e) {
        var t = /^.*[&<>].*$/;
        return console.log("特殊字符reg.test(val)", t.test(e)), t.test(e);
    },
    compareDate: function(e, t) {
        var r = new Date(e.replace(/\-/g, "/")), n = new Date(t.replace(/\-/g, "/"));
        return "" != e && "" != t && r > n;
    },
    queryDesByList: function(e, t, r, n, o) {
        if ("index" == o) {
            for (var a = 0; a < e.length; a++) if (e[a][t] == n) return a;
        } else if ("des" == o) {
            for (a = 0; a < e.length; a++) if (e[a][t] == n) return e[a][r];
        } else {
            if ("code" != o) {
                var i = [];
                for (a = 0; a < n.length; a++) for (var c = 0; c < e.length; c++) e[c][t] == n[a] && i.push(e[c]);
                return i;
            }
            for (var a = 0; a < e.length; a++) if (e[a][r] == n) return e[a][t];
        }
    },
    trim: function(e) {
        return e && "" != e ? e.replace(/\s/g, "") : "";
    },
    trimIllegal: function(e) {
        var t = "";
        return e && (t = e.replace(/\\uff5e/g, "-").replace(/\~/g, "-").replace(/\\/g, "-").replace(/\\uff3c/g, "-").replace(/@/g, "-").replace(/\uff20/g, "-").replace(/#/g, "-").replace(/\uff03/g, "-").replace(/\uffe5/g, "-").replace(/\xa5/g, "-").replace(/%/g, "-").replace(/\uff05/g, "-").replace(/&/g, "-").replace(/\uff06/g, "-").replace(/\^/g, "-").replace(/\\uff3e/g, "-")), 
        t;
    },
    veifyHongkongTaxNo: function(e) {
        return /^[A-Z]{1,2}[0-9]{6}[(][0-9A][)]$/.test(e);
    },
    hasHanzi: function(e) {
        return !!(e ? e.match(/[\u4E00-\u9FA5]/g) : "");
    }
};
function r(r, n) {
    for (k in b = r, m = new (C ? Uint8Array : Array)(L), d = O.DYNAMIC, !n && (n = {}) || "number" == typeof n.compressionType && (d = n.compressionType), 
    n) Y[k] = n[k];
    return Y.outputBuffer = m, new e(b, Y), function() {
        var r, e, n, s, l, y, h = 0;
        switch (r = B.DEFLATE) {
          case B.DEFLATE:
            e = Math.LOG2E * Math.log(S) - 8;
            break;

          default:
            throw new Error("invalid compression method");
        }
        switch (n = e << 4 | r, m[h++] = n, r) {
          case B.DEFLATE:
            switch (d) {
              case O.NONE:
                l = 0;
                break;

              case O.FIXED:
                l = 1;
                break;

              case O.DYNAMIC:
                l = 2;
                break;

              default:
                throw new Error("unsupported compression type");
            }
            break;

          default:
            throw new Error("invalid compression method");
        }
        return s = l << 6 | 0, s |= 31 - (256 * n + s) % 31, m[h++] = s, y = function(r) {
            return "string" == typeof r && (r = function(r) {
                var e, n, a = r.split("");
                for (e = 0, n = a.length; e < n; e++) a[e] = (255 & a[e].charCodeAt(0)) >>> 0;
                return a;
            }(r)), function(r, e) {
                for (var n, a = 65535 & r, t = r >>> 16 & 65535, o = e.length, f = 0; o > 0; ) {
                    o -= n = o > R ? R : o;
                    do {
                        t += a += e[f++];
                    } while (--n);
                    a %= 65521, t %= 65521;
                }
                return (t << 16 | a) >>> 0;
            }(1, r);
        }(b), z = h, m = function() {
            var r, e, n, s = g;
            switch (d) {
              case O.NONE:
                for (e = 0, n = s.length; e < n; ) e += (r = C ? s.subarray(e, e + 65535) : s.slice(e, e + 65535)).length, 
                this.makeNocompressBlock(r, e === n);
                break;

              case O.FIXED:
                p = function(r, e) {
                    alert(p);
                    var n, a, t = new u(C ? new Uint8Array(p.buffer) : p, this.op);
                    return n = e ? 1 : 0, a = O.FIXED, c(n, 1, !0), c(a, 2, !0), function(r, e) {
                        var n, a, t;
                        for (n = 0, a = r.length; n < a; n++) if (t = r[n], c.apply(e, RawDeflate_profixedHuffmanTable[t]), 
                        t > 256) c(r[++n], r[++n], !0), c(r[++n], 5), c(r[++n], r[++n], !0); else if (256 === t) break;
                    }(this.lz77(r), t), i();
                }(s, !0), z = p.length;
                break;

              case O.DYNAMIC:
                p = function(r, e) {
                    var n, s, l, y, h, A, w, b, k, g, d, m, I, T, x, F, M, B = new u(C ? new Uint8Array(p.buffer) : p, z), Y = [ 16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15 ], L = new Array(19);
                    for (n = e ? 1 : 0, s = O.DYNAMIC, c(n, 1, !0), c(s, 2, !0), l = function(r) {
                        function e(r, e) {
                            var n, t, o = function() {
                                var r, e = N, n = [], t = 0;
                                return r = a[D], n[t++] = 65535 & r, n[t++] = r >> 16 & 255, n[t++] = r >> 24, r = function(r) {
                                    var e;
                                    switch (!0) {
                                      case 1 === r:
                                        e = [ 0, r - 1, 0 ];
                                        break;

                                      case 2 === r:
                                        e = [ 1, r - 2, 0 ];
                                        break;

                                      case 3 === r:
                                        e = [ 2, r - 3, 0 ];
                                        break;

                                      case 4 === r:
                                        e = [ 3, r - 4, 0 ];
                                        break;

                                      case r <= 6:
                                        e = [ 4, r - 5, 1 ];
                                        break;

                                      case r <= 8:
                                        e = [ 5, r - 7, 1 ];
                                        break;

                                      case r <= 12:
                                        e = [ 6, r - 9, 2 ];
                                        break;

                                      case r <= 16:
                                        e = [ 7, r - 13, 2 ];
                                        break;

                                      case r <= 24:
                                        e = [ 8, r - 17, 3 ];
                                        break;

                                      case r <= 32:
                                        e = [ 9, r - 25, 3 ];
                                        break;

                                      case r <= 48:
                                        e = [ 10, r - 33, 4 ];
                                        break;

                                      case r <= 64:
                                        e = [ 11, r - 49, 4 ];
                                        break;

                                      case r <= 96:
                                        e = [ 12, r - 65, 5 ];
                                        break;

                                      case r <= 128:
                                        e = [ 13, r - 97, 5 ];
                                        break;

                                      case r <= 192:
                                        e = [ 14, r - 129, 6 ];
                                        break;

                                      case r <= 256:
                                        e = [ 15, r - 193, 6 ];
                                        break;

                                      case r <= 384:
                                        e = [ 16, r - 257, 7 ];
                                        break;

                                      case r <= 512:
                                        e = [ 17, r - 385, 7 ];
                                        break;

                                      case r <= 768:
                                        e = [ 18, r - 513, 8 ];
                                        break;

                                      case r <= 1024:
                                        e = [ 19, r - 769, 8 ];
                                        break;

                                      case r <= 1536:
                                        e = [ 20, r - 1025, 9 ];
                                        break;

                                      case r <= 2048:
                                        e = [ 21, r - 1537, 9 ];
                                        break;

                                      case r <= 3072:
                                        e = [ 22, r - 2049, 10 ];
                                        break;

                                      case r <= 4096:
                                        e = [ 23, r - 3073, 10 ];
                                        break;

                                      case r <= 6144:
                                        e = [ 24, r - 4097, 11 ];
                                        break;

                                      case r <= 8192:
                                        e = [ 25, r - 6145, 11 ];
                                        break;

                                      case r <= 12288:
                                        e = [ 26, r - 8193, 12 ];
                                        break;

                                      case r <= 16384:
                                        e = [ 27, r - 12289, 12 ];
                                        break;

                                      case r <= 24576:
                                        e = [ 28, r - 16385, 13 ];
                                        break;

                                      case r <= 32768:
                                        e = [ 29, r - 24577, 13 ];
                                        break;

                                      default:
                                        throw "invalid distance";
                                    }
                                    return e;
                                }(e), n[t++] = r[0], n[t++] = r[1], n[t++] = r[2], n;
                            }();
                            for (n = 0, t = o.length; n < t; ++n) w[b++] = o[n];
                            E[o[0]]++, U[o[3]]++, k = r.length + e - 1, l = null;
                        }
                        var n, o, f, u, s, c, i, l, y, h = {}, A = S, w = C ? [] : new Uint16Array(2 * r.length), b = 0, k = 0;
                        if (E = new (C ? Uint32Array : Array)(286), U = new (C ? Uint32Array : Array)(30), 
                        !C) {
                            for (f = 0; f <= 285; ) E[f++] = 0;
                            for (f = 0; f <= 29; ) U[f++] = 0;
                        }
                        for (E[256] = 1, n = 0, o = r.length; n < o; ++n) {
                            for (s = 0, f = 0, u = X; f < u && n + f !== o; ++f) s = s << 8 | r[n + f];
                            if (void 0 === h[s] && (h[s] = []), c = h[s], k-- > 0) c.push(n); else {
                                for (;c.length > 0 && n - c[0] > A; ) c.shift();
                                if (n + X >= o) {
                                    for (l && e(l, -1), f = 0, u = o - n; f < u; ++f) y = r[n + f], w[b++] = y, ++E[y];
                                    break;
                                }
                                c.length > 0 ? (i = t(r, n, c), l ? l.length < i.length ? (y = r[n - 1], w[b++] = y, 
                                ++E[y], e(i, 0)) : e(l, -1) : i.length < v ? l = i : e(i, 0)) : l ? e(l, -1) : (y = r[n], 
                                w[b++] = y, ++E[y]), c.push(n);
                            }
                        }
                        return w[b++] = 256, E[256]++, C ? w.subarray(0, b) : w;
                    }(r), b = f(w = o(E, 15)), g = f(k = o(U, 7)), y = 286; y > 257 && 0 === w[y - 1]; y--) ;
                    for (h = 30; h > 1 && 0 === k[h - 1]; h--) ;
                    for (m = o((d = function(r, e, n, a) {
                        var t, o, f, u, s, c, i = new (C ? Uint32Array : Array)(r + n), l = new (C ? Uint32Array : Array)(316), y = new (C ? Uint8Array : Array)(19);
                        for (o = 0, t = 0; t < r; t++) i[o++] = e[t];
                        for (t = 0; t < n; t++) i[o++] = a[t];
                        if (!C) for (t = 0, u = y.length; t < u; ++t) y[t] = 0;
                        for (s = 0, t = 0, u = i.length; t < u; t += o) {
                            for (o = 1; t + o < u && i[t + o] === i[t]; ++o) ;
                            if (f = o, 0 === i[t]) if (f < 3) for (;f-- > 0; ) l[s++] = 0, y[0]++; else for (;f > 0; ) (c = f < 138 ? f : 138) > f - 3 && c < f && (c = f - 3), 
                            c <= 10 ? (l[s++] = 17, l[s++] = c - 3, y[17]++) : (l[s++] = 18, l[s++] = c - 11, 
                            y[18]++), f -= c; else if (l[s++] = i[t], y[i[t]]++, --f < 3) for (;f-- > 0; ) l[s++] = i[t], 
                            y[i[t]]++; else for (;f > 0; ) (c = f < 6 ? f : 6) > f - 3 && c < f && (c = f - 3), 
                            l[s++] = 16, l[s++] = c - 3, y[16]++, f -= c;
                        }
                        return {
                            codes: C ? l.subarray(0, s) : l.slice(0, s),
                            freqs: y
                        };
                    }(y, w, h, k)).freqs, 7), F = 0; F < 19; F++) L[F] = m[Y[F]];
                    for (A = 19; A > 4 && 0 === L[A - 1]; A--) ;
                    for (I = f(m), c(y - 257, 5, !0), c(h - 1, 5, !0), c(A - 4, 4, !0), F = 0; F < A; F++) c(L[F], 3, !0);
                    for (F = 0, M = d.codes.length; F < M; F++) if (T = d.codes[F], c(I[T], m[T], !0), 
                    T >= 16) {
                        switch (F++, T) {
                          case 16:
                            x = 2;
                            break;

                          case 17:
                            x = 3;
                            break;

                          case 18:
                            x = 7;
                            break;

                          default:
                            throw "invalid code: " + T;
                        }
                        c(d.codes[F], x, !0);
                    }
                    return function(r, e, n, a) {
                        var t, o, f, u, s, i, l, y;
                        for (s = e[0], i = e[1], l = n[0], y = n[1], t = 0, o = r.length; t < o; ++t) if (f = r[t], 
                        c(s[f], i[f], !0), f > 256) c(r[++t], r[++t], !0), c(l[u = r[++t]], y[u], !0), c(r[++t], r[++t], !0); else if (256 === f) break;
                    }(l, [ b, w ], [ g, k ], B), i();
                }(s, !0), z = p.length;
                break;

              default:
                throw "invalid compression type";
            }
            return p;
        }(), h = m.length, C && ((m = new Uint8Array(m.buffer)).length <= h + 4 && ((p = new Uint8Array(m.length + 4)).set(m), 
        m = p), m = m.subarray(0, h + 4)), m[h++] = y >> 24 & 255, m[h++] = y >> 16 & 255, 
        m[h++] = y >> 8 & 255, m[h++] = 255 & y, m;
    }();
}

function e(r, e) {
    d = O.DYNAMIC, v = 0, g = C && r instanceof Array ? new Uint8Array(r) : r, z = 0, 
    e && (e.lazy && (this.lazy = e.lazy), "number" == typeof e.compressionType && (this.compressionType = e.compressionType), 
    e.outputBuffer && (m = C && e.outputBuffer instanceof Array ? new Uint8Array(e.outputBuffer) : e.outputBuffer), 
    "number" == typeof e.outputIndex && (this.op = e.outputIndex)), m || (m = new (C ? Uint8Array : Array)(32768)), 
    p = m;
}

function n(r, e) {
    D = r, N = e;
}

function a(r) {
    var e, n;
    r = [];
    for (e = 3; e <= 258; e++) n = function(r) {
        switch (!0) {
          case 3 === r:
            return [ 257, r - 3, 0 ];

          case 4 === r:
            return [ 258, r - 4, 0 ];

          case 5 === r:
            return [ 259, r - 5, 0 ];

          case 6 === r:
            return [ 260, r - 6, 0 ];

          case 7 === r:
            return [ 261, r - 7, 0 ];

          case 8 === r:
            return [ 262, r - 8, 0 ];

          case 9 === r:
            return [ 263, r - 9, 0 ];

          case 10 === r:
            return [ 264, r - 10, 0 ];

          case r <= 12:
            return [ 265, r - 11, 1 ];

          case r <= 14:
            return [ 266, r - 13, 1 ];

          case r <= 16:
            return [ 267, r - 15, 1 ];

          case r <= 18:
            return [ 268, r - 17, 1 ];

          case r <= 22:
            return [ 269, r - 19, 2 ];

          case r <= 26:
            return [ 270, r - 23, 2 ];

          case r <= 30:
            return [ 271, r - 27, 2 ];

          case r <= 34:
            return [ 272, r - 31, 2 ];

          case r <= 42:
            return [ 273, r - 35, 3 ];

          case r <= 50:
            return [ 274, r - 43, 3 ];

          case r <= 58:
            return [ 275, r - 51, 3 ];

          case r <= 66:
            return [ 276, r - 59, 3 ];

          case r <= 82:
            return [ 277, r - 67, 4 ];

          case r <= 98:
            return [ 278, r - 83, 4 ];

          case r <= 114:
            return [ 279, r - 99, 4 ];

          case r <= 130:
            return [ 280, r - 115, 4 ];

          case r <= 162:
            return [ 281, r - 131, 5 ];

          case r <= 194:
            return [ 282, r - 163, 5 ];

          case r <= 226:
            return [ 283, r - 195, 5 ];

          case r <= 257:
            return [ 284, r - 227, 5 ];

          case 258 === r:
            return [ 285, r - 258, 0 ];

          default:
            throw "invalid length: " + r;
        }
    }(e), r[e] = n[2] << 24 | n[1] << 16 | n[0];
    return r;
}

function t(r, e, a) {
    var t, o, f, u, s, c, i = 0, l = r.length;
    r: for (u = 0, c = a.length; u < c; u++) {
        if (t = a[c - u - 1], f = X, i > X) {
            for (s = i; s > X; s--) if (r[t + s - 1] !== r[e + s - 1]) continue r;
            f = i;
        }
        for (;f < q && e + f < l && r[t + f] === r[e + f]; ) ++f;
        if (f > i && (o = t, i = f), f === q) break;
    }
    return new n(i, e - o);
}

function o(r, e) {
    var n, a, t, o, f, u = r.length, s = (new l(2 * G), new (C ? Uint8Array : Array)(u));
    if (!C) for (o = 0; o < u; o++) s[o] = 0;
    for (o = 0; o < u; ++o) r[o] > 0 && A(o, r[o]);
    if (n = new Array(M / 2), a = new (C ? Uint32Array : Array)(M / 2), 1 === n.length) return s[w().index] = 1, 
    s;
    for (o = 0, f = M / 2; o < f; ++o) n[o] = w(), a[o] = n[o].value;
    for (t = function(r, e, n) {
        function a(r) {
            var n = h[r][A[r]];
            n === e ? (a(r + 1), a(r + 1)) : --l[n], ++A[r];
        }
        var t, o, f, u, s, c = new (C ? Uint16Array : Array)(n), i = new (C ? Uint8Array : Array)(n), l = new (C ? Uint8Array : Array)(e), y = new Array(n), h = new Array(n), A = new Array(n), w = (1 << n) - e, b = 1 << n - 1;
        for (c[n - 1] = e, o = 0; o < n; ++o) w < b ? i[o] = 0 : (i[o] = 1, w -= b), w <<= 1, 
        c[n - 2 - o] = (c[n - 1 - o] / 2 | 0) + e;
        for (c[0] = i[0], y[0] = new Array(c[0]), h[0] = new Array(c[0]), o = 1; o < n; ++o) c[o] > 2 * c[o - 1] + i[o] && (c[o] = 2 * c[o - 1] + i[o]), 
        y[o] = new Array(c[o]), h[o] = new Array(c[o]);
        for (t = 0; t < e; ++t) l[t] = n;
        for (f = 0; f < c[n - 1]; ++f) y[n - 1][f] = r[f], h[n - 1][f] = f;
        for (t = 0; t < n; ++t) A[t] = 0;
        for (1 === i[n - 1] && (--l[0], ++A[n - 1]), o = n - 2; o >= 0; --o) {
            for (t = 0, u = 0, s = A[o + 1], f = 0; f < c[o]; f++) (u = y[o + 1][s] + y[o + 1][s + 1]) > r[t] ? (y[o][f] = u, 
            h[o][f] = e, s += 2) : (y[o][f] = r[t], h[o][f] = t, ++t);
            A[o] = 0, 1 === i[o] && a(o);
        }
        return l;
    }(a, a.length, e), o = 0, f = n.length; o < f; ++o) s[n[o].index] = t[o];
    return s;
}

function f(r) {
    var e, n, a, t, o = new (C ? Uint16Array : Array)(r.length), f = [], u = [], s = 0;
    for (e = 0, n = r.length; e < n; e++) f[r[e]] = 1 + (0 | f[r[e]]);
    for (e = 1, n = V; e <= n; e++) u[e] = s, s += 0 | f[e], s <<= 1;
    for (e = 0, n = r.length; e < n; e++) for (s = u[r[e]], u[r[e]] += 1, o[e] = 0, 
    a = 0, t = r[e]; a < t; a++) o[e] = o[e] << 1 | 1 & s, s >>>= 1;
    return o;
}

function u(r, e) {
    if (T = "number" == typeof e ? e : 0, x = 0, 2 * (I = r instanceof (C ? Uint8Array : Array) ? r : new (C ? Uint8Array : Array)(H)).length <= T) throw new Error("invalid index");
    I.length <= T && s();
}

function s() {
    var r, e = I, n = e.length, a = new (C ? Uint8Array : Array)(n << 1);
    if (C) a.set(e); else for (r = 0; r < n; ++r) a[r] = e[r];
    return I = a;
}

function c(r, e, n) {
    var a, t = I, o = t[T];
    if (n && e > 1 && (r = e > 8 ? function(r) {
        return _[255 & r] << 24 | _[r >>> 8 & 255] << 16 | _[r >>> 16 & 255] << 8 | _[r >>> 24 & 255];
    }(r) >> 32 - e : _[r] >> 8 - e), e + x < 8) o = o << e | r, x += e; else for (a = 0; a < e; ++a) o = o << 1 | r >> e - a - 1 & 1, 
    8 == ++x && (x = 0, t[T++] = _[o], o = 0, T === t.length && (t = s()));
    t[T] = o, I = t;
}

function i() {
    var r, e = I;
    return x > 0 && (e[T] <<= 8 - x, e[T] = _[e[T]], T++), C ? r = e.subarray(0, T) : (e.length = T, 
    r = e), r;
}

function l(r) {
    F = new (C ? Uint16Array : Array)(2 * r), M = 0;
}

function y(r) {
    return 2 * ((r - 2) / 4 | 0);
}

function h(r) {
    return 2 * r + 2;
}

function A(r, e) {
    var n, a, t, o = F;
    for (n = M, o[M++] = e, o[M++] = r; n > 0 && (a = y(n), o[n] > o[a]); ) t = o[n], 
    o[n] = o[a], o[a] = t, t = o[n + 1], o[n + 1] = o[a + 1], o[a + 1] = t, n = a;
    return M;
}

function w() {
    var r, e, n, a, t, o = F;
    for (e = o[0], r = o[1], M -= 2, o[0] = o[M], o[1] = o[M + 1], t = 0; !((a = h(t)) >= M) && (a + 2 < M && o[a + 2] > o[a] && (a += 2), 
    o[a] > o[t]); ) n = o[t], o[t] = o[a], o[a] = n, n = o[t + 1], o[t + 1] = o[a + 1], 
    o[a + 1] = n, t = a;
    return {
        index: r,
        value: e,
        length: M
    };
}

var b, k, g, p, v, d, E, U, m, D, N, I, T, x, F, M, C = !1, B = {
    DEFLATE: 8,
    RESERVED: 15
}, Y = {}, L = 32768, R = 1024, z = 0, O = {
    NONE: 0,
    FIXED: 1,
    DYNAMIC: 2,
    RESERVED: 3
}, X = 3, q = 258, S = 32768, V = 16, G = 286, H = 32768, _ = function() {
    var r, e = new (C ? Uint8Array : Array)(256);
    for (r = 0; r < 256; ++r) e[r] = function(r) {
        var e = r, n = 7;
        for (r >>>= 1; r; r >>>= 1) e <<= 1, e |= 1 & r, --n;
        return (e << n & 255) >>> 0;
    }(r);
    return e;
}();

module.exports = {
    Deflate: r
};
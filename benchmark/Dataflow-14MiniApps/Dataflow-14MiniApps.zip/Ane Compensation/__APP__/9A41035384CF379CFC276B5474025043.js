var e = require("@babel/runtime/helpers/typeof.js"), t = "https://padn-access.pa18.com/access.php?m=msgpack&sdkv=2.0&os=mp&source=ty", n = {
    deviceId: wx.getStorageSync("deviceId") || "",
    appkey: "3B2657751F011AED14DD983B570DF673",
    appProfile: {
        versionName: "2.0.0.0",
        versionCode: "20200414",
        initTime: "",
        sdkVersion: "Mp+v2.0.0",
        partner: "安E赔小程序"
    },
    deviceProfile: {
        pixel: "",
        language: "",
        timezone: new Date().getTimezoneOffset() / 60 * -1
    },
    msgs: wx.getStorageSync("_SK_sessionMsg") ? JSON.parse(wx.getStorageSync("_SK_sessionMsg")) : []
}, a = [], s = {
    type: 2,
    data: {
        id: "",
        start: wx.getStorageSync("SessionStart") || 0,
        status: 1,
        duration: 0
    }
}, r = {
    name: "",
    start: "",
    duration: "",
    refer: ""
}, o = [], i = [], S = "__SK_SK-init-event", g = 1, c = 0, d = 0, u = {
    onEvent: function(t, n, a) {
        var o = new Date().getTime();
        if (wx.setStorageSync("SessionEnd", o), arguments.length > 0) {
            g = 22;
            try {
                var c = {
                    count: 1,
                    time: new Date().getTime()
                };
                if (null != t && (c.eventId = "string" != typeof t ? JSON.stringify(t) : t), c.label = null != n ? "string" != typeof n ? JSON.stringify(n) : n : "", 
                null != a) {
                    var d = function(t) {
                        return "object" == e(t) && "[object object]" == Object.prototype.toString.call(t).toLowerCase() && !t.length;
                    };
                    d(a) ? c.parameters = a : c.parameters = {
                        parameters: ""
                    };
                }
                var u = wx.getStorageSync(S);
                if (u) {
                    var f = JSON.parse(u);
                    f.push(c), wx.setStorageSync(S, JSON.stringify(f));
                }
                wx.setStorageSync(S, "[" + JSON.stringify(c) + "]"), s.data.status = 2, s.data.duration = 0, 
                r.name = i[i.length - 1].name, r.start = i[i.length - 1].start, r.duration = 0, 
                r.refer = i.length >= 2 ? i[i.length - 2].name : "", l.getAjax();
            } catch (e) {}
        }
    },
    onShow: function() {
        console.log("skapp onhsow>>>>>>");
        var e = getCurrentPages(), t = new Date().getTime();
        if (i.push({
            name: e[e.length - 1].route,
            start: t
        }), !c && wx.getStorageSync("sessionId") && (wx.removeStorageSync("sessionId"), 
        wx.removeStorageSync("_SK_sessionMsg"), wx.removeStorageSync(S), wx.removeStorageSync("SessionStart"), 
        wx.removeStorageSync("initTime"), wx.removeStorageSync("lastSession")), c || wx.getStorageSync("sessionId")) {
            g = 20, s.data.status = 2, s.data.duration = 0;
            var n = i.length;
            r.name = n >= 2 ? i[n - 2].name : i[n - 1].name, r.start = n >= 2 ? i[n - 2].start : i[n - 1].start, 
            r.duration = parseInt((t - r.start) / 1e3), r.refer = n >= 3 ? i[i.length - 3].name : "", 
            l.getAjax();
        } else {
            if (c = 1, s.data.start = t, l.init(), wx.getStorageSync("deviceId")) l.set(); else var a = setInterval(function() {
                var e, t = getApp();
                t.globalData && (e = t.globalData.sdkOpenId), e && (l.getDeviceId(e), l.set(), clearInterval(a));
            }, 1e3);
            g = 1, r.name = i[i.length - 1].name, r.start = i[i.length - 1].start, r.duration = 0, 
            s.data.status = 1, l.getAjax(), o.push(a);
        }
    },
    onHide: function() {
        var e = new Date().getTime();
        g = 21, wx.setStorageSync("SessionEnd", e), s.data.status = 2, s.data.duration = 0;
        var t = d, a = e;
        wx.getStorageSync("deviceId") && wx.getStorageSync("unionId") || l.getUnionId(), 
        setTimeout(function() {
            21 === g && t === d && (g = 3, r.name = i[i.length - 1].name, r.start = i[i.length - 1].start, 
            r.duration = parseInt((a - r.start) / 1e3), r.refer = i.length >= 2 ? i[i.length - 2].name : "", 
            l.getAjax(), s.data.status = 3, s.data.duration = parseInt((a - s.data.start) / 1e3), 
            wx.setStorageSync("SessionEnd", a), wx.getStorageSync("deviceId") ? (l.getAjax(), 
            wx.nextTick(function() {
                l.initPage();
            })) : wx.nextTick(function() {
                n.deviceId = l.deviceId = wx.getStorageSync("unionId"), l.setSession(), l.getAjax(), 
                wx.nextTick(function() {
                    l.initPage();
                });
            }));
        }, 50);
    }
};

!function(e) {
    e.SKBASE = e.SKBASE || {}, e.SKBASE.unique = function(e) {
        e.sort();
        for (var t = [ e[0] ], n = 1; n < e.length; n++) e[n] && e[n] !== t[t.length - 1] && t.push(e[n]);
        return t;
    }, e.SKBASE.getCommon = function(e) {
        var t;
        return t = wx.getStorageSync("appkey") ? wx.getStorageSync("appkey") : n.appkey, 
        {
            deviceId: n.deviceId,
            appkey: t,
            appProfile: n.appProfile,
            deviceProfile: n.deviceProfile,
            msgs: e.msg
        };
    }, e.SKBASE.getCommonMsg = function(e, t, n, a, s, r) {
        return {
            type: 2,
            data: {
                id: e,
                start: t,
                status: a,
                duration: s || 0,
                pages: [ n ],
                events: r || []
            }
        };
    }, e.SKBASE.addSessionStart = function(t, n) {
        var a;
        wx.setStorageSync("lastSession", JSON.stringify({
            id: s.data.id,
            start: s.data.start
        })), (a = wx.getStorageSync("SK-hold-event")) && (a = JSON.parse(a));
        var o = e.SKBASE.getCommonMsg(s.data.id, s.data.start, r, s.data.status, s.data.duration, a);
        e.SKBASE.addMsg(o), wx.removeStorageSync("SK-hold-event");
    }, e.SKBASE.addMsg = function(e) {
        if (wx.getStorageSync("_SK_sessionMsg")) {
            var t = JSON.parse(wx.getStorageSync("_SK_sessionMsg"));
            e && (t.msg[0] = e), wx.setStorageSync("_SK_sessionMsg", JSON.stringify(t));
        } else wx.setStorageSync("_SK_sessionMsg", JSON.stringify({
            msg: [ e ]
        }));
    };
}(u);

var l = {
    timedif: void 0,
    state: 1,
    deviceId: n.deviceId,
    local: [],
    set: function() {
        try {
            this.setDeviceId(), this.setSession();
        } catch (e) {
            console.log(e);
        }
    },
    init: function() {
        try {
            this.setSessionTime(), this.setInitTime(), this.setResolution();
        } catch (e) {
            console.log(e);
        }
    },
    setDeviceId: function() {
        wx.getStorageSync("deviceId") ? this.deviceId = wx.getStorageSync("deviceId") : this.deviceId = n.deviceId;
    },
    setSession: function() {
        var e, t, n = this.deviceId, a = s.data.start;
        this.deviceId && this.deviceId.indexOf("-") > -1 ? e = this.deviceId.split("-")[0] + a : e = n + a;
        if (32 - e.length > 0) for (var r = 0, o = 32 - e.length; r < o; r++) e += "0"; else 32 - e.length < 0 && (t = e.length - 32, 
        e = e.substring(t, e.length));
        wx.getStorageSync("sessionId") ? e = wx.getStorageSync("sessionId") : wx.setStorageSync("sessionId", e), 
        s.data.id = e;
    },
    setSessionTime: function() {
        var e, t;
        e = s.data.start, t = wx.getStorageSync("SessionEnd") ? wx.getStorageSync("SessionEnd") : parseInt(e), 
        s.data.duration = parseInt((e - t) / 1e3), wx.getStorageSync("SessionStart") ? e = wx.getStorageSync("SessionStart") : wx.setStorageSync("SessionStart", e), 
        wx.getStorageSync("SessionEnd") ? e = wx.getStorageSync("SessionEnd") : wx.setStorageSync("SessionEnd", e);
    },
    setInitTime: function() {
        wx.getStorageSync("initTime") ? n.appProfile.initTime = parseInt(wx.getStorageSync("initTime")) : (n.appProfile.initTime = s.data.start, 
        wx.setStorageSync("initTime", s.data.start));
    },
    setResolution: function() {
        var e = wx.getSystemInfoSync(), t = [ e.screenWidth, e.screenHeight, e.pixelRatio ];
        n.deviceProfile.pixel = t.join("*"), n.deviceProfile.language = e.language;
    },
    getDeviceId: function(e) {
        wx.getStorageSync("deviceId") || (n.deviceId = l.deviceId = e, l.setSession(), wx.setStorageSync("deviceId", n.deviceId));
    },
    getUnionId: function() {
        if (wx.getStorageSync("unionId")) return wx.getStorageSync("unionId");
        var e, t = {
            brand: "",
            model: "",
            language: "",
            system: "",
            platform: "",
            avatarUrl: ""
        }, n = wx.getSystemInfoSync();
        wx.getUserInfo({
            success: function(n) {
                var a = n.userInfo;
                for (var s in t) a[s] && (t[s] = a[s]);
                e = JSON.stringify(t).MD5(32), wx.setStorageSync("unionId", e);
            },
            fail: function() {
                for (var a in t) n[a] && (t[a] = n[a]);
                t.timezone = new Date().getTimezoneOffset() / 60 * -1, t.startTime = new Date().getTime(), 
                e = JSON.stringify(t).MD5(32), wx.setStorageSync("unionId", e);
            }
        });
    },
    getAjax: function(e, s) {
        d++, u.SKBASE.addSessionStart(e, s);
        var r = JSON.parse(wx.getStorageSync("_SK_sessionMsg")), o = u.SKBASE.getCommon(r), i = wx.getStorageSync(S), c = o.msgs[o.msgs.length - 1];
        c && (c.data.events = i && 22 === g ? JSON.parse(i) : []), n.msgs = [ c ];
        var l = JSON.parse(JSON.stringify(n));
        if (l.deviceId) {
            if (wx.request({
                url: t,
                data: JSON.stringify(l),
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                method: "POST",
                success: function(e) {
                    console.log("success");
                },
                fail: function(e) {
                    console.log(e);
                }
            }), a.length) {
                for (var f = 0; f < a.length; f++) {
                    var v = a[f];
                    v.deviceId = n.deviceId, v.msgs[0].data.id = wx.getStorageSync("sessionId"), wx.request({
                        url: t,
                        data: JSON.stringify(v),
                        header: {
                            "content-type": "application/x-www-form-urlencoded"
                        },
                        method: "POST",
                        success: function(e) {
                            console.log("success");
                        },
                        fail: function(e) {
                            console.log(e);
                        }
                    });
                }
                a = [];
            }
        } else a.length > 100 ? (a.splice(1, 1), a.push(l)) : a.push(l);
    },
    initPage: function() {
        for (var e = 0; e <= o.length; e++) clearInterval(o[e]);
        o = [], g = 0, d = 0, c = 0, wx.removeStorageSync("_SK_sessionMsg"), wx.removeStorageSync(S), 
        wx.removeStorageSync("sessionId"), wx.removeStorageSync("SessionStart"), wx.removeStorageSync("initTime"), 
        wx.removeStorageSync("lastSession");
    }
};

String.prototype.MD5 = function(e) {
    function t(e, t) {
        return e << t | e >>> 32 - t;
    }
    function n(e, t) {
        var n, a, s, r, o;
        return s = 2147483648 & e, r = 2147483648 & t, o = (1073741823 & e) + (1073741823 & t), 
        (n = 1073741824 & e) & (a = 1073741824 & t) ? 2147483648 ^ o ^ s ^ r : n | a ? 1073741824 & o ? 3221225472 ^ o ^ s ^ r : 1073741824 ^ o ^ s ^ r : o ^ s ^ r;
    }
    function a(e, a, s, r, o, i, S) {
        return e = n(e, n(n(function(e, t, n) {
            return e & t | ~e & n;
        }(a, s, r), o), S)), n(t(e, i), a);
    }
    function s(e, a, s, r, o, i, S) {
        return e = n(e, n(n(function(e, t, n) {
            return e & n | t & ~n;
        }(a, s, r), o), S)), n(t(e, i), a);
    }
    function r(e, a, s, r, o, i, S) {
        return e = n(e, n(n(function(e, t, n) {
            return e ^ t ^ n;
        }(a, s, r), o), S)), n(t(e, i), a);
    }
    function o(e, a, s, r, o, i, S) {
        return e = n(e, n(n(function(e, t, n) {
            return t ^ (e | ~n);
        }(a, s, r), o), S)), n(t(e, i), a);
    }
    function i(e) {
        var t, n = "", a = "";
        for (t = 0; t <= 3; t++) n += (a = "0" + (e >>> 8 * t & 255).toString(16)).substr(a.length - 2, 2);
        return n;
    }
    var S, g, c, d, u, l, f, v, y, w = Array();
    for (w = function(e) {
        for (var t, n = e.length, a = n + 8, s = 16 * ((a - a % 64) / 64 + 1), r = Array(s - 1), o = 0, i = 0; i < n; ) o = i % 4 * 8, 
        r[t = (i - i % 4) / 4] = r[t] | e.charCodeAt(i) << o, i++;
        return o = i % 4 * 8, r[t = (i - i % 4) / 4] = r[t] | 128 << o, r[s - 2] = n << 3, 
        r[s - 1] = n >>> 29, r;
    }(this), l = 1732584193, f = 4023233417, v = 2562383102, y = 271733878, S = 0; S < w.length; S += 16) g = l, 
    c = f, d = v, u = y, l = a(l, f, v, y, w[S + 0], 7, 3614090360), y = a(y, l, f, v, w[S + 1], 12, 3905402710), 
    v = a(v, y, l, f, w[S + 2], 17, 606105819), f = a(f, v, y, l, w[S + 3], 22, 3250441966), 
    l = a(l, f, v, y, w[S + 4], 7, 4118548399), y = a(y, l, f, v, w[S + 5], 12, 1200080426), 
    v = a(v, y, l, f, w[S + 6], 17, 2821735955), f = a(f, v, y, l, w[S + 7], 22, 4249261313), 
    l = a(l, f, v, y, w[S + 8], 7, 1770035416), y = a(y, l, f, v, w[S + 9], 12, 2336552879), 
    v = a(v, y, l, f, w[S + 10], 17, 4294925233), f = a(f, v, y, l, w[S + 11], 22, 2304563134), 
    l = a(l, f, v, y, w[S + 12], 7, 1804603682), y = a(y, l, f, v, w[S + 13], 12, 4254626195), 
    v = a(v, y, l, f, w[S + 14], 17, 2792965006), l = s(l, f = a(f, v, y, l, w[S + 15], 22, 1236535329), v, y, w[S + 1], 5, 4129170786), 
    y = s(y, l, f, v, w[S + 6], 9, 3225465664), v = s(v, y, l, f, w[S + 11], 14, 643717713), 
    f = s(f, v, y, l, w[S + 0], 20, 3921069994), l = s(l, f, v, y, w[S + 5], 5, 3593408605), 
    y = s(y, l, f, v, w[S + 10], 9, 38016083), v = s(v, y, l, f, w[S + 15], 14, 3634488961), 
    f = s(f, v, y, l, w[S + 4], 20, 3889429448), l = s(l, f, v, y, w[S + 9], 5, 568446438), 
    y = s(y, l, f, v, w[S + 14], 9, 3275163606), v = s(v, y, l, f, w[S + 3], 14, 4107603335), 
    f = s(f, v, y, l, w[S + 8], 20, 1163531501), l = s(l, f, v, y, w[S + 13], 5, 2850285829), 
    y = s(y, l, f, v, w[S + 2], 9, 4243563512), v = s(v, y, l, f, w[S + 7], 14, 1735328473), 
    l = r(l, f = s(f, v, y, l, w[S + 12], 20, 2368359562), v, y, w[S + 5], 4, 4294588738), 
    y = r(y, l, f, v, w[S + 8], 11, 2272392833), v = r(v, y, l, f, w[S + 11], 16, 1839030562), 
    f = r(f, v, y, l, w[S + 14], 23, 4259657740), l = r(l, f, v, y, w[S + 1], 4, 2763975236), 
    y = r(y, l, f, v, w[S + 4], 11, 1272893353), v = r(v, y, l, f, w[S + 7], 16, 4139469664), 
    f = r(f, v, y, l, w[S + 10], 23, 3200236656), l = r(l, f, v, y, w[S + 13], 4, 681279174), 
    y = r(y, l, f, v, w[S + 0], 11, 3936430074), v = r(v, y, l, f, w[S + 3], 16, 3572445317), 
    f = r(f, v, y, l, w[S + 6], 23, 76029189), l = r(l, f, v, y, w[S + 9], 4, 3654602809), 
    y = r(y, l, f, v, w[S + 12], 11, 3873151461), v = r(v, y, l, f, w[S + 15], 16, 530742520), 
    l = o(l, f = r(f, v, y, l, w[S + 2], 23, 3299628645), v, y, w[S + 0], 6, 4096336452), 
    y = o(y, l, f, v, w[S + 7], 10, 1126891415), v = o(v, y, l, f, w[S + 14], 15, 2878612391), 
    f = o(f, v, y, l, w[S + 5], 21, 4237533241), l = o(l, f, v, y, w[S + 12], 6, 1700485571), 
    y = o(y, l, f, v, w[S + 3], 10, 2399980690), v = o(v, y, l, f, w[S + 10], 15, 4293915773), 
    f = o(f, v, y, l, w[S + 1], 21, 2240044497), l = o(l, f, v, y, w[S + 8], 6, 1873313359), 
    y = o(y, l, f, v, w[S + 15], 10, 4264355552), v = o(v, y, l, f, w[S + 6], 15, 2734768916), 
    f = o(f, v, y, l, w[S + 13], 21, 1309151649), l = o(l, f, v, y, w[S + 4], 6, 4149444226), 
    y = o(y, l, f, v, w[S + 11], 10, 3174756917), v = o(v, y, l, f, w[S + 2], 15, 718787259), 
    f = o(f, v, y, l, w[S + 9], 21, 3951481745), l = n(l, g), f = n(f, c), v = n(v, d), 
    y = n(y, u);
    return 32 == e ? i(l) + i(f) + i(v) + i(y) : i(f) + i(v);
}, module.exports = {
    onEvent: u.onEvent,
    onShow: u.onShow,
    onHide: u.onHide
};
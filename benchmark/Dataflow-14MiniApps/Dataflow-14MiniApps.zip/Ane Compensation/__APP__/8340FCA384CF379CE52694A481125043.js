Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.sampleDescription = void 0;

exports.sampleDescription = [ {
    materialCode: [ "601" ],
    description: [ "1、需审核资料原件或复印件;", "2、没有医保报销或其他先期报销的，需拍照上传原件；有医保报销或其他先期报销的，有原件拍照上传原件，没有原件可拍照上传复印件;", "3、注意按治疗时间的先后顺序拍照上传；" ],
    sampleList: [ {
        materialTitle: "发票样例"
    } ]
}, {
    materialCode: [ "901" ],
    description: [ "1、需对资料原件审核后拍照上传；", "2、意外事故证明指说明意外事故经过的证明资料：<br/>&nbsp;&nbsp;&nbsp;a/交通事故提供交警部门出具的《交通事故责任认定书》、《交通事故责任调解书》、《交通事故简易程序处理书》、机动车驾驶证与行驶证（正、副本）等材料；<br/>&nbsp;&nbsp;&nbsp;b/因遭受不法侵害受伤的可提供公安部门的“事故证明”等材料；<br/>&nbsp;&nbsp;&nbsp;c/无第三方见证的原则上可由申请人提供说明意外经过的书面材料等；", "3、对于索赔金额在3000元以下个人医疗保险小额理赔中，除有公安机关等第三方介入的情况外，无需提供意外事故证明；" ],
    sampleList: [ {
        materialTitle: "意外事故证明样例"
    } ]
}, {
    materialCode: [ "22", "101", "102", "103" ],
    description: [ "1、需对资料原件审核后拍照上传；", "2、常见身份证明：居民身份证、港澳居民往来内地通行证、台湾居民来往大陆通行证、护照、由公安机关户籍管理部门出具的带照片的身份证明文件等；" ],
    sampleList: [ {
        materialTitle: "身份证样例1"
    }, {
        materialTitle: "身份证样例2"
    } ]
}, {
    materialCode: [ "104" ],
    description: [ "1、需审核资料原件后拍照上传；", "2、常见身份证明：居民身份证、港澳居民往来内地通行证、台湾居民来往大陆通行证、护照、由公安机关户籍管理部门出具的带照片的身份证明文件等；", "3、常见身份关系证明：结婚证、出生医学证明书、独生子女证、居民户口簿、公证书、公安部门出具的亲属关系证明及监护证明等。" ],
    sampleList: [ {
        materialTitle: "身份证样例1"
    }, {
        materialTitle: "身份证样例2"
    } ]
}, {
    materialCode: [ "21" ],
    description: [ "1、需对资料原件审核后拍照上传；", "2、《理赔申请确认函》由申请人本人填写完整；如出险人未成年或不具备完全民事行为能力的，由出险人的监护人代为申请；" ],
    sampleList: [ {
        materialTitle: "理赔申请确认函样例"
    } ]
}, {
    materialCode: [ "34" ],
    description: [ "1、需对资料原件审核后拍照上传；", "2、《个人客户纳税身份声明文件(理赔申请)》由申请人本人填写完整；如出险人未成年或不具备完全民事行为能力的，由出险人的监护人代为申请；", "3、请关注：如声明为“仅为非居民”或“既是中国税收居民又是其他国家（地区）税收居民”的，需按文件中要求继续填写相关信息，谢谢！" ],
    sampleList: [ {
        materialTitle: "个人客户纳税身份声明样例"
    } ]
}, {
    materialCode: [ "17" ],
    description: [ "1、需对资料原件审核后拍照上传；", "2、常见关系证明：出生医学证明书、独生子女证、居民户口簿、公证书、公安部门出具的亲属关系证明及监护证明等；" ],
    sampleList: [ {
        materialTitle: "身份关系证明样例"
    } ]
}, {
    materialCode: [ "201" ],
    description: [ "1、需审核资料原件;", "2、包括门诊病历封面、与本次事故有关的所有门诊就诊病历；", "3、注意按治疗时间的先后顺序拍照上传；" ],
    sampleList: [ {
        materialTitle: "出院证明样例"
    }, {
        materialTitle: "病历样例1"
    }, {
        materialTitle: "病历样例2"
    } ]
}, {
    materialCode: [ "202" ],
    description: [ "1、需审核资料原件;", "2、包括出院小结（出院记录）、疾病诊断证明书、住院病历；" ],
    sampleList: [ {
        materialTitle: "出院证明样例"
    }, {
        materialTitle: "病历样例1"
    }, {
        materialTitle: "病历样例2"
    } ]
}, {
    materialCode: [ "203" ],
    description: [ "1、需审核资料原件;", "2、包括病理报告、化验报告、放射检查报告等；" ],
    sampleList: [ {
        materialTitle: "出院证明样例"
    }, {
        materialTitle: "病历样例1"
    }, {
        materialTitle: "病历样例2"
    } ]
}, {
    materialCode: [ "204" ],
    description: [ "1、需审核资料原件后拍照上传；" ],
    sampleList: [ {
        materialTitle: "出院证明样例"
    }, {
        materialTitle: "病历样例1"
    }, {
        materialTitle: "病历样例2"
    } ]
}, {
    materialCode: [ "19" ],
    description: [ "1、需对资料原件审核后拍照上传；", "2、银行帐户须为申请人名下，包括银行存折、银行卡；" ],
    sampleList: [ {
        materialTitle: "银行存折卡样例"
    } ]
}, {
    materialCode: [ "20" ],
    description: [ "1、需上传原件；" ],
    sampleList: [ {
        materialTitle: "授权委托书样例"
    } ]
}, {
    materialCode: [ "23" ],
    description: [ "1、需对资料原件审核后，按治疗时间的先后顺序拍照上传；", "2、提供与医疗费用发票相对应的费用明细清单；" ],
    sampleList: [ {
        materialTitle: "清单样例"
    } ]
}, {
    materialCode: [ "25" ],
    description: [ "1、需对资料原件审核后拍照上传;", "2、常见社保证明资料包括：社会保障卡、农合手册、社保结算单、商业保险结算单、其他第三方赔付证明等；" ],
    sampleList: [ {
        materialTitle: "社保证明（正面）样例1"
    }, {
        materialTitle: "社保证明（背面）样例2"
    } ]
}, {
    materialCode: [ "30" ],
    description: [ "1、需审核资料原件后拍照上传;", "2、重大疾病诊断证明：申请重大疾病保险金，应提供相关诊断证明、检查/检验结果等医学资料；如恶性肿瘤原则上应提供病理报告（如客户未行病理检查，应提供相关影像学等医学检查记录）；" ],
    sampleList: [ {
        materialTitle: "重大疾病诊断证明样例1"
    }, {
        materialTitle: "重大疾病诊断证明样例2"
    } ]
}, {
    materialCode: [ "31" ],
    description: [ "1、需审核资料原件后拍照上传;", "2、残疾鉴定证明：指由保险公司、理赔申请人双方认可的医疗机构或有资质的鉴定机构根据客户购买的意外伤害保险条款中关于残疾程度的约定项目及标准出具的被保险人残疾程度的资料或身体残疾程度评定书；" ],
    sampleList: [ {
        materialTitle: "残疾鉴定证明样例"
    } ]
}, {
    materialCode: [ "32" ],
    description: [ "1、客户有可见伤残的，请上传客户的伤残部位照片;", "2、伤残照片需包含一张全身照，以便确认是客户本人出险；另根据需要上传一张或一张以上局部照，以便判断客户的伤残程度；" ],
    sampleList: [ {
        materialTitle: "伤残部位照片全身样例1"
    }, {
        materialTitle: "伤残部位照片正面样例2"
    }, {
        materialTitle: "伤残部位照片侧面样例3"
    } ]
}, {
    materialCode: [ "602" ],
    description: [ "1、包括城镇职工医保、城镇居民医保、新农合、医疗救助等政府举办的基本医疗保障项目;", "2、需审核并提供医保报销单原件，并注明报销金额与比例，加盖报销单位印章;", "3、注意按治疗时间的先后顺序拍照上传；" ],
    sampleList: [ {
        materialTitle: "医保报销单样例"
    } ]
}, {
    materialCode: [ "603" ],
    description: [ "1、包括其他保险公司、工作单位等的费用报销;", "2、需审核并提供报销单原件，并注明报销金额与比例，加盖报销单位印章;", "3、注意按治疗时间的先后顺序拍照上传；" ],
    sampleList: [ {
        materialTitle: "其他先期报销证明样例"
    } ]
}, {
    materialCode: [ "37" ],
    description: [ "1、需对资料原件审核后拍照上传；", "2、《关系声明》由申请人本人填写完整；" ],
    sampleList: [ {
        materialTitle: "关系声明样例"
    } ]
}, {
    materialCode: [ "701" ],
    description: [ "1、需审核资料原件；", "2、注意按治疗时间的先后顺序拍照上传；", "3、注意提供与医疗费用发票相对应的费用明细清单。" ],
    sampleList: [ {
        materialTitle: "医疗费用汇总清单样例"
    } ]
}, {
    materialCode: [ "1001" ],
    description: [ "1、需对资料原件审核后拍照上传；", "2、银行帐户须为申请人名下，包括银行存折、银行卡；" ],
    sampleList: [ {
        materialTitle: "银行存折卡样例"
    } ]
}, {
    materialCode: [ "604" ],
    description: [ "1、需审核资料原件后拍照上传；", "2、住院缴付押金后医院出具的证明；" ],
    sampleList: [ {
        materialTitle: "押金单样例"
    } ]
}, {
    materialCode: [ "207" ],
    description: [ "1、需审核资料原件后拍照上传；", "2、医院出具的入院证或床头卡；" ],
    sampleList: [ {
        materialTitle: "入院证/床头卡样例1"
    }, {
        materialTitle: "入院证/床头卡样例2"
    } ]
}, {
    materialCode: [ "208" ],
    description: [ "1、上传被保险人在医院病房住院的照片" ],
    sampleList: [ {
        materialTitle: "住院现场照片样例"
    } ]
} ];
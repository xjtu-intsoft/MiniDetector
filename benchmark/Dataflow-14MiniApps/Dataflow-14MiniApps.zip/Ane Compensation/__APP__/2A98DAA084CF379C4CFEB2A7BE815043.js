var n = require("8770FA2584CF379CE116922226815043.js"), t = require("F2E3964184CF379C9485FE465AD15043.js"), a = require("7A4F598784CF379C1C29318090A15043.js");

module.exports = {
    init: function(t, a) {
        return !!(t && "function" == typeof t && t.length >= 3) && (n.initAnySignApi(t, a), 
        !0);
    },
    addDataobj: function(a, e) {
        return !(!e instanceof t.DataConfig) && n._addDataObj(a, e);
    },
    addSignatureObj: function(a, e) {
        return !(!e instanceof t.SignatureConfig) && n._addSignatureObj(a, e);
    },
    addEvidence: function(t, a, e, i, o) {
        return n._addEvidence(t, a, e, i, o);
    },
    addCachetObj: function(a) {
        return a instanceof t.CachetConfig && n._addChachetObj(a);
    },
    setTemplate: function(t, a, e, i) {
        return !!n && n._setTemplate(t, a, e, i);
    },
    setTID: function(t) {
        return n._setTID(t);
    },
    setData: function(t, a) {
        return n._setData(t, a);
    },
    showSignatureDialog: function(t, a) {
        return n._showSignatureDialog(t, a);
    },
    commitConfig: function() {
        return n._commitConfig();
    },
    resetConfig: function() {
        return n._resetConfig();
    },
    isReadyToUpload: function() {
        return n._isReadyToUpload();
    },
    getUploadDataGram: function() {
        return n._getUploadDataGram();
    },
    getVersion: function() {
        return "AnySign_V1.3.3_WX_1.0.0";
    },
    getOSInfo: function() {
        return n._getOSInfo();
    },
    canvasStart: function(n) {
        a.canvasStart(n);
    },
    canvasMove: function(n) {
        a.canvasMove(n);
    },
    canvasEnd: function(n) {
        a.canvasEnd(n);
    },
    sign_confirm: function() {
        a.sign_confirm();
    },
    clear_canvas: function() {
        a.clear_canvas();
    },
    cancel_sign: function() {
        a.sign_cancel();
    }
};
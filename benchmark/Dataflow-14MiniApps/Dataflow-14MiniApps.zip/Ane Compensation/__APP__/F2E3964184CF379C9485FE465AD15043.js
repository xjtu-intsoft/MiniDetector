function t(t, e, i, n, o) {
    if (!t || 0 === t.length) throw "SignRule_KeyWordV2 constructor parameter keyword could not be null or empty";
    if (1 !== e && 2 !== e && 3 !== e && 4 != e) throw "SignRule_KeyWord constructor parameter keyWordAlignMethod invalid, should be one of '1' '2' '3' '4'";
    this.RuleType = "0", isNaN(n) || isNaN(i) || isNaN(o) || (this.KWRule = {
        KW: t,
        KWPos: e,
        KWOffset: i,
        Pageno: n,
        KWIndex: o,
        XOffset: 0,
        YOffset: 0
    });
}

function e(t, e, i, n, o) {
    if (!t || 0 === t.length) throw "SignRule_KeyWordV2 constructor parameter keyword could not be null or empty";
    this.RuleType = "0", isNaN(n) || isNaN(o) || (this.KWRule = {
        KW: t,
        KWPos: 0,
        KWOffset: 0,
        XOffset: e,
        YOffset: i,
        Pageno: n,
        KWIndex: o
    });
}

function i(t) {
    if (!t || 0 === t.length) throw "SignRule_Tid constructor parameter tid could not be null or empty";
    this.RuleType = "2", this.Tid = t;
}

function n(t, e, i, n, o, s) {
    if (isNaN(t) || isNaN(e) || isNaN(i) || isNaN(n) || isNaN(o)) throw "SignRule_XYZ constructor parameter invalid, only float or int permitted";
    if (i < t) throw "SignRule_XYZ constructor left must be less than right";
    if (e < n) throw "SignRule_XYZ constructor top must not be less than bottom";
    if (!s || "pt" !== s && "dp" !== s) throw "SignRule_XYZ constructor parameter unit can only be 'dp' or 'pt'";
    this.RuleType = "1", this.XYZRule = {
        Left: t,
        Top: e,
        Right: i,
        Bottom: n,
        Pageno: o,
        Unit: s
    };
}

function o(t, e) {
    if (!t || !e || 0 === t.length || 0 === e.length) throw "Signer constructor parameter name and id could not be null or empty";
    this.UName = t, this.IDNumber = e, this.IDType = "1";
}

module.exports = {
    SignatureConfig: function(o, s) {
        if (!o || !s) throw "SignatureConfig constructor parameter signer or signRule could not be null.";
        if (!(s instanceof t || s instanceof i || s instanceof n || s instanceof e || s instanceof SignRule_KeyWordV3)) throw "SignatureConfig constructor parameter signRule invalid, should be instance of SignRule_KeyWord or SignRule_Tid or SignRule_XYZ";
        this.signer = o, this.signRule = s, this.cid = 0, this.title = "请投保人刘伟签名", this.titleSpanFromOffset = 4, 
        this.titleSpanToOffset = 5, this.isTSS = !1, this.nessesary = !1, this.singleWidth = 500, 
        this.singleHeight = 500, this.penColor = "#000000", this.signatureImgRatio = 1, 
        this.timeTag = null, this.widthMultiple = 1;
    },
    CachetConfig: function(s, r, l) {
        if (!(s instanceof o)) throw "CachetConfig constructor parameter signer invalid";
        if (this.Signer = s, !(r instanceof t || r instanceof i || r instanceof n || r instanceof e || r instanceof SignRule_KeyWordV3)) throw "CachetConfig constructor parameter signRule invalid, should be instance of SignRule_KeyWord or SignRule_Tid or SignRule_XYZ";
        this.SignRule = r, this.IsTSS = l;
    },
    SignRule_KeyWord: t,
    SignRule_KeyWordV2: e,
    SignRule_Tid: i,
    SignRule_XYZ: n,
    signer: o,
    TimeTag: function(t, e) {
        if (!t || !e || 0 === t.length || 0 === e.length) throw "TimeTag constructor parameter { and position could not be null or empty";
        this.Pos = t, this.Format = e;
    },
    DataConfig: function() {
        this.cid = 0, this.name = null, this.format = null, this.nessesary = !0;
    }
};
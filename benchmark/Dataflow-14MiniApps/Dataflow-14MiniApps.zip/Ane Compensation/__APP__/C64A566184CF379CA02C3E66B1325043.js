function r(r) {
    for (var t, n = 0, o = r.length, a = "", i = ""; n < o; ) {
        for (var h = 0, f = (t = r.subarray(n, Math.min(n + 32768, o))).length; h < f; h++) i += String.fromCharCode(t[h]);
        a += i, n += 32768, i = "";
    }
    return function(r) {
        var t, n, o = "";
        for (t = 0, n = r.length; t < n; t += 3) {
            var a = 255 & r.charCodeAt(t), i = 255 & r.charCodeAt(t + 1), h = 255 & r.charCodeAt(t + 2), f = a >> 2, c = (3 & a) << 4 | i >> 4, u = t + 1 < n ? (15 & i) << 2 | h >> 6 : 64, d = t + 2 < n ? 63 & h : 64;
            o += e.charAt(f) + e.charAt(c) + e.charAt(u) + e.charAt(d);
        }
        return o;
    }(a);
}

var t = require("3CEE3F0084CF379C5A88570750625043.js"), n = [ "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f" ], e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

module.exports = {
    encodeUint8Array: r,
    decodeUint8ArrayB64: function(r) {
        return new Uint8Array(atob(r).split("").map(function(r) {
            return r.charCodeAt(0);
        }));
    },
    encode: function(r) {
        var t, n, e, o, a, i, h, f = "", c = 0;
        for (r = Base64._utf8_encode(r); c < r.length; ) o = (t = r.charCodeAt(c++)) >> 2, 
        a = (3 & t) << 4 | (n = r.charCodeAt(c++)) >> 4, i = (15 & n) << 2 | (e = r.charCodeAt(c++)) >> 6, 
        h = 63 & e, isNaN(n) ? i = h = 64 : isNaN(e) && (h = 64), f = f + this._keyStr.charAt(o) + this._keyStr.charAt(a) + this._keyStr.charAt(i) + this._keyStr.charAt(h);
        return f;
    },
    decode: function(r) {
        var t, n, e, o, a, i, h = "", f = 0;
        for (r = r.replace(/[^A-Za-z0-9\+\/\=]/g, ""); f < r.length; ) t = this._keyStr.indexOf(r.charAt(f++)) << 2 | (o = this._keyStr.indexOf(r.charAt(f++))) >> 4, 
        n = (15 & o) << 4 | (a = this._keyStr.indexOf(r.charAt(f++))) >> 2, e = (3 & a) << 6 | (i = this._keyStr.indexOf(r.charAt(f++))), 
        h += String.fromCharCode(t), 64 != a && (h += String.fromCharCode(n)), 64 != i && (h += String.fromCharCode(e));
        return Base64._utf8_decode(h);
    },
    _utf8_encode: function(r) {
        r = r.replace(/\r\n/g, "\n");
        for (var t = "", n = 0; n < r.length; n++) {
            var e = r.charCodeAt(n);
            e < 128 ? t += String.fromCharCode(e) : e > 127 && e < 2048 ? (t += String.fromCharCode(e >> 6 | 192), 
            t += String.fromCharCode(63 & e | 128)) : (t += String.fromCharCode(e >> 12 | 224), 
            t += String.fromCharCode(e >> 6 & 63 | 128), t += String.fromCharCode(63 & e | 128));
        }
        return t;
    },
    _utf8_decode: function(r) {
        for (var t = "", n = 0, e = 0, o = 0, a = 0; n < r.length; ) (e = r.charCodeAt(n)) < 128 ? (t += String.fromCharCode(e), 
        n++) : e > 191 && e < 224 ? (o = r.charCodeAt(n + 1), t += String.fromCharCode((31 & e) << 6 | 63 & o), 
        n += 2) : (o = r.charCodeAt(n + 1), a = r.charCodeAt(n + 2), t += String.fromCharCode((15 & e) << 12 | (63 & o) << 6 | 63 & a), 
        n += 3);
        return t;
    },
    uint32ArrayToUint8Array: function(r) {
        if (!r) return null;
        for (var t, n = new Uint8Array(4 * r.length), e = 0, o = r.length; e < o; e++) n[t = e << 2] = r[e] >> 24 & 255, 
        n[t + 1] = r[e] >> 16 & 255, n[t + 2] = r[e] >> 8 & 255, n[t + 3] = 255 & r[e];
        return n;
    },
    uint8ArrayToHexStr: function(r) {
        if (!r) return null;
        for (var t = "", e = 0; e < r.length; e++) {
            var o = r[e];
            t += n[o >>> 4], t += n[15 & o];
        }
        return t;
    },
    hexStrToUint8Array: function(r) {
        if (!r || r.length % 2 != 0) return null;
        for (var t = [], n = 0; n < r.length; n += 2) t.push(parseInt("0x" + r.substr(n, 2), 16));
        return new Uint8Array(t);
    },
    hexStrToUint8Str: function(r) {
        if (!r || r.length % 2 != 0) return null;
        for (var t = "", n = 0; n < r.length; n += 2) t += String.fromCharCode(parseInt("0x" + r.substr(n, 2), 16));
        return decodeURIComponent(escape(t));
    },
    strToUtf8ArrayUint8: function(r) {
        for (var t = unescape(encodeURIComponent(r)), n = new Uint8Array(t.length), e = 0; e < t.length; e++) n[e] = t.charCodeAt(e);
        return n;
    },
    utf8ArrayUint8ToStr: function(r) {
        for (var t = "", n = 0; n < r.length; n++) t += String.fromCharCode(r[n]);
        return decodeURIComponent(escape(t));
    },
    toUtf8str: function(r) {
        return unescape(encodeURIComponent(r));
    },
    uint8ArrayAscIIToStr: function(r) {
        return String.fromCharCode.apply(null, r);
    },
    strToUint8ArrayAscII: function(r) {
        for (var t = new Uint8Array(r.length), n = 0, e = r.length; n < e; ++n) t[n] = r.charCodeAt(n);
        return t;
    },
    compressToB64: function(n) {
        for (var e = new t.Deflate(n), o = new Uint8Array(e.length), a = 0, i = o.length; a < i; ++a) o[a] = e[a];
        return r(e = o);
    },
    stringify: function(r) {
        return JSON.stringify(r);
    },
    stringToObj: function(r) {
        return JSON.parse(r);
    },
    crc32: function(r) {
        for (var t, n = [], e = 0; e < 256; e++) {
            t = e;
            for (var o = 0; o < 8; o++) t = 1 & t ? 3988292384 ^ t >>> 1 : t >>> 1;
            n[e] = t;
        }
        for (var a = -1, i = 0; i < r.length; i++) a = a >>> 8 ^ n[255 & (a ^ r.charCodeAt(i))];
        return (-1 ^ a) >>> 0;
    }
};
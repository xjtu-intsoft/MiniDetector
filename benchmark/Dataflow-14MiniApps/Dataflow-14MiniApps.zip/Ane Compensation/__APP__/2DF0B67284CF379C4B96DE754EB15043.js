function t(t, e, n, o) {
    wx.request({
        url: e,
        data: n,
        method: t,
        header: {
            "Content-Type": "application/json",
            Charset: "utf-8"
        },
        success: function(t) {
            return "function" == typeof o && o(t);
        },
        fail: function() {
            return "function" == typeof o && o(!1);
        }
    });
}

module.exports = {
    getReq: function(e, n, o) {
        t("get", e, n, o);
    },
    postReq: function(e, n, o) {
        t("post", e, n, o);
    }
};
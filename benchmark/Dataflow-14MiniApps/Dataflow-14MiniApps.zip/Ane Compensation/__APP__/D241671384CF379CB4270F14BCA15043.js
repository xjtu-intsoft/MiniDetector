module.exports = {
    AnySignRoot: function() {
        this.Version = "4.7", this.EncCertSN = null, this.EncKey = null, this.TermSrc = "PAD", 
        this.Digest = null, this.EncData = null;
    },
    Digest: function() {
        this.Alg = null, this.Value = null;
    },
    FormInfo: function() {
        this.WONo = null, this.WOHash = null, this.IsSync = !1, this.IsUnit = !1, this.EncAlg = "RSA", 
        this.FlowID = null, this.Channel = null, this.USignArray = [], this.DataArray = [], 
        this.CachetArray = [], this.ExtInfo = null;
    },
    SaveFormInfo: function() {
        this.WONo = null, this.WOHash = null, this.Channel = null, this.EncAlg = "RSA", 
        this.USignObjs = [], this.USignConfigs = [], this.DataObjs = [], this.DataConfigs = [], 
        this.CachetArray = [];
    },
    ExtInfo: function() {},
    PlainData: function() {
        this.P10Data = null, this.CertOID = null;
    },
    P10Data: function() {
        this.RawHash = null, this.Hash = null, this.Value = null, this.ValueType = null, 
        this.P10SignValue = null, this.Hashalg = null, this.Dn = null, this.IDType = null, 
        this.IDNumber = null, this.Templname = "3", this.Channel = "10000";
    },
    CertOID: function() {
        this.Version = "3.2", this.IDType = null, this.IDNumber = null, this.RawHash = null, 
        this.BioFeature = null, this.ClientOS = null;
    },
    BioFeature: function() {
        this.PhotoArray = [], this.SoundArray = [], this.Script = null;
    },
    Script: function() {
        this.Format = "zip", this.Width = "180", this.Color = null, this.Count = null, this.Data = null, 
        this.Device = null, this.RefHeight = 99999, this.RefWidth = 99999, this.Geoloca = null;
    },
    Device: function() {
        this.DeviceName = "", this.SampleRate = "1024", this.PressMax = "1024", this.Width = 99999, 
        this.Height = 99999, this.DriverVer = "v1.0", this.DeviceID = "", this.CertInfo = null;
    },
    ClientOS: function() {
        this.Name = "", this.Edition = "", this.ServicePack = "None", this.Version = "", 
        this.OSArch = "32/64", this.DeviceID = "";
    },
    ImageSize: function(t, i) {
        this.Width = t, this.Height = i, this.Unit = "dp";
    },
    SignatureObj: function() {
        this.Cid = 0, this.SignRule = null, this.Signer = null, this.Image = null, this.ImageSize = null, 
        this.IsTSS = !1, this.Points = null, this.ImageFMT = getApp().sigGlobalData.DataFormat.IMAGE_PNG, 
        this.TimeTag = null;
    },
    DataObj: function() {
        this.Cid = 0, this.OwnerCid = 0, this.PointHash = null, this.Data = null, this.Name = null, 
        this.Format = null, this.PDFCrdRule = null;
    },
    PDFCrdRule: function() {
        this.DocCrdTid = null, this.DocFormat = null, this.DocStyleTid = null;
    }
};
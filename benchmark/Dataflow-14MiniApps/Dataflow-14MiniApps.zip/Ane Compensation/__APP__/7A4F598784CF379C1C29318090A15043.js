function e() {
    console.log("clear"), w = !0, m = [], c = "", h = "", u = 0, 0, 0, n.clearRect(0, 0, f, r), 
    n.draw(!0);
}

require("C64A566184CF379CA02C3E66B1325043.js");

var n, o, a, t, s, c, i, l, g = !1, h = "", u = 0, d = 0, r = 0, f = 0, p = 4, m = [], w = !0;

module.exports = {
    onloadAnysignView: function(t, c, i) {
        s = i, o = t, a = c, w = !0, (n = wx.createCanvasContext("anysignCanvas")).setStrokeStyle(o ? o.penColor : "#000000"), 
        n.setLineWidth(p), n.setLineCap("round"), n.setLineJoin("round"), wx.getSystemInfo({
            success: function(e) {
                f = e.windowWidth, r = e.windowHeight;
            }
        }), e();
    },
    canvasStart: function(e) {
        i = e.changedTouches[0].x, l = e.changedTouches[0].y, g = !0, m.push({
            x: e.changedTouches[0].x,
            y: e.changedTouches[0].y
        });
    },
    canvasMove: function(e) {
        if (g && w) {
            var o = e.changedTouches[0].x, a = e.changedTouches[0].y, t = e.changedTouches[0].x, s = e.changedTouches[0].y;
            m.push({
                x: e.changedTouches[0].x,
                y: e.changedTouches[0].y
            });
            var c = e.timeStamp;
            0 !== u || isNaN(c) || (d = c), isNaN(c) ? h += t + "," + s + "," + p + ",0\n" : h += t + "," + s + "," + p + "," + (c - d) + "\n", 
            u += 1, n.moveTo(i, l), n.lineTo(o, a), n.stroke(), i = o, l = a, n.draw(!0);
        }
    },
    canvasEnd: function(e) {
        m = [], g = !1;
    },
    clear_canvas: e,
    sign_confirm: function() {
        if (0 == u) return wx.showModal({
            title: "提示",
            content: "签名内容不能为空！",
            showCancel: !1
        }), !1;
        s.setData({
            hidden: !1
        }), wx.canvasToTempFilePath({
            canvasId: "anysignCanvas",
            success: function(n) {
                c = n.tempFilePath, w = !1, console.log("getApp", getApp()), console.log("getApp().sigGlobalData.getImageURL", getApp().sigGlobalData.getImageURL), 
                wx.uploadFile({
                    url: getApp().sigGlobalData.getImageURL,
                    filePath: n.tempFilePath,
                    name: "file",
                    formData: {
                        fileName: "CustomerPhoto.jpg",
                        documentCode: "3003",
                        documentName: "客户电子签名照片",
                        materialCode: "24",
                        inferiorFlag: "N",
                        operateType: "C"
                    },
                    header: {
                        "Content-Type": "multipart/form-data",
                        Charset: "utf-8"
                    },
                    success: function(n) {
                        console.log("n", n);
                        var i = n.data, l = JSON.parse(i);
                        console.log("e", l), t && (t(20, "CALLBACK_TYPE_SIGNATURE", c), a(l.imageData, h, u, o.singleWidth, o.singleHeight)), 
                        s.setData({
                            showView: !1,
                            hidden: !0
                        }), e();
                    },
                    fail: function(e) {
                        console.log("n", e), console.log(e.errMsg), w = !0, s.setData({
                            hidden: !0
                        }), wx.showModal({
                            title: "提示",
                            content: "获取图片数据失败！"
                        });
                    },
                    complete: function(e) {
                        console.log(n.errMsg);
                    }
                });
            },
            fail: function(e) {
                console.log(e.errMsg), w = !0, s.setData({
                    hidden: !0
                }), wx.showModal({
                    title: "提示",
                    content: "获取图片数据失败！"
                });
            }
        });
    },
    sign_cancel: function() {
        e(), s.setData({
            showView: !1
        });
    },
    setCallback: function(e) {
        t = e;
    }
};
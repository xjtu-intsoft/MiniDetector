Component({
    properties: {
        hasMoreData: Boolean
    }
});
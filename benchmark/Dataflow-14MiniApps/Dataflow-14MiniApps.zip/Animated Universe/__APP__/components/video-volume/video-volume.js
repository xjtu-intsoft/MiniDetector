Component({
    properties: {
        iconsrc: String
    }
});
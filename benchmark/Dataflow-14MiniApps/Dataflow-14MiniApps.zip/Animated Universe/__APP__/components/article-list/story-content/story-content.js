Component({
    properties: {
        content: String,
        rowCount: Number
    }
});
Component({
    properties: {
        item: Object,
        width: {
            type: Number,
            value: ""
        },
        rowCount: {
            type: Number,
            value: 2
        },
        margins: Object
    }
});
Component({
    properties: {
        item: Object
    }
});
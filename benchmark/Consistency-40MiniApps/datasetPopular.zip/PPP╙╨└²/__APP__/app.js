function e(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e;
}

var t = require("vendor/qcloud-weapp-client-sdk/index.js"), n = (require("utils/util.js"), 
require("utils/commin.js")), i = require("utils/api.js");

App({
    data: {
        channel_id: "",
        scene: "",
        enterprise_code: "",
        enterprise_action: ""
    },
    globalData: {
        userInfo: null,
        version: "1.5.8.0"
    },
    onShow: function(e) {
        var t = e.query.channel_id || 0, n = e.scene, i = e.query.enterprise_code || "", o = e.query.enterprise_action || "";
        this.data.channel_id = t, this.data.scene = n, this.data.enterprise_code = i, this.data.enterprise_action = o;
    },
    onLaunch: function(e) {
        this.getNewVersion(), this.login(e), wx.showShareMenu({
            withShareTicket: !0
        }), i.getList("GET", "user/info", "").then(function(e) {
            var t = n.resExport(e);
            wx.setStorageSync("payTime", t);
        });
    },
    onError: function(t) {
        var n, o = wx.getSystemInfoSync();
        wx.request({
            url: i.getBaseUrl() + "/log/wxapp",
            method: "post",
            data: (n = {
                model: o.model,
                pixelRatio: o.pixelRatio,
                windowWidth: o.windowWidth,
                windowHeight: o.windowHeight,
                language: o.language,
                wxVersion: o.version,
                platform: o.platform,
                msg: t,
                appVersion: this.globalData.version,
                level: "erroe",
                system: o.system
            }, e(n, "platform", o.platform), e(n, "SDKVersion", o.SDKVersion), e(n, "pixelRatio", o.pixelRatio), 
            n),
            header: {
                "content-type": "application/x-www-form-urlencoded",
                "X-Requested-With": "XMLHttpRequest"
            },
            success: function(e) {}
        });
    },
    login: function(e) {
        var n = this;
        t.setLoginUrl(i.getBaseUrl() + "/user/login"), t.login({
            method: "POST",
            success: function(t) {
                console.log("登录成功", t), wx.setStorageSync("userInfo", t);
                var o = n.data;
                setTimeout(function() {
                    n.getInfo(e, o), i.getList("GET", "goods/discount", "").then(function(e) {
                        "000000" == e.data.code ? wx.setStorage({
                            key: "discountTitle",
                            data: e.data.data.title
                        }) : console.log("获取自定义标题失败");
                    });
                }, 1e3);
            },
            fail: function(e) {
                console.log("登录失败", e);
            }
        });
    },
    getInfo: function(e, t) {
        i.getList("GET", "user/info", "").then(function(o) {
            wx.setStorageSync("user_uniq_token", o.data.data.user_uniq_token), wx.setStorageSync("channel_id", o.data.data.channel_id);
            var a = n.resExport(o);
            wx.setStorageSync("payTime", a), wx.getShareInfo({
                shareTicket: e.shareTicket,
                complete: function(n) {
                    if (1044 == e.scene) {
                        var o = {};
                        o.encryptedData = n.encryptedData, o.iv = n.iv, o.userToken = e.query.userToken, 
                        o.scene = e.scene, o.shareTime = e.query.shareTime, t.shareData = JSON.stringify(o);
                    }
                    i.getList("POST", "user/init", t).then(function(e) {
                        console.log(e);
                    });
                }
            });
        });
    },
    getNewVersion: function() {
        if (wx.canIUse("getUpdateManager")) {
            var e = wx.getUpdateManager();
            e.onCheckForUpdate(function(t) {
                t.hasUpdate && (e.onUpdateReady(function() {
                    wx.showModal({
                        title: "更新提示",
                        content: "新版本已经准备好，是否重启应用？",
                        success: function(t) {
                            t.confirm && e.applyUpdate();
                        }
                    });
                }), e.onUpdateFailed(function() {
                    wx.showModal({
                        title: "已经有新版本了哟~",
                        content: "新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~"
                    });
                }));
            });
        }
    }
});
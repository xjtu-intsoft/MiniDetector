require("../../../vendor/qcloud-weapp-client-sdk/index.js");

var n = require("../../../utils/api.js");

require("../../../utils/util.js"), require("../../../utils/commin.js");

Page({
    data: {
        ifLoading: !1,
        url: ""
    },
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {
        var i = this;
        n.getList("GET", "enterprises/qrcode", "").then(function(n) {
            i.setData({
                url: n.data.data.url,
                ifLoading: !0
            });
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
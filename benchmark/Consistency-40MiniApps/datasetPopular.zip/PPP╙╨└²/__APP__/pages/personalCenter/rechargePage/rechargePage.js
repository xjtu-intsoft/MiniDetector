require("../../../vendor/qcloud-weapp-client-sdk/index.js");

var e = require("../../../utils/api.js"), a = require("../../../utils/commin.js");

require("../../../utils/util.js"), getApp();

Page({
    data: {
        motto: "Hello World",
        userInfo: {},
        prices: [],
        total: null,
        selectCode: 0,
        payData: 0,
        useSection: "",
        ifLoading: !0,
        isDisable: !0,
        skipPage: "",
        isMealLoad: !1,
        isIOS: !1,
        ifGroup: !1,
        adValue: [],
        adInfoTitle: [],
        showAdInfo: !1
    },
    onShow: function() {
        var t = {
            page: "pages/personalCenter/rechargePage/rechargePage",
            des: "付费"
        };
        a.pageMonitoring(e, t), this.getAdInfoTitle(), this.getAdInfo();
    },
    onLoad: function(e) {
        var a = this;
        a.setData({
            userInfo: wx.getStorageSync("userInfo"),
            skipPage: e.skipPage
        }), a.payNews();
    },
    payNews: function() {
        var t = this;
        wx.getSystemInfo({
            success: function(i) {
                "ios" == i.platform ? t.setData({
                    prices: [],
                    isMealLoad: !0,
                    isIOS: !0
                }) : (t.setData({
                    isIOS: !1
                }), e.getList("GET", "goods/list", "").then(function(i) {
                    var s = i.data.data;
                    wx.getStorage({
                        key: "payTime",
                        success: function(a) {
                            var i = a.data;
                            e.getList("GET", "server/unixtime", "").then(function(e) {
                                var a = e.data.data.time, n = i - a, o = Math.floor(n / 86400);
                                t.timeJudge(t, o, s);
                            });
                        },
                        fail: function() {
                            e.getList("GET", "user/info", "").then(function(i) {
                                var n = a.resExport(i), o = n;
                                wx.setStorageSync("payTime", n), e.getList("GET", "server/unixtime", "").then(function(e) {
                                    var a = e.data.data.time, i = o - a, n = Math.floor(i / 86400);
                                    t.timeJudge(t, n, s);
                                });
                            });
                        }
                    });
                }));
            }
        });
    },
    timeJudge: function(e, a, t) {
        if (a <= 0) e.setData({
            prices: t,
            isMealLoad: !0,
            ifGroup: !0,
            isIOS: !1
        }); else {
            if (a > 690) for (var i = 0; i < 3; i++) t[i].disabled = !0; else 630 < a && a <= 690 ? (t[0].disabled = !0, 
            t[1].disabled = !0) : 360 < a && a <= 630 && (t[0].disabled = !0);
            e.setData({
                prices: t,
                isMealLoad: !0,
                ifGroup: !0
            });
        }
    },
    payExplain: function(e) {
        for (var a = this, t = (e.currentTarget.dataset.item.price, e.currentTarget.dataset.item), i = t.code, s = a.data.prices, n = 0; n < s.length; n++) s[n].id == t.id ? (s[n].checked = !0, 
        a.setData({
            payData: s[n].pay_price / 100,
            useSection: s[n].name
        })) : s[n].checked = !1;
        a.setData({
            prices: s,
            selectCode: i,
            isDisable: !1
        });
    },
    chargeAgreement: function() {
        wx.navigateTo({
            url: "/pages/personalCenter/serviceAgreement/serviceAgreement"
        });
    },
    groupPay: function() {
        wx.navigateTo({
            url: "/pages/personalCenter/groupPay/groupPay"
        });
    },
    rechargeBtn: function() {
        var t = this, i = {
            goods_code: t.data.selectCode
        };
        t.setData({
            ifLoading: !1
        }), e.getList("POST", "orders/create", i).then(function(i) {
            if (t.setData({
                ifLoading: !0
            }), "000000" == i.data.code) {
                var s = i.data.data;
                s.isPay && wx.requestPayment({
                    appId: s.config.appId,
                    timeStamp: s.config.timestamp,
                    nonceStr: s.config.nonceStr,
                    package: s.config.package,
                    signType: s.config.signType,
                    paySign: s.config.paySign,
                    success: function(i) {
                        wx.showToast({
                            title: "开通成功",
                            icon: "success",
                            duration: 2e3
                        }), wx.removeStorage({
                            key: "hintTime",
                            success: function(e) {
                                console.log("成功移除payDateTime");
                            }
                        }), e.getList("GET", "user/info", "").then(function(e) {
                            var t = a.resExport(e);
                            wx.setStorageSync("payTime", t), console.log("已存储payTime");
                        }), "search" == t.data.skipPage ? setTimeout(function() {
                            wx.navigateTo({
                                url: "/pages/project/" + t.data.skipPage + "/" + t.data.skipPage
                            });
                        }, 1500) : setTimeout(function() {
                            wx.switchTab({
                                url: "/pages/" + t.data.skipPage + "/" + t.data.skipPage
                            });
                        }, 1500);
                    },
                    fail: function(e) {
                        console.log("fail");
                    }
                });
            }
        });
    },
    getAdInfo: function() {
        var a = this, t = {
            key: "5be02e8898484"
        };
        e.getList("GET", "ad/position", t).then(function(e) {
            if ("000000" == e.data.code) {
                var t = e.data.data.startTime, i = e.data.data.endTime, s = Date.parse(new Date()) / 1e3;
                if (t <= s && s <= i) {
                    if ("text" === e.data.data.content.type) {
                        var n = e.data.data.content.value;
                        a.setData({
                            adValue: n,
                            showAdInfo: !0
                        });
                    }
                } else a.setData({
                    adValue: [],
                    showAdInfo: !1
                });
            }
        });
    },
    getAdInfoTitle: function() {
        var a = this, t = {
            key: "5be15a3b5933b"
        };
        e.getList("GET", "ad/position", t).then(function(e) {
            if ("000000" == e.data.code) {
                var t = e.data.data.content.value;
                a.setData({
                    adInfoTitle: t
                });
            }
        });
    }
});
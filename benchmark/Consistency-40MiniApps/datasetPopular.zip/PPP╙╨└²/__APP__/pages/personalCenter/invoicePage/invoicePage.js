require("../../../vendor/qcloud-weapp-client-sdk/index.js");

var e = require("../../../utils/api.js"), t = require("../../../utils/commin.js");

getApp();

Page({
    data: {
        isInvoice: !0,
        selectedAllStatus: !1,
        invoice: 0,
        invoices: [],
        noInvoice: [],
        total: 0,
        num: 0,
        invoiceId: [],
        isLoading: !0,
        isAlreadyLoading: !1,
        ifNull: !1,
        ifAlreadyNull: !1
    },
    onShow: function() {
        var a = {
            page: "pages/personalCenter/invoicePage/invoicePage",
            des: "发票列表"
        };
        t.pageMonitoring(e, a);
    },
    onLoad: function() {
        var t = this, a = t.data.invoices, i = {
            invoice: 1
        };
        e.getList("GET", "orders/list", i).then(function(e) {
            0 == e.data.data.length && t.setData({
                ifAlreadyNull: !0
            });
            for (var i = e.data.data, n = 0; n < i.length; n++) "已支付" == i[n].order_status.name && a.push(i[n]);
            t.setData({
                invoices: a,
                isAlreadyLoading: !0
            });
        });
    },
    invoiceNew: function(t) {
        var a = this, i = this, n = t.currentTarget.dataset.isinvoice;
        i.data.noInvoice;
        if (i.setData({
            total: 0
        }), "true" == n) {
            s = {
                invoice: 1
            };
            i.setData({
                isInvoice: !0,
                isAlreadyLoading: !1,
                ifAlreadyNull: !1
            }), e.getList("GET", "orders/list", s).then(function(e) {
                0 == e.data.data.length && a.setData({
                    ifNull: !0,
                    ifAlreadyNull: !0
                }), i.setData({
                    isAlreadyLoading: !0,
                    invoices: e.data.data
                });
            });
        } else {
            var s = {
                invoice: 0
            };
            i.setData({
                isInvoice: !1,
                isLoading: !1,
                ifNull: !1
            }), e.getList("GET", "orders/list", s).then(function(e) {
                var t = e.data.data, n = [];
                0 == t.length && a.setData({
                    ifNull: !0,
                    ifAlreadyNull: !0
                });
                for (var s = 0; s < t.length; s++) "已支付" == t[s].order_status.name && (t[s].selected = !1, 
                0 != t[s].pay_price && n.push(t[s]));
                i.setData({
                    noInvoice: n,
                    num: 0,
                    selectedAllStatus: !1,
                    isLoading: !0,
                    isAlreadyLoading: !0
                });
            });
        }
    },
    bindCheckbox: function(e) {
        var t = this, a = parseInt(e.currentTarget.dataset.index), i = t.data.noInvoice, n = t.data.total, s = t.data.selectedAllStatus, o = t.data.num;
        1 == i[a].selected ? (i[a].selected = !1, n -= i[a].pay_price, o -= 1, s = !1) : (i[a].selected = !0, 
        n += i[a].pay_price, o += 1), t.setData({
            noInvoice: i,
            total: n,
            num: o,
            selectedAllStatus: s
        }), this.data.noInvoice.length == this.data.num && this.setData({
            selectedAllStatus: !0
        });
    },
    bindSelectAll: function() {
        var e = this, t = e.data.selectedAllStatus, a = 0, i = 0;
        t = !t;
        var n = e.data.noInvoice;
        if (t) {
            for (s = 0; s < n.length; s++) n[s].selected = t, a += n[s].pay_price;
            i = n.length;
        } else {
            for (var s = 0; s < n.length; s++) n[s].selected = t;
            a = 0, i = 0;
        }
        e.setData({
            selectedAllStatus: t,
            noInvoice: n,
            total: a,
            num: i
        });
    },
    bindCheckout: function() {
        var e = this.data.total, t = this.data.noInvoice, a = this.data.invoiceId;
        if (0 != this.data.num) if (0 != e) {
            for (var i = 0; i < t.length; i++) t[i].selected && a.push(t[i].id);
            if (a.length > 0) {
                var n = {
                    url: "/pages/personalCenter/invoicetypePage/invoicetypePage?total=" + e + "&&invoiceId=" + a
                };
                wx.redirectTo(n);
            } else wx.showModal({
                title: "提示",
                content: "请选择需要开发票的订单",
                showCancel: !1,
                success: function(e) {
                    e.confirm && console.log("用户点击确定");
                }
            });
        } else wx.showModal({
            title: "提示",
            content: "所选订单金额为0",
            showCancel: !1,
            success: function(e) {
                e.confirm && console.log("用户点击确定");
            }
        }); else wx.showModal({
            title: "提示",
            content: "请选择需要开发票的订单",
            showCancel: !1,
            success: function(e) {
                e.confirm && console.log("用户点击确定");
            }
        });
    }
});
require("../../../vendor/qcloud-weapp-client-sdk/index.js");

var e = require("../../../utils/api.js");

Page({
    data: {
        isNew: !0,
        addUserNum: 0,
        isRenew: !0,
        renewUserNum: 2,
        groupInfo: "",
        renewInfo: "",
        ifAddUser: !0,
        ifRenew: !0,
        presentAlreadyUser: 0,
        pay_price: 0,
        reNewPay_price: 0,
        goodsCode: "",
        renewGoodsCode: "",
        isPayLoading: !0,
        renewDisabled: !0
    },
    opened: function() {
        var a = this;
        if (!this.data.isNew) {
            var t = this, n = t.data.presentAlreadyUser;
            t.setData({
                ifRenew: !1
            }), n > 0 && t.setData({
                addUserNum: 1
            }), e.getList("GET", "goods/e_list", "").then(function(e) {
                var n = e.data.data, i = a.data.addUserNum * n[0].pay_price / 100;
                t.setData({
                    groupInfo: n,
                    pay_price: i,
                    goodsCode: n[0].code,
                    isNew: !0,
                    ifRenew: !0
                });
            });
        }
    },
    notOpened: function() {
        var a = this;
        if (this.data.isNew) {
            if (this.data.presentAlreadyUser <= 0) t = !0; else var t = !1;
            this.setData({
                ifAddUser: !0,
                renewDisabled: t
            }), e.getList("GET", "goods/renew_list", "").then(function(e) {
                var t = e.data.data, n = a.data.renewUserNum * t[0].pay_price / 100;
                a.setData({
                    renewInfo: t,
                    isNew: !1,
                    ifAddUser: !1,
                    renewGoodsCode: e.data.data[0].code,
                    reNewPay_price: n
                });
            });
        }
    },
    userMinus: function() {
        var e = this.data.addUserNum, a = this.data.presentAlreadyUser, t = this.data.groupInfo;
        e--, 0 == a && e <= 2 ? e = 2 : e < 1 && (e = 1);
        var n = e * t[0].pay_price / 100;
        this.setData({
            addUserNum: e,
            pay_price: n
        });
    },
    userAdd: function() {
        var e = this.data.addUserNum, a = ++e * this.data.groupInfo[0].pay_price / 100;
        this.setData({
            addUserNum: e,
            pay_price: a
        });
    },
    rechargeBtn: function(a) {
        var t = this;
        t.setData({
            isPayLoading: !1
        });
        var n = a.detail.value;
        e.getList("POST", "orders/create", n).then(function(a) {
            if (t.setData({
                isPayLoading: !0
            }), "000000" == a.data.code) {
                var n = a.data.data;
                n.isPay && wx.requestPayment({
                    appId: n.config.appId,
                    timeStamp: n.config.timestamp,
                    nonceStr: n.config.nonceStr,
                    package: n.config.package,
                    signType: n.config.signType,
                    paySign: n.config.paySign,
                    success: function(a) {
                        wx.showToast({
                            title: "开通成功",
                            icon: "success",
                            duration: 2e3
                        }), wx.removeStorage({
                            key: "hintTime",
                            success: function(e) {
                                console.log("成功移除payDateTime");
                            }
                        }), e.getList("GET", "user/info", "").then(function(e) {
                            var a = Commin.resExport(e);
                            wx.setStorageSync("payTime", a), console.log("已存储payTime");
                        }), setTimeout(function() {
                            wx.navigateBack({
                                delta: 1
                            });
                        }, 1500);
                    },
                    fail: function(e) {
                        console.log("fail");
                    }
                });
            }
        });
    },
    renewUserMinus: function() {
        var e = this.data.renewUserNum, a = this.data.renewInfo;
        --e <= 2 && (e = 2);
        var t = e * a[0].pay_price / 100;
        this.setData({
            renewUserNum: e,
            reNewPay_price: t
        });
    },
    renewUserAdd: function() {
        var e = this.data.renewUserNum, a = this.data.renewInfo;
        ++e >= this.data.presentAlreadyUser && (e = this.data.presentAlreadyUser);
        var t = e * a[0].pay_price / 100;
        this.setData({
            renewUserNum: e,
            reNewPay_price: t
        });
    },
    renewPay: function(a) {
        var t = this;
        t.setData({
            isPayLoading: !1
        });
        var n = a.detail.value;
        e.getList("POST", "orders/create", n).then(function(a) {
            if (t.setData({
                isPayLoading: !0
            }), "000000" == a.data.code) {
                var n = a.data.data;
                n.isPay && wx.requestPayment({
                    appId: n.config.appId,
                    timeStamp: n.config.timestamp,
                    nonceStr: n.config.nonceStr,
                    package: n.config.package,
                    signType: n.config.signType,
                    paySign: n.config.paySign,
                    success: function(a) {
                        console.log("success"), wx.showToast({
                            title: "续费成功",
                            icon: "success",
                            duration: 2e3
                        }), wx.removeStorage({
                            key: "hintTime",
                            success: function(e) {
                                console.log("成功移除payDateTime");
                            }
                        }), e.getList("GET", "user/info", "").then(function(e) {
                            var a = Commin.resExport(e);
                            wx.setStorageSync("payTime", a), console.log("已存储payTime");
                        }), setTimeout(function() {
                            wx.navigateBack({
                                delta: 1
                            });
                        }, 1500);
                    },
                    fail: function(e) {
                        console.log("fail");
                    }
                });
            }
        });
    },
    chargeAgreement: function() {
        var e = {
            url: "/pages/personalCenter/serviceAgreement/serviceAgreement"
        };
        wx.navigateTo(e);
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {
        var a = this, t = this;
        e.getList("GET", "enterprises/use_info", "").then(function(e) {
            var a = e.data.data.useInfo.totalUserAmount;
            a > 0 ? t.setData({
                addUserNum: 1
            }) : t.setData({
                addUserNum: 2
            }), t.setData({
                presentAlreadyUser: a,
                renewUserNum: a
            });
        }).then(function(n) {
            e.getList("GET", "goods/e_list", "").then(function(e) {
                var n = e.data.data, i = a.data.addUserNum * n[0].pay_price / 100;
                t.setData({
                    groupInfo: n,
                    ifAddUser: !1,
                    pay_price: i,
                    goodsCode: n[0].code
                });
            });
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
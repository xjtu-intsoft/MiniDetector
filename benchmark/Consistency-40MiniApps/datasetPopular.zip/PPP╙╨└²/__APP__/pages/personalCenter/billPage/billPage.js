require("../../../vendor/qcloud-weapp-client-sdk/index.js");

var i = require("../../../utils/commin.js"), e = require("../../../utils/api.js");

getApp();

Page({
    data: {
        newsList: [],
        isLoading: !1,
        isBill: !1
    },
    onShow: function() {
        var a = {
            page: "pages/personalCenter/billPage/billPage",
            des: "订单"
        };
        i.pageMonitoring(e, a);
    },
    onLoad: function(i) {
        var a = this, t = this;
        e.getList("GET", "orders/list", "").then(function(i) {
            var e = i.data.data;
            0 == e.length && a.setData({
                isBill: !0
            }), t.setData({
                newsList: e,
                isLoading: !0
            });
        });
    },
    navigateTo: function() {
        wx.navigateBack();
    }
});
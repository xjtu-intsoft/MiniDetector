require("../../../vendor/qcloud-weapp-client-sdk/index.js");

var n = require("../../../utils/api.js");

require("../../../utils/util.js"), require("../../../utils/commin.js");

Page({
    data: {},
    userSet: function() {
        wx.navigateTo({
            url: "/pages/personalCenter/userSet/userSet"
        });
    },
    invite: function() {
        n.getList("GET", "user/info", "").then(function(n) {
            "000000" == n.data.code && (n.data.data.is_enterprise_admin ? wx.navigateTo({
                url: "/pages/personalCenter/companyInvite/companyInvite"
            }) : wx.showModal({
                title: "提示",
                content: "您不是企业管理员,无法查看企业用户邀请码!",
                showCancel: !1,
                success: function(n) {
                    n.confirm && console.log("用户点击确定");
                }
            }));
        });
    },
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
var e = require("../../../utils/api.js"), t = require("../../../utils/commin.js");

Page({
    data: {
        title: "",
        wordNum: "200"
    },
    onShow: function() {
        var n = {
            page: "pages/personalCenter/feedbackAdvice/feedbackAdvice",
            des: "意见反馈"
        };
        t.pageMonitoring(e, n);
    },
    onLoad: function(e) {
        var t = e.title;
        this.setData({
            title: t
        });
    },
    residueNum: function(e) {
        var t = "";
        t = 200 - (e.detail.value.length || 0), this.setData({
            wordNum: t
        });
    },
    bindFormSubmit: function(t) {
        var n = t.detail.value;
        "" != n.feedback ? (wx.showToast({
            title: "正在提交",
            icon: "loading"
        }), e.getList("POST", "user/feedback", n).then(function(e) {
            wx.hideLoading(), wx.showModal({
                title: "提示",
                content: "感谢您的支持与反馈！",
                showCancel: !1,
                success: function(e) {
                    e.confirm && wx.switchTab({
                        url: "/pages/personalCenterHome/personalCenterHome"
                    });
                }
            });
        })) : wx.showToast({
            title: "未填写意见",
            icon: "success",
            duration: 1500
        });
    },
    onReady: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
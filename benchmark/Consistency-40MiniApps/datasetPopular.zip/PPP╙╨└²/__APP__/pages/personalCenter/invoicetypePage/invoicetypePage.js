require("../../../vendor/qcloud-weapp-client-sdk/index.js");

var e = require("../../../utils/api.js"), t = require("../../../utils/commin.js");

getApp();

Page({
    data: {
        total: 0,
        order: [],
        invoiceType: 1,
        title: "",
        email: "",
        toastHidden: !0,
        isPerson: !1,
        isGeneral: !0,
        isLoading: !0
    },
    onShow: function() {
        var i = {
            page: "pages/personalCenter/invoiceTypePage/invoiceTypePage",
            des: "发票索取"
        };
        t.pageMonitoring(e, i);
    },
    onLoad: function(e) {
        this.setData({
            total: e.total,
            order: e.invoiceId
        });
    },
    formSubmit: function(t) {
        var i = this, a = (t.detail.value.order, t.detail.value.invoiceType, t.detail.value.title), o = t.detail.value.taxpayerIdNumber, n = t.detail.value.email, s = t.detail.value.address, l = t.detail.value.tel, c = t.detail.value.openAccountBank, d = t.detail.value.accountNumber, r = t.detail.value.consigneeAddress, u = t.detail.value.recipients, w = t.detail.value.phone;
        if ("" != a) if ("" != o) {
            if (void 0 !== n) {
                if ("" == n) return void wx.showModal({
                    title: "提示",
                    content: "电子邮件为空",
                    showCancel: !1
                });
                if (!/^([0-9A-Za-z\-_\.]+)@([0-9a-z]+\.[a-z]{2,3}(\.[a-z]{2})?)$/g.test(n)) return void wx.showModal({
                    title: "提示",
                    content: "电子邮件格式不正确,请重新输入",
                    showCancel: !1
                });
            }
            if (void 0 === s || "" != s) if (void 0 === l || "" != l) if (void 0 === c || "" != c) if (void 0 === d || "" != d) if (void 0 === r || "" != r) if (void 0 === u || "" != u) if (void 0 === w || "" != w) {
                this.setData({
                    isLoading: !1
                });
                var v = t.detail.value;
                e.getList("POST", "invoice/create", v).then(function(e) {
                    "100201" != e.data.code ? (i.setData({
                        isLoading: !0
                    }), wx.showToast({
                        title: "提交成功",
                        icon: "success",
                        duration: 2e3,
                        success: function() {
                            setTimeout(function() {
                                wx.redirectTo({
                                    url: "/pages/personalCenter/invoicePage/invoicePage"
                                });
                            }, 1500);
                        }
                    })) : wx.showModal({
                        title: "提示",
                        showCancel: !1,
                        content: "所选订单金额为0",
                        success: function(e) {
                            e.confirm && wx.redirectTo({
                                url: "/pages/personalCenter/invoicePage/invoicePage"
                            });
                        }
                    });
                });
            } else wx.showModal({
                title: "提示",
                content: "手机号为空",
                showCancel: !1
            }); else wx.showModal({
                title: "提示",
                content: "收件人为空",
                showCancel: !1
            }); else wx.showModal({
                title: "提示",
                content: "快递地址为空",
                showCancel: !1
            }); else wx.showModal({
                title: "提示",
                content: "开户行账号为空",
                showCancel: !1
            }); else wx.showModal({
                title: "提示",
                content: "开户行为空",
                showCancel: !1
            }); else wx.showModal({
                title: "提示",
                content: "电话为空",
                showCancel: !1
            }); else wx.showModal({
                title: "提示",
                content: "地址为空",
                showCancel: !1
            });
        } else wx.showModal({
            title: "提示",
            content: "纳税人识别号为空",
            showCancel: !1
        }); else wx.showModal({
            title: "提示",
            content: "发票抬头为空",
            showCancel: !1
        });
    },
    radioChange: function(e) {
        1 == e.detail.value ? this.setData({
            isPerson: !1
        }) : this.setData({
            isPerson: !0
        });
    },
    radioTitleChange: function(e) {
        3 == e.detail.value ? this.setData({
            isGeneral: !1,
            isPerson: !0
        }) : this.setData({
            isGeneral: !0,
            isPerson: !1
        });
    }
});
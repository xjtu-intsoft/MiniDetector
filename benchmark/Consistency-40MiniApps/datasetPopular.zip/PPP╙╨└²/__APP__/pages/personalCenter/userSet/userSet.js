require("../../../vendor/qcloud-weapp-client-sdk/index.js");

var e = require("../../../utils/api.js"), t = require("../../../utils/util.js");

require("../../../utils/commin.js");

Page({
    data: {
        isSet: !1,
        alreadyOpenedData: [],
        notOpenedData: [],
        openAllSelect: !1,
        notOpenAllSelect: !1,
        openSelsectData: [],
        notOpenSelsectData: [],
        isRenew: !1,
        scrollViewHeight: 910,
        hintHight: 78,
        ifLoading: !1,
        ifOpenLoading: !0,
        ifNotOpenDisable: !0,
        ifOpenDisable: !0,
        notOpenLoading: !0,
        openLoading: !0,
        buyUserNum: 0,
        bindNum: 0,
        unBindNum: 0,
        currentTime: "",
        renewNum: 0,
        renewDate: "",
        stickDisable: !1,
        delOpenLoading: !0
    },
    stick: function(t) {
        var n = this, a = t.target.dataset.index, s = n.data.alreadyOpenedData, i = s[a];
        s.splice(a, 1), s.unshift(i), n.setData({
            stickDisable: !0
        });
        for (var o = [], l = 0; l < s.length; l++) o.unshift({
            userToken: s[l].userToken
        });
        o = JSON.stringify(o), e.getList("POST", "enterprises/sort_users", {
            userList: o
        }).then(function(e) {
            n.open(n);
        });
    },
    opened: function() {
        if (!this.data.isSet) {
            var e = this;
            e.setData({
                isSet: !0,
                ifOpenLoading: !1,
                openAllSelect: !1
            }), e.open(e);
        }
    },
    notOpened: function() {
        if (this.data.isSet) {
            var e = this;
            e.setData({
                isSet: !1,
                ifLoading: !1,
                notOpenAllSelect: !1
            }), e.notOpen(e);
        }
    },
    openSelect: function(e) {
        var t = e.currentTarget.dataset.index, n = e.currentTarget.dataset.id, a = this.data.alreadyOpenedData, s = this.data.openSelsectData;
        if (a[t].select) {
            a[t].select = !1;
            t = s.indexOf(n);
            s.splice(t, 1);
            for (var i = !0, o = 0; o < a.length; o++) a[o].select && (i = !1);
            this.setData({
                ifOpenDisable: i,
                openAllSelect: !1,
                alreadyOpenedData: a,
                openSelsectData: s
            });
        } else {
            a[t].select = !0, s.push(n);
            for (var l = !0, o = 0; o < a.length; o++) a[o].select || (l = !1);
            this.setData({
                ifOpenDisable: !1,
                openAllSelect: l,
                alreadyOpenedData: a,
                openSelsectData: s
            });
        }
    },
    stopUse: function(t) {
        var n = this;
        n.setData({
            openLoading: !1
        }), e.getList("POST", "enterprises/unbind_user", t.detail.value).then(function(e) {
            "000000" == e.data.code && (n.setData({
                openLoading: !0,
                openAllSelect: !1,
                ifOpenDisable: !0
            }), wx.showToast({
                title: "取消成功",
                icon: "success",
                duration: 1500,
                success: function() {
                    n.open(n);
                }
            }));
        });
    },
    openAllSelect: function() {
        var e = this.data.alreadyOpenedData, t = this.data.openSelsectData;
        if (!(e.length <= 0)) if (this.data.openAllSelect) {
            for (n = 0; n < e.length; n++) e[n].select = !1;
            this.setData({
                ifOpenDisable: !0,
                openAllSelect: !1,
                alreadyOpenedData: e,
                openSelsectData: []
            });
        } else {
            for (var n = 0; n < e.length; n++) {
                e[n].select = !0;
                var a = e[n].userToken;
                -1 == t.indexOf(a) && t.push(a);
            }
            this.setData({
                ifOpenDisable: !1,
                openAllSelect: !0,
                alreadyOpenedData: e,
                openSelsectData: t
            });
        }
    },
    notOpenSelect: function(e) {
        var t = e.currentTarget.dataset.index, n = e.currentTarget.dataset.id, a = this.data.notOpenedData, s = this.data.notOpenSelsectData;
        if (a[t].select) {
            a[t].select = !1;
            t = s.indexOf(n);
            s.splice(t, 1);
            for (var i = !0, o = 0; o < a.length; o++) a[o].select && (i = !1);
            this.setData({
                ifNotOpenDisable: i,
                notOpenAllSelect: !1,
                notOpenedData: a,
                notOpenSelsectData: s
            });
        } else {
            a[t].select = !0, s.push(n);
            for (var l = !0, o = 0; o < a.length; o++) a[o].select || (l = !1);
            this.setData({
                ifNotOpenDisable: !1,
                notOpenAllSelect: l,
                notOpenedData: a,
                notOpenSelsectData: s
            });
        }
    },
    delUesr: function() {
        var t = this, n = t.data.notOpenSelsectData;
        t.data.unBindNum;
        wx.showModal({
            title: "提示",
            content: "您确定删除已选中用户吗?",
            success: function(a) {
                a.confirm && (t.setData({
                    delOpenLoading: !1
                }), n = n.join(","), e.getList("POST", "enterprises/remove_user", {
                    userToken: n
                }).then(function(e) {
                    "000000" == e.data.code && (t.setData({
                        delOpenLoading: !0,
                        ifNotOpenDisable: !0,
                        notOpenAllSelect: !1
                    }), wx.showToast({
                        title: "删除成功",
                        icon: "success",
                        duration: 1500,
                        success: function() {
                            t.notOpen(t), t.open(t);
                        }
                    }));
                }));
            }
        });
    },
    startUse: function() {
        var t = this, n = t.data.notOpenSelsectData, a = t.data.unBindNum;
        return t.setData({
            notOpenLoading: !1
        }), 0 == a ? (t.setData({
            notOpenLoading: !0
        }), void wx.showModal({
            title: "提示",
            content: "您购买的用户数已达到最大关联数!",
            showCancel: !1,
            success: function(e) {
                e.confirm && console.log("用户点击确定");
            }
        })) : a < n.length ? (t.setData({
            notOpenLoading: !0
        }), void wx.showModal({
            title: "提示",
            content: "您选中的开通用户数已超过最大关联数!",
            showCancel: !1,
            success: function(e) {
                e.confirm && console.log("用户点击确定");
            }
        })) : (n = n.join(","), void e.getList("POST", "enterprises/bind_user", {
            userToken: n
        }).then(function(e) {
            "000000" == e.data.code && (t.setData({
                notOpenLoading: !0,
                ifNotOpenDisable: !0,
                notOpenAllSelect: !1
            }), wx.showToast({
                title: "开通成功",
                icon: "success",
                duration: 1500,
                success: function() {
                    t.notOpen(t), t.open(t);
                }
            })), "100204" == e.data.code && (t.setData({
                notOpenLoading: !0,
                ifNotOpenDisable: !0,
                notOpenAllSelect: !1
            }), wx.showModal({
                title: "提示",
                content: e.data.msg,
                showCancel: !1,
                success: function(e) {
                    e.confirm && console.log("用户点击确定");
                }
            }));
        }));
    },
    notOpenAllSelect: function() {
        var e = this.data.notOpenedData, t = this.data.notOpenSelsectData;
        if (!(void 0 == e || e.length <= 0)) if (this.data.notOpenAllSelect) {
            for (n = 0; n < e.length; n++) e[n].select = !1;
            this.setData({
                ifNotOpenDisable: !0,
                notOpenAllSelect: !1,
                notOpenedData: e,
                notOpenSelsectData: []
            });
        } else {
            for (var n = 0; n < e.length; n++) {
                e[n].select = !0;
                var a = e[n].userToken;
                -1 == t.indexOf(a) && t.push(a);
            }
            this.setData({
                ifNotOpenDisable: !1,
                notOpenAllSelect: !0,
                notOpenedData: e,
                notOpenSelsectData: t
            });
        }
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {
        var e = this;
        e.notOpen(e), e.open(e);
    },
    notOpen: function(t) {
        e.getList("GET", "enterprises/user", {
            is_bind: 0
        }).then(function(e) {
            t.setData({
                notOpenedData: e.data.data.userList,
                ifLoading: !0,
                openSelsectData: [],
                notOpenSelsectData: []
            });
        });
    },
    open: function(n) {
        e.getList("GET", "enterprises/user", {
            is_bind: 1
        }).then(function(e) {
            if ("000000" == e.data.code) {
                e.data.data.useInfo.future.length > 0 && (n.setData({
                    isRenew: !0,
                    renewNum: e.data.data.useInfo.future[0].totalUsers,
                    currentTime: t.secondToDate(new Date(1e3 * e.data.data.useInfo.expires_time)),
                    renewDate: t.secondToDate(new Date(1e3 * e.data.data.useInfo.future[0].expires_time))
                }), new Date().getTime() > 1e3 * e.data.data.useInfo.future[0].expires_time && n.setData({
                    isRenew: !1
                }));
                for (var a = 0; a < e.data.data.userList.length; a++) {
                    var s = e.data.data.userList[a].enterpriseMemberExpires;
                    e.data.data.userList[a].memberExpires = t.secondToDate(new Date(1e3 * s));
                }
                n.data.isRenew ? n.setData({
                    scrollViewHeight: 810,
                    hintHight: 158
                }) : n.setData({
                    scrollViewHeight: 910,
                    hintHight: 78
                }), n.setData({
                    alreadyOpenedData: e.data.data.userList,
                    ifOpenLoading: !0,
                    buyUserNum: e.data.data.useInfo.totalUserAmount,
                    bindNum: e.data.data.useInfo.bindUserAmount,
                    unBindNum: e.data.data.useInfo.unBindUserAmount,
                    openSelsectData: [],
                    notOpenSelsectData: [],
                    stickDisable: !1
                });
            } else n.setData({
                ifOpenLoading: !0
            });
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
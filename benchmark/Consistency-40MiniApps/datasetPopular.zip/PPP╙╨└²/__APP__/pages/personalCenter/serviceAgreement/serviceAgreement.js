var n = require("../../../utils/api.js"), e = require("../../../utils/commin.js");

Page({
    data: {},
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {
        var o = {
            page: "pages/personalCenter/serviceAgreement/serviceAgreement",
            des: "服务条款"
        };
        e.pageMonitoring(n, o);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
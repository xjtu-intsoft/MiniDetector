var e = require("../../utils/api.js"), t = require("../../vendor/qcloud-weapp-client-sdk/index.js"), a = require("../../utils/commin.js"), n = require("../../utils/util.js");

getApp();

Page({
    data: {
        motto: "Hello World",
        userInfo: {},
        canIUseGetUserProfile: !1,
        expireTime: "****-**-**",
        isPayMember: !1,
        imageIcon: "",
        imageContent: "",
        startTime: "",
        endTime: "",
        showImage: !1,
        showLogBtn: !0
    },
    onLoad: function(e) {
        var t = this;
        wx.getStorage({
            key: "show_useinfo",
            success: function(e) {
                console.log(e.data), !1 === e.data && t.setData({
                    userInfo: null
                });
            },
            fail: function(e) {
                t.setData({
                    userInfo: wx.getStorageSync("userInfo")
                });
            }
        });
    },
    onShow: function() {
        var t = this;
        wx.getStorage({
            key: "show_useinfo",
            success: function(e) {
                console.log(e.data), !1 === e.data && t.setData({
                    userInfo: null
                });
            },
            fail: function(e) {
                t.setData({
                    userInfo: wx.getStorageSync("userInfo")
                });
            }
        }), wx.removeStorageSync("show_useinfo");
        this.getImage(), this.getUserPayInfo();
        var n = {
            page: "pages/personalCenterHome/personalCenterHome",
            des: "个人中心"
        };
        a.pageMonitoring(e, n);
    },
    getUserProfile: function(e) {
        var a = this;
        wx.getUserProfile({
            desc: "用于完善会员资料",
            success: function(e) {
                t.setUserInfos(e), a.setData({
                    loadHidden: !1
                }), a.login();
            }
        });
    },
    getUserPayInfo: function() {
        var t = this;
        e.getList("GET", "user/info", "").then(function(e) {
            var o = a.resExport(e), i = 1e3 * o;
            0 != i ? (console.log("获取付费时间"), expireTime = n.secondToDate(new Date(i)), t.setData({
                expireTime: expireTime,
                isPayMember: !0
            }), a.memberDateHint(o, n)) : console.log("未付费");
        });
    },
    recharge: function() {
        void 0 === this.data.userInfo.nickName ? (wx.showLoading({
            title: "请登录后再查看"
        }), setTimeout(function() {
            wx.hideLoading();
        }, 2e3)) : wx.getStorage({
            key: "isBindPhone",
            complete: function(t) {
                if (t.data || "") console.log("有缓存"), wx.navigateTo({
                    url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=personalCenterHome"
                }); else {
                    console.log("没缓存");
                    e.getList("GET", "user/isBindPhone", "").then(function(e) {
                        wx.setStorage({
                            key: "isBindPhone",
                            data: e.data.data.bindStatus
                        }), e.data.data.bindStatus ? wx.navigateTo({
                            url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=personalCenterHome"
                        }) : wx.navigateTo({
                            url: "/pages/personalCenter/personalPage/personalPage?skipPage=personalCenterHome"
                        });
                    });
                }
            }
        });
    },
    bill: function() {
        void 0 === this.data.userInfo.nickName ? (wx.showLoading({
            title: "请登录后再查看"
        }), setTimeout(function() {
            wx.hideLoading();
        }, 2e3)) : wx.navigateTo({
            url: "/pages/personalCenter/billPage/billPage"
        });
    },
    setpage: function() {
        wx.navigateTo({
            url: "/pages/personalCenter/setPage/setPage"
        });
    },
    invoice: function() {
        void 0 === this.data.userInfo.nickName ? (wx.showLoading({
            title: "请登录后再查看"
        }), setTimeout(function() {
            wx.hideLoading();
        }, 2e3)) : wx.navigateTo({
            url: "/pages/personalCenter/invoicePage/invoicePage"
        });
    },
    advicePage: function() {
        wx.navigateTo({
            url: "/pages/personalCenter/feedbackAdvice/feedbackAdvice?title=提交"
        });
    },
    serviceTerms: function() {
        wx.navigateTo({
            url: "/pages/personalCenter/serviceAgreement/serviceAgreement"
        });
    },
    hotPhone: function() {
        wx.makePhoneCall({
            phoneNumber: "010-85879580"
        });
    },
    showClickYouLiWeb: function() {
        wx.showModal({
            title: "提示",
            content: "请在浏览器中输入“www.youlidata.com”访问“PPP有例数据服务+投资决策支持平台”商用版",
            showCancel: !1,
            success: function(e) {
                e.confirm && console.log("用户点击确定");
            }
        });
    },
    openAdvertising: function() {
        this.data.openAdvertising ? this.setData({
            openAdvertising: !1
        }) : this.setData({
            openAdvertising: !0
        });
    },
    closeAdvertising: function() {
        this.setData({
            openAdvertising: !1
        });
    },
    toRechargePage: function() {
        a.toPaymentPage(e);
    },
    getImage: function() {
        var t = this, a = {
            key: "5be0110f63ec8"
        };
        e.getList("GET", "ad/position", a).then(function(e) {
            if ("000000" == e.data.code) {
                var a = e.data.data.startTime, n = e.data.data.endTime, o = Date.parse(new Date()) / 1e3;
                if (a <= o && o <= n) {
                    if ("images" === e.data.data.content.type) {
                        var i = e.data.data.content.value;
                        t.setData({
                            imageContent: i[0],
                            imageIcon: e.data.data.icon,
                            showImage: !0
                        });
                    }
                } else t.setData({
                    imageIcon: "",
                    showImage: !1
                });
            }
        });
    },
    bindViewTap: function() {},
    login: function() {
        var a = this, n = a.data.options;
        t.setLoginUrl(e.getBaseUrl() + "/user/login"), t.login({
            method: "POST",
            success: function(t) {
                console.log("登录成功", t), wx.setStorageSync("userInfo", t);
                var o = a.data;
                a.getInfo(n, o), setTimeout(function() {
                    e.getList("GET", "goods/discount", "").then(function(e) {
                        "000000" == e.data.code ? wx.setStorage({
                            key: "discountTitle",
                            data: e.data.data.title
                        }) : console.log("获取自定义标题失败"), a.setData({
                            loadHidden: !0
                        }), wx.redirectTo({
                            url: "../../pages/projectHome/projectHome"
                        });
                    });
                }, 1e3);
            },
            fail: function(e) {
                a.setData({
                    loadHidden: !0
                }), wx.showToast({
                    title: "登录失败！",
                    icon: "none",
                    duration: 2e3
                });
            }
        });
    },
    getInfo: function(t, n) {
        e.getList("GET", "user/info", "").then(function(o) {
            wx.setStorageSync("user_uniq_token", o.data.data.user_uniq_token), wx.setStorageSync("channel_id", o.data.data.channel_id);
            var i = a.resExport(o);
            wx.setStorageSync("payTime", i), console.log("已经存储user_uniq_token+payTime+channel_id"), 
            wx.getShareInfo({
                shareTicket: t.shareTicket,
                complete: function(a) {
                    if (1044 == t.scene) {
                        var o = {};
                        o.encryptedData = a.encryptedData, o.iv = a.iv, o.userToken = t.query.userToken, 
                        o.scene = t.scene, o.shareTime = t.query.shareTime, n.shareData = JSON.stringify(o);
                    }
                    e.getList("POST", "user/init", n).then(function(e) {
                        console.log(e);
                    });
                }
            });
        });
    }
});
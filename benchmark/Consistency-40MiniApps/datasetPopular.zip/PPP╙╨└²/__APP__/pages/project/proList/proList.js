var e = require("../../../utils/projects-min.js"), t = require("../../../utils/area-min.js"), a = require("../../../utils/city-min.js"), i = (require("../../../vendor/qcloud-weapp-client-sdk/index.js"), 
require("../../../utils/shorts.js"), require("../../../utils/util.js")), n = require("../../../utils/commin.js"), o = require("../../../utils/api.js");

getApp();

Page({
    data: {
        newsList: [],
        moreHidden: "none",
        loadFinished: !1,
        loadMore: "loadMore",
        isDisplay: !1,
        image1: "../../../images/no.png",
        image2: "../../../images/no.png",
        resultNum: "加载中...",
        isMember: !1,
        input_Value: "",
        win_bid_time_start: "",
        win_bid_time_end: "",
        cooperation_phase_min: 0,
        cooperation_phase_max: 999,
        first_industry: "",
        second_industry: "",
        province: "",
        city: "",
        town: "",
        investment_scale_min: 0,
        investment_scale_max: 9999,
        procurement_mode: "",
        payment_method: "",
        operation_pattern: "",
        bid: "",
        order_by: "desc",
        order_name: "win_bid_time",
        isShortTime: !0,
        page: 0,
        toastHidden: !0,
        noNews: "",
        loadHidden: !0,
        isload: !0,
        isShare: !1,
        iScreen: !1,
        isRefresh: !1,
        isShowCollection: !0,
        id: "0",
        cache_id: "",
        isShowproList: !1,
        scroollHeight: 0,
        isTrue: !1,
        inputValue: "",
        disable: !0,
        tradeAll: !1,
        ifTrade: !1,
        ifArea: !1,
        ifCity: !1,
        ifCityUse: !1,
        ifCounty: !1,
        ifCountyUse: !1,
        projects: e.getProjects(),
        area: t.getArea(),
        isThisProvince: [],
        citys: a.getProvince(),
        getCity: [],
        getCounty: [],
        upperDate: "2013-01-01",
        startDate: i.startFormatTime(new Date()),
        endDate: i.endFormatTime(new Date()),
        downDate: i.presentTime(new Date()),
        allTrade: [ "请选择" ],
        firstTradeId: [],
        secondTradeId: [],
        allTradeId: [],
        tradeColor: "#C7C7CC",
        chooseProvince: [ "省" ],
        chooseProvinceId: [],
        chooseCity: [ "市" ],
        chooseCityId: [],
        chooseCounty: [ "区" ],
        chooseCountyId: [],
        temporaryCity: [],
        temporary: [],
        areaColor: "#00000",
        cityColor: "#C7C7CC",
        countyColor: "#C7C7CC",
        scaleMin: "最低",
        scaleMax: "最高",
        scaleMinArr: [ {
            key: 0,
            value: "低于1亿"
        }, {
            key: 1,
            value: "1亿"
        }, {
            key: 5,
            value: "5亿"
        }, {
            key: 10,
            value: "10亿"
        } ],
        scaleMaxArr: [ {
            key: 1,
            value: "1亿"
        }, {
            key: 5,
            value: "5亿"
        }, {
            key: 10,
            value: "10亿"
        }, {
            key: 9999,
            value: "10亿以上"
        } ],
        scaleMinData: 0,
        scaleMaxData: 9999,
        cooperationMin: "最低",
        cooperationMax: "最高",
        cooperationMinArr: [ {
            key: 0,
            value: "低于10年"
        }, {
            key: 10,
            value: "10年"
        }, {
            key: 20,
            value: "20年"
        }, {
            key: 30,
            value: "30年"
        } ],
        cooperationMaxArr: [ {
            key: 10,
            value: "10年"
        }, {
            key: 20,
            value: "20年"
        }, {
            key: 30,
            value: "30年"
        }, {
            key: 999,
            value: "30年以上"
        } ],
        cooperationMinData: 0,
        cooperationMaxData: 999,
        projecttypes: [ {
            id: 0,
            value: "全部",
            purchaseType: "1",
            checked: !0
        }, {
            id: 9,
            value: "PPP",
            purchaseType: "2",
            checked: !1
        }, {
            id: 268,
            value: "类PPP",
            purchaseType: "3",
            checked: !1
        } ],
        projecttypeId: 0,
        investmentList: [ {
            id: "",
            value: "全部",
            investmentType: "0",
            checked: !1
        }, {
            id: "0-1",
            value: "1亿以下",
            investmentType: "1",
            checked: !1
        }, {
            id: "1-5",
            value: "1-5亿",
            investmentType: "2",
            checked: !1
        }, {
            id: "5-20",
            value: "5-20亿",
            investmentType: "3",
            checked: !1
        }, {
            id: "20-50",
            value: "20-50亿",
            investmentType: "4",
            checked: !1
        }, {
            id: "50-100",
            value: "50-100亿",
            investmentType: "5",
            checked: !1
        }, {
            id: "100-999999",
            value: "100亿以上",
            investmentType: "6",
            checked: !1
        } ],
        investmentId: [],
        purchase: [ {
            id: 37,
            value: "竞争性磋商",
            purchaseType: "1",
            checked: !1
        }, {
            id: 38,
            value: "公开招标",
            purchaseType: "2",
            checked: !1
        }, {
            id: 39,
            value: "竞争性谈判",
            purchaseType: "3",
            checked: !1
        }, {
            id: 40,
            value: "单一来源采购",
            purchaseType: "4",
            checked: !1
        }, {
            id: 122,
            value: "邀请招标",
            purchaseType: "5",
            checked: !1
        } ],
        purchaseId: "",
        purchaseMore: "更多",
        purchaseHeighe: "80rpx",
        purchaseImg: "more_down.png",
        reportId: [],
        reportMore: "更多",
        reportHeighe: "80rpx",
        reportImg: "more_down.png",
        patternId: [],
        patternMore: "更多",
        patternHeighe: "80rpx",
        patternImg: "more_down.png",
        subject: [ {
            id: null,
            value: "全部",
            checked: !1
        }, {
            id: "127",
            value: "全投资收益率",
            checked: !1
        }, {
            id: "131",
            value: "运营收入单价",
            checked: !1
        }, {
            id: "126",
            value: "运营成本单价",
            checked: !1
        }, {
            id: "128",
            value: "资本金投资收益率",
            checked: !1
        }, {
            id: "129",
            value: "融资部分收益率",
            checked: !1
        }, {
            id: "57",
            value: "建安费下浮率",
            checked: !1
        } ],
        subjectId: [],
        subjectMore: "更多",
        subjectHeighe: "80rpx",
        subjectImg: "more_down.png",
        searchPosition: "relative",
        showCounty: 0,
        imageIcon: "",
        imageContent: "",
        startTime: "",
        endTime: "",
        showImage: !1
    },
    onShareAppMessage: function(e) {
        var t = this;
        return n.sharePage("项目查询", "/pages/project/proList/proList", "share=true&shareId=" + t.data.cache_id);
    },
    onLoad: function(e) {
        wx.showShareMenu({
            withShareTicket: !0
        }), wx.setStorage({
            key: "keyRefresh",
            data: !1
        });
        var t = this, a = e.share || 0;
        if (wx.getSystemInfo({
            success: function(e) {
                t.setData({
                    scroollHeight: e.windowHeight
                });
            }
        }), a) {
            var s = e.shareId;
            "" != s ? (wx.setStorage({
                key: "cache_id",
                data: s
            }), t.setData({
                cache_id: s
            })) : s = wx.getStorageSync("cache_id"), t.setData({
                newsList: []
            }), o.getList("GET", "cache/get/" + s, "").then(function(e) {
                var a = JSON.parse(e.data.data.cacheData);
                t.setData({
                    input_Value: a.input_Value,
                    win_bid_time_start: a.win_bid_time_start,
                    win_bid_time_end: a.win_bid_time_end,
                    cooperation_phase_min: a.cooperation_phase_min,
                    cooperation_phase_max: a.cooperation_phase_max,
                    first_industry: a.first_industry,
                    second_industry: a.second_industry,
                    province: a.province,
                    city: a.city,
                    town: a.town,
                    investment_scale_min: a.investment_scale_min,
                    investment_scale_max: a.investment_scale_max,
                    procurement_mode: a.procurement_mode,
                    payment_method: a.payment_method,
                    operation_pattern: a.operation_pattern,
                    bid: a.bid,
                    order_by: a.order_by,
                    order_name: a.order_name,
                    page: a.page,
                    resultNum: a.resultNum,
                    newsList: a.newsList,
                    moreHidden: a.moreHidden,
                    isShare: a.isShare,
                    id: a.id
                });
            }), o.getList("GET", "user/info", "").then(function(e) {
                var a = 1e3 * n.resExport(e);
                a = i.secondToDate(new Date(a));
                var o = parseInt(a.replace(/-/g, ""));
                t.ifChangeShareDate(o);
            });
        } else o.getList("GET", "user/info", "").then(function(e) {
            var a = 1e3 * n.resExport(e);
            a = i.secondToDate(new Date(a));
            var o = parseInt(a.replace(/-/g, ""));
            t.ifChangeStartDate(o), t.timeShort();
        });
    },
    onShow: function() {
        var e = this, t = e.data.isShortTime;
        e.data.order_by;
        e.setData({
            isload: !0
        }), this.getImage(), wx.getStorage({
            key: "payTime",
            success: function(e) {
                n.memberDateHint(e.data, i);
            },
            fail: function() {
                o.getList("GET", "user/info", "").then(function(e) {
                    var t = n.resExport(e);
                    wx.setStorageSync("payTime", t), n.memberDateHint(t, i);
                });
            }
        }), wx.getStorage({
            key: "keyRefresh",
            success: function(a) {
                a.data && (e.setData({
                    newsList: [],
                    page: 0,
                    moreHidden: "none"
                }), t ? e.timeShort() : e.scaleShort(), wx.setStorage({
                    key: "keyRefresh",
                    data: !1
                }));
            }
        }), n.clearProjectStory();
        var a = {
            page: "pages/project/proList/proList",
            des: "项目查询列表"
        };
        n.pageMonitoring(o, a);
    },
    ifChangeStartDate: function(e) {
        var t = i.presentTime(new Date()), a = parseInt(t.replace(/-/g, ""));
        e >= a ? (this.setData({
            win_bid_time_start: "2013-01-01",
            win_bid_time_end: i.presentTime(new Date()),
            startDate: "2013-01-01",
            isMember: !0,
            endDate: i.presentTime(new Date())
        }), wx.setStorageSync("isMember", !0)) : e < a && (this.setData({
            isMember: !1,
            win_bid_time_start: i.startFormatTime(new Date()),
            win_bid_time_end: i.presentTime(new Date())
        }), wx.setStorageSync("isMember", !1), wx.setStorageSync("endTime", i.endFormatTime(new Date())));
    },
    ifChangeShareDate: function(e) {
        var t = i.presentTime(new Date());
        e >= parseInt(t.replace(/-/g, "")) ? (this.setData({
            startDate: "2013-01-01",
            isMember: !0,
            endDate: i.presentTime(new Date())
        }), wx.setStorageSync("isMember", !0)) : (wx.setStorageSync("isMember", !1), wx.setStorageSync("endTime", i.endFormatTime(new Date())));
    },
    loadData: function(e) {
        var t = this;
        t.setData({
            loadHidden: !1,
            loadFinished: !1,
            loadMore: "loadMore"
        });
        var a = e, i = t.data.page, s = {}, r = {};
        (a.length > 0 || i > 1) && t.setData({
            noNews: "没有更多"
        }), a.length < 1 ? t.setData({
            toastHidden: !1,
            moreHidden: "none"
        }) : (a = n.projectListValue(a)).length >= 1 && a.length < 10 && 1 == i ? (t.setData({
            moreHidden: "none"
        }), r.moreHidden = "none") : (t.setData({
            moreHidden: ""
        }), r.moreHidden = ""), t.setData({
            loadHidden: !0
        }), r.input_Value = t.data.input_Value, r.win_bid_time_start = t.data.win_bid_time_start, 
        r.win_bid_time_end = t.data.win_bid_time_end, r.cooperation_phase_min = t.data.cooperation_phase_min, 
        r.cooperation_phase_max = t.data.cooperation_phase_max, r.first_industry = t.data.first_industry, 
        r.second_industry = t.data.second_industry, r.province = t.data.province, r.city = t.data.city, 
        r.town = t.data.town, r.investment_scale_min = t.data.investment_scale_min, r.investment_scale_max = t.data.investment_scale_max, 
        r.procurement_mode = t.data.procurement_mode, r.payment_method = t.data.payment_method, 
        r.operation_pattern = t.data.operation_pattern, r.bid = t.data.bid, r.order_by = t.data.order_by, 
        r.order_name = t.data.order_name, r.page = t.data.page, r.resultNum = t.data.resultNum, 
        r.newsList = t.data.newsList, r.image1 = t.data.image1, r.image2 = t.data.image2, 
        r.isShare = !0, r.id = "0", s.cache_data = JSON.stringify(r), o.getList("POST", "cache/create", s).then(function(e) {
            t.setData({
                cache_id: e.data.data.id
            });
        });
    },
    loadMore: function() {
        var e = this, t = e.data.order_name, a = e.data.isShare;
        0 != e.data.loadHidden && ("investment_scale" == t && e.scaleShort(a), "win_bid_time" == t && e.timeShort(a));
    },
    toastChange: function() {
        this.data.newsList.length > 1 && this.setData({
            loadFinished: !0
        }), this.setData({
            toastHidden: !0,
            loadMore: ""
        });
    },
    scaleShort: function(e) {
        var t = this;
        t.setData({
            loadHidden: !1,
            loadFinished: !1,
            loadMore: "loadMore"
        });
        var a = t.data.input_Value, s = t.data.win_bid_time_start, r = t.data.win_bid_time_end, c = t.data.cooperation_phase_min, d = t.data.cooperation_phase_max, h = t.data.first_industry, l = t.data.second_industry, p = t.data.province, u = t.data.city, m = t.data.town, g = t.data.investment_scale_min, _ = t.data.investment_scale_max, y = t.data.procurement_mode, v = t.data.payment_method, f = t.data.operation_pattern, D = t.data.bid, C = t.data.order_by, w = t.data.order_name, k = t.data.page, I = e, T = t.data.id;
        t.data.image1;
        try {
            1 == I ? T = T : (T = e.target.dataset.id, t.setData({
                image2: "../../../images/no.png"
            }), "asc" == C && t.setData({
                order_by: "desc"
            }), "desc" == C && t.setData({
                order_by: "asc"
            }));
        } catch (e) {
            T = "0";
        }
        C = t.data.order_by;
        "1" == T ? (t.setData({
            page: 1
        }), k = 1) : k = parseInt(t.data.page) + 1;
        var x = {
            input_value: a,
            win_bid_time_start: s,
            win_bid_time_end: r,
            cooperation_phase_min: c,
            cooperation_phase_max: d,
            first_industry: h,
            second_industry: l,
            province: p,
            city: u,
            town: m,
            investment_scale_min: g,
            investment_scale_max: _,
            procurement_mode: y,
            payment_method: v,
            operation_pattern: f,
            bid: D,
            order_by: C,
            order_name: w = "investment_scale",
            page: k
        };
        o.getList("GET", "project/posts", x).then(function(e) {
            if ("000000" === e.data.code) {
                var I = e.data.data.total, x = e.data.data.nonMemberTotal, b = e.data.data.data || "";
                if ((b.length > 0 || k > 1) && t.setData({
                    noNews: "没有更多"
                }), b.length < 1) t.setData({
                    toastHidden: !1,
                    moreHidden: "none"
                }); else {
                    b = n.projectListValue(b, !1, k);
                    var j = {}, P = {};
                    if ("0" == T) {
                        var M = t.data.newsList.concat(b);
                        b.length >= 1 && b.length < 10 && 1 == k ? (t.setData({
                            newsList: M,
                            resultNum: "共有" + I + "条结果",
                            moreHidden: "none",
                            page: k
                        }), P.newsList = M, P.moreHidden = "none") : (t.setData({
                            newsList: M,
                            moreHidden: "",
                            page: k
                        }), P.newsList = M, P.moreHidden = "");
                    }
                    "1" == T && (t.setData({
                        isShare: !1,
                        id: ""
                    }), b.length >= 1 && b.length < 10 ? (t.setData({
                        newsList: b,
                        resultNum: "共有" + I + "条结果",
                        moreHidden: "none",
                        page: 1
                    }), P.newsList = b, P.moreHidden = "none") : (t.setData({
                        newsList: b,
                        moreHidden: "",
                        page: 1
                    }), P.newsList = b, P.moreHidden = ""), "asc" == C && (t.setData({
                        image1: "../../../images/up.png"
                    }), P.image1 = "../../../images/up.png"), "desc" == C && (t.setData({
                        image1: "../../../images/down.png"
                    }), P.image1 = "../../../images/down.png")), "" == x ? (t.setData({
                        resultNum: "共有" + I + "条结果"
                    }), P.resultNum = "共有" + I + "条结果") : (t.setData({
                        resultNum: "项目总数：" + I + "（未付费用户可查看" + i.startFormatTime(new Date()) + "至" + i.endFormatTime(new Date()) + "之间的项目总数：" + x + "）"
                    }), P.resultNum = "项目总数：" + I + "（未付费用户可查看" + i.startFormatTime(new Date()) + "至" + i.endFormatTime(new Date()) + "之间的项目总数：" + x + "）");
                }
                t.setData({
                    loadHidden: !0
                }), P.input_Value = a, P.win_bid_time_start = s, P.win_bid_time_end = r, P.cooperation_phase_min = c, 
                P.cooperation_phase_max = d, P.first_industry = h, P.second_industry = l, P.province = p, 
                P.city = u, P.town = m, P.investment_scale_min = g, P.investment_scale_max = _, 
                P.procurement_mode = y, P.payment_method = v, P.operation_pattern = f, P.bid = D, 
                P.order_by = C, P.order_name = w, P.page = k, P.image2 = "../../../images/no.png", 
                P.isShare = !0, P.id = T, j.cache_data = JSON.stringify(P), o.getList("POST", "cache/create", j).then(function(e) {
                    t.setData({
                        cache_id: e.data.data.id
                    });
                });
            } else t.setData({
                loadHidden: !0
            });
        }), t.setData({
            order_name: w,
            isShortTime: !1
        });
    },
    timeShort: function(e) {
        var t = this;
        t.setData({
            loadHidden: !1,
            loadFinished: !1,
            loadMore: "loadMore"
        });
        var a = t.data.input_Value, s = t.data.win_bid_time_start, r = t.data.win_bid_time_end, c = t.data.firstTradeId || "", d = t.data.secondTradeId || "", h = t.data.chooseProvinceId || "", l = t.data.chooseCityId || "", p = t.data.chooseCountyId || "", u = t.data.scaleMinData, m = t.data.scaleMaxData, g = t.data.cooperationMinData, _ = t.data.cooperationMaxData, y = 0 === t.data.projecttypeId ? "" : t.data.projecttypeId, v = t.data.investmentId || "", f = t.data.purchaseId || "", D = t.data.reportId || "", C = t.data.patternId || "", w = t.data.subjectId || "", k = t.data.order_by, I = (t.data.order_name, 
        t.data.page), y = 0 === t.data.projecttypeId ? "" : t.data.projecttypeId, T = e, x = t.data.id;
        t.data.image2;
        try {
            1 == T ? x = x : (x = e.target.dataset.id, t.setData({
                image1: "../../../images/no.png"
            }), "asc" == k && t.setData({
                order_by: "desc"
            }), "desc" == k && t.setData({
                order_by: "asc"
            }));
        } catch (e) {
            x = "0";
        }
        k = t.data.order_by;
        "2" == x ? (t.setData({
            page: 1
        }), I = 1) : I = parseInt(t.data.page) + 1;
        var b = {
            input_value: a,
            win_bid_time_start: s,
            win_bid_time_end: r,
            cooperation_phase_min: g,
            cooperation_phase_max: _,
            first_industry: c.join(","),
            second_industry: d.join(","),
            province: h.join(","),
            city: l.join(","),
            town: p.join(","),
            investment_scale_min: u,
            investment_scale_max: m,
            procurement_mode: f,
            payment_method: D.join(","),
            operation_pattern: C.join(","),
            bid: w.join(","),
            order_by: k,
            order_name: "win_bid_time",
            page: I,
            project_type: y,
            investment_scale: v.join(",")
        };
        o.getList("GET", "project/posts", b).then(function(e) {
            var y = e.data.data.total, v = e.data.data.nonMemberTotal, T = e.data.data.data || "";
            if ((T.length > 0 || I > 1) && t.setData({
                noNews: "没有更多"
            }), T.length < 1) t.setData({
                toastHidden: !1,
                moreHidden: "none"
            }); else {
                T = n.projectListValue(T, !1, I);
                var b = {}, j = {};
                if ("0" == x) {
                    var P = t.data.newsList.concat(T);
                    T.length >= 1 && T.length < 10 && 1 == I ? (t.setData({
                        newsList: P,
                        resultNum: "共有" + y + "条结果",
                        moreHidden: "none",
                        page: I
                    }), j.newsList = P, j.moreHidden = "none") : (t.setData({
                        newsList: P,
                        moreHidden: "",
                        page: I
                    }), j.newsList = P, j.moreHidden = "");
                }
                "2" == x && (t.setData({
                    isShare: !1,
                    id: ""
                }), T.length >= 1 && T.length < 10 ? (t.setData({
                    newsList: T,
                    resultNum: "共有" + y + "条结果",
                    moreHidden: "none",
                    page: 1
                }), j.newsList = T, j.moreHidden = "none") : (t.setData({
                    newsList: T,
                    moreHidden: "",
                    page: 1
                }), j.newsList = T, j.moreHidden = ""), "asc" == k && (t.setData({
                    image2: "../../../images/up.png"
                }), j.image2 = "../../../images/up.png"), "desc" == k && (t.setData({
                    image2: "../../../images/down.png"
                }), j.image2 = "../../../images/down.png")), "" == v ? (t.setData({
                    resultNum: "共有" + y + "条结果"
                }), j.resultNum = "共有" + y + "条结果") : (t.setData({
                    resultNum: "项目总数：" + y + "（未付费用户可查看" + i.startFormatTime(new Date()) + "至" + i.endFormatTime(new Date()) + "之间的项目总数：" + v + "）"
                }), j.resultNum = "项目总数：" + y + "（未付费用户可查看" + i.startFormatTime(new Date()) + "至" + i.endFormatTime(new Date()) + "之间的项目总数：" + v + "）");
            }
            t.setData({
                loadHidden: !0
            }), j.input_Value = a, j.win_bid_time_start = s, j.win_bid_time_end = r, j.cooperation_phase_min = g, 
            j.cooperation_phase_max = _, j.first_industry = c, j.second_industry = d, j.province = h, 
            j.city = l, j.town = p, j.investment_scale_min = u, j.investment_scale_max = m, 
            j.procurement_mode = f, j.payment_method = D, j.operation_pattern = C, j.bid = w, 
            j.order_by = k, j.order_name = "win_bid_time", j.image1 = "../../../images/no.png", 
            j.page = I, j.isShare = !0, j.id = x, b.cache_data = JSON.stringify(j), o.getList("POST", "cache/create", b).then(function(e) {
                t.setData({
                    cache_id: e.data.data.id
                });
            });
        }), t.setData({
            order_name: "win_bid_time",
            isShortTime: !0
        });
    },
    loadDetails: function(e) {
        this.setData({
            isload: !1,
            isRefresh: !0
        });
        var t = this, a = e.currentTarget.dataset.id, n = e.currentTarget.dataset.recentproject, s = e.currentTarget.dataset.winbidtime, r = i.startFormatTime(new Date()), c = i.endFormatTime(new Date()), d = i.presentTime(new Date()), h = parseInt(r.replace(/-/g, "")), l = parseInt(c.replace(/-/g, "")), p = parseInt(s.replace(/-/g, "")), u = parseInt(d.replace(/-/g, "")), m = t.data.isShowCollection;
        h <= p && p <= l ? wx.navigateTo({
            url: "/pages/project/details/details?id=" + a + "&&recentProject=" + n + "&&isShowCollection=" + m
        }) : wx.getStorage({
            key: "payTime",
            success: function(e) {
                t.setData({
                    isload: !0
                });
                var s = 1e3 * e.data;
                s = i.secondToDate(new Date(s));
                var r = parseInt(s.replace(/-/g, ""));
                0 == e.data ? wx.showModal({
                    title: "提示",
                    content: "未付费用户查看数据范围：当前日期前18个月至前6个月，开通会员享有全部数据权限。",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? wx.getStorage({
                            key: "isBindPhone",
                            complete: function(e) {
                                e.data || "" ? wx.navigateTo({
                                    url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=projectHome"
                                }) : o.getList("GET", "user/isBindPhone", "").then(function(e) {
                                    wx.setStorage({
                                        key: "isBindPhone",
                                        data: e.data.data.bindStatus
                                    }), e.data.data.bindStatus ? wx.navigateTo({
                                        url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=projectHome"
                                    }) : wx.navigateTo({
                                        url: "/pages/personalCenter/personalPage/personalPage?skipPage=projectHome"
                                    });
                                });
                            }
                        }) : e.cancel && t.setData({
                            isload: !0
                        });
                    }
                }) : r >= u ? wx.navigateTo({
                    url: "/pages/project/details/details?id=" + a + "&&recentProject=" + n + "&&isShowCollection=" + m
                }) : r < u ? wx.showModal({
                    title: "提示",
                    content: "您的会员已过期,重新开通会员享有全部数据权限",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? (t.setData({
                            isload: !0
                        }), wx.navigateTo({
                            url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=projectHome"
                        })) : e.cancel && t.setData({
                            isload: !0
                        });
                    }
                }) : console.log("时间范围超出限制");
            },
            fail: function(e) {
                console.log("获取日期失败");
            }
        });
    },
    loadSearch: function() {
        this.setData({
            isShowproList: !1
        });
    },
    loadCollection: function() {
        var e = {
            url: "/pages/project/proCollectionList/proCollectionList"
        };
        wx.navigateTo(e);
    },
    inputValue: function(e) {
        var t = e.detail.value.replace(/^\s+|\s+$/g, "");
        this.setData({
            inputValue: t
        });
    },
    optionTrade: function(e) {
        this.setData({
            ifTrade: !0,
            searchPosition: "fixed"
        });
    },
    hideTrade: function(e) {
        "trade-choose" == e.target.dataset.id && (this.tradeConfirm(), this.setData({
            ifTrade: !1,
            searchPosition: "relative"
        }));
    },
    listHeight: function(e) {
        var t = e.target.dataset.value, a = this.data.projects;
        n.getHeight(t, a), this.setData({
            projects: a
        });
    },
    tradeAlltap: function(e) {
        var t = this.data.projects, a = this.data.firstTradeId;
        if (e.target.dataset.checked) {
            for (i = 0; i < t.length; i++) {
                t[i].checked = !1, t.splice(i, 1, t[i]), t[i].checkElement.length = 0, t[i].checkElementId.length = 0;
                for (n = 0; n < t[i].list.length; n++) t[i].list[n].checked = !1, t[i].list.splice(n, 1, t[i].list[n]);
            }
            this.setData({
                tradeAll: !1,
                projects: t,
                firstTradeId: [],
                secondTradeId: []
            });
        } else {
            for (n = 0; n < t.length; n++) t[n].checkElement.length = 0, t[n].checkElementId.length = 0;
            for (var i = 0; i < t.length; i++) {
                t[i].checked = !0, t.splice(i, 1, t[i]), a.push(t[i].id);
                for (var n = 0; n < t[i].list.length; n++) t[i].list[n].checked = !0, t[i].list.splice(n, 1, t[i].list[n]), 
                t[i].checkElement.push(t[i].list[n].name), t[i].checkElementId.push(t[i].list[n].id);
            }
            this.setData({
                tradeAll: !0,
                projects: t,
                firstTradeId: a
            });
        }
    },
    chartTrade: function(e) {
        var t = e.target.dataset.value, a = this.data.projects, i = this.data.firstTradeId, n = this.data.secondTradeId, o = a[t], s = !0;
        if (o.checked) {
            o.checked = !1;
            for (var r = 0; r < i.length; r++) i[r] == o.id && i.splice(r, 1);
            for (c = 0; c < a[t].list.length; c++) a[t].list[c].checked = !1;
            this.setData({
                tradeAll: !1
            }), a[t].checkElement.length = 0, a[t].checkElementId.length = 0;
        } else {
            o.checked = !0, i.push(o.id), a[t].checkElement.length = 0, a[t].checkElementId.length = 0;
            for (var c = 0; c < a[t].list.length; c++) {
                a[t].list[c].checked = !0, a[t].checkElement.push(a[t].list[c].name), a[t].checkElementId.push(a[t].list[c].id);
                for (var d = 0; d < n.length; d++) n[d] == a[t].list[c].id && n.splice(d, 1);
            }
            for (var h = 0; h < a.length; h++) if (0 == a[h].checked) {
                s = !1;
                break;
            }
            s && this.setData({
                tradeAll: !0
            });
        }
        a.splice(t, 1, o), this.setData({
            projects: a
        });
    },
    chartTradeSecond: function(e) {
        var t = e.target.dataset.value, a = e.target.dataset.superiorvalue, i = [], n = this.data.secondTradeId, o = this.data.firstTradeId, s = this.data.projects, r = s[a].list[t], c = s[a].list[t].parent, d = e.target.dataset.name, h = e.target.dataset.id;
        if (r.checked) {
            r.checked = !1;
            for (var l = 0; l < o.length; l++) o[l] == c && o.splice(l, 1);
            for (var p = 0; p < s[a].list.length; p++) s[a].list[p].checked && i.push(s[a].list[p].id), 
            this.setData({
                secondTradeId: i
            });
            s[a].checked = !1, this.setData({
                tradeAll: !1
            });
            var u = s[a].checkElement.indexOf(d), m = s[a].checkElementId.indexOf(h);
            s[a].checkElement.splice(u, 1), s[a].checkElementId.splice(m, 1);
        } else {
            r.checked = !0, n.push(r.id);
            var g = !0, _ = !0;
            s[a].checkElement.push(d), s[a].checkElementId.push(h);
            for (y = 0; y < s[a].list.length; y++) if (0 == s[a].list[y].checked) {
                g = !1;
                break;
            }
            g && (s[a].checked = !0);
            for (var y = 0; y < s.length; y++) if (0 == s[y].checked) {
                _ = !1;
                break;
            }
            _ && this.setData({
                tradeAll: !0
            });
        }
        s[a].list.splice(t, 1, r), this.setData({
            projects: s
        });
    },
    tradeRestoration: function() {
        var e = this.data.projects;
        n.clearProjects(e), this.setData({
            tradeAll: !1,
            projects: e
        });
    },
    tradeConfirm: function() {
        var e = this.data.projects, t = this.data.allTrade, a = this.data.allTradeId, i = (this.data.secondTradeId, 
        0), n = 0;
        t.length = 0, a.length = 0;
        for (var o = 0; o < e.length; o++) {
            for (s = 0; s < e[o].list.length; s++) i++;
            for (s = 0; s < e[o].checkElement.length; s++) n++, t.push(e[o].checkElement[s]);
            for (var s = 0; s < e[o].checkElementId.length; s++) a.push(e[o].checkElementId[s]);
        }
        0 == t.length ? (t.push("请选择"), this.setData({
            tradeColor: "#C7C7CC"
        })) : this.setData({
            tradeColor: "#31a4ff"
        }), this.setData({
            ifTrade: !1,
            allTrade: t,
            allTradeId: a,
            secondTradeId: a,
            searchPosition: "relative"
        }), n == i && (t.length = 0, this.setData({
            allTrade: [ "全部行业" ]
        }));
    },
    optionProvince: function() {
        this.setData({
            ifArea: !0,
            searchPosition: "fixed"
        });
    },
    hideArea: function(e) {
        "area-choose" == e.target.dataset.id && (this.areaConfirm(), this.setData({
            ifArea: !1,
            searchPosition: "relative"
        }));
    },
    provinceHeight: function(e) {
        var t = this.data.area, a = e.target.dataset.value;
        n.getHeight(a, t), this.setData({
            area: t
        });
    },
    areaAlltap: function(e) {
        var t = this.data.area, a = this.data.chooseProvinceId;
        if (e.target.dataset.checked) {
            for (i = 0; i < t.length; i++) {
                t[i].checked = !1, t.splice(i, 1, t[i]), t[i].checkElement.length = 0, t[i].checkElementId.length = 0;
                for (n = 0; n < t[i].province.length; n++) t[i].province[n].checked = !1, t[i].province.splice(n, 1, t[i].province[n]);
            }
            this.setData({
                areaAll: !1,
                area: t,
                chooseProvinceId: []
            });
        } else {
            for (n = 0; n < t.length; n++) t[n].checkElement.length = 0, t[n].checkElementId.length = 0;
            for (var i = 0; i < t.length; i++) {
                t[i].checked = !0, t.splice(i, 1, t[i]);
                for (var n = 0; n < t[i].province.length; n++) t[i].province[n].checked = !0, t[i].province.splice(n, 1, t[i].province[n]), 
                t[i].checkElement.push(t[i].province[n].name), t[i].checkElementId.push(t[i].province[n].id), 
                a.push(t[i].province[n].id);
            }
            this.setData({
                areaAll: !0,
                area: t
            });
        }
    },
    chartArea: function(e) {
        var t = e.target.dataset.value, a = this.data.area, i = a[t], n = !0;
        if (i.checked) {
            i.checked = !1;
            for (o = 0; o < a[t].province.length; o++) a[t].province[o].checked = !1;
            this.setData({
                areaAll: !1
            }), a[t].checkElement.length = 0, a[t].checkElementId.length = 0;
        } else {
            i.checked = !0, a[t].checkElement.length = 0, a[t].checkElementId.length = 0;
            for (var o = 0; o < a[t].province.length; o++) a[t].province[o].checked = !0, a[t].checkElement.push(a[t].province[o].name), 
            a[t].checkElementId.push(a[t].province[o].id);
            for (var s = 0; s < a.length; s++) if (0 == a[s].checked) {
                n = !1;
                break;
            }
            n && this.setData({
                areaAll: !0
            });
        }
        a.splice(t, 1, i), this.setData({
            area: a
        });
    },
    chartAreaSecond: function(e) {
        var t = e.target.dataset.value, a = e.target.dataset.superiorvalue, i = this.data.area, n = i[a].province[t], o = e.target.dataset.name, s = e.target.dataset.id;
        if (n.checked) {
            n.checked = !1, i[a].checked = !1, this.setData({
                areaAll: !1
            });
            var r = i[a].checkElement.indexOf(o), c = i[a].checkElementId.indexOf(s);
            i[a].checkElement.splice(r, 1), i[a].checkElementId.splice(c, 1);
        } else {
            n.checked = !0;
            var d = !0, h = !0;
            i[a].checkElement.push(o), i[a].checkElementId.push(s);
            for (l = 0; l < i[a].province.length; l++) if (0 == i[a].province[l].checked) {
                d = !1;
                break;
            }
            d && (i[a].checked = !0);
            for (var l = 0; l < i.length; l++) if (0 == i[l].checked) {
                h = !1;
                break;
            }
            h && this.setData({
                areaAll: !0
            });
        }
        i[a].province.splice(t, 1, n), this.setData({
            area: i
        });
    },
    areaRestoration: function() {
        var e = this.data.area;
        n.clearArea(e), this.setData({
            areaAll: !1,
            area: e
        });
    },
    areaConfirm: function() {
        var e = this.data.area, t = this.data.chooseProvince, a = this.data.chooseProvinceId, i = (this.data.chooseCity, 
        this.data.chooseCounty, this.data.ifCityUse, this.data.ifCountyUse, 0), n = 0;
        t.length = 0, a.length = 0;
        for (var o = 0; o < e.length; o++) {
            for (s = 0; s < e[o].province.length; s++) i++;
            for (var s = 0; s < e[o].checkElement.length; s++) n++, t.push(e[o].checkElement[s]);
            for (var r = 0; r < e[o].checkElementId.length; r++) a.push(e[o].checkElementId[r]);
        }
        0 == t.length || "省" == t[0] ? (t.push("省"), this.setData({
            areaColor: "#000000",
            ifCityUse: !1,
            ifCountyUse: !1,
            chooseCity: "不可选",
            chooseCounty: "不可选",
            cityColor: "#C7C7CC",
            countyColor: "#C7C7CC",
            chooseCityId: [],
            chooseCountyId: []
        })) : t.length > 1 ? this.setData({
            chooseCity: "不可选",
            chooseCounty: "不可选",
            cityColor: "#C7C7CC",
            countyColor: "#C7C7CC",
            ifCityUse: !1,
            ifCountyUse: !1,
            areaColor: "#31a4ff",
            chooseCityId: [],
            chooseCountyId: []
        }) : this.setData({
            areaColor: "#31a4ff",
            chooseCity: [ "市" ],
            chooseCounty: [ "区" ],
            cityColor: "#000000",
            countyColor: "#C7C7CC",
            ifCityUse: !0,
            ifCountyUse: !1,
            chooseCityId: [],
            chooseCountyId: []
        }), a.length > 1 && this.setData({
            chooseCityId: [],
            chooseCountyId: []
        }), this.setData({
            ifArea: !1,
            chooseProvince: t,
            chooseProvinceId: a,
            searchPosition: "relative"
        }), 0 == this.data.chooseProvinceId.length || 0 == this.data.allTradeId.length ? this.setData({
            disable: !0
        }) : this.setData({
            disable: !1
        }), n == i && (t.length = 0, this.setData({
            chooseProvince: [ "全国" ]
        }));
    },
    optionCity: function() {
        if (1 == this.data.ifCityUse) {
            this.setData({
                ifCity: !0,
                searchPosition: "fixed"
            });
            var e = this.data.chooseProvinceId, t = this.data.isThisProvince, a = this.data.citys;
            this.data.getCity;
            if (t.join(",") != e.join(",")) for (var i = 0; i < a.length; i++) a[i].id == e && this.setData({
                getCity: a[i].city
            });
        }
    },
    hideCity: function(e) {
        "area-choose" == e.target.dataset.id && (this.cityConfirm(), this.setData({
            ifCity: !1,
            searchPosition: "relative"
        }));
    },
    chartCity: function(e) {
        var t = e.target.dataset.index, a = this.data.getCity, i = a[t], o = this.data.chooseCity, s = this.data.chooseProvinceId, r = this.data.chooseCityId;
        n.searchCity(a, i, t, !0), this.setData({
            getCity: a
        }), o = [], r = [];
        for (var c = 0; c < a.length; c++) a[c].checked && (o.push(a[c].name), r.push(a[c].id));
        this.setData({
            chooseCity: o,
            chooseCityId: r,
            isThisProvince: s
        });
    },
    cityConfirm: function() {
        var e = this, t = e.data.chooseCity, a = e.data.chooseCityId, i = (e.data.ifCountyUse, 
        n.isCityWithoutDistricts(this.data.getCity, a));
        if (e.setData({
            ifCity: !1,
            searchPosition: "relative"
        }), 0 == t.length || "市" == t[0]) e.setData({
            cityColor: "#000000",
            chooseCity: [ "市" ],
            countyColor: "#C7C7CC",
            ifCountyUse: !1,
            chooseCounty: [ "不可选" ],
            chooseCountyId: []
        }); else if (t.length > 1) e.setData({
            chooseCounty: [ "不可选" ],
            countyColor: "#C7C7CC",
            cityColor: "#31a4ff",
            ifCountyUse: !1,
            chooseCountyId: []
        }); else if (i) e.setData({
            chooseCounty: [ "不设区的市" ],
            countyColor: "#C7C7CC",
            cityColor: "#31a4ff",
            ifCountyUse: !1,
            chooseCountyId: []
        }); else {
            e.setData({
                cityColor: "#31a4ff",
                chooseCounty: [ "区" ],
                countyColor: "#000000",
                ifCountyUse: !0,
                chooseCountyId: []
            });
            var s = {
                id: a.join(",")
            };
            o.getList("GET", "project/areaTown", s).then(function(t) {
                e.setData({
                    getCounty: t.data.data
                });
            });
        }
    },
    cityRestoration: function() {
        var e = this.data.getCity;
        n.clearCity(e), this.setData({
            getCity: e,
            chooseCity: [],
            chooseCityId: []
        });
    },
    optionCounty: function() {
        var e = this;
        1 == e.data.ifCountyUse && e.setData({
            ifCounty: !0,
            searchPosition: "fixed"
        });
    },
    hideCounty: function(e) {
        "area-choose" == e.target.dataset.id && (this.countyConfirm(), this.setData({
            ifCounty: !1,
            searchPosition: "relative"
        }));
    },
    chartCounty: function(e) {
        var t = e.target.dataset.index, a = this.data.chooseCounty, i = this.data.chooseCountyId, o = this.data.getCounty, s = o[t];
        n.searchCity(o, s, t, !0), this.setData({
            getCounty: o
        }), a = [], i = [];
        for (var r = 0; r < o.length; r++) o[r].checked && (a.push(o[r].name), i.push(o[r].id));
        this.setData({
            chooseCounty: a,
            chooseCountyId: i
        });
    },
    countyConfirm: function() {
        var e = this.data.chooseCounty;
        this.setData({
            ifCounty: !1,
            searchPosition: "relative"
        }), 0 == e.length ? (e.push([ "区" ]), this.setData({
            cityColor: "#31a4ff",
            countyColor: "#000000",
            chooseCounty: [ "区" ]
        })) : this.setData({
            countyColor: "#31a4ff"
        });
    },
    countyRestoration: function() {
        var e = this.data.getCounty;
        n.clearCity(e), this.setData({
            getCounty: e,
            chooseCounty: [],
            chooseCountyId: []
        });
    },
    bindScaleMinChange: function(e) {
        var t = e.detail.value, a = this.data.scaleMinArr, i = this.data.scaleMaxData, n = a[t].value, o = a[t].key;
        o > i ? wx.showModal({
            title: "提示",
            content: "区间选择错误，请重新选择",
            showCancel: !1,
            success: function(e) {
                e.confirm && console.log("用户点击确定");
            }
        }) : this.setData({
            scaleMin: n,
            scaleMinData: o
        });
    },
    bindScaleMaxChange: function(e) {
        var t = e.detail.value, a = this.data.scaleMinData, i = this.data.scaleMaxArr, n = i[t].value, o = i[t].key;
        a > o ? wx.showModal({
            title: "提示",
            content: "区间选择错误，请重新选择",
            showCancel: !1,
            success: function(e) {
                e.confirm && console.log("用户点击确定");
            }
        }) : this.setData({
            scaleMax: n,
            scaleMaxData: o
        });
    },
    bindCooMinChange: function(e) {
        var t = e.detail.value, a = this.data.cooperationMinArr, i = this.data.cooperationMaxData, n = a[t].value, o = a[t].key;
        o > i ? wx.showModal({
            title: "提示",
            content: "区间选择错误，请重新选择",
            showCancel: !1,
            success: function(e) {
                e.confirm && console.log("用户点击确定");
            }
        }) : this.setData({
            cooperationMin: n,
            cooperationMinData: o
        });
    },
    bindCooMaxChange: function(e) {
        var t = e.detail.value, a = this.data.cooperationMaxArr, i = this.data.cooperationMinData, n = a[t].value, o = a[t].key;
        i > o ? wx.showModal({
            title: "提示",
            content: "区间选择错误，请重新选择",
            showCancel: !1,
            success: function(e) {
                e.confirm && console.log("用户点击确定");
            }
        }) : this.setData({
            cooperationMax: n,
            cooperationMaxData: o
        });
    },
    bindStartDateChange: function(e) {
        var t = this, a = e.detail.value, n = i.startFormatTime(new Date()), s = i.endFormatTime(new Date()), r = i.presentTime(new Date()), c = parseInt(a.replace(/-/g, "")), d = parseInt(n.replace(/-/g, "")), h = parseInt(s.replace(/-/g, "")), l = parseInt(r.replace(/-/g, ""));
        d <= c && c <= h ? t.setData({
            startDate: e.detail.value
        }) : wx.getStorage({
            key: "payTime",
            success: function(a) {
                var n = 1e3 * a.data;
                n = i.secondToDate(new Date(n));
                var s = parseInt(n.replace(/-/g, ""));
                0 == a.data ? wx.showModal({
                    title: "提示",
                    content: "未付费用户查看数据范围：当前日期前18个月至前6个月，开通会员享有全部数据权限。",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? wx.getStorage({
                            key: "isBindPhone",
                            complete: function(e) {
                                e.data || "" ? wx.navigateTo({
                                    url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=projectHome"
                                }) : o.getList("GET", "user/isBindPhone", "").then(function(e) {
                                    wx.setStorage({
                                        key: "isBindPhone",
                                        data: e.data.data.bindStatus
                                    }), e.data.data.bindStatus ? wx.navigateTo({
                                        url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=projectHome"
                                    }) : wx.navigateTo({
                                        url: "/pages/personalCenter/personalPage/personalPage?skipPage=projectHome"
                                    });
                                });
                            }
                        }) : e.cancel && console.log("用户点击取消");
                    }
                }) : s >= l ? t.setData({
                    startDate: e.detail.value
                }) : s < l ? wx.showModal({
                    title: "提示",
                    content: "您的会员已过期,重新开通会员享有全部数据权限",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? wx.navigateTo({
                            url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=projectHome"
                        }) : e.cancel && console.log("用户点击取消");
                    }
                }) : console.log("时间范围超出限制");
            },
            fail: function(e) {
                console.log("获取日期失败");
            }
        });
    },
    bindEndDateChange: function(e) {
        var t = this, a = e.detail.value, n = i.startFormatTime(new Date()), s = i.endFormatTime(new Date()), r = i.presentTime(new Date()), c = parseInt(a.replace(/-/g, "")), d = parseInt(n.replace(/-/g, "")), h = parseInt(s.replace(/-/g, "")), l = parseInt(r.replace(/-/g, ""));
        d <= c && c <= h ? t.setData({
            endDate: e.detail.value
        }) : wx.getStorage({
            key: "payTime",
            success: function(a) {
                var n = 1e3 * a.data;
                n = i.secondToDate(new Date(n));
                var s = parseInt(n.replace(/-/g, ""));
                0 == a.data ? wx.showModal({
                    title: "提示",
                    content: "未付费用户查看数据范围：当前日期前18个月至前6个月，开通会员享有全部数据权限。",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? wx.getStorage({
                            key: "isBindPhone",
                            complete: function(e) {
                                e.data || "" ? (console.log("有缓存已绑定"), wx.navigateTo({
                                    url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=projectHome"
                                })) : (console.log("无缓存发请求"), o.getList("GET", "user/isBindPhone", "").then(function(e) {
                                    wx.setStorage({
                                        key: "isBindPhone",
                                        data: e.data.data.bindStatus
                                    }), e.data.data.bindStatus ? (console.log("已绑定"), wx.navigateTo({
                                        url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=projectHome"
                                    })) : (console.log("未绑定"), wx.navigateTo({
                                        url: "/pages/personalCenter/personalPage/personalPage?skipPage=projectHome"
                                    }));
                                }));
                            }
                        }) : e.cancel && console.log("用户点击取消");
                    }
                }) : s >= l ? (console.log("会员未过期"), t.setData({
                    endDate: e.detail.value
                })) : s < l ? (console.log("会员过期"), wx.showModal({
                    title: "提示",
                    content: "您的会员已过期,重新开通会员享有全部数据权限",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? (console.log("用户点击确定"), wx.navigateTo({
                            url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=projectHome"
                        })) : e.cancel && console.log("用户点击取消");
                    }
                })) : console.log("时间范围超出限制");
            },
            fail: function(e) {
                console.log("获取日期失败");
            }
        });
    },
    formSubmit: function() {
        var e = this;
        e.setData({
            loadHidden: !1,
            firstAccess: !0
        }), n.clearProjectStory();
        var t = e.data.inputValue || "", a = e.data.startDate, s = e.data.endDate, r = e.data.firstTradeId || "", c = e.data.secondTradeId || "", d = e.data.chooseProvinceId || "", h = e.data.chooseCityId || "", l = e.data.chooseCountyId || "", p = e.data.scaleMinData, u = e.data.scaleMaxData, m = e.data.cooperationMinData, g = e.data.cooperationMaxData, _ = 0 === e.data.projecttypeId ? "" : e.data.projecttypeId, y = e.data.investmentId || "", v = e.data.purchaseId || "", f = e.data.reportId || "", D = e.data.patternId || "", C = e.data.subjectId || "";
        "" != l && (d = [], h = []), "" != h && (d = []);
        var w = {
            input_value: t,
            win_bid_time_start: a,
            win_bid_time_end: s,
            cooperation_phase_min: m,
            cooperation_phase_max: g,
            first_industry: r.join(","),
            second_industry: c.join(","),
            province: d.join(","),
            city: h.join(","),
            town: l.join(","),
            investment_scale_min: p,
            investment_scale_max: u,
            project_type: _,
            investment_scale: y.join(","),
            procurement_mode: v,
            payment_method: f.join(","),
            operation_pattern: D.join(","),
            bid: C.join(","),
            order_by: "desc",
            order_name: "win_bid_time",
            page: 1
        };
        o.getList("GET", "project/posts", w).then(function(o) {
            if ("000000" === o.data.code) {
                var y = o.data.data.total, w = o.data.data.nonMemberTotal, k = o.data.data.data || [];
                k = n.projectListValue(k), e.setData({
                    loadHidden: !0
                }), "" === w ? e.setData({
                    resultNum: "共有" + y + "条结果"
                }) : e.setData({
                    resultNum: "项目总数：" + y + "（未付费用户可查看" + i.startFormatTime(new Date()) + "至" + i.endFormatTime(new Date()) + "之间的项目总数：" + w + "）"
                }), e.setData({
                    input_Value: t,
                    win_bid_time_start: a,
                    win_bid_time_end: s,
                    first_industry: r.join(","),
                    second_industry: c.join(","),
                    province: d.join(","),
                    city: h.join(","),
                    town: l.join(","),
                    cooperation_phase_min: m,
                    cooperation_phase_max: g,
                    investment_scale_min: p,
                    investment_scale_max: u,
                    project_type: _,
                    procurement_mode: v,
                    payment_method: f.join(","),
                    operation_pattern: D.join(","),
                    bid: C.join(","),
                    newsList: k,
                    page: 1,
                    iScreen: !0,
                    isShowproList: !0,
                    order_by: "desc",
                    isShare: !1,
                    firstAccess: !1,
                    image2: "../../../images/no.png"
                }), e.loadData(k);
            } else e.setData({
                firstAccess: !1,
                loadHidden: !0
            }), wx.showModal({
                title: "登录提示",
                content: "请在“个人中心”登录后再查询数据",
                showCancel: !0,
                cancelText: "取消",
                confirmText: "个人中心",
                success: function(e) {
                    wx.setStorage({
                        key: "show_useinfo",
                        data: !1
                    }), e.confirm ? wx.switchTab({
                        url: "../../personalCenterHome/personalCenterHome"
                    }) : e.cancel;
                }
            });
        });
    },
    formReset: function(e) {
        var t = this, a = t.data.projects, s = t.data.getCity, r = t.data.getCounty, c = t.data.area, d = t.data.purchase, h = t.data.projecttypes, l = t.data.investmentList, p = t.data.subject;
        n.clearProjects(a), n.clearArea(c), n.clearCity(s), n.clearCity(r), n.clearReport(h), 
        n.clearReport(l), n.clearReport(d), n.clearReport(p), wx.getStorage({
            key: "payTime",
            complete: function(e) {
                void 0 == e.data || "" == e.data ? o.getList("GET", "user/info", "").then(function(e) {
                    var a = n.resExport(e);
                    t.ifChangeStartDate(a), wx.setStorageSync("payTime", a);
                }) : t.ifChangeStartDate(e.data);
            }
        }), t.setData({
            tradeAll: !1,
            inputValue: "",
            projects: a,
            firstTradeId: [],
            secondTradeId: [],
            area: c,
            getCity: s,
            getCounty: r,
            allTrade: [ "请选择" ],
            allTradeId: [],
            areaAll: !1,
            chooseProvince: [ "省" ],
            chooseProvinceId: [],
            chooseCity: [ "市" ],
            chooseCityId: [],
            chooseCounty: [ "区" ],
            chooseCountyId: [],
            ifCountyUse: !1,
            ifCityUse: !1,
            tradeColor: "#C7C7CC",
            areaColor: "#000000",
            cityColor: "#C7C7CC",
            countyColor: "#C7C7CC",
            scaleMin: "最低",
            scaleMax: "最高",
            scaleMinData: 0,
            scaleMaxData: 9999,
            cooperationMin: "最低",
            cooperationMax: "最高",
            cooperationMinData: 0,
            cooperationMaxData: 9999,
            endDate: i.endFormatTime(new Date()),
            projecttypes: h,
            projecttypeId: 0,
            investmentList: l,
            investmentId: [],
            purchase: d,
            purchaseId: "",
            subject: p,
            subjectId: [],
            openAdvertising: !1
        });
    },
    formCancel: function() {
        this.setData({
            isShowproList: !0
        });
    },
    searchtypes: function(e) {
        var t = e.target.dataset.index, a = this.data.projecttypes, i = a[t];
        if (i.checked) i.checked = !1, this.setData({
            projecttypeId: 0
        }); else {
            for (var n = 0; n < a.length; n++) a[n].checked = !1;
            i.checked = !0, this.setData({
                projecttypeId: i.id
            });
        }
        a.splice(t, 1, i), this.setData({
            projecttypes: a
        });
    },
    searchInvestment: function(e) {
        var t = e.target.dataset.index, a = this.data.investmentList, i = this.data.investmentId, o = a[t];
        n.searchReport(a, o, t, !0), i = [];
        for (var s = 0; s < a.length; s++) a[s].checked && i.push(a[s].id);
        i = a.length == i.length ? [] : i, this.setData({
            investmentList: a,
            investmentId: i
        });
    },
    searchPurchase: function(e) {
        var t = e.target.dataset.index, a = this.data.purchase, i = a[t];
        if (i.checked) i.checked = !1, this.setData({
            purchaseId: ""
        }); else {
            for (var n = 0; n < a.length; n++) a[n].checked = !1;
            i.checked = !0, this.setData({
                purchaseId: i.id
            });
        }
        a.splice(t, 1, i), this.setData({
            purchase: a
        });
    },
    purchaseMore: function(e) {
        "收起" == e.target.dataset.name ? this.setData({
            purchaseMore: "更多",
            purchaseHeighe: "80rpx",
            purchaseImg: "more_down.png"
        }) : this.setData({
            purchaseMore: "收起",
            purchaseHeighe: "auto",
            purchaseImg: "more_up.png"
        });
    },
    searchReport: function(e) {
        var t = e.target.dataset.index, a = this.data.report, i = a[t], o = this.data.reportId;
        n.searchReport(a, i, t, !0), o = [];
        for (var s = 0; s < a.length; s++) a[s].checked && o.push(a[s].id);
        this.setData({
            report: a,
            reportId: o
        });
    },
    reportMore: function(e) {
        "收起" == e.target.dataset.name ? this.setData({
            reportMore: "更多",
            reportHeighe: "80rpx",
            reportImg: "more_down.png"
        }) : this.setData({
            reportMore: "收起",
            reportHeighe: "auto",
            reportImg: "more_up.png"
        });
    },
    searchPattern: function(e) {
        var t = e.target.dataset.index, a = this.data.pattern, i = this.data.patternId, o = a[t];
        n.searchReport(a, o, t, !0), i = [];
        for (var s = 0; s < a.length; s++) a[s].checked && i.push(a[s].id);
        this.setData({
            pattern: a,
            patternId: i
        });
    },
    patternMore: function(e) {
        "收起" == e.target.dataset.name ? this.setData({
            patternMore: "更多",
            patternHeighe: "80rpx",
            patternImg: "more_down.png"
        }) : this.setData({
            patternMore: "收起",
            patternHeighe: "auto",
            patternImg: "more_up.png"
        });
    },
    searchSubject: function(e) {
        var t = e.target.dataset.index, a = this.data.subject, i = this.data.subjectId, o = a[t];
        n.searchReport(a, o, t, !0), i = [];
        for (var s = 0; s < a.length; s++) a[s].checked && i.push(a[s].id);
        this.setData({
            subject: a,
            subjectId: i
        });
    },
    subjectMore: function(e) {
        "收起" == e.target.dataset.name ? this.setData({
            subjectMore: "更多",
            subjectHeighe: "80rpx",
            subjectImg: "more_down.png"
        }) : this.setData({
            subjectMore: "收起",
            subjectHeighe: "auto",
            subjectImg: "more_up.png"
        });
    },
    openAdvertising: function() {
        this.data.openAdvertising ? this.setData({
            openAdvertising: !1
        }) : this.setData({
            openAdvertising: !0
        });
    },
    closeAdvertising: function() {
        this.setData({
            openAdvertising: !1
        });
    },
    toRechargePage: function() {
        n.toPaymentPage(o);
    },
    getImage: function() {
        var e = this, t = {
            key: "5be00906b33c6"
        };
        o.getList("GET", "ad/position", t).then(function(t) {
            if ("000000" == t.data.code) {
                var a = t.data.data.startTime, i = t.data.data.endTime, n = Date.parse(new Date()) / 1e3;
                if (a <= n && n <= i) {
                    if ("images" === t.data.data.content.type) {
                        var o = t.data.data.content.value;
                        e.setData({
                            imageContent: o[0],
                            imageIcon: t.data.data.icon,
                            showImage: !0
                        });
                    }
                } else e.setData({
                    imageIcon: "",
                    showImage: !1
                });
            }
        });
    }
});
require("../../../vendor/qcloud-weapp-client-sdk/index.js");

var e = require("../../../utils/api.js"), t = require("../../../utils/commin.js"), a = require("../../../wxParse/wxParse.js");

Page({
    data: {
        LABLEONE: "项目中标",
        LABLETOW: "资审中标",
        LABLETHREE: "资审",
        LABLEFOUR: "采购",
        info: {},
        data: [],
        project_name: "",
        loadHidden: !0,
        id: "",
        province: "",
        city: "",
        town: "",
        areaName: "",
        investment: "",
        region: "",
        cooperation: "",
        build: "",
        operate: "",
        runPattern: "",
        enteredTreasury: "",
        isfeedback: !1,
        feedbackValue: "",
        cache_id: "",
        recentProject: "false",
        option: "",
        state: "",
        collectionName: "收藏",
        isCollection: !1,
        isShowCollection: !0,
        showCompanyUrl: !1,
        companyInfo: ""
    },
    onShareAppMessage: function(e) {
        console.log("我点击的是转发");
        var a = this;
        return t.sharePage("项目详情", "/pages/project/details/details", "share=true&shareId=" + a.data.cache_id);
    },
    onShow: function() {
        var a = {
            page: "pages/project/details/details",
            des: "项目详情"
        };
        t.pageMonitoring(e, a);
    },
    onLoad: function(t) {
        wx.showShareMenu({
            withShareTicket: !0
        });
        var o = this, n = o.data.areaName, i = o.data.LABLEONE, r = o.data.LABLETOW, c = o.data.LABLETHREE, s = o.data.LABLEFOUR;
        if (t.share || 0) {
            console.log("从转发渠道打开");
            var l = t.shareId;
            "" != l ? (wx.setStorage({
                key: "cache_id",
                data: l
            }), o.setData({
                cache_id: l
            })) : l = wx.getStorageSync("cache_id"), e.getList("GET", "cache/get/" + l, "").then(function(e) {
                console.log("转发渠道发送请求------");
                var t = JSON.parse(e.data.data.cacheData);
                if (o.setData({
                    province: t.province,
                    city: t.city,
                    town: t.town,
                    areaName: t.areaName,
                    investment: t.investment,
                    region: t.region,
                    build: t.build,
                    cooperation: t.cooperation,
                    operate: t.operate,
                    data: t.data,
                    id: t.id,
                    option: t.option,
                    recentProject: t.recentProject,
                    isShowCollection: t.isShowCollection
                }), "true" == t.recentProject) if (t.option == c) {
                    o.setData({
                        state: "资格预审"
                    });
                    i = t.data[0].prequalification_notice || "";
                    a.wxParse("recentProjectInfo", "html", i, o, 0);
                } else if (t.option == s) {
                    o.setData({
                        state: "公开招标"
                    });
                    var n = t.data[0].open_bid_notice || "";
                    a.wxParse("recentProjectTenderInfo", "html", n, o, 0);
                } else if (t.option == r) {
                    o.setData({
                        state: "资格预审中标"
                    });
                    var i = t.data[0].prequalification_notice || "";
                    a.wxParse("recentProjectInfo", "html", i, o, 0);
                    var l = t.data[0].prequalification_bid_notice || "";
                    a.wxParse("recentProjectBidInfo", "html", l, o, 0);
                }
                var d = t.data[0].payment_method_detail || "";
                a.wxParse("mechanism", "html", d, o, 0);
                var p = t.data[0].project_survey || "";
                a.wxParse("info", "html", p, o, 0);
            });
        } else {
            console.log("不是转发渠道进来");
            var d = o.data.province, p = o.data.city, _ = o.data.town, h = "", m = "", u = "", f = {}, y = {};
            o.setData({
                loadHidden: !1,
                recentProject: t.recentProject,
                option: t.option || "",
                isShowCollection: t.isShowCollection
            }), "true" == t.recentProject ? (m = "project/projectShow", u = {
                id: t.id,
                option: o.data.option
            }) : (m = "project/show", u = {
                id: t.id
            }), e.getList("GET", m, u).then(function(l) {
                var m;
                if ("true" == t.recentProject && o.data.option != i) {
                    m = l.data.data.data;
                    for (w = 0; w < m.length; w++) if (h = m[w].project_name.length > 68 ? m[w].project_name.substring(0, 68) + "..." : m[w].project_name, 
                    o.setData({
                        project_name: h
                    }), l.data.data.option == c) {
                        o.setData({
                            state: "资格预审"
                        });
                        v = m[w].prequalification_notice || "";
                        a.wxParse("recentProjectInfo", "html", v, o, 0);
                    } else if (l.data.data.option == s) {
                        o.setData({
                            state: "公开招标"
                        });
                        var u = m[w].open_bid_notice || "";
                        a.wxParse("recentProjectTenderInfo", "html", u, o, 0);
                    } else if (l.data.data.option == r) {
                        o.setData({
                            state: "资格预审中标"
                        });
                        var v = m[w].prequalification_notice || "";
                        a.wxParse("recentProjectInfo", "html", v, o, 0);
                        var g = m[w].prequalification_bid_notice || "";
                        a.wxParse("recentProjectBidInfo", "html", g, o, 0);
                    }
                } else {
                    m = o.data.option == i ? l.data.data.data : l.data.data;
                    for (var w = 0; w < m.length; w++) {
                        h = m[w].project_name.length > 68 ? m[w].project_name.substring(0, 68) + "..." : m[w].project_name, 
                        o.setData({
                            project_name: h
                        });
                        for (S = 0; S < m[w].province.length; S++) d = m[w].province[S].name, o.setData({
                            province: d
                        }), y.province = d;
                        for (var j = 0; j < m[w].city.length; j++) p = m[w].city[j].name, o.setData({
                            city: p
                        }), y.city = p;
                        for (var P = 0; P < m[w].town.length; P++) _ = m[w].town[P].name, o.setData({
                            town: _
                        }), y.town = _;
                        if ("" == p || void 0 == p ? (o.setData({
                            areaName: d
                        }), y.areaName = n) : "" == _ || void 0 == _ ? (n = d + "-" + p, o.setData({
                            areaName: n
                        }), y.areaName = n) : (n = d + "-" + p + "-" + _, o.setData({
                            areaName: n
                        }), y.areaName = n), null == m[w].investment_scale || "" == m[w].investment_scale || void 0 == m[w].investment_scale || "0" == m[w].investment_scale) o.setData({
                            investment: m[w].investment_scale_ext
                        }), y.investment = x; else {
                            var x = null == m[w].investment_scale || "" == m[w].investment_scale ? "" : m[w].investment_scale;
                            o.setData({
                                investment: x
                            }), y.investment = x;
                        }
                        if (null == m[w].region_scale_ext || "" == m[w].region_scale_ext || void 0 == m[w].region_scale_ext) {
                            var D = null == m[w].region_scale || "" == m[w].region_scale ? "" : m[w].region_scale + "平方公里";
                            o.setData({
                                region: D
                            }), y.region = D;
                        } else o.setData({
                            region: null == m[w].region_scale ? "" : m[w].region_scale
                        }), y.region = null == m[w].region_scale ? "" : m[w].region_scale;
                        if (null == m[w].build_phase_ext || "" == m[w].build_phase_ext) {
                            var b = m[w].build_phase;
                            b = parseInt(b / 12) > 0 ? parseInt(b / 12) + "年" + (b % 12 == 0 ? "" : b % 12 + "月") : null == b || "" == b || "0" == b ? "" : b + "月", 
                            o.setData({
                                build: b
                            }), y.build = b;
                        } else o.setData({
                            build: null == m[w].build_phase_ext ? "" : m[w].build_phase_ext
                        }), y.build = null == m[w].build_phase_ext ? "" : m[w].build_phase_ext;
                        if (null == m[w].cooperation_phase_ext || "" == m[w].cooperation_phase_ext) {
                            var C = "未知" == m[w].cooperation_phase ? "" : m[w].cooperation_phase;
                            o.setData({
                                cooperation: C
                            }), y.cooperation = C;
                        } else o.setData({
                            cooperation: null == m[w].cooperation_phase_ext ? "" : m[w].cooperation_phase_ext
                        }), y.cooperation = null == m[w].cooperation_phase_ext ? "" : m[w].cooperation_phase_ext;
                        if (null == m[w].operate_phase_ext || "" == m[w].operate_phase_ext) {
                            var L = m[w].operate_phase;
                            L = parseInt(L / 12) > 0 ? parseInt(L / 12) + "年" + (L % 12 == 0 ? "" : L % 12 + "月") : null == L || "" == L || "0" == L ? "" : L + "月", 
                            o.setData({
                                operate: L
                            }), y.operate = L;
                        } else o.setData({
                            operate: m[w].operate_phase_ext
                        }), y.operate = m[w].operate_phase_ext;
                        if (m[w].bidCompany = [], m[w].company_single.length > 0) for (var S = 0; S < m[w].company_single.length; S++) m[w].bidCompany.push({
                            name: m[w].company_single[S].name,
                            tyc_id: m[w].company_single[S].tyc_id
                        });
                        if (m[w].view_company_project.length > 0) for (var T = 0; T < m[w].view_company_project.length; T++) m[w].bidCompany.push({
                            name: m[w].view_company_project[T].name,
                            tyc_id: m[w].view_company_project[T].tyc_id
                        });
                        if (m[w].runPattern = "", m[w].sys_dictionary_operation_pattern.length > 0) for (var k = 0; k < m[w].sys_dictionary_operation_pattern.length; k++) "" == m[w].runPattern ? m[w].runPattern = m[w].sys_dictionary_operation_pattern[k].value : m[w].runPattern = m[w].runPattern + "," + m[w].sys_dictionary_operation_pattern[k].value;
                        if (m[w].dictionary_payment = "", m[w].sys_dictionary_payment_method.length > 0) for (N = 0; N < m[w].sys_dictionary_payment_method.length; N++) "" == m[w].dictionary_payment ? m[w].dictionary_payment = m[w].sys_dictionary_payment_method[N].value : m[w].dictionary_payment = m[w].dictionary_payment + "," + m[w].sys_dictionary_payment_method[N].value;
                        if (m[w].isBid = "", m[w].bid.length > 0) for (var N = 0; N < m[w].bid.length; N++) "" == m[w].bid[N].name && "" == m[w].bid[N].value || (m[w].isBid = !0);
                        m[w].isCollection ? o.setData({
                            collectionName: "已收藏"
                        }) : o.setData({
                            collectionName: "收藏"
                        }), "" == m[w].stage || null == m[w].stage ? o.setData({
                            enteredTreasury: ""
                        }) : null != m[w].stage.project_type ? o.setData({
                            enteredTreasury: m[w].stage.project_type + "-" + m[w].stage.stage
                        }) : o.setData({
                            enteredTreasury: m[w].stage.stage
                        }), o.setData({
                            isCollection: m[w].isCollection
                        });
                        var I = m[w].payment_method_detail || "";
                        a.wxParse("mechanism", "html", I, o, 0);
                        var E = m[w].project_survey || "";
                        a.wxParse("info", "html", E, o, 0);
                    }
                }
                o.setData({
                    data: m,
                    loadHidden: !0,
                    id: t.id
                }), y.data = m, y.id = t.id, y.option = o.data.option, y.recentProject = o.data.recentProject, 
                y.isShowCollection = !1, f.cache_data = JSON.stringify(y), e.getList("POST", "cache/create", f).then(function(e) {
                    o.setData({
                        cache_id: e.data.data.id
                    });
                });
            });
        }
    },
    navigateTo: function() {
        wx.navigateBack();
    },
    feedbackProject: function() {
        var e = t.getProjectStory(this.data.id);
        this.setData({
            isfeedback: !0,
            feedbackValue: e.value
        });
    },
    feedbackClose: function() {
        this.setData({
            isfeedback: !1
        });
    },
    feedbackSubmit: function(a) {
        var o = this, n = a.detail.value, i = o.data.id;
        if ("" != n.feedback.replace(/^\s+|\s+$/g, "")) {
            var r = {
                feedback_content: n.feedback,
                project_id: i
            };
            wx.showToast({
                title: "正在提交",
                icon: "loading"
            }), e.getList("POST", "project/projectFeedback", r).then(function(e) {
                wx.hideLoading(), wx.showModal({
                    title: "提示",
                    content: "感谢您的支持与反馈！",
                    showCancel: !1,
                    success: function(e) {
                        e.confirm && (t.removeProjectStoryKey(o.data.id), o.setData({
                            isfeedback: !1
                        }));
                    }
                });
            });
        } else wx.showToast({
            title: "抱歉，纠正错误的信息不能为空",
            icon: "success",
            duration: 2e3
        });
    },
    feedbackKey: function(e) {
        "" != e.detail.value.replace(/^\s+|\s+$/g, "") && t.appendProjectStory("projectidFeedback", {
            proId: this.data.id,
            value: e.detail.value
        });
    },
    isCollection: function(t) {
        var a = this, o = this, n = o.data.id, i = (o.data.collectionName, {
            project_id: n
        }), r = o.data.isCollection;
        wx.setStorage({
            key: "keyRefresh",
            data: !0
        }), r ? e.getList("POST", "project/cancelProjectCollect", i).then(function(e) {
            "000000" == e.data.code && a.setData({
                collectionName: "收藏",
                isCollection: !1
            });
        }) : e.getList("GET", "project/projectCollect", i).then(function(e) {
            "000000" == e.data.code && a.setData({
                collectionName: "已收藏",
                isCollection: !0
            });
        });
    },
    clickCompany: function(e) {
        var t = e.currentTarget.dataset.name.tyc_id;
        null !== t && "" !== t ? this.setData({
            showCompanyUrl: !0,
            companyInfo: "https://www.tianyancha.com/company/" + t
        }) : wx.showToast({
            title: "暂无该公司信息",
            icon: "success",
            duration: 2e3
        });
    },
    copyUrl: function() {
        var e = this;
        wx.setClipboardData({
            data: e.data.companyInfo,
            success: function(t) {
                wx.showToast({
                    title: "链接已复制"
                }), e.setData({
                    showCompanyUrl: !1
                });
            }
        });
    },
    cancelCopy: function() {
        this.setData({
            showCompanyUrl: !1
        });
    }
});
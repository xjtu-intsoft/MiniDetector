var t = require("../../../utils/api.js"), e = require("../../../utils/commin.js");

Page({
    data: {
        newsList: [],
        resultNum: "加载中...",
        moreHidden: "none",
        loadFinished: !1,
        loadMore: "loadMore",
        toastHidden: !0,
        noNews: "",
        newProjrct: "",
        loadHidden: !0,
        isload: !0,
        page: 1,
        isEmpty: !1,
        isShowCollection: !0,
        scroollHeight: 0
    },
    onLoad: function(t) {
        var e = this;
        wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    scroollHeight: t.windowHeight
                });
            }
        }), e.getProjectList();
    },
    onShow: function() {
        var a = this, o = {
            page: "pages/project/proCollectionList/proCollectionList",
            des: "项目查询列表"
        };
        e.pageMonitoring(t, o), wx.getStorage({
            key: "keyRefresh",
            success: function(t) {
                t.data && (a.setData({
                    newsList: [],
                    page: 1,
                    loadFinished: !1,
                    loadMore: "loadMore"
                }), a.getProjectList());
            }
        });
    },
    getProjectList: function() {
        var a = this, o = a.data.page, s = {
            page: o
        };
        a.setData({
            loadHidden: !1
        }), t.getList("GET", "project/projectCollectList", s).then(function(t) {
            if ("000000" === t.data.code) {
                var s = t.data.data.data || "", n = a.data.newsList.concat(s);
                s.length < 1 && o > 1 ? a.setData({
                    toastHidden: !1,
                    noNews: "没有更多",
                    moreHidden: "none"
                }) : s.length < 1 && 1 == o ? a.setData({
                    moreHidden: "none",
                    newsList: [],
                    isEmpty: !0
                }) : (n = e.projectListValue(n), s.length >= 1 && s.length < 10 && 1 == o ? a.setData({
                    moreHidden: "none"
                }) : a.setData({
                    moreHidden: ""
                }), a.setData({
                    newsList: n,
                    page: o,
                    resultNum: "共收藏" + t.data.data.total + "个项目"
                })), a.setData({
                    loadHidden: !0
                });
            } else wx.showModal({
                title: "登录提示",
                content: "请在“个人中心”登录后再查询数据",
                showCancel: !0,
                cancelText: "取消",
                confirmText: "个人中心",
                success: function(t) {
                    wx.setStorage({
                        key: "show_useinfo",
                        data: !1
                    }), t.confirm ? wx.switchTab({
                        url: "../../personalCenterHome/personalCenterHome"
                    }) : t.cancel;
                }
            }), a.setData({
                loadHidden: !0
            });
        });
    },
    loadMore: function() {
        var t = this.data.page;
        this.setData({
            page: t + 1
        }), this.getProjectList();
    },
    toastChange: function() {
        this.data.newsList.length > 1 && this.setData({
            loadFinished: !0
        }), this.setData({
            toastHidden: !0,
            loadMore: ""
        });
    },
    loadDetails: function(t) {
        var e = t.currentTarget.dataset.id, a = this.data.isShowCollection, o = t.currentTarget.dataset.recentproject;
        this.setData({
            moreHidden: "none"
        }), wx.navigateTo({
            url: "/pages/project/details/details?id=" + e + "&&recentProject=" + o + "&&isShowCollection=" + a
        });
    }
});
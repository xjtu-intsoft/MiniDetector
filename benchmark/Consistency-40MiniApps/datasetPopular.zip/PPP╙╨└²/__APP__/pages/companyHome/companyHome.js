var e = require("../../utils/wxSearch/wxSearch.js"), a = (require("../../vendor/qcloud-weapp-client-sdk/index.js"), 
require("../../utils/api.js")), t = require("../../utils/commin.js"), n = require("../../utils/util.js");

getApp();

Page({
    data: {
        loadHidden: !0,
        toastHidden: !0,
        moreHidden: "none",
        loadFinished: !1,
        loadMore: "loadMore",
        noValue: 1,
        chooseNum: 2,
        newCompany: "暂无数据",
        page: 1,
        newsList: [],
        noNews: "没有符合条件的信息",
        cache_id: "",
        isShowCollection: !0,
        isShare: !1,
        scroollHeight: 0,
        imageIcon: "",
        imageContent: "",
        startTime: "",
        endTime: "",
        showImage: !1
    },
    onShareAppMessage: function(e) {
        console.log("我点击的是转发");
        var a = this;
        return t.sharePage("企业分析", "/pages/companyHome/companyHome", "share=true&shareId=" + a.data.cache_id);
    },
    onLoad: function(t) {
        o = this;
        if (wx.showShareMenu({
            withShareTicket: !0
        }), wx.setStorage({
            key: "keyRefresh",
            data: !1
        }), wx.getSystemInfo({
            success: function(e) {
                o.setData({
                    scroollHeight: e.windowHeight
                });
            }
        }), t.share || 0) {
            console.log("从转发渠道打开"), o.setData({
                isShare: !0
            }), e.init(o, 60);
            var n = t.shareId || "";
            "" != n ? (wx.setStorage({
                key: "cache_id",
                data: n
            }), o.setData({
                cache_id: n
            })) : n = wx.getStorageSync("cache_id"), a.getList("GET", "cache/get/" + n, "").then(function(e) {
                console.log("转发渠道发送请求------"), console.log(e), console.log("上面是请求的数据"), console.log(e.data.data.cacheData), 
                console.log("这是取出来的data");
                var a = JSON.parse(e.data.data.cacheData), t = o.data.wxSearchData;
                t.value = a.input_value, o.setData({
                    wxSearchData: t,
                    page: a.page,
                    newsList: a.newsList,
                    newCompany: a.newCompany,
                    moreHidden: a.moreHidden
                });
            });
        } else {
            console.log("不是转发渠道进来");
            var o = this;
            e.init(o, 60);
            var i = {}, s = {};
            s.input_value = "", s.page = o.data.page, s.newCompany = "暂无数据", s.newsList = [], 
            s.moreHidden = "none", i.cache_data = JSON.stringify(s), console.log("获取分享内容"), 
            a.getList("POST", "cache/create", i).then(function(e) {
                o.setData({
                    cache_id: e.data.data.id
                });
            });
        }
    },
    onShow: function() {
        var e = this, o = e.data.wxSearchData.value || "";
        this.getImage(), wx.getStorage({
            key: "payTime",
            success: function(e) {
                console.log("已缓存"), t.memberDateHint(e.data, n);
            },
            fail: function() {
                console.log("未缓存"), a.getList("GET", "user/info", "").then(function(e) {
                    var a = t.resExport(e);
                    wx.setStorageSync("payTime", a), t.memberDateHint(a, n);
                });
            }
        }), wx.getStorage({
            key: "keyRefresh",
            success: function(a) {
                a.data && ("" != o.replace(/^\s+|\s+$/g, "") && (e.setData({
                    newsList: [],
                    page: 0,
                    loadFinished: !1,
                    loadMore: "loadMore",
                    moreHidden: "none"
                }), e.wxSearchFn()), wx.setStorage({
                    key: "keyRefresh",
                    data: !1
                }));
            }
        });
        var i = {
            page: "pages/companyHome/companyHome",
            des: "企业分析"
        };
        t.pageMonitoring(a, i);
    },
    wxSearchFn: function(t) {
        var n = this, o = n.data.wxSearchData.value || "";
        if ("" == o.replace(/^\s+|\s+$/g, "")) n.setData({
            loadFinished: !1,
            loadMore: "loadMore"
        }), wx.showModal({
            title: "提示",
            content: "查询条件不能为空",
            showCancel: !1,
            success: function(e) {
                e.confirm && console.log("用户点击确定");
            }
        }); else {
            n.setData({
                loadHidden: !1,
                isShare: !1,
                loadFinished: !1,
                loadMore: "loadMore"
            });
            var i = {
                input_value: o,
                page: 1
            };
            a.getList("GET", "project/enterprise", i).then(function(e) {
                if ("000000" === e.data.code) {
                    var t = e.data.data.data || "";
                    t.length < 1 ? n.setData({
                        toastHidden: !1,
                        moreHidden: "none",
                        newsList: [],
                        newCompany: "共有关0条搜索结果"
                    }) : t.length >= 1 && t.length < 10 ? n.setData({
                        newsList: t,
                        page: 1,
                        moreHidden: "none",
                        newCompany: "共有关" + e.data.data.total + "条搜索结果"
                    }) : n.setData({
                        newsList: t,
                        page: 1,
                        moreHidden: "",
                        newCompany: "共有关" + e.data.data.total + "条搜索结果"
                    }), n.setData({
                        isShowCollection: !0
                    });
                    var i = {}, s = {};
                    s.input_value = o, s.page = 1, s.newCompany = n.data.newCompany, s.newsList = n.data.newsList, 
                    s.moreHidden = n.data.moreHidden, i.cache_data = JSON.stringify(s), console.log("获取分享内容"), 
                    a.getList("POST", "cache/create", i).then(function(e) {
                        n.setData({
                            cache_id: e.data.data.id
                        });
                    });
                } else wx.showModal({
                    title: "登录提示",
                    content: "请在“个人中心”登录后再查询数据",
                    showCancel: !0,
                    cancelText: "取消",
                    confirmText: "个人中心",
                    success: function(e) {
                        wx.setStorage({
                            key: "show_useinfo",
                            data: !1
                        }), e.confirm ? wx.switchTab({
                            url: "../../pages/personalCenterHome/personalCenterHome"
                        }) : e.cancel;
                    }
                });
            }), setTimeout(n.loadChange, 100), e.wxSearchAddHisKey(n);
        }
    },
    wxSerchFocus: function(a) {
        var t = this;
        e.wxSearchFocus(a, t);
    },
    wxSearchBlur: function(a) {
        var t = this;
        e.wxSearchBlur(a, t);
        var n = t.data.wxSearchData;
        t.data.noValue;
        n.value ? t.setData({
            noValue: 0
        }) : t.setData({
            noValue: 1
        });
    },
    wxSearchKeyTap: function(a) {
        var t = this;
        e.wxSearchKeyTap(a, t);
    },
    wxSearchDeleteKey: function(a) {
        var t = this;
        e.wxSearchDeleteKey(a, t);
    },
    wxSearchDeleteAll: function(a) {
        var t = this;
        e.wxSearchDeleteAll(t);
    },
    wxSearchTap: function(a) {
        var t = this;
        e.wxSearchHiddenPancel(t);
        var n = t.data.wxSearchData;
        t.data.noValue;
        n.value ? t.setData({
            noValue: 0
        }) : t.setData({
            noValue: 1
        });
    },
    textEmpty: function() {
        var e = this, a = e.data.wxSearchData;
        0 == e.data.noValue && (a.value = null, e.setData({
            wxSearchData: a,
            noValue: 1
        }));
    },
    loadMore: function() {
        var e = this, t = e.data.wxSearchData.value, n = e.data.page + 1;
        e.setData({
            loadHidden: !1
        });
        var o = {
            input_value: t,
            page: n
        };
        a.getList("GET", "project/enterprise", o).then(function(a) {
            var t = a.data.data.data || "";
            if (t.length < 1) e.setData({
                noNews: "没有更多",
                moreHidden: "none",
                toastHidden: !1
            }); else {
                var n = e.data.newsList.concat(t);
                e.setData({
                    newsList: n,
                    moreHidden: ""
                });
            }
        }), e.setData({
            page: n
        }), setTimeout(e.loadChange, 100);
    },
    toastChange: function() {
        this.data.newsList.length > 1 && this.setData({
            loadFinished: !0
        }), this.setData({
            toastHidden: !0,
            loadMore: ""
        });
    },
    loadChange: function() {
        this.setData({
            loadHidden: !0
        });
    },
    loadCollection: function() {
        var e = {
            url: "/pages/company/companyCollectionList/companyCollectionList"
        };
        wx.navigateTo(e);
    },
    loadDetails: function(e) {
        var a = e.currentTarget.dataset.id, t = e.currentTarget.dataset.iscollection, n = this.data.isShowCollection;
        wx.navigateTo({
            url: "../../pages/company/companyDetails/companyDetails?id=" + a + "&&isCollection=" + t + "&&isShowCollection=" + n
        });
    },
    openAdvertising: function() {
        this.data.openAdvertising ? this.setData({
            openAdvertising: !1
        }) : this.setData({
            openAdvertising: !0
        });
    },
    closeAdvertising: function() {
        this.setData({
            openAdvertising: !1
        });
    },
    toRechargePage: function() {
        t.toPaymentPage(a);
    },
    getImage: function() {
        var e = this, t = {
            key: "5be03032b0323"
        };
        a.getList("GET", "ad/position", t).then(function(a) {
            if ("000000" == a.data.code) {
                var t = a.data.data.startTime, n = a.data.data.endTime, o = Date.parse(new Date()) / 1e3;
                if (t <= o && o <= n) {
                    if ("images" === a.data.data.content.type) {
                        var i = a.data.data.content.value;
                        e.setData({
                            imageContent: i[0],
                            imageIcon: a.data.data.icon,
                            showImage: !0
                        });
                    }
                } else e.setData({
                    imageIcon: "",
                    showImage: !1
                });
            }
        });
    }
});
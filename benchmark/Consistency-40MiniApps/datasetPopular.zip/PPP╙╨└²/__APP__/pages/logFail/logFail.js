var e = require("../../vendor/qcloud-weapp-client-sdk/index.js"), t = (require("../../utils/util.js"), 
require("../../utils/api.js"));

Page({
    data: {
        defaultSize: "default",
        primarySize: "default",
        warnSize: "default",
        disabled: !1,
        plain: !1,
        loading: !1,
        options: "",
        loadHidden: !0
    },
    onShow: function() {},
    bindGetUserInfo: function(t) {
        e.setUserInfos(t.detail), this.setData({
            loadHidden: !1
        }), this.login();
    },
    onLoad: function(e) {
        this.data.options = e;
    },
    login: function() {
        var n = this, o = n.data.options;
        e.setLoginUrl(t.getBaseUrl() + "/user/login"), e.login({
            method: "POST",
            success: function(e) {
                console.log("登录成功", e), wx.setStorageSync("userInfo", e);
                var i = n.data;
                n.getInfo(o, i), setTimeout(function() {
                    t.getList("GET", "goods/discount", "").then(function(e) {
                        "000000" == e.data.code ? wx.setStorage({
                            key: "discountTitle",
                            data: e.data.data.title
                        }) : console.log("获取自定义标题失败"), n.setData({
                            loadHidden: !0
                        }), wx.redirectTo({
                            url: "../../pages/projectHome/projectHome"
                        });
                    });
                }, 1e3);
            },
            fail: function(e) {
                n.setData({
                    loadHidden: !0
                }), wx.showToast({
                    title: "授权失败！",
                    icon: "none",
                    duration: 2e3
                });
            }
        });
    },
    getInfo: function(e, n) {
        t.getList("GET", "user/info", "").then(function(o) {
            wx.setStorageSync("user_uniq_token", o.data.data.user_uniq_token), wx.setStorageSync("channel_id", o.data.data.channel_id);
            var i = Commin.resExport(o);
            wx.setStorageSync("payTime", i), console.log("已经存储user_uniq_token+payTime+channel_id"), 
            wx.getShareInfo({
                shareTicket: e.shareTicket,
                complete: function(o) {
                    if (1044 == e.scene) {
                        var i = {};
                        i.encryptedData = o.encryptedData, i.iv = o.iv, i.userToken = e.query.userToken, 
                        i.scene = e.scene, i.shareTime = e.query.shareTime, n.shareData = JSON.stringify(i);
                    }
                    t.getList("POST", "user/init", n).then(function(e) {
                        console.log(e);
                    });
                }
            });
        });
    }
});
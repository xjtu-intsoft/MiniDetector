var a = require("../../../utils/wxcharts-min.js"), e = require("../../../utils/api.js"), t = require("../../../utils/commin.js"), r = (getApp(), 
null);

Page({
    data: {
        allTrade: [],
        allArea: [],
        startTime: "",
        endTime: "",
        tradeMore: "更多",
        tradeMoreImg: "more_down.png",
        tradeMoreHeight: "115rpx",
        ifTradeMore: !1,
        areaMore: "更多",
        areaMoreImg: "more_down.png",
        areaMoreHeight: "115rpx",
        ifAreaMore: !1,
        chartWidth: "320",
        screenWidth: "",
        yieldPageX: "",
        yieldAlreadyX: "",
        yieldNum: "",
        sampleNum: "",
        countRed: [],
        createSimulation: {}
    },
    touchHandler: function(a) {
        r.showToolTip(a, {});
    },
    createSimulationData: function() {
        var a = this.data.createSimulation;
        return {
            categories: a.categories,
            data: a.data
        };
    },
    onShareAppMessage: function(a) {
        console.log("我点击的是转发");
        var e = this;
        return t.sharePage("行业收益率水平变化", "/pages/charts/chartsEarnings/chartsEarnings", "share=true&shareId=" + e.data.cache_id);
    },
    tradeMore: function(a) {
        "更多" == a.target.dataset.name ? this.setData({
            tradeMore: "收起",
            tradeMoreImg: "more_up.png",
            tradeMoreHeight: "auto"
        }) : this.setData({
            tradeMore: "更多",
            tradeMoreImg: "more_down.png",
            tradeMoreHeight: "115rpx"
        });
    },
    areaMore: function(a) {
        "更多" == a.target.dataset.name ? this.setData({
            areaMore: "收起",
            areaMoreImg: "more_up.png",
            areaMoreHeight: "auto"
        }) : this.setData({
            areaMore: "更多",
            areaMoreImg: "more_down.png",
            areaMoreHeight: "115rpx"
        });
    },
    yieldSlideStart: function(a) {
        var e = a.touches[0].pageX - this.data.yieldNum;
        this.setData({
            yieldPageX: e
        });
    },
    yieldSlideMove: function(a) {
        var e = a.touches[0].pageX, t = this.data.yieldPageX, r = this.data.screenWidth - this.data.chartWidth, i = e - t;
        i >= 0 ? i = 0 : i <= r && (i = r), this.setData({
            yieldNum: i
        });
    },
    onShow: function() {
        var a = {
            page: "pages/charts/chartsEarnings/chartsEarnings",
            des: "行业收益率"
        };
        t.pageMonitoring(e, a);
    },
    onLoad: function(a) {
        var t = this;
        wx.showShareMenu({
            withShareTicket: !0
        });
        var r = this;
        if (a.share || 0) {
            console.log("从转发渠道打开");
            var i = a.shareId;
            "" != i ? (wx.setStorage({
                key: "cache_id",
                data: i
            }), this.setData({
                cache_id: i
            })) : i = wx.getStorageSync("cache_id"), e.getList("GET", "cache/get/" + i, "").then(function(a) {
                console.log("转发渠道发送请求------"), console.log(a);
                var e = JSON.parse(a.data.data.cacheData), i = 40 * e.createSimulation.data.length;
                t.setData({
                    chartWidth: i
                }), r.setData({
                    createSimulation: e.createSimulation,
                    allTrade: e.allTrade,
                    allArea: e.allArea,
                    startTime: e.startTime,
                    endTime: e.endTime,
                    countRed: e.countRed,
                    sampleNum: e.sampleNum
                });
            }).then(function(a) {
                r.canvas(r);
            });
        } else {
            console.log("不是转发渠道进来");
            var s = a.allTrade, d = a.allArea, n = a.startTime, o = a.endTime, l = JSON.parse(a.res), h = [], u = [];
            h = s.split(","), u = d.split(","), h.length > 8 ? this.setData({
                ifTradeMore: !0,
                tradeMoreHeight: "115rpx"
            }) : this.setData({
                ifTradeMore: !1,
                tradeMoreHeight: "auto"
            }), u.length > 8 ? this.setData({
                ifAreaMore: !0,
                areaMoreHeight: "115rpx"
            }) : this.setData({
                ifAreaMore: !1,
                areaMoreHeight: "auto"
            }), this.setData({
                allTrade: h,
                allArea: u,
                startTime: n,
                endTime: o
            });
            var c = 40 * l.result.data.length;
            this.setData({
                chartWidth: c
            });
            for (var g = [], m = [], p = [], f = l.result.effective_sample_size, M = 0; M < l.result.data.length; M++) 0 == M ? (g.push(l.result.data[M].yield_data), 
            0 == l.result.data[M].yield_data && p.push(M + 1)) : M == l.result.data.length - 1 ? (g.push(l.result.data[M].yield_data), 
            0 == l.result.data[M].yield_data && p.push(M + 1)) : 0 == l.result.data[M].yield_data ? (g.push((l.result.data[M - 1].yield_data + l.result.data[M + 1].yield_data) / 2), 
            p.push(M + 1)) : g.push(l.result.data[M].yield_data), 0 == M ? m.push(l.result.data[M].month) : "01" == l.result.data[M].month.substr(5, 2) ? m.push(l.result.data[M].month) : m.push(l.result.data[M].month.substr(5, 2));
            var T = new function(a, e) {
                this.categories = a, this.data = e;
            }(m, g);
            this.setData({
                createSimulation: T,
                sampleNum: f,
                countRed: p
            }), this.canvas(r);
            var S = {}, y = {};
            y.createSimulation = r.data.createSimulation, y.allTrade = r.data.allTrade, y.allArea = r.data.allArea, 
            y.startTime = r.data.startTime, y.endTime = r.data.endTime, y.countRed = r.data.countRed, 
            y.sampleNum = r.data.sampleNum, S.cache_data = JSON.stringify(y), e.getList("POST", "cache/create", S).then(function(a) {
                r.setData({
                    cache_id: a.data.data.id
                });
            });
        }
    },
    canvas: function(e) {
        var t = "", i = wx.getSystemInfoSync().windowWidth, s = e.data.chartWidth;
        t = i > s ? i : s, e.setData({
            screenWidth: i,
            chartWidth: t
        });
        var d = e.createSimulationData();
        r = new a({
            canvasId: "lineCanvas",
            type: "line",
            categories: d.categories,
            animation: !1,
            background: "#f5f5f5",
            series: [ {
                name: "收益率",
                data: d.data,
                format: function(a, e) {
                    return a.toFixed(2) + "%";
                }
            } ],
            xAxis: {
                disableGrid: !0
            },
            yAxis: {
                title: "收益率 (%)",
                format: function(a) {
                    return a.toFixed(0);
                },
                min: 0
            },
            width: t,
            height: 200,
            dataLabel: !0,
            dataPointShape: !0,
            extra: {
                lineStyle: "default"
            },
            legend: !1,
            countRed: e.data.countRed
        });
    }
});
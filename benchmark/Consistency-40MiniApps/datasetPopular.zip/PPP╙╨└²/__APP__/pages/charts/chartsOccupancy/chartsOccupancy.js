var a = require("../../../utils/api.js"), e = require("../../../utils/commin.js");

Page({
    data: {
        allTrade: [],
        allArea: [],
        startTime: "",
        endTime: "",
        tradeMore: "更多",
        tradeMoreImg: "more_down.png",
        tradeMoreHeight: "115rpx",
        ifTradeMore: !1,
        areaMore: "更多",
        areaMoreImg: "more_down.png",
        areaMoreHeight: "115rpx",
        ifAreaMore: !1,
        bgColor: [ "#EF6D99", "#FD856B", "#f2b075", "#EFD70C", "#C1E675", "#14CD78", "#00afc8", "#2097F5", "#5EB0DB", "#8091CB" ],
        participationNum: [],
        participationScale: [],
        occupyNum: [],
        occupyscale: [],
        isParticipationNum: !1,
        isParticipationScale: !1,
        isOccupancyNum: !1,
        isOccupancyScale: !1,
        cache_id: ""
    },
    onShareAppMessage: function(a) {
        console.log("我点击的是转发");
        var t = this;
        return e.sharePage("行业占有率排名", "/pages/charts/chartsOccupancy/chartsOccupancy", "share=true&shareId=" + t.data.cache_id);
    },
    tradeMore: function(a) {
        "更多" == a.target.dataset.name ? this.setData({
            tradeMore: "收起",
            tradeMoreImg: "more_up.png",
            tradeMoreHeight: "auto"
        }) : this.setData({
            tradeMore: "更多",
            tradeMoreImg: "more_down.png",
            tradeMoreHeight: "115rpx"
        });
    },
    areaMore: function(a) {
        "更多" == a.target.dataset.name ? this.setData({
            areaMore: "收起",
            areaMoreImg: "more_up.png",
            areaMoreHeight: "auto"
        }) : this.setData({
            areaMore: "更多",
            areaMoreImg: "more_down.png",
            areaMoreHeight: "115rpx"
        });
    },
    onLoad: function(e) {
        var t = this;
        if (wx.showShareMenu({
            withShareTicket: !0
        }), e.share || 0) {
            console.log("从转发渠道打开");
            var r = e.shareId;
            "" != r ? (wx.setStorage({
                key: "cache_id",
                data: r
            }), this.setData({
                cache_id: r
            })) : r = wx.getStorageSync("cache_id"), a.getList("GET", "cache/get/" + r, "").then(function(a) {
                console.log("转发渠道发送请求------"), console.log(a), console.log("上面是请求的数据"), console.log(a.data.data.cacheData), 
                console.log("这是取出来的data");
                var e = JSON.parse(a.data.data.cacheData);
                t.setData({
                    participationNum: e.participationNum,
                    participationScale: e.participationScale,
                    occupyNum: e.occupyNum,
                    occupyscale: e.occupyscale,
                    allTrade: e.allTrade,
                    allArea: e.allArea,
                    startTime: e.startTime,
                    endTime: e.endTime
                });
            });
        } else {
            var i = function(a, e, t, r) {
                this.companyTitle = a, this.contentWidth = e, this.companyNumber = t, this.bgColor = r;
            };
            console.log("不是转发渠道进来");
            var c = e.allTrade, o = e.allArea, n = e.startTime, s = e.endTime, l = JSON.parse(e.res), u = [], p = [], h = this;
            u = c.split(","), p = o.split(","), u.length > 8 ? this.setData({
                ifTradeMore: !0,
                tradeMoreHeight: "115rpx"
            }) : this.setData({
                ifTradeMore: !1,
                tradeMoreHeight: "auto"
            }), p.length > 8 ? this.setData({
                ifAreaMore: !0,
                areaMoreHeight: "115rpx"
            }) : this.setData({
                ifAreaMore: !1,
                areaMoreHeight: "auto"
            }), this.setData({
                allTrade: u,
                allArea: p,
                startTime: n,
                endTime: s,
                isParticipationNum: !1,
                isParticipationScale: !1,
                isOccupancyNum: !1,
                isOccupancyScale: !1
            });
            var d = [], m = [], g = [], y = [], _ = this.data.bgColor, M = l.result.industry_cy_num[0];
            if (0 != M.length) for (var f = M[0].total_num / .9, T = 0; T < M.length; T++) {
                var D = M[T].company_name, S = M[T].total_num, N = new i(D, x = M[T].total_num / f * 100 + "%", S, I = _[T]);
                d.push(N);
            } else this.setData({
                isParticipationNum: !0
            });
            var v = l.result.industry_cy_scale[0];
            if (0 != v.length) for (var w = v[0].total_scale / .9, T = 0; T < v.length; T++) {
                var D = v[T].company_name, S = v[T].total_scale, N = new i(D, x = v[T].total_scale / w * 100 + "%", S, I = _[T]);
                m.push(N);
            } else this.setData({
                isParticipationScale: !0
            });
            var O = l.result.industry_zy_num[0];
            if (0 != O) for (var A = O[0].total_num / .9, T = 0; T < O.length; T++) {
                var D = O[T].company_name, S = O[T].total_num, N = new i(D, x = O[T].total_num / A * 100 + "%", S, I = _[T]);
                g.push(N);
            } else this.setData({
                isOccupancyNum: !0
            });
            var H = l.result.industry_zy_scale[0];
            if (0 != H) for (var P = H[0].total_scale / .9, T = 0; T < H.length; T++) {
                var D = H[T].company_name, S = H[T].total_scale, x = H[T].total_scale / P * 100 + "%", I = _[T], N = new i(D, x, S, I);
                y.push(N);
            } else this.setData({
                isOccupancyScale: !0
            });
            this.setData({
                participationNum: d,
                participationScale: m,
                occupyNum: g,
                occupyscale: y
            });
            var C = {}, b = {};
            b.participationNum = h.data.participationNum, b.participationScale = h.data.participationScale, 
            b.occupyNum = h.data.occupyNum, b.occupyscale = h.data.occupyscale, b.allTrade = h.data.allTrade, 
            b.allArea = h.data.allArea, b.startTime = h.data.startTime, b.endTime = h.data.endTime, 
            C.cache_data = JSON.stringify(b), a.getList("POST", "cache/create", C).then(function(a) {
                h.setData({
                    cache_id: a.data.data.id
                });
            });
        }
    },
    onReady: function() {},
    onShow: function() {
        var t = {
            page: "pages/charts/chartsOccupancy/chartsOccupancy",
            des: "行业占有率"
        };
        e.pageMonitoring(a, t);
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
var a = require("../../../utils/wxcharts-min.js"), e = require("../../../utils/api.js"), t = require("../../../utils/commin.js"), r = (getApp(), 
null), s = null;

Page({
    data: {
        allTrade: [],
        allArea: [],
        startTime: "",
        endTime: "",
        tradeMore: "更多",
        tradeMoreImg: "more_down.png",
        tradeMoreHeight: "115rpx",
        ifTradeMore: !1,
        areaMore: "更多",
        areaMoreImg: "more_down.png",
        areaMoreHeight: "115rpx",
        ifAreaMore: !1,
        chartWidth: "320",
        screenWidth: "",
        numberPageX: "",
        numberAlreadyX: "",
        numberNum: "",
        scalePageX: "",
        scaleAlreadyX: "",
        scaleNum: "",
        chartsDealNumber: {},
        chartsDealScale: {},
        cache_id: "",
        projectNum: "_____",
        totalScale: "_____"
    },
    touchNumberHandler: function(a) {
        r.showToolTip(a, {});
    },
    touchScaleHandler: function(a) {
        s.showToolTip(a, {});
    },
    chartsDealNumberData: function() {
        var a = this.data.chartsDealNumber;
        return {
            categories: a.categories,
            data: a.data
        };
    },
    chartsDealScaleData: function() {
        var a = this.data.chartsDealScale;
        return {
            categories: a.categories,
            data: a.data
        };
    },
    onShareAppMessage: function(a) {
        console.log("我点击的是转发");
        var e = this;
        return t.sharePage("成交状况统计", "/pages/charts/chartsDeal/chartsDeal", "share=true&shareId=" + e.data.cache_id);
    },
    tradeMore: function(a) {
        "更多" == a.target.dataset.name ? this.setData({
            tradeMore: "收起",
            tradeMoreImg: "more_up.png",
            tradeMoreHeight: "auto"
        }) : this.setData({
            tradeMore: "更多",
            tradeMoreImg: "more_down.png",
            tradeMoreHeight: "115rpx"
        });
    },
    areaMore: function(a) {
        "更多" == a.target.dataset.name ? this.setData({
            areaMore: "收起",
            areaMoreImg: "more_up.png",
            areaMoreHeight: "auto"
        }) : this.setData({
            areaMore: "更多",
            areaMoreImg: "more_down.png",
            areaMoreHeight: "115rpx"
        });
    },
    onReady: function() {},
    numberSlideStart: function(a) {
        var e = a.touches[0].pageX - this.data.numberNum;
        this.setData({
            numberPageX: e
        });
    },
    numberSlideMove: function(a) {
        var e = a.touches[0].pageX, t = this.data.numberPageX, r = this.data.screenWidth - this.data.chartWidth, s = e - t;
        s >= 0 ? s = 0 : s <= r && (s = r), this.setData({
            numberNum: s
        });
    },
    scaleSlideStart: function(a) {
        var e = a.touches[0].pageX - this.data.scaleNum;
        this.setData({
            scalePageX: e
        });
    },
    scaleSlideMove: function(a) {
        var e = a.touches[0].pageX, t = this.data.scalePageX, r = this.data.screenWidth - this.data.chartWidth, s = e - t;
        s >= 0 ? s = 0 : s <= r && (s = r), this.setData({
            scaleNum: s
        });
    },
    onShow: function() {
        var a = {
            page: "pages/charts/chartsDeal/chartsDeal",
            des: "成交状况"
        };
        t.pageMonitoring(e, a);
    },
    onLoad: function(t) {
        function i(e) {
            var t = "", i = wx.getSystemInfoSync().windowWidth, n = e.data.chartWidth;
            t = i > n ? i : n, e.setData({
                screenWidth: i,
                chartWidth: t
            });
            var o = e.chartsDealNumberData();
            r = new a({
                canvasId: "chartsDealNumber",
                type: "line",
                categories: o.categories,
                animation: !1,
                background: "#f5f5f5",
                series: [ {
                    name: "数量",
                    data: o.data,
                    format: function(a, e) {
                        return a.toFixed(0) + "";
                    }
                } ],
                xAxis: {
                    disableGrid: !0
                },
                yAxis: {
                    title: "数量（个）",
                    format: function(a) {
                        return a.toFixed(0);
                    },
                    min: 0
                },
                width: t,
                height: 200,
                dataLabel: !0,
                dataPointShape: !0,
                extra: {
                    lineStyle: "default"
                },
                legend: !1
            });
            var l = e.chartsDealScaleData();
            s = new a({
                canvasId: "chartsDealScale",
                type: "line",
                categories: l.categories,
                animation: !1,
                background: "#f5f5f5",
                series: [ {
                    name: "规模",
                    data: l.data,
                    format: function(a, e) {
                        return a.toFixed(0) + "";
                    }
                } ],
                xAxis: {
                    disableGrid: !0
                },
                yAxis: {
                    title: "规模（亿元）",
                    format: function(a) {
                        return a.toFixed(0);
                    },
                    min: 0
                },
                width: t,
                height: 200,
                dataLabel: !0,
                dataPointShape: !0,
                extra: {
                    lineStyle: "default"
                },
                legend: !1
            });
        }
        var n = this;
        wx.showShareMenu({
            withShareTicket: !0
        });
        var o = this;
        if (t.share || 0) {
            console.log("从转发渠道打开");
            var l = t.shareId;
            "" != l ? (wx.setStorage({
                key: "cache_id",
                data: l
            }), this.setData({
                cache_id: l
            })) : l = wx.getStorageSync("cache_id"), e.getList("GET", "cache/get/" + l, "").then(function(a) {
                console.log("转发渠道发送请求------");
                var e = JSON.parse(a.data.data.cacheData), t = 30 * e.chartsDealNumber.data.length;
                n.setData({
                    chartWidth: t
                }), n.setData({
                    chartsDealNumber: e.chartsDealNumber,
                    chartsDealScale: e.chartsDealScale,
                    allTrade: e.allTrade,
                    allArea: e.allArea,
                    startTime: e.startTime,
                    endTime: e.endTime
                });
            }).then(function(a) {
                i(o);
            });
        } else {
            var c = function(a, e) {
                this.categories = a, this.data = e;
            };
            console.log("不是转发渠道进来");
            var h = t.allTrade, d = t.allArea, u = t.startTime, m = t.endTime, g = JSON.parse(t.res), p = [], D = [];
            this.projectCompanyNum(JSON.parse(t.toFormData)), p = h.split(","), D = d.split(","), 
            p.length > 8 ? this.setData({
                ifTradeMore: !0,
                tradeMoreHeight: "115rpx"
            }) : this.setData({
                ifTradeMore: !1,
                tradeMoreHeight: "auto"
            }), D.length > 8 ? this.setData({
                ifAreaMore: !0,
                areaMoreHeight: "115rpx"
            }) : this.setData({
                ifAreaMore: !1,
                areaMoreHeight: "auto"
            }), this.setData({
                allTrade: p,
                allArea: D,
                startTime: u,
                endTime: m
            });
            var f = 30 * g.result.length;
            this.setData({
                chartWidth: f
            });
            for (var S = [], _ = [], M = [], T = 0; T < g.result.length; T++) null == g.result[T].num_total && (g.result[T].num_total = 0), 
            null == g.result[T].investment_scale_total && (g.result[T].investment_scale_total = 0), 
            S.push(g.result[T].num_total), _.push(g.result[T].investment_scale_total), 0 == T ? M.push(g.result[T].month) : "01" == g.result[T].month.substr(5, 2) ? M.push(g.result[T].month) : M.push(g.result[T].month.substr(5, 2));
            var v = new c(M, S), b = new c(M, _);
            this.setData({
                chartsDealNumber: v,
                chartsDealScale: b
            }), i(o);
            var N = {}, x = {};
            x.chartsDealNumber = o.data.chartsDealNumber, x.chartsDealScale = o.data.chartsDealScale, 
            x.allTrade = o.data.allTrade, x.allArea = o.data.allArea, x.startTime = o.data.startTime, 
            x.endTime = o.data.endTime, N.cache_data = JSON.stringify(x), e.getList("POST", "cache/create", N).then(function(a) {
                o.setData({
                    cache_id: a.data.data.id
                });
            });
        }
    },
    projectCompanyNum: function(a) {
        var t = this, r = {
            start_time: a.start_time,
            end_time: a.end_time,
            industry: a.industry,
            region: a.region
        };
        e.getList("GET", "report/projectInfo", r).then(function(a) {
            var e = a.data.data[0];
            t.setData({
                projectNum: e.projectTotal,
                totalScale: parseInt(e.scaleSum)
            });
        });
    }
});
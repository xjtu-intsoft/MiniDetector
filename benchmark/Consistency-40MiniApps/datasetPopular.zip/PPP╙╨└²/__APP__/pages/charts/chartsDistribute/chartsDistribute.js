var a = require("../../../utils/wxcharts-min.js"), e = require("../../../utils/api.js"), t = require("../../../utils/commin.js"), r = (getApp(), 
null), i = null;

Page({
    data: {
        allTrade: [ "全部行业" ],
        allArea: [],
        startTime: "",
        endTime: "",
        tradeDistribute: [],
        tradeScale: [],
        areaMore: "更多",
        areaMoreImg: "more_down.png",
        areaMoreHeight: "115rpx",
        ifAreaMore: !1,
        sort: [ "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨", "⑩", "⑪", "⑫", "⑬", "⑭" ],
        cache_id: ""
    },
    onShareAppMessage: function(a) {
        console.log("我点击的是转发");
        var e = this;
        return t.sharePage("行业分布统计", "/pages/charts/chartsDistribute/chartsDistribute", "share=true&shareId=" + e.data.cache_id);
    },
    areaMore: function(a) {
        "更多" == a.target.dataset.name ? this.setData({
            areaMore: "收起",
            areaMoreImg: "more_up.png",
            areaMoreHeight: "auto"
        }) : this.setData({
            areaMore: "更多",
            areaMoreImg: "more_down.png",
            areaMoreHeight: "115rpx"
        });
    },
    onShow: function() {
        var a = {
            page: "pages/charts/chartsDistribute/chartsDistribute",
            des: "行业分布"
        };
        t.pageMonitoring(e, a);
    },
    onLoad: function(a) {
        var t = this;
        wx.showShareMenu({
            withShareTicket: !0
        });
        var r = this;
        if (a.share || 0) {
            console.log("从转发渠道打开");
            var i = a.shareId;
            "" != i ? (wx.setStorage({
                key: "cache_id",
                data: i
            }), this.setData({
                cache_id: i
            })) : i = wx.getStorageSync("cache_id"), console.log(i), e.getList("GET", "cache/get/" + i, "").then(function(a) {
                console.log("转发渠道发送请求------"), console.log(a), console.log("上面是请求的数据"), console.log(a.data.data.cacheData), 
                console.log("这是取出来的data");
                var e = JSON.parse(a.data.data.cacheData);
                t.setData({
                    tradeDistribute: e.tradeDistribute,
                    tradeScale: e.tradeScale,
                    allTrade: e.allTrade,
                    allArea: e.allArea,
                    startTime: e.startTime,
                    endTime: e.endTime
                });
            }).then(function(a) {
                r.canvas(r);
            });
        } else {
            console.log("不是转发渠道进来");
            var s = a.allArea, n = a.startTime, o = a.endTime, l = JSON.parse(a.res), d = [], c = [], h = [];
            (d = s.split(",")).length > 8 ? this.setData({
                ifAreaMore: !0,
                areaMoreHeight: "115rpx"
            }) : this.setData({
                ifAreaMore: !1,
                areaMoreHeight: "auto"
            });
            for (var u = 0, g = 0; g < l.result.length; g++) if (null != l.result[g].industry_name) {
                var m = {}, p = {};
                m.name = this.data.sort[u] + l.result[g].industry_name + "  ", m.data = l.result[g].num_total, 
                p.name = this.data.sort[u] + l.result[g].industry_name + "  ", p.data = l.result[g].investment_scale_total, 
                c.push(m), h.push(p), u++;
            }
            this.setData({
                allArea: d,
                startTime: n,
                endTime: o,
                tradeDistribute: c,
                tradeScale: h
            });
            var S = {}, D = {};
            D.tradeDistribute = r.data.tradeDistribute, D.tradeScale = r.data.tradeScale, D.allTrade = r.data.allTrade, 
            D.allArea = r.data.allArea, D.startTime = r.data.startTime, D.endTime = r.data.endTime, 
            S.cache_data = JSON.stringify(D), e.getList("POST", "cache/create", S).then(function(a) {
                r.setData({
                    cache_id: a.data.data.id
                });
            }), r.canvas(r);
        }
    },
    canvas: function(e) {
        var t = 320;
        try {
            t = wx.getSystemInfoSync().windowWidth;
        } catch (a) {
            console.error("getSystemInfoSync failed!");
        }
        r = new a({
            animation: !1,
            canvasId: "chartsDisNumber",
            type: "pie",
            series: e.data.tradeDistribute,
            width: t,
            height: 300,
            dataLabel: !0,
            disablePieStroke: !0
        }), i = new a({
            animation: !1,
            canvasId: "chartsDisScale",
            type: "pie",
            series: e.data.tradeScale,
            width: t,
            height: 300,
            dataLabel: !0,
            disablePieStroke: !0
        });
    }
});
function e(e, t, a) {
    return t in e ? Object.defineProperty(e, t, {
        value: a,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = a, e;
}

var t, a = require("../../utils/area-min.js"), i = require("../../utils/city-min.js"), o = (require("../../vendor/qcloud-weapp-client-sdk/index.js"), 
require("../../utils/api.js")), s = require("../../utils/util.js"), n = require("../../utils/commin.js");

getApp();

Page({
    data: (t = {
        newsList: [],
        resultNum: "0",
        startTime: "",
        moreHidden: "none",
        loadFinished: !1,
        loadMore: "loadMore",
        toastHidden: !0,
        loadHidden: !0,
        idMember: "true",
        isList: !1,
        noNews: "无查询结果",
        isTender: !0,
        isload: !0,
        isScreen: !1,
        isChoice: !1,
        isTenderProject: !1,
        isBidProject: !1,
        isNone: !1,
        province: [],
        citys: [],
        town: [],
        phase_id: "",
        timerange: "",
        page: 0,
        isBid: "false",
        isPage: "0",
        cache_id: "",
        isRefresh: !1,
        isShowCollection: !1,
        disable: !0,
        ifArea: !1,
        ifCityUse: !1,
        ifCountyUse: !1,
        area: a.getArea(),
        isThisProvince: [],
        city: i.getProvince(),
        getCity: [],
        getCounty: [],
        allTradeId: [],
        tradeColor: "#C7C7CC",
        chooseProvince: [ "省" ],
        chooseProvinceId: [],
        chooseCity: [ "市" ],
        chooseCityId: [],
        chooseCounty: [ "区" ],
        chooseCountyId: [],
        temporaryCity: [],
        temporary: [],
        areaColor: "#00000",
        cityColor: "#C7C7CC",
        countyColor: "#C7C7CC",
        tenderStage: [ {
            id: "1",
            value: "资审",
            checked: !1
        }, {
            id: "2",
            value: "采购",
            checked: !1
        } ],
        tenderTime: [ {
            id: "1",
            value: "近一周",
            checked: !1
        }, {
            id: "2",
            value: "近一月",
            checked: !1
        }, {
            id: "3",
            value: "近三月",
            checked: !1
        } ],
        bidStage: [ {
            id: "1",
            value: "资审中标",
            checked: !1
        }, {
            id: "2",
            value: "项目中标",
            checked: !1
        } ],
        bidTime: [ {
            id: "1",
            value: "近一周",
            checked: !1
        }, {
            id: "2",
            value: "近两周",
            checked: !1
        } ],
        tenderStageId: [],
        tenderTimeId: [],
        bidStageId: [],
        bidTimeId: [],
        searchPosition: "relative",
        scroollHeight: 0,
        openAdvertising: !1,
        imageIcon: "",
        imageContent: ""
    }, e(t, "startTime", ""), e(t, "endTime", ""), e(t, "showImage", !1), t),
    onShow: function(e) {
        var t = this;
        this.getImage(), t.setData({
            isload: !0
        }), wx.getStorage({
            key: "payTime",
            complete: function(e) {
                if (void 0 == e.data || "" == e.data) {
                    console.log("未缓存");
                    o.getList("GET", "user/info", "").then(function(e) {
                        var t = e.data.data.member_expires;
                        wx.setStorageSync("payTime", t);
                        var a = 1e3 * t;
                        a = s.secondToDate(new Date(a));
                        parseInt(a.replace(/-/g, ""));
                    });
                } else {
                    console.log("已缓存");
                    var t = 1e3 * e.data;
                    t = s.secondToDate(new Date(t));
                    parseInt(t.replace(/-/g, ""));
                }
            }
        });
        var a = {
            page: "/pages/recentProjectsHome/recentProjectsHome",
            des: "在招项目列表"
        };
        n.pageMonitoring(o, a);
    },
    onShareAppMessage: function(e) {
        console.log("我点击的是转发");
        var t = this;
        return n.sharePage("在招项目", "/pages/recentProjectsHome/recentProjectsHome", "share=true&shareId=" + t.data.cache_id);
    },
    onLoad: function(e) {
        wx.showShareMenu({
            withShareTicket: !0
        });
        var t = this, a = e.share || 0;
        if (wx.getSystemInfo({
            success: function(e) {
                t.setData({
                    scroollHeight: e.windowHeight
                });
            }
        }), a) {
            console.log("从转发渠道打开");
            var i = e.shareId;
            "" != i ? (wx.setStorage({
                key: "cache_id",
                data: i
            }), t.setData({
                cache_id: i
            })) : i = wx.getStorageSync("cache_id"), o.getList("GET", "cache/get/" + i, "").then(function(e) {
                console.log("转发渠道发送请求------"), console.log(e), console.log("上面是请求的数据"), console.log(e.data.data.cacheData), 
                console.log("这是取出来的data");
                var a = JSON.parse(e.data.data.cacheData);
                t.setData({
                    province: a.province,
                    citys: a.citys,
                    town: a.town,
                    page: a.page,
                    startTime: a.startTime,
                    resultNum: a.resultNum,
                    isTender: a.isTender,
                    isBid: a.isBid,
                    newsList: a.newsList,
                    moreHidden: a.moreHidden,
                    phase_id: a.phase_id,
                    timerange: a.timerange,
                    isScreen: a.isScreen,
                    isChoice: a.isChoice
                });
            });
        } else t.setData({
            province: "",
            citys: "",
            town: "",
            phase_id: "",
            timerange: ""
        }), t.getTenderProject();
    },
    getTenderProject: function(e) {
        var t = this, a = t.data.page, i = t.data.isChoice, s = {}, n = {};
        t.setData({
            isTender: !0,
            loadHidden: !1,
            loadFinished: !1,
            loadMore: "loadMore"
        });
        try {
            i && t.setData({
                page: 0,
                newsList: [],
                moreHidden: "none",
                isTenderProject: !0
            }), t.setData({
                isBid: e.currentTarget.dataset.isinvoice
            }), t.setData({
                page: 1,
                newsList: [],
                moreHidden: "none",
                isNone: !1,
                isTenderProject: !1
            }), t.formReset(), a = t.data.page;
        } catch (e) {
            i ? a = t.data.page + 1 : a += 1, t.setData({
                page: a
            });
        }
        var r = t.data.province, d = t.data.citys, c = t.data.town, h = t.data.phase_id, l = t.data.timerange, g = {
            province: r,
            city: d,
            town: c,
            phase_id: h,
            timerange: l,
            page: a,
            project_type: "1",
            isScreen: t.data.isScreen
        };
        o.getList("GET", "project/projectInResort", g).then(function(e) {
            if ("000000" === e.data.code) {
                var i = e.data.data.data || "";
                if (i.length < 1 && a > 1 && t.setData({
                    noNews: "没有更多"
                }), i.length < 1) t.setData({
                    toastHidden: !1,
                    moreHidden: "none",
                    startTime: e.data.data.start_time,
                    resultNum: e.data.data.total,
                    isNone: !0
                }); else {
                    t.setData({
                        isShare: !1,
                        id: ""
                    });
                    var r = t.data.newsList.concat(i);
                    i.length >= 1 && i.length < 10 ? a > 1 ? (t.setData({
                        newsList: r,
                        startTime: e.data.data.start_time,
                        resultNum: e.data.data.total,
                        moreHidden: ""
                    }), n.moreHidden = "") : (t.setData({
                        newsList: r,
                        startTime: e.data.data.start_time,
                        resultNum: e.data.data.total,
                        moreHidden: "none"
                    }), n.moreHidden = "none") : (t.setData({
                        newsList: r,
                        startTime: e.data.data.start_time,
                        resultNum: e.data.data.total,
                        moreHidden: ""
                    }), n.moreHidden = ""), n.resultNum = e.data.data.total, n.startTime = e.data.data.start_time, 
                    n.page = t.data.page, n.isTender = t.data.isTender, n.isBid = t.data.isBid, n.province = t.data.province, 
                    n.citys = t.data.citys, n.town = t.data.town, n.phase_id = h, n.timerange = l, n.newsList = t.data.newsList, 
                    n.isScreen = t.data.isScreen, n.isChoice = t.data.isChoice, s.cache_data = JSON.stringify(n), 
                    console.log("获取分享内容"), o.getList("POST", "cache/create", s).then(function(e) {
                        t.setData({
                            cache_id: e.data.data.id
                        });
                    });
                }
            } else wx.showModal({
                title: "登录提示",
                content: "请在“个人中心”登录后再查询数据",
                showCancel: !0,
                cancelText: "取消",
                confirmText: "个人中心",
                success: function(e) {
                    wx.setStorage({
                        key: "show_useinfo",
                        data: !1
                    }), e.confirm ? wx.switchTab({
                        url: "../../pages/personalCenterHome/personalCenterHome"
                    }) : e.cancel;
                }
            });
        }), setTimeout(t.loadChange, 800);
    },
    getBidProject: function(e) {
        var t = this, a = t.data.page, i = t.data.isChoice, s = {}, n = {};
        t.setData({
            isTender: !1,
            loadHidden: !1,
            loadFinished: !1,
            loadMore: "loadMore"
        });
        try {
            i && t.setData({
                page: 0,
                newsList: [],
                moreHidden: "none",
                isBidProject: !0
            }), t.setData({
                isBid: e.currentTarget.dataset.isinvoice
            }), t.setData({
                page: 1,
                newsList: [],
                moreHidden: "none",
                isNone: !1,
                isBidProject: !1
            }), t.formReset(), a = t.data.page;
        } catch (e) {
            i ? a = t.data.page + 1 : a += 1, t.setData({
                page: a
            });
        }
        var r = t.data.province, d = t.data.citys, c = t.data.town, h = t.data.phase_id, l = t.data.timerange, g = {
            province: r,
            city: d,
            town: c,
            phase_id: h,
            timerange: l,
            page: a,
            project_type: 2,
            isScreen: t.data.isScreen
        };
        o.getList("GET", "project/projectInResort", g).then(function(e) {
            if ("000000" === e.data.code) {
                var i = e.data.data.data || "";
                if (i.length < 1 && a > 1 && t.setData({
                    noNews: "没有更多"
                }), i.length < 1) t.setData({
                    toastHidden: !1,
                    moreHidden: "none",
                    startTime: e.data.data.start_time,
                    resultNum: e.data.data.total,
                    isNone: !0
                }); else {
                    t.setData({
                        isShare: !1,
                        id: ""
                    });
                    var r = t.data.newsList.concat(i);
                    i.length >= 1 && i.length < 5 ? a > 1 ? (t.setData({
                        newsList: r,
                        startTime: e.data.data.start_time,
                        resultNum: e.data.data.total,
                        moreHidden: ""
                    }), n.moreHidden = "") : (t.setData({
                        newsList: r,
                        startTime: e.data.data.start_time,
                        resultNum: e.data.data.total,
                        moreHidden: "none"
                    }), n.moreHidden = "none") : (t.setData({
                        newsList: r,
                        startTime: e.data.data.start_time,
                        resultNum: e.data.data.total,
                        moreHidden: ""
                    }), n.moreHidden = ""), n.resultNum = e.data.data.total, n.startTime = e.data.data.start_time, 
                    n.page = t.data.page, n.isTender = t.data.isTender, n.isBid = t.data.isBid, n.province = t.data.province, 
                    n.citys = t.data.citys, n.town = t.data.town, n.phase_id = h, n.timerange = l, n.newsList = t.data.newsList, 
                    n.isScreen = t.data.isScreen, n.isChoice = t.data.isChoice, s.cache_data = JSON.stringify(n), 
                    console.log("获取分享内容"), o.getList("POST", "cache/create", s).then(function(e) {
                        t.setData({
                            cache_id: e.data.data.id
                        });
                    });
                }
            } else wx.showModal({
                title: "登录提示",
                content: "请在“个人中心”登录后再查询数据",
                showCancel: !0,
                cancelText: "取消",
                confirmText: "个人中心",
                success: function(e) {
                    wx.setStorage({
                        key: "show_useinfo",
                        data: !1
                    }), e.confirm ? wx.switchTab({
                        url: "../../pages/personalCenterHome/personalCenterHome"
                    }) : e.cancel;
                }
            });
        }), setTimeout(t.loadChange, 800);
    },
    loadMore: function() {
        var e = this.data.isBid;
        this.setData({
            isChoice: !1
        }), "true" == e && this.getBidProject(), "false" == e && this.getTenderProject();
    },
    toastChange: function() {
        this.data.newsList.length > 1 && this.setData({
            loadFinished: !0
        }), this.setData({
            toastHidden: !0,
            loadMore: ""
        });
    },
    loadChange: function() {
        this.setData({
            loadHidden: !0
        });
    },
    loadDetails: function(e) {
        this.setData({
            isload: !1
        }), n.clearProjectStory();
        var t = this, a = e.currentTarget.dataset.id, i = e.currentTarget.dataset.recentproject, o = e.currentTarget.dataset.value, s = e.currentTarget.dataset.option, r = t.data.isTender, d = t.data.isTenderProject, c = t.data.isScreen, h = t.data.isShowCollection, l = t.data.isBidProject;
        r ? d && c ? t.isMemberUser(a, i, s) : o < 5 ? (wx.navigateTo({
            url: "/pages/project/details/details?id=" + a + "&&recentProject=" + i + "&&option=" + s + "&&isShowCollection=" + h
        }), t.setData({
            isload: !0
        })) : t.isMemberUser(a, i, s) : l && c ? t.isMemberUser(a, i, s) : o < 5 ? (wx.navigateTo({
            url: "/pages/project/details/details?id=" + a + "&&recentProject=" + i + "&&option=" + s + "&&isShowCollection=" + h
        }), t.setData({
            isload: !0
        })) : t.isMemberUser(a, i, s);
    },
    isMemberUser: function(e, t, a) {
        var i = this, n = i.data.isShowCollection;
        wx.getStorage({
            key: "payTime",
            success: function(r) {
                console.log(r.data), i.setData({
                    isload: !0
                });
                var d = 1e3 * r.data, c = s.presentTime(new Date());
                d = s.secondToDate(new Date(d));
                var h = parseInt(d.replace(/-/g, "")), l = parseInt(c.replace(/-/g, ""));
                console.log(h), 0 == r.data ? (console.log("未开通会员"), wx.showModal({
                    title: "提示",
                    content: "付费查看全部数据",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? (console.log("用户点击确定"), wx.getStorage({
                            key: "isBindPhone",
                            complete: function(e) {
                                e.data || "" ? (console.log("有缓存已绑定"), wx.navigateTo({
                                    url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=recentProjectsHome"
                                })) : (console.log("无缓存发请求"), o.getList("GET", "user/isBindPhone", "").then(function(e) {
                                    wx.setStorage({
                                        key: "isBindPhone",
                                        data: e.data.data.bindStatus
                                    }), e.data.data.bindStatus ? (console.log("已绑定"), wx.navigateTo({
                                        url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=recentProjectsHome"
                                    })) : (console.log("未绑定"), wx.navigateTo({
                                        url: "/pages/personalCenter/personalPage/personalPage?skipPage=recentProjectsHome"
                                    }));
                                }));
                            }
                        })) : e.cancel && (i.setData({
                            isload: !0
                        }), console.log("用户点击取消"));
                    }
                })) : h >= l ? (console.log("会员未过期"), wx.navigateTo({
                    url: "/pages/project/details/details?id=" + e + "&&recentProject=" + t + "&&option=" + a + "&&isShowCollection=" + n
                })) : h < l ? (console.log("会员过期"), wx.showModal({
                    title: "提示",
                    content: "您的会员已过期,重新开通会员享有全部数据权限",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? (i.setData({
                            isload: !0
                        }), console.log("用户点击确定"), wx.navigateTo({
                            url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=recentProjectsHome"
                        })) : e.cancel && (i.setData({
                            isload: !0
                        }), console.log("用户点击取消"));
                    }
                })) : console.log("时间范围超出限制");
            },
            fail: function(e) {
                console.log("获取日期失败");
            }
        });
    },
    optionProvince: function() {
        this.setData({
            ifArea: !0,
            searchPosition: "fixed"
        });
    },
    hideArea: function(e) {
        "area-choose" == e.target.dataset.id && (this.areaConfirm(), this.setData({
            ifArea: !1,
            searchPosition: "relative"
        }));
    },
    provinceHeight: function(e) {
        var t = this.data.area, a = e.target.dataset.value;
        n.getHeight(a, t), this.setData({
            area: t
        });
    },
    areaAlltap: function(e) {
        var t = this.data.area, a = this.data.chooseProvinceId;
        if (e.target.dataset.checked) {
            for (i = 0; i < t.length; i++) {
                t[i].checked = !1, t.splice(i, 1, t[i]), t[i].checkElement.length = 0, t[i].checkElementId.length = 0;
                for (o = 0; o < t[i].province.length; o++) t[i].province[o].checked = !1, t[i].province.splice(o, 1, t[i].province[o]);
            }
            this.setData({
                areaAll: !1,
                area: t,
                chooseProvinceId: []
            });
        } else {
            for (o = 0; o < t.length; o++) t[o].checkElement.length = 0, t[o].checkElementId.length = 0;
            for (var i = 0; i < t.length; i++) {
                t[i].checked = !0, t.splice(i, 1, t[i]);
                for (var o = 0; o < t[i].province.length; o++) t[i].province[o].checked = !0, t[i].province.splice(o, 1, t[i].province[o]), 
                t[i].checkElement.push(t[i].province[o].name), t[i].checkElementId.push(t[i].province[o].id), 
                a.push(t[i].province[o].id);
            }
            this.setData({
                areaAll: !0,
                area: t
            });
        }
    },
    chartArea: function(e) {
        var t = e.target.dataset.value, a = this.data.area, i = a[t], o = !0;
        if (i.checked) {
            i.checked = !1;
            for (s = 0; s < a[t].province.length; s++) a[t].province[s].checked = !1;
            this.setData({
                areaAll: !1
            }), a[t].checkElement.length = 0, a[t].checkElementId.length = 0;
        } else {
            i.checked = !0, a[t].checkElement.length = 0, a[t].checkElementId.length = 0;
            for (var s = 0; s < a[t].province.length; s++) a[t].province[s].checked = !0, a[t].checkElement.push(a[t].province[s].name), 
            a[t].checkElementId.push(a[t].province[s].id);
            for (var n = 0; n < a.length; n++) if (0 == a[n].checked) {
                o = !1;
                break;
            }
            o && this.setData({
                areaAll: !0
            });
        }
        a.splice(t, 1, i), this.setData({
            area: a
        });
    },
    chartAreaSecond: function(e) {
        var t = e.target.dataset.value, a = e.target.dataset.superiorvalue, i = this.data.area, o = i[a].province[t], s = e.target.dataset.name, n = e.target.dataset.id;
        if (o.checked) {
            o.checked = !1, i[a].checked = !1, this.setData({
                areaAll: !1
            });
            var r = i[a].checkElement.indexOf(s), d = i[a].checkElementId.indexOf(n);
            i[a].checkElement.splice(r, 1), i[a].checkElementId.splice(d, 1);
        } else {
            o.checked = !0;
            var c = !0, h = !0;
            i[a].checkElement.push(s), i[a].checkElementId.push(n);
            for (l = 0; l < i[a].province.length; l++) if (0 == i[a].province[l].checked) {
                c = !1;
                break;
            }
            c && (i[a].checked = !0);
            for (var l = 0; l < i.length; l++) if (0 == i[l].checked) {
                h = !1;
                break;
            }
            h && this.setData({
                areaAll: !0
            });
        }
        i[a].province.splice(t, 1, o), this.setData({
            area: i
        });
    },
    areaRestoration: function() {
        var e = this.data.area;
        n.clearArea(e), this.setData({
            areaAll: !1,
            area: e
        });
    },
    areaConfirm: function() {
        var e = this.data.area, t = this.data.chooseProvince, a = this.data.chooseProvinceId, i = (this.data.chooseCity, 
        this.data.chooseCounty, this.data.ifCityUse, this.data.ifCountyUse, 0), o = 0;
        t.length = 0, a.length = 0;
        for (var s = 0; s < e.length; s++) {
            for (n = 0; n < e[s].province.length; n++) i++;
            for (var n = 0; n < e[s].checkElement.length; n++) o++, t.push(e[s].checkElement[n]);
            for (var r = 0; r < e[s].checkElementId.length; r++) a.push(e[s].checkElementId[r]);
        }
        0 == t.length || "省" == t[0] ? (t.push("省"), this.setData({
            areaColor: "#000000",
            ifCityUse: !1,
            ifCountyUse: !1,
            chooseCity: "不可选",
            chooseCounty: "不可选",
            cityColor: "#C7C7CC",
            countyColor: "#C7C7CC",
            chooseCityId: [],
            chooseCountyId: []
        })) : t.length > 1 ? this.setData({
            chooseCity: "不可选",
            chooseCounty: "不可选",
            cityColor: "#C7C7CC",
            countyColor: "#C7C7CC",
            ifCityUse: !1,
            ifCountyUse: !1,
            areaColor: "#31a4ff",
            chooseCityId: [],
            chooseCountyId: []
        }) : this.setData({
            areaColor: "#31a4ff",
            chooseCity: [ "市" ],
            chooseCounty: [ "区" ],
            cityColor: "#000000",
            countyColor: "#C7C7CC",
            ifCityUse: !0,
            ifCountyUse: !1,
            chooseCityId: [],
            chooseCountyId: []
        }), a.length > 1 && this.setData({
            chooseCityId: [],
            chooseCountyId: []
        }), this.setData({
            ifArea: !1,
            chooseProvince: t,
            chooseProvinceId: a,
            searchPosition: "relative"
        }), 0 == this.data.chooseProvinceId.length || 0 == this.data.allTradeId.length ? this.setData({
            disable: !0
        }) : this.setData({
            disable: !1
        }), o == i && (t.length = 0, this.setData({
            chooseProvince: [ "全国" ]
        }));
    },
    optionCity: function() {
        if (1 == this.data.ifCityUse) {
            this.setData({
                ifCity: !0,
                searchPosition: "fixed"
            });
            var e = this.data.chooseProvinceId, t = this.data.isThisProvince, a = this.data.city;
            this.data.getCity;
            if (t.join(",") != e.join(",")) for (var i = 0; i < a.length; i++) a[i].id == e && this.setData({
                getCity: a[i].city
            });
        }
    },
    hideCity: function(e) {
        "area-choose" == e.target.dataset.id && (this.cityConfirm(), this.setData({
            ifCity: !1,
            searchPosition: "relative"
        }));
    },
    chartCity: function(e) {
        var t = e.target.dataset.index, a = this.data.getCity, i = a[t], o = this.data.chooseCity, s = this.data.chooseProvinceId, r = this.data.chooseCityId;
        n.searchCity(a, i, t, !0), this.setData({
            getCity: a
        }), o = [], r = [];
        for (var d = 0; d < a.length; d++) a[d].checked && (o.push(a[d].name), r.push(a[d].id));
        this.setData({
            chooseCity: o,
            chooseCityId: r,
            isThisProvince: s
        });
    },
    cityConfirm: function() {
        var e = this, t = e.data.chooseCity, a = e.data.chooseCityId, i = (e.data.ifCountyUse, 
        n.isCityWithoutDistricts(this.data.getCity, a));
        if (e.setData({
            ifCity: !1,
            searchPosition: "relative"
        }), 0 == t.length || "市" == t[0]) e.setData({
            cityColor: "#000000",
            chooseCity: [ "市" ],
            countyColor: "#C7C7CC",
            ifCountyUse: !1,
            chooseCounty: [ "不可选" ],
            chooseCountyId: []
        }); else if (t.length > 1) e.setData({
            chooseCounty: [ "不可选" ],
            countyColor: "#C7C7CC",
            cityColor: "#31a4ff",
            ifCountyUse: !1,
            chooseCountyId: []
        }); else if (i) e.setData({
            chooseCounty: [ "不设区的市" ],
            countyColor: "#C7C7CC",
            cityColor: "#31a4ff",
            ifCountyUse: !1,
            chooseCountyId: []
        }); else {
            e.setData({
                cityColor: "#31a4ff",
                chooseCounty: [ "区" ],
                countyColor: "#000000",
                ifCountyUse: !0,
                chooseCountyId: []
            });
            var s = {
                id: a.join(",")
            };
            o.getList("GET", "project/areaTown", s).then(function(t) {
                e.setData({
                    getCounty: t.data.data
                });
            });
        }
    },
    cityRestoration: function() {
        var e = this.data.getCity;
        n.clearCity(e), this.setData({
            getCity: e,
            chooseCity: [],
            chooseCityId: []
        });
    },
    optionCounty: function() {
        var e = this;
        1 == e.data.ifCountyUse && e.setData({
            ifCounty: !0,
            searchPosition: "fixed"
        });
    },
    hideCounty: function(e) {
        "area-choose" == e.target.dataset.id && (this.countyConfirm(), this.setData({
            ifCounty: !1,
            searchPosition: "relative"
        }));
    },
    chartCounty: function(e) {
        var t = e.target.dataset.index, a = this.data.chooseCounty, i = this.data.chooseCountyId, o = this.data.getCounty, s = o[t];
        n.searchCity(o, s, t, !0), this.setData({
            getCounty: o
        }), a = [], i = [];
        for (var r = 0; r < o.length; r++) o[r].checked && (a.push(o[r].name), i.push(o[r].id));
        this.setData({
            chooseCounty: a,
            chooseCountyId: i
        });
    },
    countyConfirm: function() {
        var e = this.data.chooseCounty;
        this.setData({
            ifCounty: !1,
            searchPosition: "relative"
        }), 0 == e.length ? (e.push([ "区" ]), this.setData({
            cityColor: "#31a4ff",
            countyColor: "#000000",
            chooseCounty: [ "区" ]
        })) : this.setData({
            countyColor: "#31a4ff"
        });
    },
    countyRestoration: function() {
        var e = this.data.getCounty;
        n.clearCity(e), this.setData({
            getCounty: e,
            chooseCounty: [],
            chooseCountyId: []
        });
    },
    formSubmit: function() {
        var e = this, t = e.data.chooseProvinceId || "", a = e.data.chooseCityId || "", i = e.data.chooseCountyId || "", o = e.data.tenderStageId || "", s = e.data.tenderTimeId || "", n = e.data.bidStageId || "", r = e.data.bidTimeId || "", d = e.data.isTender;
        "" != i && (t = [], a = []), "" != a && (t = []), 0 == t.length && 0 == a.length && 0 == i.length && 0 == o.length && 0 == s.length && 0 == n.length && 0 == r.length ? e.setData({
            isScreen: !1
        }) : e.setData({
            isScreen: !0
        }), e.setData({
            province: t.join(","),
            citys: a.join(","),
            town: i.join(","),
            isList: !1,
            isChoice: !0,
            isNone: !1
        }), d ? (e.setData({
            phase_id: o.join(","),
            timerange: s
        }), e.getTenderProject()) : (e.setData({
            phase_id: n.join(","),
            timerange: r
        }), e.getBidProject());
    },
    formReset: function(e) {
        var t = this, a = t.data.getCity, i = t.data.getCounty, s = t.data.area, r = t.data.tenderStage, d = t.data.tenderTime, c = t.data.bidStage, h = t.data.bidTime;
        n.clearArea(s), n.clearCity(a), n.clearCity(i), n.clearReport(r), n.clearReport(d), 
        n.clearReport(c), n.clearReport(h), wx.getStorage({
            key: "payTime",
            complete: function(e) {
                if (void 0 == e.data || "" == e.data) {
                    console.log("未缓存");
                    o.getList("GET", "user/info", "").then(function(e) {
                        var a = e.data.data.member_expires;
                        t.ifChangeStartDate(a), wx.setStorageSync("payTime", a);
                    });
                } else t.ifChangeStartDate(e.data), console.log("已缓存");
            }
        }), t.setData({
            area: s,
            getCity: a,
            getCounty: i,
            areaAll: !1,
            chooseProvince: [ "省" ],
            chooseProvinceId: [],
            chooseCity: [ "市" ],
            chooseCityId: [],
            chooseCounty: [ "区" ],
            chooseCountyId: [],
            ifCountyUse: !1,
            ifCityUse: !1,
            tradeColor: "#C7C7CC",
            areaColor: "#000000",
            cityColor: "#C7C7CC",
            countyColor: "#C7C7CC",
            tenderStage: r,
            tenderTime: d,
            bidStage: c,
            bidTime: h,
            tenderStageId: [],
            tenderTimeId: [],
            bidStageId: [],
            bidTimeId: [],
            province: "",
            citys: "",
            town: "",
            phase_id: "",
            timerange: "",
            isScreen: !1,
            imageIcon: "",
            imageContent: "",
            startTime: "",
            endTime: "",
            showImage: !1
        });
    },
    ifChangeStartDate: function(e) {
        var t = s.presentTime(new Date()), a = parseInt(t.replace(/-/g, ""));
        e >= a ? this.setData({
            startDate: "2013-01-01",
            endDate: s.presentTime(new Date())
        }) : e < a && this.setData({
            startDate: s.startFormatTime(new Date()),
            endDate: s.endFormatTime(new Date())
        });
    },
    formCancel: function() {
        this.setData({
            isList: !1
        });
    },
    searchTenderStage: function(e) {
        var t = e.target.dataset.index, a = this.data.tenderStage, i = a[t], o = this.data.tenderStageId;
        n.searchMethod(a, i, t, !0), o = [];
        for (var s = 0; s < a.length; s++) a[s].checked && o.push(a[s].id);
        this.setData({
            tenderStage: a,
            tenderStageId: o
        });
    },
    searchTenderTime: function(e) {
        var t = e.target.dataset.index, a = this.data.tenderTime, i = a[t];
        if (i.checked) i.checked = !1, this.setData({
            tenderTimeId: ""
        }); else {
            for (var o = 0; o < a.length; o++) a[o].checked = !1;
            i.checked = !0, this.setData({
                tenderTimeId: i.id
            });
        }
        a.splice(t, 1, i), this.setData({
            tenderTime: a
        });
    },
    searchBidStage: function(e) {
        var t = e.target.dataset.index, a = this.data.bidStage, i = a[t], o = this.data.bidStageId;
        n.searchMethod(a, i, t, !0), o = [];
        for (var s = 0; s < a.length; s++) a[s].checked && o.push(a[s].id);
        this.setData({
            bidStage: a,
            bidStageId: o
        });
    },
    searchBidTime: function(e) {
        var t = e.target.dataset.index, a = this.data.bidTime, i = a[t];
        if (i.checked) i.checked = !1, this.setData({
            bidTimeId: ""
        }); else {
            for (var o = 0; o < a.length; o++) a[o].checked = !1;
            i.checked = !0, this.setData({
                bidTimeId: i.id
            });
        }
        a.splice(t, 1, i), this.setData({
            bidTime: a
        });
    },
    isList: function(e) {
        this.setData({
            isList: !0
        });
    },
    selectTerm: function() {
        this.data.disable, this.data.ifArea, this.data.ifCityUse, this.data.ifCountyUse, 
        this.data.area, this.data.isThisProvince, this.data.city, this.data.getCity, this.data.getCounty, 
        this.data.allTradeId, this.data.tradeColor, this.data.chooseProvince, this.data.chooseProvinceId, 
        this.data.chooseCity, this.data.chooseCityId, this.data.chooseCounty, this.data.chooseCountyId, 
        this.data.temporaryCity, this.data.temporary, this.data.areaColor, this.data.cityColor, 
        this.data.countyColor, this.data.tenderStage, this.data.tenderTime, this.data.bidStage, 
        this.data.bidTime, this.data.tenderStageId, this.data.tenderTimeId, this.data.bidStageId, 
        this.data.bidTimeId;
    },
    openAdvertising: function() {
        this.data.openAdvertising ? this.setData({
            openAdvertising: !1
        }) : this.setData({
            openAdvertising: !0
        });
    },
    closeAdvertising: function() {
        this.setData({
            openAdvertising: !1
        });
    },
    toRechargePage: function() {
        n.toPaymentPage(o);
    },
    getImage: function() {
        var e = this, t = {
            key: "5be010e03de64"
        };
        o.getList("GET", "ad/position", t).then(function(t) {
            if ("000000" == t.data.code) {
                var a = t.data.data.startTime, i = t.data.data.endTime, o = Date.parse(new Date()) / 1e3;
                if (a <= o && o <= i) {
                    if ("images" === t.data.data.content.type) {
                        var s = t.data.data.content.value;
                        e.setData({
                            imageContent: s[0],
                            imageIcon: t.data.data.icon,
                            showImage: !0
                        });
                    }
                } else e.setData({
                    imageIcon: "",
                    showImage: !1
                });
            }
        });
    }
});
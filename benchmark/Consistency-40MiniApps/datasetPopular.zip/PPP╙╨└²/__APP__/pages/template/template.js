function e() {
    return [ {
        current: 0,
        pagePath: "/pages/project/proList/proList",
        iconPath: "/images/query.png",
        selectedIconPath: "/images/query_select.png",
        text: "项目查询"
    }, {
        current: 0,
        pagePath: "/pages/recentProjectsHome/recentProjectsHome",
        iconPath: "/images/tender.png",
        selectedIconPath: "/images/tender_select.png",
        text: "在招项目"
    }, {
        current: 0,
        pagePath: "/pages/companyHome/companyHome",
        iconPath: "/images/analyze.png",
        selectedIconPath: "/images/analyze_select.png",
        text: "企业分析"
    }, {
        current: 0,
        pagePath: "/pages/chartsHome/chartsHome",
        iconPath: "/images/chart.png",
        selectedIconPath: "/images/chart_select.png",
        text: "统计报表"
    }, {
        current: 0,
        pagePath: "/pages/personalCenterHome/personalCenterHome",
        iconPath: "/images/set.png",
        selectedIconPath: "/images/set_select.png",
        text: "个人中心"
    } ];
}

module.exports = {
    tabbar: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "tabdata", a = arguments[1], n = arguments[2], c = {}, s = e();
        s[a].iconPath = s[a].selectedIconPath, s[a].current = 1, c[t] = s, n.setData({
            bindData: c
        });
    }
};
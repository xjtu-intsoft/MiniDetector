require("../../vendor/qcloud-weapp-client-sdk/index.js"), require("../../utils/util.js");

var t = require("../../utils/commin.js"), e = require("../template/template.js"), o = require("../../utils/api.js");

Page({
    data: {
        projectNum: "_____",
        totalScale: "_____",
        companyNum: "_____",
        last_month: "____",
        last_week: "____",
        display: "",
        options: "",
        openAdvertising: !1,
        imageIcon: "",
        imageContent: "",
        startTime: "",
        endTime: "",
        showImage: !1
    },
    onShareAppMessage: function(e) {
        return t.sharePage("PPP有例--最全行业数据服务", "/pages/projectHome/projectHome");
    },
    onReady: function() {
        this.projectCompanyNum();
    },
    onLoad: function(t) {
        this.data.options = t, e.tabbar("tabBar", 0, this), wx.showShareMenu ? wx.showShareMenu({
            withShareTicket: !0
        }) : wx.showModal({
            title: "提示",
            content: "当前微信版本过低，小程序部分功能可能无法使用，建议将微信升级到最新版本后使用。"
        });
    },
    onShow: function() {
        wx.login({
            success: function(t) {
                t.code || console.log("登录失败！" + t.errMsg);
            }
        }), this.projectCompanyNum();
        var e = {
            page: "pages/projectHome/projectHome",
            des: "项目查询"
        };
        t.pageMonitoring(o, e), this.getImage();
    },
    projectCompanyNum: function() {
        var t = this;
        wx.request({
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            url: "https://wx.youlidata.com/api/wx/v1/totalProjectCompany",
            data: "",
            method: "GET",
            success: function(e) {
                t.setData({
                    projectNum: e.data.data.totalProject,
                    totalScale: parseInt(e.data.data.totalScale),
                    companyNum: e.data.data.totalCompany,
                    last_month: e.data.data.lastMonth,
                    last_week: e.data.data.lastWeek
                });
            },
            fail: function(t) {
                console.log("submit fail");
            },
            complete: function(t) {
                console.log("submit complete");
            }
        });
    },
    btQueryCriteria: function() {
        var t = {
            url: "/pages/project/proList/proList"
        };
        wx.switchTab(t);
    },
    showClickYouLiWeb: function() {
        wx.showModal({
            title: "提示",
            content: "请在浏览器中输入“www.youlidata.com”访问“PPP有例数据服务+投资决策支持平台”商用版",
            showCancel: !1,
            success: function(t) {
                t.confirm && console.log("用户点击确定");
            }
        });
    },
    showview: function() {
        this.setData({
            display: "block"
        });
    },
    hideview: function() {
        this.setData({
            display: "none"
        });
    },
    openAdvertising: function() {
        this.data.openAdvertising ? this.setData({
            openAdvertising: !1
        }) : this.setData({
            openAdvertising: !0
        });
    },
    closeAdvertising: function() {
        this.setData({
            openAdvertising: !1
        });
    },
    toRechargePage: function() {
        t.toPaymentPage(o);
    },
    getImage: function() {}
});
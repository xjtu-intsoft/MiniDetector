var e = require("../../utils/area-min.js"), a = require("../../utils/projects-min.js"), t = require("../../utils/commin.js"), r = require("../../utils/api.js"), s = require("../../utils/util.js");

Page({
    data: {
        disable: !0,
        tradeAll: !1,
        ifTrade: !1,
        ifArea: !1,
        areaAll: !1,
        items: [ {
            value: "企业中标数排名",
            chartType: "1",
            checked: !0
        }, {
            value: "行业平均收益率变化",
            chartType: "2",
            checked: !1
        }, {
            value: "行业成交项目总量",
            chartType: "3",
            checked: !1
        }, {
            value: "行业分布统计",
            chartType: "4",
            checked: !1
        } ],
        allTradeDis: !1,
        projects: a.getProjects(),
        area: e.getArea(),
        upperDate: "2013-01-01",
        startDate: s.startFormatTime(new Date()),
        endDate: s.endFormatTime(new Date()),
        downDate: s.presentTime(new Date()),
        chartType: "1",
        allTrade: [ "请选择" ],
        allTradeId: [],
        tradeColor: "#C7C7CC",
        allArea: [ "请选择" ],
        allAreaId: [],
        areaColor: "#C7C7CC",
        hidden: !0,
        ifShade: !1,
        ifProEnter: !1,
        projectNum: "_____",
        totalScale: "_____",
        imageIcon: "",
        imageContent: "",
        startTime: "",
        endTime: "",
        showImage: !1
    },
    changeHidden: function() {
        this.setData({
            hidden: !this.data.hidden
        });
    },
    onReady: function() {
        this.projectCompanyNum();
    },
    onShareAppMessage: function(e) {
        return t.sharePage("统计报表", "/pages/chartsHome/chartsHome");
    },
    chartType: function(e) {
        for (var a = e.target.dataset.index, t = e.target.dataset.charttype, r = this.data.projects, s = this.data.area, n = this.data.items, c = this.data.allTradeId, l = n[a], i = 0; i < n.length; i++) n[i].checked = !1;
        switch (l.checked = !0, n.splice(a, 1, l), t) {
          case "1":
          case "2":
          case "3":
            for (i = 0; i < r.length; i++) {
                r[i].disabled = !1, r.splice(i, 1, r[i]);
                for (o = 0; o < r[i].list.length; o++) r[i].list[o].disabled = !1, r[i].list.splice(o, 1, r[i].list[o]);
            }
            this.setData({
                allTradeDis: !1,
                ifShade: !1,
                ifProEnter: !1
            });
            break;

          case "4":
            for (i = 0; i < r.length; i++) {
                r[i].disabled = !0, r[i].checked = !0, r.splice(i, 1, r[i]);
                for (var o = 0; o < r[i].list.length; o++) r[i].list[o].disabled = !0, r[i].list[o].checked = !0, 
                r[i].list.splice(o, 1, r[i].list[o]), -1 == (d = r[i].checkElement.indexOf(r[i].list[o].name)) && r[i].checkElement.push(r[i].list[o].name), 
                -1 == (a = r[i].checkElementId.indexOf(r[i].list[o].id)) && r[i].checkElementId.push(r[i].list[o].id);
                for (var h = 0; h < this.data.projects[i].checkElementId.length; h++) {
                    var d = c.indexOf(r[i].checkElementId[h]);
                    -1 == d && c.push(r[i].checkElementId[h]);
                }
            }
            this.setData({
                allTradeDis: !0,
                tradeColor: "#31a4ff",
                allTrade: [ "全部行业" ],
                allTradeId: c,
                tradeAll: !0,
                ifShade: !0,
                projects: r,
                ifProEnter: !0
            });
        }
        this.setData({
            items: n,
            chartType: t,
            projects: r,
            area: s
        }), 0 == this.data.allAreaId.length || 0 == this.data.allTradeId.length ? this.setData({
            disable: !0
        }) : this.setData({
            disable: !1
        });
    },
    optionTrade: function(e) {
        this.setData({
            ifTrade: !0
        });
    },
    hideTrade: function(e) {
        "trade-choose" == e.target.dataset.id && (this.tradeConfirm(), this.setData({
            ifTrade: !1
        }));
    },
    listHeight: function(e) {
        var a = e.target.dataset.value, r = this.data.projects;
        t.getHeight(a, r), this.setData({
            projects: r
        });
    },
    tradeAlltap: function(e) {
        var a = this.data.projects;
        if (e.target.dataset.checked) {
            for (t = 0; t < a.length; t++) {
                a[t].checked = !1, a.splice(t, 1, a[t]), a[t].checkElement.length = 0, a[t].checkElementId.length = 0;
                for (r = 0; r < a[t].list.length; r++) a[t].list[r].checked = !1, a[t].list.splice(r, 1, a[t].list[r]);
            }
            this.setData({
                tradeAll: !1,
                projects: a
            });
        } else {
            for (r = 0; r < a.length; r++) a[r].checkElement.length = 0, a[r].checkElementId.length = 0;
            for (var t = 0; t < a.length; t++) {
                a[t].checked = !0, a.splice(t, 1, a[t]);
                for (var r = 0; r < a[t].list.length; r++) a[t].list[r].checked = !0, a[t].list.splice(r, 1, a[t].list[r]), 
                a[t].checkElement.push(a[t].list[r].name), a[t].checkElementId.push(a[t].list[r].id);
            }
            this.setData({
                tradeAll: !0,
                projects: a
            });
        }
    },
    chartTrade: function(e) {
        var a = e.target.dataset.value, t = this.data.projects, r = t[a], s = !0;
        if (r.checked) {
            r.checked = !1;
            for (n = 0; n < t[a].list.length; n++) t[a].list[n].checked = !1;
            this.setData({
                tradeAll: !1
            }), t[a].checkElement.length = 0, t[a].checkElementId.length = 0;
        } else {
            r.checked = !0, t[a].checkElement.length = 0, t[a].checkElementId.length = 0;
            for (var n = 0; n < t[a].list.length; n++) t[a].list[n].checked = !0, t[a].checkElement.push(t[a].list[n].name), 
            t[a].checkElementId.push(t[a].list[n].id);
            for (var c = 0; c < t.length; c++) if (0 == t[c].checked) {
                s = !1;
                break;
            }
            s && this.setData({
                tradeAll: !0
            });
        }
        t.splice(a, 1, r), this.setData({
            projects: t
        });
    },
    chartTradeSecond: function(e) {
        var a = e.target.dataset.value, t = e.target.dataset.superiorvalue, r = this.data.projects, s = r[t].list[a], n = e.target.dataset.name, c = e.target.dataset.id;
        if (s.checked) {
            s.checked = !1, r[t].checked = !1, this.setData({
                tradeAll: !1
            });
            var l = r[t].checkElement.indexOf(n), i = r[t].checkElementId.indexOf(c);
            r[t].checkElement.splice(l, 1), r[t].checkElementId.splice(i, 1);
        } else {
            s.checked = !0;
            var o = !0, h = !0;
            r[t].checkElement.push(n), r[t].checkElementId.push(c);
            for (d = 0; d < r[t].list.length; d++) if (0 == r[t].list[d].checked) {
                o = !1;
                break;
            }
            o && (r[t].checked = !0);
            for (var d = 0; d < r.length; d++) if (0 == r[d].checked) {
                h = !1;
                break;
            }
            h && this.setData({
                tradeAll: !0
            });
        }
        r[t].list.splice(a, 1, s), this.setData({
            projects: r
        });
    },
    tradeRestoration: function() {
        var e = this.data.projects;
        t.clearProjects(e), this.setData({
            tradeAll: !1,
            projects: e
        });
    },
    tradeConfirm: function() {
        var e = this.data.projects, a = this.data.allTrade, t = this.data.allTradeId, r = 0, s = 0;
        a.length = 0, t.length = 0;
        for (var n = 0; n < e.length; n++) {
            for (c = 0; c < e[n].list.length; c++) r++;
            for (c = 0; c < e[n].checkElement.length; c++) -1 == (l = a.indexOf(e[n].checkElement[c])) && (s++, 
            a.push(e[n].checkElement[c]));
            for (var c = 0; c < e[n].checkElementId.length; c++) {
                var l = t.indexOf(e[n].checkElementId[c]);
                -1 == l && t.push(e[n].checkElementId[c]);
            }
        }
        0 == a.length ? (a.push("请选择"), this.setData({
            tradeColor: "#C7C7CC"
        })) : this.setData({
            tradeColor: "#31a4ff"
        }), s == r && (a.length = 0, a.push("全部行业")), this.setData({
            ifTrade: !1,
            allTrade: a,
            allTradeId: t
        }), 0 == this.data.allAreaId.length || 0 == this.data.allTradeId.length ? this.setData({
            disable: !0
        }) : this.setData({
            disable: !1
        });
    },
    optionArea: function() {
        this.setData({
            ifArea: !0
        });
    },
    hideArea: function(e) {
        "area-choose" == e.target.dataset.id && (this.areaConfirm(), this.setData({
            ifArea: !1
        }));
    },
    provinceHeight: function(e) {
        var a = this.data.area, r = e.target.dataset.value;
        t.getHeight(r, a), this.setData({
            area: a
        });
    },
    areaAlltap: function(e) {
        var a = this.data.area;
        if (e.target.dataset.checked) {
            for (t = 0; t < a.length; t++) {
                a[t].checked = !1, a.splice(t, 1, a[t]), a[t].checkElement.length = 0, a[t].checkElementId.length = 0;
                for (r = 0; r < a[t].province.length; r++) a[t].province[r].checked = !1, a[t].province.splice(r, 1, a[t].province[r]);
            }
            this.setData({
                areaAll: !1,
                area: a
            });
        } else {
            for (r = 0; r < a.length; r++) a[r].checkElement.length = 0, a[r].checkElementId.length = 0;
            for (var t = 0; t < a.length; t++) {
                a[t].checked = !0, a.splice(t, 1, a[t]);
                for (var r = 0; r < a[t].province.length; r++) a[t].province[r].checked = !0, a[t].province.splice(r, 1, a[t].province[r]), 
                a[t].checkElement.push(a[t].province[r].name), a[t].checkElementId.push(a[t].province[r].id);
            }
            this.setData({
                areaAll: !0,
                area: a
            });
        }
    },
    chartArea: function(e) {
        var a = e.target.dataset.value, t = this.data.area, r = t[a], s = !0;
        if (r.checked) {
            r.checked = !1;
            for (n = 0; n < t[a].province.length; n++) t[a].province[n].checked = !1;
            this.setData({
                areaAll: !1
            }), t[a].checkElement.length = 0, t[a].checkElementId.length = 0;
        } else {
            r.checked = !0, t[a].checkElement.length = 0, t[a].checkElementId.length = 0;
            for (var n = 0; n < t[a].province.length; n++) t[a].province[n].checked = !0, t[a].checkElement.push(t[a].province[n].name), 
            t[a].checkElementId.push(t[a].province[n].id);
            for (var c = 0; c < t.length; c++) if (0 == t[c].checked) {
                s = !1;
                break;
            }
            s && this.setData({
                areaAll: !0
            });
        }
        t.splice(a, 1, r), this.setData({
            area: t
        });
    },
    chartAreaSecond: function(e) {
        var a = e.target.dataset.value, t = e.target.dataset.superiorvalue, r = this.data.area, s = r[t].province[a], n = e.target.dataset.name, c = e.target.dataset.id;
        if (s.checked) {
            s.checked = !1, r[t].checked = !1, this.setData({
                areaAll: !1
            });
            var l = r[t].checkElement.indexOf(n), i = r[t].checkElementId.indexOf(c);
            r[t].checkElement.splice(l, 1), r[t].checkElementId.splice(i, 1);
        } else {
            s.checked = !0;
            var o = !0, h = !0;
            r[t].checkElement.push(n), r[t].checkElementId.push(c);
            for (d = 0; d < r[t].province.length; d++) if (0 == r[t].province[d].checked) {
                o = !1;
                break;
            }
            o && (r[t].checked = !0);
            for (var d = 0; d < r.length; d++) if (0 == r[d].checked) {
                h = !1;
                break;
            }
            h && this.setData({
                areaAll: !0
            });
        }
        r[t].province.splice(a, 1, s), this.setData({
            area: r
        });
    },
    areaRestoration: function() {
        var e = this.data.area;
        t.clearArea(e), this.setData({
            areaAll: !1,
            area: e
        });
    },
    areaConfirm: function() {
        var e = this.data.area, a = this.data.allArea, t = this.data.allAreaId, r = 0, s = 0;
        a.length = 0, t.length = 0;
        for (var n = 0; n < e.length; n++) {
            for (c = 0; c < e[n].province.length; c++) r++;
            for (var c = 0; c < e[n].checkElement.length; c++) s++, "台湾" != e[n].checkElement[c] && "香港特别行政区" != e[n].checkElement[c] && "澳门特别行政区" != e[n].checkElement[c] && -1 == (i = a.indexOf(e[n].checkElement[c])) && a.push(e[n].checkElement[c]);
            for (var l = 0; l < e[n].checkElementId.length; l++) {
                var i = t.indexOf(e[n].checkElementId[l]);
                -1 == i && t.push(e[n].checkElementId[l]);
            }
        }
        0 == a.length ? (a.push("请选择"), this.setData({
            areaColor: "#C7C7CC"
        })) : this.setData({
            areaColor: "#31a4ff"
        }), r == s && (a.length = 0, a.push("全国")), this.setData({
            ifArea: !1,
            allArea: a,
            allAreaId: t
        }), 0 == this.data.allAreaId.length || 0 == this.data.allTradeId.length ? this.setData({
            disable: !0
        }) : this.setData({
            disable: !1
        });
    },
    onLoad: function() {
        var e = this;
        wx.showShareMenu({
            withShareTicket: !0
        }), r.getList("GET", "user/info", "").then(function(a) {
            var r = 1e3 * t.resExport(a);
            r = s.secondToDate(new Date(r));
            var n = parseInt(r.replace(/-/g, ""));
            e.ifChangeStartDate(n);
        });
    },
    onShow: function() {
        var e = this;
        this.getImage(), e.setData({
            hidden: !0
        }), wx.getStorage({
            key: "payTime",
            success: function(e) {
                console.log("已缓存"), console.log(e.data), t.memberDateHint(e.data, s);
            },
            fail: function() {
                console.log("未缓存"), r.getList("GET", "user/info", "").then(function(e) {
                    console.log(e);
                    var a = e.data.data.member_expires;
                    wx.setStorageSync("payTime", a), t.memberDateHint(a, s);
                });
            }
        });
        var a = {
            page: "pages/chartsHome/chartsHome",
            des: "统计报表"
        };
        t.pageMonitoring(r, a);
    },
    ifChangeStartDate: function(e) {
        var a = s.presentTime(new Date()), t = parseInt(a.replace(/-/g, ""));
        e >= t ? this.setData({
            startDate: "2013-01-01",
            endDate: s.presentTime(new Date())
        }) : e < t && this.setData({
            startDate: s.startFormatTime(new Date()),
            endDate: s.endFormatTime(new Date())
        });
    },
    bindStartDateChange: function(e) {
        var a = this, t = e.detail.value, n = s.startFormatTime(new Date()), c = s.endFormatTime(new Date()), l = s.presentTime(new Date()), i = parseInt(t.replace(/-/g, "")), o = parseInt(n.replace(/-/g, "")), h = parseInt(c.replace(/-/g, "")), d = parseInt(l.replace(/-/g, ""));
        o <= i && i <= h ? (console.log("一年内"), a.setData({
            startDate: e.detail.value
        })) : (console.log("一年以上"), wx.getStorage({
            key: "payTime",
            success: function(t) {
                var n = 1e3 * t.data;
                n = s.secondToDate(new Date(n));
                var c = parseInt(n.replace(/-/g, ""));
                0 == t.data ? (console.log("未开通会员"), wx.showModal({
                    title: "提示",
                    content: "未付费用户查看数据范围：当前日期前18个月至前6个月，开通会员享有全部数据权限。",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? (console.log("用户点击确定"), wx.getStorage({
                            key: "isBindPhone",
                            complete: function(e) {
                                e.data || "" ? (console.log("有缓存已绑定"), wx.navigateTo({
                                    url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=chartsHome"
                                })) : (console.log("无缓存发请求"), r.getList("GET", "user/isBindPhone", "").then(function(e) {
                                    wx.setStorage({
                                        key: "isBindPhone",
                                        data: e.data.data.bindStatus
                                    }), e.data.data.bindStatus ? (console.log("已绑定"), wx.navigateTo({
                                        url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=chartsHome"
                                    })) : (console.log("未绑定"), wx.navigateTo({
                                        url: "/pages/personalCenter/personalPage/personalPage?skipPage=chartsHome"
                                    }));
                                }));
                            }
                        })) : e.cancel && console.log("用户点击取消");
                    }
                })) : c >= d ? (console.log("会员未过期"), a.setData({
                    startDate: e.detail.value
                })) : c < d ? (console.log("会员过期"), wx.showModal({
                    title: "提示",
                    content: "您的会员已过期,重新开通会员享有全部数据权限",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? (console.log("用户点击确定"), wx.navigateTo({
                            url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=chartsHome"
                        })) : e.cancel && console.log("用户点击取消");
                    }
                })) : console.log("时间范围超出限制");
            },
            fail: function(e) {
                console.log("获取日期失败");
            }
        }));
    },
    bindEndDateChange: function(e) {
        var a = this, t = e.detail.value, n = s.startFormatTime(new Date()), c = s.endFormatTime(new Date()), l = s.presentTime(new Date()), i = parseInt(t.replace(/-/g, "")), o = parseInt(n.replace(/-/g, "")), h = parseInt(c.replace(/-/g, "")), d = parseInt(l.replace(/-/g, ""));
        o <= i && i <= h ? (console.log("一年内"), a.setData({
            endDate: e.detail.value
        })) : (console.log("一年以上"), wx.getStorage({
            key: "payTime",
            success: function(t) {
                var n = 1e3 * t.data;
                n = s.secondToDate(new Date(n));
                var c = parseInt(n.replace(/-/g, ""));
                0 == t.data ? (console.log("未开通会员"), wx.showModal({
                    title: "提示",
                    content: "未付费用户查看数据范围：当前日期前18个月至前6个月，开通会员享有全部数据权限。",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? (console.log("用户点击确定"), wx.getStorage({
                            key: "isBindPhone",
                            complete: function(e) {
                                e.data || "" ? (console.log("有缓存已绑定"), wx.navigateTo({
                                    url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=chartsHome"
                                })) : (console.log("无缓存发请求"), r.getList("GET", "user/isBindPhone", "").then(function(e) {
                                    wx.setStorage({
                                        key: "isBindPhone",
                                        data: e.data.data.bindStatus
                                    }), e.data.data.bindStatus ? (console.log("已绑定"), wx.navigateTo({
                                        url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=chartsHome"
                                    })) : (console.log("未绑定"), wx.navigateTo({
                                        url: "/pages/personalCenter/personalPage/personalPage?skipPage=chartsHome"
                                    }));
                                }));
                            }
                        })) : e.cancel && console.log("用户点击取消");
                    }
                })) : c >= d ? (console.log("会员未过期"), a.setData({
                    endDate: e.detail.value
                })) : c < d ? (console.log("会员过期"), wx.showModal({
                    title: "提示",
                    content: "您的会员已过期,重新开通会员享有全部数据权限",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? (console.log("用户点击确定"), wx.navigateTo({
                            url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=chartsHome"
                        })) : e.cancel && console.log("用户点击取消");
                    }
                })) : console.log("时间范围超出限制");
            },
            fail: function(e) {
                console.log("获取日期失败");
            }
        }));
    },
    formSubmit: function(e) {
        var a = this, t = e.detail.value, s = this.data.allTrade, n = this.data.allArea, c = this.data.startDate, l = this.data.endDate;
        r.getList("GET", "report/index", t).then(function(e) {
            if ("000000" === e.data.code) {
                if (a.setData({
                    hidden: !0
                }), "100301" == e.data.code) return void wx.showModal({
                    title: "提示",
                    content: "查询数据为空,请重新输入条件",
                    showCancel: !1,
                    success: function(e) {
                        e.confirm && console.log("用户点击确定");
                    }
                });
                var r = JSON.stringify(t), i = JSON.stringify(e.data.data);
                switch (e.data.data.reportType + "") {
                  case "1":
                    wx.navigateTo({
                        url: "../charts/chartsOccupancy/chartsOccupancy?allTrade=" + s + "&allArea=" + n + "&startTime=" + c + "&endTime=" + l + "&res=" + i
                    });
                    break;

                  case "2":
                    wx.navigateTo({
                        url: "../charts/chartsEarnings/chartsEarnings?allTrade=" + s + "&allArea=" + n + "&startTime=" + c + "&endTime=" + l + "&res=" + i
                    });
                    break;

                  case "3":
                    wx.navigateTo({
                        url: "../charts/chartsDeal/chartsDeal?toFormData=" + r + "&allTrade=" + s + "&allArea=" + n + "&startTime=" + c + "&endTime=" + l + "&res=" + i
                    });
                    break;

                  case "4":
                    wx.navigateTo({
                        url: "../charts/chartsDistribute/chartsDistribute?allTrade=" + s + "&allArea=" + n + "&startTime=" + c + "&endTime=" + l + "&res=" + i
                    });
                    break;

                  default:
                    console.log("报表类型为空");
                }
            } else a.setData({
                hidden: !0
            }), wx.showModal({
                title: "登录提示",
                content: "请在“个人中心”登录后再查询数据",
                showCancel: !0,
                cancelText: "取消",
                confirmText: "个人中心",
                success: function(e) {
                    wx.setStorage({
                        key: "show_useinfo",
                        data: !1
                    }), e.confirm ? wx.switchTab({
                        url: "../../pages/personalCenterHome/personalCenterHome"
                    }) : e.cancel;
                }
            });
        });
    },
    formReset: function(e) {
        var a = this.data.projects, r = this.data.area, n = this.data.items;
        t.clearProjects(a), t.clearArea(r);
        for (var c = 0; c < n.length; c++) n[c].checked = !1, 0 == c && (n[c].checked = !0);
        this.setData({
            allTrade: [ "请选择" ],
            allArea: [ "请选择" ],
            allTradeId: [],
            allAreaId: [],
            chartType: "1",
            tradeColor: "#C7C7CC",
            areaColor: "#C7C7CC",
            projects: a,
            area: r,
            items: n,
            allTradeDis: !1,
            tradeAll: !1,
            areaAll: !1,
            disable: !0,
            startDate: s.startFormatTime(new Date()),
            endDate: s.endFormatTime(new Date())
        });
    },
    projectCompanyNum: function() {
        var e = this;
        r.getList("GET", "totalProjectCompany", "").then(function(a) {
            e.setData({
                projectNum: a.data.data.totalProject,
                totalScale: parseInt(a.data.data.totalScale)
            });
        });
    },
    openAdvertising: function() {
        this.data.openAdvertising ? this.setData({
            openAdvertising: !1
        }) : this.setData({
            openAdvertising: !0
        });
    },
    closeAdvertising: function() {
        this.setData({
            openAdvertising: !1
        });
    },
    toRechargePage: function() {
        t.toPaymentPage(r);
    },
    getImage: function() {
        var e = this, a = {
            key: "5be010f406960"
        };
        r.getList("GET", "ad/position", a).then(function(a) {
            if ("000000" == a.data.code) {
                var t = a.data.data.startTime, r = a.data.data.endTime, s = Date.parse(new Date()) / 1e3;
                if (t <= s && s <= r) {
                    if ("images" === a.data.data.content.type) {
                        var n = a.data.data.content.value;
                        e.setData({
                            imageContent: n[0],
                            imageIcon: a.data.data.icon,
                            showImage: !0
                        });
                    }
                } else e.setData({
                    imageIcon: "",
                    showImage: !1
                });
            }
        });
    }
});
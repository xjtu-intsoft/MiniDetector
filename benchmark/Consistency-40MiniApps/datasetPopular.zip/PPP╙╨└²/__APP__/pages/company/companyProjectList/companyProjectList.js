var e = require("../../../utils/api.js"), t = require("../../../utils/util.js"), a = require("../../../utils/commin.js");

Page({
    data: {
        newsList: [],
        loadHidden: !0,
        isload: !0,
        toastHidden: !0,
        moreHidden: "none",
        loadFinished: !1,
        loadMore: "loadMore",
        iscompanyProject: !0,
        id: "",
        address: "",
        company_name: "",
        isListed: "",
        companyType: "",
        totleProject: "",
        projectNum: "",
        page: 1,
        isindustry: !0,
        noNews: "没有符合条件的信息",
        province_id: "",
        industry_id: "",
        cache_id: "",
        isShowCollection: !0,
        scroollHeight: 0
    },
    onShareAppMessage: function(e) {
        console.log("我点击的是转发");
        var t = this;
        return a.sharePage("企业分析", "/pages/company/companyProjectList/companyProjectList", "share=true&shareId=" + t.data.cache_id);
    },
    onLoad: function(t) {
        wx.showShareMenu({
            withShareTicket: !0
        });
        var a = this, o = t.share || 0;
        if (wx.getSystemInfo({
            success: function(e) {
                a.setData({
                    scroollHeight: e.windowHeight
                });
            }
        }), o) {
            console.log("从转发渠道打开");
            var s = t.shareId;
            "" != s ? (wx.setStorage({
                key: "cache_id",
                data: s
            }), a.setData({
                cache_id: s
            })) : s = wx.getStorageSync("cache_id"), console.log(s), e.getList("GET", "cache/get/" + s, "").then(function(e) {
                console.log("转发渠道发送请求------"), console.log(e), console.log("上面是请求的数据"), console.log(e.data.data.cacheData), 
                console.log("这是取出来的data");
                var t = JSON.parse(e.data.data.cacheData);
                a.setData({
                    isindustry: t.isindustry,
                    projectId: t.projectId,
                    projectNum: t.projectNum,
                    address: t.address,
                    company_name: t.company_name,
                    isListed: t.isListed,
                    companyType: t.companyType,
                    totleProject: t.totleProject,
                    industry_id: t.industry_id,
                    province_id: t.province_id
                }), "true" == a.data.isindustry ? a.getByIndustry() : a.getByProvince();
            });
        } else {
            t.isindustry;
            a.setData({
                isindustry: t.isindustry,
                projectId: t.projectId,
                projectNum: t.projectNum,
                address: t.address,
                company_name: t.company_name,
                isListed: t.isListed,
                companyType: t.companyType,
                totleProject: t.totleProject,
                industry_id: t.industry_id,
                province_id: t.province_id
            });
            var n = {}, i = {};
            i.isindustry = t.isindustry, i.projectId = t.projectId, i.projectNum = t.projectNum, 
            i.address = t.address, i.company_name = t.company_name, i.isListed = t.isListed, 
            i.companyType = t.companyType, i.totleProject = t.totleProject, i.industry_id = t.industry_id, 
            i.province_id = t.province_id, n.cache_data = JSON.stringify(i), console.log("获取分享内容"), 
            e.getList("POST", "cache/create", n).then(function(e) {
                a.setData({
                    cache_id: e.data.data.id
                });
            }), "true" == a.data.isindustry ? a.getByIndustry() : a.getByProvince();
        }
    },
    onShow: function() {
        this.setData({
            isload: !0
        });
        wx.getStorage({
            key: "payTime",
            complete: function(o) {
                if (void 0 == o.data || "" == o.data) {
                    console.log("未缓存");
                    e.getList("GET", "user/info", "").then(function(e) {
                        var o = a.resExport(e);
                        wx.setStorageSync("payTime", o);
                        var s = 1e3 * o;
                        s = t.secondToDate(new Date(s));
                        parseInt(s.replace(/-/g, ""));
                    });
                } else {
                    console.log("已缓存");
                    var s = 1e3 * o.data;
                    s = t.secondToDate(new Date(s));
                    parseInt(s.replace(/-/g, ""));
                }
            }
        });
        var o = {
            page: "pages/company/companyProjectList/companyProjectList",
            des: "企业项目列表"
        };
        a.pageMonitoring(e, o);
    },
    getByIndustry: function() {
        var t = this, o = t.data.industry_id, s = t.data.projectId, n = t.data.page, i = t.data.iscompanyProject;
        console.log("通过行业来查询"), t.setData({
            loadHidden: !1
        });
        var r = {
            project_id_array: s,
            industry_id: o,
            page: n
        };
        e.getList("GET", "project/projectLists", r).then(function(e) {
            var o = e.data.data.data || "";
            if ((o.length > 0 || n > 1) && t.setData({
                noNews: "没有更多"
            }), o.length < 1) t.setData({
                toastHidden: !1,
                moreHidden: "none",
                loadHidden: !0
            }); else if (1 == n && o.length < 10) {
                s = o;
                s = a.projectListValue(s, i, n), t.setData({
                    newsList: s,
                    moreHidden: "none",
                    loadHidden: !0
                });
            } else {
                var s = t.data.newsList.concat(o);
                s = a.projectListValue(s, i), t.setData({
                    newsList: s,
                    moreHidden: "",
                    loadHidden: !0
                });
            }
        });
    },
    getByProvince: function() {
        var t = this, o = t.data.projectId, s = t.data.page, n = t.data.province_id, i = t.data.iscompanyProject;
        console.log("通过地区来查询"), t.setData({
            loadHidden: !1
        });
        var r = {
            project_id_array: o,
            province_id: n,
            page: s
        };
        e.getList("GET", "project/projectLists", r).then(function(e) {
            var o = e.data.data.data || "";
            if ((o.length > 0 || s > 1) && t.setData({
                noNews: "没有更多"
            }), o.length < 1) t.setData({
                toastHidden: !1,
                moreHidden: "none",
                loadHidden: !0
            }); else if (1 == s && o.length < 10) {
                n = o;
                n = a.projectListValue(n, i, s), t.setData({
                    newsList: n,
                    moreHidden: "none",
                    loadHidden: !0
                });
            } else {
                var n = t.data.newsList.concat(o);
                n = a.projectListValue(n, i, s), t.setData({
                    newsList: n,
                    moreHidden: "",
                    loadHidden: !0
                });
            }
        });
    },
    loadMore: function() {
        var e = this.data.isindustry, t = this.data.page;
        "true" == e ? (this.setData({
            page: t + 1
        }), this.getByIndustry()) : (this.setData({
            page: t + 1
        }), this.getByProvince());
    },
    toastChange: function() {
        this.data.newsList.length > 1 && this.setData({
            loadFinished: !0
        }), this.setData({
            toastHidden: !0,
            loadMore: ""
        });
    },
    loadDetails: function(a) {
        this.setData({
            isload: !1
        });
        var o = this, s = a.currentTarget.dataset.id, n = a.currentTarget.dataset.recentproject, i = a.currentTarget.dataset.bidtime, r = t.startFormatTime(new Date()), d = t.endFormatTime(new Date()), c = t.presentTime(new Date()), l = parseInt(i.replace(/-/g, "")), p = parseInt(r.replace(/-/g, "")), g = parseInt(d.replace(/-/g, "")), u = parseInt(c.replace(/-/g, "")), y = o.data.isShowCollection;
        p <= l && l <= g ? (console.log("一年内"), wx.navigateTo({
            url: "/pages/project/details/details?id=" + s + "&&recentProject=" + n + "&&isShowCollection=" + y
        })) : (console.log("一年以上"), wx.getStorage({
            key: "payTime",
            success: function(a) {
                o.setData({
                    isload: !0
                });
                var i = 1e3 * a.data;
                i = t.secondToDate(new Date(i));
                var r = parseInt(i.replace(/-/g, ""));
                0 == a.data ? (console.log("未开通会员"), wx.showModal({
                    title: "提示",
                    content: "未付费用户查看数据范围：当前日期前18个月至前6个月，开通会员享有全部数据权限。",
                    confirmText: "去开通",
                    success: function(t) {
                        t.confirm ? (console.log("用户点击确定"), wx.getStorage({
                            key: "isBindPhone",
                            complete: function(t) {
                                t.data || "" ? (console.log("有缓存已绑定"), wx.navigateTo({
                                    url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=companyHome"
                                })) : (console.log("无缓存发请求"), e.getList("GET", "user/isBindPhone", "").then(function(e) {
                                    wx.setStorage({
                                        key: "isBindPhone",
                                        data: e.data.data.bindStatus
                                    }), e.data.data.bindStatus ? (console.log("已绑定"), wx.navigateTo({
                                        url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=companyHome"
                                    })) : (console.log("未绑定"), wx.navigateTo({
                                        url: "/pages/personalCenter/personalPage/personalPage?skipPage=companyHome"
                                    }));
                                }));
                            }
                        })) : t.cancel && (o.setData({
                            isload: !0
                        }), console.log("用户点击取消"));
                    }
                })) : r >= u ? (console.log("会员未过期"), wx.navigateTo({
                    url: "/pages/project/details/details?id=" + s + "&&recentProject=" + n + "&&isShowCollection=" + y
                })) : r < u ? (console.log("会员过期"), wx.showModal({
                    title: "提示",
                    content: "您的会员已过期,重新开通会员享有全部数据权限",
                    confirmText: "去开通",
                    success: function(e) {
                        e.confirm ? (o.setData({
                            isload: !0
                        }), console.log("用户点击确定"), wx.navigateTo({
                            url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=companyHome"
                        })) : e.cancel && (o.setData({
                            isload: !0
                        }), console.log("用户点击取消"));
                    }
                })) : console.log("时间范围超出限制");
            },
            fail: function(e) {
                console.log("获取日期失败");
            }
        }));
    }
});
var a = require("../../../utils/api.js"), t = (require("../../../utils/util.js"), 
require("../../../utils/commin.js"));

Page({
    data: {
        newsList: [],
        loadHidden: !0,
        toastHidden: !0,
        noNews: "没有符合条件的数据",
        isloadHidden: !0,
        id: "",
        address: "",
        area: [],
        industry: [],
        company_name: "",
        isListed: "",
        companyType: "",
        totleProject: "",
        companyTotalScale: "",
        projectId: [],
        cache_id: "",
        collectionName: "收藏",
        isCollection: !1,
        isShowCollection: "true",
        projectNum: "_____",
        totalScale: "_____"
    },
    onShareAppMessage: function(a) {
        console.log("我点击的是转发");
        var e = this;
        return t.sharePage("企业分析", "/pages/company/companyDetails/companyDetails", "share=true&shareId=" + e.data.cache_id);
    },
    onLoad: function(t) {
        var e = this;
        if (wx.showShareMenu({
            withShareTicket: !0
        }), this.projectCompanyNum(), t.share || 0) {
            console.log("从转发渠道打开");
            var o = t.shareId;
            "" != o ? (wx.setStorage({
                key: "cache_id",
                data: o
            }), e.setData({
                cache_id: o
            })) : o = wx.getStorageSync("cache_id"), a.getList("GET", "cache/get/" + o, "").then(function(a) {
                console.log("转发渠道发送请求------"), console.log(a), console.log("上面是请求的数据"), console.log(a.data.data.cacheData), 
                console.log("这是取出来的data");
                var t = JSON.parse(a.data.data.cacheData);
                e.getCompanyTotalScale(t.industry), e.setData({
                    area: t.area,
                    industry: t.industry,
                    address: t.address,
                    isListed: t.isListed,
                    company_name: t.company_name,
                    companyType: t.companyType,
                    totleProject: t.totleProject,
                    projectId: t.projectId,
                    isShowCollection: t.isShowCollection
                });
            });
        } else {
            var n = t.id, c = {
                id: n
            };
            e.setData({
                loadHidden: !1,
                id: n,
                isShowCollection: t.isShowCollection
            }), "true" == t.isCollection ? e.setData({
                collectionName: "已收藏",
                isCollection: !0
            }) : e.setData({
                collectionName: "收藏",
                isCollection: !1
            }), a.getList("GET", "project/enterpriseStatistics", c).then(function(t) {
                t.data.data.area.length < 1 && t.data.data.industry.length < 1 ? (setTimeout(e.loadChange, 200), 
                e.setData({
                    toastHidden: !1,
                    area: t.data.data.area,
                    address: t.data.data.company_info.province.name,
                    isListed: t.data.data.company_info.is_listed,
                    company_name: t.data.data.company_info.company_name,
                    companyType: t.data.data.company_info.nature.value,
                    totleProject: t.data.data.company_info.totle_project.total_project + "个",
                    companyTotalScale: t.data.data.company_info.totle_project.scale.toFixed(2) + "亿元",
                    projectId: t.data.data.company_info.project_id_array
                })) : (e.setData({
                    area: t.data.data.area,
                    industry: t.data.data.industry,
                    address: t.data.data.company_info.province.name,
                    isListed: t.data.data.company_info.is_listed,
                    company_name: t.data.data.company_info.company_name,
                    companyType: t.data.data.company_info.nature.value,
                    totleProject: t.data.data.company_info.totle_project.total_project + "个",
                    companyTotalScale: t.data.data.company_info.totle_project.scale.toFixed(2) + "亿元",
                    projectId: t.data.data.company_info.project_id_array
                }), setTimeout(e.loadChange, 200));
                var o = {}, n = {};
                n.area = t.data.data.area, n.industry = t.data.data.industry, n.address = t.data.data.company_info.province.name, 
                n.isListed = t.data.data.company_info.is_listed, n.company_name = t.data.data.company_info.company_name, 
                n.companyType = t.data.data.company_info.nature.value, n.totleProject = t.data.data.company_info.totle_project.total_project + "个", 
                n.companyTotalScale = t.data.data.company_info.totle_project.scale.toFixed(2) + "亿元", 
                n.projectId = t.data.data.company_info.project_id_array, n.isShowCollection = !1, 
                o.cache_data = JSON.stringify(n), console.log("获取分享内容"), a.getList("POST", "cache/create", o).then(function(a) {
                    e.setData({
                        cache_id: a.data.data.id
                    });
                });
            });
        }
    },
    onShow: function() {
        this.setData({
            isloadHidden: !0
        });
        var e = {
            page: "pages/company/companyDetails/companyDetails",
            des: "企业详情"
        };
        t.pageMonitoring(a, e);
    },
    getByIndustry: function(a) {
        this.paylimit(a);
    },
    getByProvince: function(a) {
        this.paylimit(a);
    },
    toastChange: function() {
        this.setData({
            toastHidden: !0
        });
    },
    loadChange: function() {
        this.setData({
            loadHidden: !0
        });
    },
    paylimit: function(a) {
        var e = this;
        e.setData({
            isloadHidden: !1
        }), t.clearProjectStory();
        var o = a.currentTarget.dataset.isbyindustry, n = a.currentTarget.dataset.item.province_id, c = a.currentTarget.dataset.item.industry_id, i = e.data.projectId, d = a.currentTarget.dataset.item.num_total, s = e.data.address, r = e.data.company_name, l = e.data.isListed, p = e.data.companyType, m = e.data.totleProject;
        if ("true" == o) {
            y = {
                url: "/pages/company/companyProjectList/companyProjectList?projectId=" + i + "&&industry_id=" + c + "&&projectNum=" + d + "&&isindustry=" + o + "&&company_name=" + r + "&&address=" + s + "&&isListed=" + l + "&&companyType=" + p + "&&totleProject=" + m
            };
            wx.navigateTo(y);
        } else {
            var y = {
                url: "/pages/company/companyProjectList/companyProjectList?projectId=" + i + "&&province_id=" + n + "&&projectNum=" + d + "&&isindustry=" + o + "&&company_name=" + r + "&&address=" + s + "&&isListed=" + l + "&&companyType=" + p + "&&totleProject=" + m
            };
            wx.navigateTo(y);
        }
    },
    isCollection: function(t) {
        var e = this, o = this, n = o.data.id, c = (o.data.collectionName, {
            company_id: n
        }), i = o.data.isCollection;
        wx.setStorage({
            key: "keyRefresh",
            data: !0
        }), i ? a.getList("POST", "project/cancelCompanyCollect", c).then(function(a) {
            "000000" == a.data.code && e.setData({
                collectionName: "收藏",
                isCollection: !1
            });
        }) : a.getList("GET", "project/companyCollect", c).then(function(a) {
            "000000" == a.data.code && e.setData({
                collectionName: "已收藏",
                isCollection: !0
            });
        });
    },
    projectCompanyNum: function() {
        var a = this;
        wx.request({
            header: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            url: "https://wx.youlidata.com/api/wx/v1/totalProjectCompany",
            data: "",
            method: "GET",
            success: function(t) {
                a.setData({
                    projectNum: t.data.data.totalProject,
                    totalScale: parseInt(t.data.data.totalScale)
                });
            },
            fail: function(a) {
                console.log("submit fail");
            },
            complete: function(a) {
                console.log("submit complete");
            }
        });
    }
});
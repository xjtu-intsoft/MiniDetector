var t = require("../../../utils/api.js"), e = require("../../../utils/commin.js");

Page({
    data: {
        loadHidden: !0,
        toastHidden: !0,
        moreHidden: "none",
        loadFinished: !1,
        loadMore: "loadMore",
        page: 1,
        newsList: [],
        noNews: "没有符合条件的信息",
        isEmpty: !1,
        isCollection: !0,
        isShowCollection: !0,
        scroollHeight: 0
    },
    onLoad: function(t) {
        var e = this;
        wx.getSystemInfo({
            success: function(t) {
                e.setData({
                    scroollHeight: t.windowHeight
                });
            }
        }), this.getCompanyList();
    },
    onShow: function() {
        var a = this, o = {
            page: "pages/company/companyCollectionList/companyCollectionList",
            des: "企业分析"
        };
        e.pageMonitoring(t, o), wx.getStorage({
            key: "keyRefresh",
            success: function(t) {
                t.data && (a.setData({
                    newsList: [],
                    page: 1,
                    loadFinished: !1,
                    loadMore: "loadMore"
                }), a.getCompanyList());
            }
        });
    },
    onHide: function() {},
    getCompanyList: function() {
        var e = this, a = e.data.page, o = {
            page: a
        };
        e.setData({
            loadHidden: !1
        }), t.getList("GET", "project/companyCollectList", o).then(function(t) {
            if ("000000" === t.data.code) {
                var o = t.data.data.data || "", n = e.data.newsList.concat(o);
                o.length < 1 && a > 1 ? e.setData({
                    toastHidden: !1,
                    noNews: "没有更多",
                    moreHidden: "none"
                }) : o.length < 1 && 1 == a ? e.setData({
                    moreHidden: "none",
                    newsList: [],
                    isEmpty: !0
                }) : (o.length >= 1 && o.length < 10 && 1 == a ? e.setData({
                    moreHidden: "none"
                }) : e.setData({
                    moreHidden: ""
                }), e.setData({
                    newsList: n,
                    page: a,
                    newCompany: "共收藏" + t.data.data.total + "个企业"
                })), e.setData({
                    loadHidden: !0
                });
            } else wx.showModal({
                title: "登录提示",
                content: "请在“个人中心”登录后再查询数据",
                showCancel: !0,
                cancelText: "取消",
                confirmText: "个人中心",
                success: function(t) {
                    wx.setStorage({
                        key: "show_useinfo",
                        data: !1
                    }), t.confirm ? wx.switchTab({
                        url: "../../personalCenterHome/personalCenterHome"
                    }) : t.cancel;
                }
            }), e.setData({
                loadHidden: !0
            });
        });
    },
    loadMore: function() {
        var t = this.data.page;
        this.setData({
            page: t + 1
        }), this.getCompanyList();
    },
    toastChange: function() {
        this.data.newsList.length > 1 && this.setData({
            loadFinished: !0
        }), this.setData({
            toastHidden: !0,
            loadMore: ""
        });
    },
    loadDetails: function(t) {
        var e = t.currentTarget.dataset.id, a = t.currentTarget.dataset.iscollection, o = this.data.isShowCollection;
        wx.navigateTo({
            url: "/pages/company/companyDetails/companyDetails?id=" + e + "&&isCollection=" + a + "&&isShowCollection=" + o
        });
    }
});
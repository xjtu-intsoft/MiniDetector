function t(t) {
    return (t = t.toString())[1] ? t : "0" + t;
}

module.exports = {
    formatTime: function(e) {
        var n = e.getFullYear(), o = e.getMonth() + 1, r = e.getDate(), a = e.getHours(), u = e.getMinutes(), i = e.getSeconds();
        return 1 == d ? [ n, o, r ].map(t).join("-") : 2 == d ? [ a, u ].map(t).join(":") : [ n, o, r ].map(t).join("/") + " " + [ a, u, i ].map(t).join(":");
    },
    startFormatTime: function(e) {
        for (var n = e.getFullYear(), o = e.getMonth() - 17, r = e.getDate(), a = -Math.floor(o / 12), u = 0; u <= a; u++) o <= 0 && (o = 12 + o, 
        n -= 1);
        return [ n, o, r ].map(t).join("-");
    },
    endFormatTime: function(e) {
        for (var n = e.getFullYear(), o = e.getMonth() - 5, r = e.getDate(), a = -Math.floor(o / 12), u = 0; u <= a; u++) o <= 0 && (o = 12 + o, 
        n -= 1);
        return [ n, o, r ].map(t).join("-");
    },
    formatNumber: t,
    json2Form: function(t) {
        var e = [];
        for (var n in t) e.push(encodeURIComponent(n) + "=" + encodeURIComponent(t[n]));
        return e.join("&");
    },
    secondToDate: function(e) {
        var n = e.getFullYear(), o = e.getMonth() - 11, r = e.getDate();
        return o <= 0 && (o = 12 + o, n = n), [ n, o, r ].map(t).join("-");
    },
    presentTime: function(e) {
        var n = e.getFullYear(), o = e.getMonth() + 1, r = e.getDate();
        return o <= 0 && (o = 12 + o, n -= 1), [ n, o, r ].map(t).join("-");
    },
    formatDate: function(t) {
        var e = t.getFullYear(), n = t.getMonth() + 1;
        n = n < 10 ? "0" + n : n;
        var o = t.getDate();
        return o = o < 10 ? "0" + o : o, e + "-" + n + "-" + o;
    }
};
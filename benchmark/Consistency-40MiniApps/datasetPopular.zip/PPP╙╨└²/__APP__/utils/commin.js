function e(e) {
    for (var t = 0; t < e.length; t++) {
        e[t].checked = !1, e[t].disabled = !1, e.splice(t, 1, e[t]), e[t].checkElement.length = 0, 
        e[t].checkElementId.length = 0;
        for (var n = 0; n < e[t].list.length; n++) e[t].list[n].checked = !1, e[t].list[n].disabled = !1, 
        e[t].list.splice(n, 1, e[t].list[n]);
    }
    return e;
}

function t(e, t, n, a) {
    if (0 == n) if (t.checked) for (r = 0; r < e.length; r++) e[r].checked = !1; else for (r = 0; r < e.length; r++) e[r].checked = !0; else if (t.checked) t.checked = !1, 
    e[0].checked = !1; else {
        t.checked = !0;
        for (var r = 1; r < e.length; r++) e[r].checked || (a = !1);
        a && (e[0].checked = !0);
    }
    return e;
}

function t(e, t, n, a) {
    if (0 == n) if (t.checked) for (r = 0; r < e.length; r++) e[r].checked = !1; else for (r = 0; r < e.length; r++) e[r].checked = !0; else if (t.checked) t.checked = !1, 
    e[0].checked = !1; else {
        t.checked = !0;
        for (var r = 1; r < e.length; r++) e[r].checked || (a = !1);
        a && (e[0].checked = !0);
    }
    return e;
}

function n() {
    return "projectidFeedback";
}

module.exports = {
    getHeight: function(e, t) {
        var n = t[e];
        return "80rpx" == n.style.height ? (n.style.height = "auto", n.style.url = "more_down.png") : (n.style.height = "80rpx", 
        n.style.url = "more_up.png"), t.splice(e, 1, n), t;
    },
    clearArea: function(e) {
        for (var t = 0; t < e.length; t++) {
            e[t].checked = !1, e.splice(t, 1, e[t]), e[t].checkElement.length = 0, e[t].checkElementId.length = 0;
            for (var n = 0; n < e[t].province.length; n++) e[t].province[n].checked = !1, e[t].province.splice(n, 1, e[t].province[n]);
        }
        return e;
    },
    clearProjects: e,
    searchReport: t,
    searchMethod: function(e, t, n, a) {
        if (t.checked) t.checked = !1; else {
            t.checked = !0;
            for (var r = 1; r < e.length; r++) e[r].checked;
        }
        return e;
    },
    projectChoose: function(t, n) {
        for (var a = 0; a < t.length; a++) {
            t[a].disabled = n, t.splice(a, 1, t[a]);
            for (var r = 0; r < t[a].list.length; r++) t[a].list[r].disabled = n;
            e(t);
        }
    },
    searchCity: function(e, t, n, a) {
        if (t.checked) t.checked = !1; else {
            t.checked = !0;
            for (var r = 1; r < e.length; r++) e[r].checked || (a = !1);
            a && (e[0].checked = !0);
        }
        return e;
    },
    clearReport: function(e) {
        for (var t = 0; t < e.length; t++) e[t].checked = !1, e.splice(t, 1, e[t]);
        return e;
    },
    clearCity: function(e) {
        for (var t = 0; t < e.length; t++) e[t].checked = !1, e.splice(t, 1, e[t]);
        return e;
    },
    appendProjectStory: function(e, t) {
        if ("" != (r = wx.getStorageSync(e))) {
            var a = this.getProjectStory(t.proId);
            "" != a ? r.data[a.index] = t : r.data.push(t);
        } else var r = {
            data: new Array(t)
        };
        wx.setStorageSync(n(), r);
    },
    getProjectStory: function(e) {
        var t = wx.getStorageSync(n());
        if (0 == t.data.length) return "";
        for (var a = 0; a < t.data.length; a++) if (null != t.data[a] && t.data[a].proId == e) return {
            index: a,
            value: t.data[a].value
        };
        return "";
    },
    clearProjectStory: function() {
        wx.setStorageSync(n(), {
            data: []
        });
    },
    removeProjectStoryKey: function(e) {
        for (var t = wx.getStorageSync(n()), a = 0; a < t.data.length; a++) null != t.data[a] && t.data[a].proId == e && delete t.data[a];
        wx.setStorageSync(n(), t);
    },
    pageMonitoring: function(e, t) {},
    projectListValue: function(e, t, n) {
        for (var a = e, r = wx.getStorageSync("isMember"), o = parseInt(wx.getStorageSync("endTime").replace(/-/g, "")), t = t, n = n, c = 0; c < a.length; c++) {
            if (a[c].bidCompany = "", a[c].runPattern = "", a[c].cooperation = "", null == a[c].cooperation_phase_ext || "" == a[c].cooperation_phase_ext) {
                var i = a[c].cooperation_phase;
                a[c].cooperation = i;
            } else a[c].cooperation = null == a[c].cooperation_phase_ext ? "" : a[c].cooperation_phase_ext;
            if (1 != t) {
                if (0 == r && parseInt(a[c].win_bid_time.replace(/-/g, "")) > o && (n > 1 ? a[c].project_name = "***************************************" : c > 2 && (a[c].project_name = "***************************************")), 
                a[c].company_single.length > 0) for (var l = 0; l < a[c].company_single.length; l++) "" == a[c].bidCompany ? a[c].bidCompany = a[c].company_single[l].name : a[c].bidCompany = a[c].bidCompany + "和" + a[c].company_single[l].name;
                if (a[c].view_company_project.length > 0) for (var s = 0; s < a[c].view_company_project.length; s++) "" == a[c].bidCompany ? a[c].bidCompany = a[c].view_company_project[s].name : a[c].bidCompany = a[c].bidCompany + "和" + a[c].view_company_project[s].name;
            }
            if (a[c].sys_dictionary_operation_pattern.length > 0) for (var g = 0; g < a[c].sys_dictionary_operation_pattern.length; g++) "" == a[c].runPattern ? a[c].runPattern = a[c].sys_dictionary_operation_pattern[g].value : a[c].runPattern = a[c].runPattern + "," + a[c].sys_dictionary_operation_pattern[g].value;
        }
        return a;
    },
    sharePage: function(e, t, n) {
        var n = n || "", a = Date.parse(new Date()) / 1e3, r = wx.getStorageSync("user_uniq_token"), o = wx.getStorageSync("channel_id"), c = wx.getStorageSync("discountTitle"), i = "";
        return i = "" == c ? e : c, {
            title: i,
            path: t + "?channel_id=" + o + "&userToken=" + r + "&shareTime=" + a + "&" + n,
            success: function(e) {
                console.log("分享成功"), wx.showToast({
                    title: "分享成功",
                    icon: "success",
                    duration: 1500
                });
            },
            fail: function(e) {
                console.log("分享失败");
            }
        };
    },
    memberDateHint: function(e, t) {
        var n = wx.getStorageSync("hintTime") || "", a = Date.parse(new Date()) / 1e3, r = e, o = t.secondToDate(new Date(1e3 * r)), c = r - a, i = Math.floor(c / 86400);
        if (n) {
            var l = t.secondToDate(new Date(1e3 * a));
            l = parseInt(l.replace(/-/g, "")), parseInt(o.replace(/-/g, "")) >= l && l > n && (console.log("当前日期大于提示日期,重新提示"), 
            wx.showModal({
                title: "提示",
                content: "您的会员身份将于" + o + "日到期,请续费",
                confirmText: "去续费",
                success: function(e) {
                    wx.setStorage({
                        key: "hintTime",
                        data: l
                    }), e.confirm ? (console.log("用户点击确定"), wx.navigateTo({
                        url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=personalCenterHome"
                    })) : e.cancel && console.log("用户点击取消");
                }
            }));
        } else 0 <= i && i < 7 && wx.showModal({
            title: "提示",
            content: "您的会员身份将于" + o + "日到期,请续费",
            confirmText: "去续费",
            success: function(e) {
                var n = t.secondToDate(new Date(1e3 * a));
                n = parseInt(n.replace(/-/g, "")), wx.setStorage({
                    key: "hintTime",
                    data: n
                }), e.confirm ? (console.log("用户点击确定"), wx.navigateTo({
                    url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=personalCenterHome"
                })) : e.cancel && console.log("用户点击取消");
            }
        });
    },
    resExport: function(e) {
        if (e.data.data.is_enterprise_user) t = e.data.data.enterprise_member_expires; else var t = e.data.data.member_expires;
        return t;
    },
    isCityWithoutDistricts: function(e, t) {
        if (0 == t.length || t.length > 1) return !1;
        for (var n = 0; n < e.length; n++) if (e[n].id == t[0]) return !(e[n].district.length > 0);
    },
    toPaymentPage: function(e) {
        wx.getStorage({
            key: "isBindPhone",
            complete: function(t) {
                t.data ? (console.log("有缓存"), wx.navigateTo({
                    url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=personalCenterHome"
                })) : (console.log("没缓存"), e.getList("GET", "user/isBindPhone", "").then(function(e) {
                    wx.setStorage({
                        key: "isBindPhone",
                        data: e.data.data.bindStatus
                    }), e.data.data.bindStatus ? wx.navigateTo({
                        url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=personalCenterHome"
                    }) : wx.navigateTo({
                        url: "/pages/personalCenter/personalPage/personalPage?skipPage=personalCenterHome"
                    });
                }));
            }
        });
    }
};
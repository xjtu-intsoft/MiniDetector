function a(a) {
    var e = a.data.chooseNum, t = a.data.isDeleteKey;
    if (1 == e && ((s = a.data.nameData).view.isShow = !1, a.setData({
        nameData: s
    })), 2 == e) {
        var s = a.data.wxSearchData;
        1 != t && (s.view.isShow = !1), a.setData({
            wxSearchData: s
        });
    }
}

function e(a) {
    a.setData({
        isDeleteKey: !1
    });
    var e = a.data.chooseNum, t = [];
    try {
        if (1 == e && (t = wx.getStorageSync("nameHisKeys")) && ((s = a.data.nameData).his = t, 
        a.setData({
            nameData: s
        })), 2 == e && (t = wx.getStorageSync("wxSearchHisKeys"))) {
            var s = a.data.wxSearchData;
            s.his = t, a.setData({
                wxSearchData: s
            });
        }
    } catch (a) {}
}

module.exports = {
    init: function(a, t, s, c, i, n) {
        var r = {}, o = a.data.chooseNum, h = {
            barHeight: t,
            isShow: !1
        };
        h.isShowSearchKey = void 0 === c || c, h.isShowSearchHistory = void 0 === i || i, 
        r.keys = s, wx.getSystemInfo({
            success: function(e) {
                var s = e.windowHeight;
                h.seachHeight = s - t, r.view = h, 1 == o && a.setData({
                    nameData: r
                }), 2 == o && a.setData({
                    wxSearchData: r
                });
            }
        }), "function" == typeof n && n(), e(a);
    },
    wxSearchFocus: function(a, e, t) {
        var s = e.data.chooseNum;
        if (1 == s && ((c = e.data.nameData).view.isShow = !0, e.setData({
            nameData: c
        })), 2 == s) {
            var c = e.data.wxSearchData;
            c.view.isShow = !0, e.setData({
                wxSearchData: c
            });
        }
        "function" == typeof t && t();
    },
    wxSearchBlur: function(a, e, t) {
        var s = e.data.chooseNum;
        if (1 == s && ((c = e.data.nameData).value = a.detail.value, e.setData({
            nameData: c
        })), 2 == s) {
            var c = e.data.wxSearchData;
            c.value = a.detail.value, e.setData({
                wxSearchData: c
            });
        }
        "function" == typeof t && t();
    },
    wxSearchKeyTap: function(a, e, t) {
        var s = e.data.chooseNum;
        if (1 == s && ((c = e.data.nameData).value = a.target.dataset.key, e.setData({
            nameData: c
        })), 2 == s) {
            var c = e.data.wxSearchData;
            c.value = a.target.dataset.key, e.setData({
                wxSearchData: c
            });
        }
        "function" == typeof t && t();
    },
    wxSearchAddHisKey: function(t) {
        t.setData({
            isDeleteKey: !1
        }), a(t);
        var s = t.data.chooseNum;
        if (1 == s) {
            if (void 0 === (c = t.data.nameData.value) || 0 == c.length) return;
            (i = wx.getStorageSync("nameHisKeys")) ? (i.indexOf(c) < 0 && i.unshift(c), wx.setStorage({
                key: "nameHisKeys",
                data: i,
                success: function() {
                    e(t);
                }
            })) : ((i = []).push(c), wx.setStorage({
                key: "nameHisKeys",
                data: i,
                success: function() {
                    e(t);
                }
            }));
        }
        if (2 == s) {
            var c = t.data.wxSearchData.value;
            if (void 0 === c || 0 == c.length) return;
            var i = wx.getStorageSync("wxSearchHisKeys");
            i ? (i.indexOf(c) < 0 && i.unshift(c), wx.setStorage({
                key: "wxSearchHisKeys",
                data: i,
                success: function() {
                    e(t);
                }
            })) : ((i = []).push(c), wx.setStorage({
                key: "wxSearchHisKeys",
                data: i,
                success: function() {
                    e(t);
                }
            }));
        }
    },
    wxSearchDeleteKey: function(a, t) {
        var s = t.data.chooseNum;
        1 == s && (c = a.target.dataset.key, (i = wx.getStorageSync("nameHisKeys")).splice(i.indexOf(c), 1), 
        wx.setStorage({
            key: "nameHisKeys",
            data: i,
            success: function() {
                e(t);
            }
        }));
        if (2 == s) {
            var c = a.target.dataset.key, i = wx.getStorageSync("wxSearchHisKeys");
            t.setData({
                isDeleteKey: !0
            }), i.splice(i.indexOf(c), 1), wx.setStorage({
                key: "wxSearchHisKeys",
                data: i,
                success: function() {
                    e(t);
                }
            });
        }
    },
    wxSearchDeleteAll: function(a) {
        var e = a.data.chooseNum;
        1 == e && wx.removeStorage({
            key: "nameHisKeys",
            success: function(e) {
                var t = [], s = a.data.nameData;
                s.his = t, a.setData({
                    nameData: s
                });
            }
        }), 2 == e && (a.setData({
            isDeleteKey: !1
        }), wx.removeStorage({
            key: "wxSearchHisKeys",
            success: function(e) {
                var t = [], s = a.data.wxSearchData;
                s.his = t, a.setData({
                    wxSearchData: s
                });
            }
        }));
    },
    wxSearchHiddenPancel: a
};
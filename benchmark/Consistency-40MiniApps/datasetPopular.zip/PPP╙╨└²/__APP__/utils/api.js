function e(e, s, r) {
    var d = "";
    return d = "post" == e.toLowerCase() ? "application/x-www-form-urlencoded" : "json", 
    new o(function(o, a) {
        t.request({
            url: n + "/" + s,
            method: "" + e,
            data: r,
            header: {
                "X-drive-model": i.model,
                "X-drive-windowWidth": i.windowWidth,
                "X-drive-windowHeight": i.windowHeight,
                "X-drive-platform": i.platform,
                "X-drive-appVersion": "",
                "X-drive-system": i.system,
                "content-type": d,
                "X-Requested-With": "XMLHttpRequest"
            },
            success: function(e) {
                e.statusCode < 500 ? o(e) : wx.showModal({
                    title: "提示",
                    content: "数据正在整理中,请您稍后进行查询",
                    showCancel: !1,
                    success: function(e) {
                        e.confirm && (console.log("用户点击确定"), wx.navigateBack({
                            delta: 1
                        }));
                    }
                });
            },
            fail: function(e) {
                console.log("fail"), a(e);
            }
        });
    });
}

var t = require("../vendor/qcloud-weapp-client-sdk/index.js"), o = require("./es6-promise-min.js"), n = "https://wx.youlidata.com/api/wx/v1", i = wx.getSystemInfoSync();

module.exports = {
    getList: function(t, o, n) {
        return e(t, o, n);
    },
    getBaseUrl: function() {
        return n;
    }
};
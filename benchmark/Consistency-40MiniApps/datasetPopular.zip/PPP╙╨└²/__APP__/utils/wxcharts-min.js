function t(t, e) {
    if (null == t) throw new TypeError("Cannot convert undefined or null to object");
    for (var i = Object(t), n = 1; n < arguments.length; n++) {
        var o = arguments[n];
        if (null != o) for (var a in o) Object.prototype.hasOwnProperty.call(o, a) && (i[a] = o[a]);
    }
    return i;
}

function e(t, e, i) {
    if (isNaN(t)) throw new Error("[wxCharts] unvalid series data!");
    i = i || 10, e = e || "upper";
    for (var n = 1; i < 1; ) i *= 10, n *= 10;
    for (t = "upper" === e ? Math.ceil(t * n) : Math.floor(t * n); t % i != 0; ) "upper" === e ? t++ : t--;
    return t / n;
}

function i(t, e, i) {
    var n = t, o = i - e, a = n + (i - o - n) / Math.sqrt(2);
    return {
        transX: a *= -1,
        transY: (i - o) * (Math.sqrt(2) - 1) - (i - o - n) / Math.sqrt(2)
    };
}

function n(t, e) {
    var i = null, n = null, o = null, a = null;
    if (e < 1 ? (i = t[0].x + .2 * (t[1].x - t[0].x), n = t[0].y + .2 * (t[1].y - t[0].y)) : (i = t[e].x + .2 * (t[e + 1].x - t[e - 1].x), 
    n = t[e].y + .2 * (t[e + 1].y - t[e - 1].y)), e > t.length - 3) {
        var r = t.length - 1;
        o = t[r].x - .2 * (t[r].x - t[r - 1].x), a = t[r].y - .2 * (t[r].y - t[r - 1].y);
    } else o = t[e + 1].x - .2 * (t[e + 2].x - t[e].x), a = t[e + 1].y - .2 * (t[e + 2].y - t[e].y);
    return {
        ctrA: {
            x: i,
            y: n
        },
        ctrB: {
            x: o,
            y: a
        }
    };
}

function o(t, e, i) {
    return {
        x: i.x + t,
        y: i.y - e
    };
}

function a(t, e) {
    if (e) for (;U.isCollision(t, e); ) t.start.x > 0 ? t.start.y-- : t.start.x < 0 ? t.start.y++ : t.start.y > 0 ? t.start.y++ : t.start.y--;
    return t;
}

function r(t, e) {
    var i = 0;
    return t.map(function(t) {
        return t.color || (t.color = e.colors[i], i = (i + 1) % e.colors.length), t;
    });
}

function s(t, i) {
    var n = 0, o = i - t;
    return n = o >= 1e4 ? 1e3 : o >= 1e3 ? 100 : o >= 100 ? 10 : o >= 10 ? 5 : o >= 1 ? 1 : o >= .1 ? .1 : .01, 
    {
        minRange: e(t, "lower", n),
        maxRange: e(i, "upper", n)
    };
}

function l(t) {
    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 10, i = 0;
    return (t = (t = String(t)).split("")).forEach(function(t) {
        /[a-zA-Z]/.test(t) ? i += 7 : /[0-9]/.test(t) ? i += 5.5 : /\./.test(t) ? i += 2.7 : /-/.test(t) ? i += 3.25 : /[\u4e00-\u9fa5]/.test(t) ? i += 10 : /\(|\)/.test(t) ? i += 3.73 : /\s/.test(t) ? i += 2.5 : /%/.test(t) ? i += 8 : i += 10;
    }), i * e / 10;
}

function h(t) {
    return t.reduce(function(t, e) {
        return (t.data ? t.data : t).concat(e.data);
    }, []);
}

function c(t, e) {
    var i = [];
    return t.forEach(function(t) {
        if (null !== t.data[e] && "undefinded" != typeof t.data[e]) {
            var n = {};
            n.color = t.color, n.name = t.name, n.data = t.format ? t.format(t.data[e]) : t.data[e], 
            i.push(n);
        }
    }), i;
}

function f(t) {
    var e = t.map(function(t) {
        return l(t);
    });
    return Math.max.apply(null, e);
}

function d(t) {
    for (var e = 2 * Math.PI / t, i = [], n = 0; n < t; n++) i.push(e * n);
    return i.map(function(t) {
        return -1 * t + Math.PI / 2;
    });
}

function x(t, e, i) {
    var n = t.map(function(t) {
        return {
            text: t.name + ": " + t.data,
            color: t.color
        };
    }), o = [], a = {
        x: 0,
        y: 0
    };
    return e.forEach(function(t) {
        "undefinded" != typeof t[i] && null !== t[i] && o.push(t[i]);
    }), o.forEach(function(t) {
        a.x = Math.round(t.x), a.y += t.y;
    }), a.y /= o.length, {
        textList: n,
        offset: a
    };
}

function u(t, e, i, n) {
    var o = -1;
    return g(t, i, n) && e.forEach(function(e, i) {
        t.x > e && (o = i);
    }), o;
}

function g(t, e, i) {
    return t.x < e.width - i.padding && t.x > i.padding + i.yAxisWidth + i.yAxisTitleWidth && t.y > i.padding && t.y < e.height - i.legendHeight - i.xAxisHeight - i.padding;
}

function p(t, e, i) {
    var n = 2 * Math.PI / i, o = -1;
    return v(t, e.center, e.radius) && function() {
        var i = function(t) {
            return t < 0 && (t += 2 * Math.PI), t > 2 * Math.PI && (t -= 2 * Math.PI), t;
        }, a = Math.atan2(e.center.y - t.y, t.x - e.center.x);
        (a *= -1) < 0 && (a += 2 * Math.PI), e.angleList.map(function(t) {
            return t = i(-1 * t);
        }).forEach(function(t, e) {
            var r = i(t - n / 2), s = i(t + n / 2);
            s < r && (s += 2 * Math.PI), (a >= r && a <= s || a + 2 * Math.PI >= r && a + 2 * Math.PI <= s) && (o = e);
        });
    }(), o;
}

function y(t, e) {
    var i = -1;
    return v(t, e.center, e.radius) && function() {
        var n = Math.atan2(e.center.y - t.y, t.x - e.center.x);
        n < 0 && (n += 2 * Math.PI), n = 2 * Math.PI - n, e.series.forEach(function(t, e) {
            n > t._start_ && (i = e);
        });
    }(), i;
}

function v(t, e, i) {
    return Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2) <= Math.pow(i, 2);
}

function m(t) {
    var e = [], i = [];
    return t.forEach(function(t, n) {
        null !== t ? i.push(t) : (i.length && e.push(i), i = []);
    }), i.length && e.push(i), e;
}

function P(t, e, i) {
    if (!1 === e.legend) return {
        legendList: [],
        legendHeight: 0
    };
    var n = [], o = 0, a = [];
    return t.forEach(function(t) {
        var i = 30 + l(t.name || "undefinded");
        o + i > e.width ? (n.push(a), o = i, a = [ t ]) : (o += i, a.push(t));
    }), a.length && n.push(a), {
        legendList: n,
        legendHeight: n.length * (i.fontSize + 8) + 5
    };
}

function T(t, e, i) {
    var n = {
        angle: 0,
        xAxisHeight: i.xAxisHeight
    }, o = (E(t, e, i).eachSpacing, t.map(function(t) {
        return l(t);
    })), a = Math.max.apply(this, o);
    return n.angle = 45 * Math.PI / 180, n.xAxisHeight = 2 * i.xAxisTextPadding + a * Math.sin(n.angle), 
    n;
}

function S(t, e, i, n, a) {
    var r = arguments.length > 5 && void 0 !== arguments[5] ? arguments[5] : 1, s = a.extra.radar || {};
    s.max = s.max || 0;
    var l = Math.max(s.max, Math.max.apply(null, h(n))), c = [];
    return n.forEach(function(n) {
        var a = {};
        a.color = n.color, a.data = [], n.data.forEach(function(n, s) {
            var h = {};
            h.angle = t[s], h.proportion = n / l, h.position = o(i * h.proportion * r * Math.cos(h.angle), i * h.proportion * r * Math.sin(h.angle), e), 
            a.data.push(h);
        }), c.push(a);
    }), c;
}

function A(t) {
    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, i = 0, n = 0;
    return t.forEach(function(t) {
        t.data = null === t.data ? 0 : t.data, i += t.data;
    }), t.forEach(function(t) {
        t.data = null === t.data ? 0 : t.data, t._proportion_ = t.data / i * e;
    }), t.forEach(function(t) {
        t._start_ = n, n += 2 * t._proportion_ * Math.PI;
    }), t;
}

function b(t) {
    var e = 0;
    return (t = A(t)).forEach(function(t) {
        var i = t.format ? t.format(+t._proportion_.toFixed(2)) : U.toFixed(100 * t._proportion_) + "%";
        e = Math.max(e, l(i));
    }), e;
}

function M(t, e, i, n, o, a) {
    return t.map(function(t) {
        return null === t ? null : (t.width = (e - 2 * o.columePadding) / i, a.extra.column && a.extra.column.width && +a.extra.column.width > 0 ? t.width = Math.min(t.width, +a.extra.column.width) : t.width = Math.min(t.width, 25), 
        t.x += (n + .5 - i / 2) * t.width, t);
    });
}

function E(t, e, i) {
    var n = i.yAxisWidth + i.yAxisTitleWidth, o = (e.width - 2 * i.padding - n) / t.length, a = [], r = i.padding + n, s = e.width - i.padding;
    return t.forEach(function(t, e) {
        a.push(r + e * o);
    }), a.push(s), {
        xAxisPoints: a,
        startX: r,
        endX: s,
        eachSpacing: o
    };
}

function F(t, e, i, n, o, a, r) {
    var s = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : 1, l = [], h = a.height - 2 * r.padding - r.xAxisHeight - r.legendHeight;
    return t.forEach(function(t, c) {
        if (null === t) l.push(null); else {
            var f = {};
            f.x = n[c] + Math.round(o / 2);
            var d = h * (t - e) / (i - e);
            d *= s, f.y = a.height - r.xAxisHeight - r.legendHeight - Math.round(d) - r.padding, 
            l.push(f);
        }
    }), l;
}

function L(t, e, i) {
    var n = h(t);
    n = n.filter(function(t) {
        return null !== t;
    });
    var o = Math.min.apply(this, n), a = Math.max.apply(this, n);
    if ("number" == typeof e.yAxis.min && (o = Math.min(e.yAxis.min, o)), "number" == typeof e.yAxis.max && (a = Math.max(e.yAxis.max, a)), 
    o === a) {
        var r = a || 1;
        o -= r, a += r;
    }
    for (var l = s(o, a), c = l.minRange, f = [], d = (l.maxRange - c) / i.yAxisSplit, x = 0; x <= i.yAxisSplit; x++) f.push(c + d * x);
    return f.reverse();
}

function C(t, e, i) {
    var n = L(t, e, i), o = i.yAxisWidth, a = n.map(function(t) {
        return t = U.toFixed(t, 2), t = e.yAxis.format ? e.yAxis.format(Number(t)) : t, 
        o = Math.max(o, l(t) + 5), t;
    });
    return !0 === e.yAxis.disabled && (o = 0), {
        rangesFormat: a,
        ranges: n,
        yAxisWidth: o
    };
}

function w(t, e, i, n) {
    n.beginPath(), n.setStrokeStyle("#ffffff"), n.setLineWidth(1), n.setFillStyle(e), 
    "diamond" === i ? t.forEach(function(t, e) {
        null !== t && (n.moveTo(t.x, t.y - 4.5), n.lineTo(t.x - 4.5, t.y), n.lineTo(t.x, t.y + 4.5), 
        n.lineTo(t.x + 4.5, t.y), n.lineTo(t.x, t.y - 4.5));
    }) : "circle" === i ? t.forEach(function(t, e) {
        null !== t && (n.moveTo(t.x + 3.5, t.y), n.arc(t.x, t.y, 4, 0, 2 * Math.PI, !1));
    }) : "rect" === i ? t.forEach(function(t, e) {
        null !== t && (n.moveTo(t.x - 3.5, t.y - 3.5), n.rect(t.x - 3.5, t.y - 3.5, 7, 7));
    }) : "triangle" === i && t.forEach(function(t, e) {
        null !== t && (n.moveTo(t.x, t.y - 4.5), n.lineTo(t.x - 4.5, t.y + 4.5), n.lineTo(t.x + 4.5, t.y + 4.5), 
        n.lineTo(t.x, t.y - 4.5));
    }), n.closePath(), n.fill(), n.stroke();
}

function H(t, e, i) {
    var n = t.title.fontSize || e.titleFontSize, o = t.subtitle.fontSize || e.subtitleFontSize, a = t.title.name || "", r = t.subtitle.name || "", s = t.title.color || e.titleColor, h = t.subtitle.color || e.subtitleColor, c = a ? n : 0, f = r ? o : 0;
    if (r) {
        var d = l(r, o), x = (t.width - d) / 2 + (t.subtitle.offsetX || 0), u = (t.height - e.legendHeight + o) / 2;
        a && (u -= (c + 5) / 2), i.beginPath(), i.setFontSize(o), i.setFillStyle(h), i.fillText(r, x, u), 
        i.stroke(), i.closePath();
    }
    if (a) {
        var g = l(a, n), p = (t.width - g) / 2 + (t.title.offsetX || 0), y = (t.height - e.legendHeight + n) / 2;
        r && (y += (f + 5) / 2), i.beginPath(), i.setFontSize(n), i.setFillStyle(s), i.fillText(a, p, y), 
        i.stroke(), i.closePath();
    }
}

function k(t, e, i, n) {
    var o = e.data;
    n.beginPath(), n.setFontSize(i.fontSize), n.setFillStyle("#666666"), t.forEach(function(t, i) {
        if (null !== t) {
            var a = e.format ? e.format(o[i]) : o[i];
            n.fillText(a, t.x - l(a) / 2, t.y - 2);
        }
    }), n.closePath(), n.stroke();
}

function z(t, e, i, n, a, r) {
    var s = n.extra.radar || {};
    e += a.radarLabelTextMargin, r.beginPath(), r.setFontSize(a.fontSize), r.setFillStyle(s.labelColor || "#666666"), 
    t.forEach(function(t, s) {
        var h = {
            x: e * Math.cos(t),
            y: e * Math.sin(t)
        }, c = o(h.x, h.y, i), f = c.x, d = c.y;
        U.approximatelyEqual(h.x, 0) ? f -= l(n.categories[s] || "") / 2 : h.x < 0 && (f -= l(n.categories[s] || "")), 
        r.fillText(n.categories[s] || "", f, d + a.fontSize / 2);
    }), r.stroke(), r.closePath();
}

function I(t, e, i, n, r, s) {
    var h = r + i.pieChartLinePadding, c = (i.pieChartTextPadding, []), f = null, d = 0;
    t.map(function(t) {
        var e = 2 * Math.PI - (t._start_ + 2 * Math.PI * t._proportion_ / 2), n = t.format ? t.format(+t._proportion_.toFixed(2)) : U.toFixed(100 * t._proportion_) + "% " + i.sort[d] + "   ", o = t.color;
        return d++, {
            arc: e,
            text: n,
            color: o
        };
    }).forEach(function(t) {
        var e = Math.cos(t.arc) * h, n = Math.sin(t.arc) * h, o = Math.cos(t.arc) * r, s = Math.sin(t.arc) * r, d = e >= 0 ? e + i.pieChartTextPadding : e - i.pieChartTextPadding, x = n, u = l(t.text), g = x;
        f && U.isSameXCoordinateArea(f.start, {
            x: d
        }) && (g = d > 0 ? Math.min(x, f.start.y) : e < 0 ? Math.max(x, f.start.y) : x > 0 ? Math.max(x, f.start.y) : Math.min(x, f.start.y)), 
        d < 0 && (d -= u);
        var p = {
            lineStart: {
                x: o,
                y: s
            },
            lineEnd: {
                x: e,
                y: n
            },
            start: {
                x: d,
                y: g
            },
            width: u,
            height: i.fontSize,
            text: t.text,
            color: t.color
        };
        f = a(p, f), c.push(f);
    }), c.forEach(function(t) {
        var e = o(t.lineStart.x, t.lineStart.y, s), a = o(t.lineEnd.x, t.lineEnd.y, s), r = o(t.start.x, t.start.y, s);
        n.setLineWidth(1), n.setFontSize(i.fontSize), n.beginPath(), n.setStrokeStyle(t.color), 
        n.setFillStyle(t.color), n.moveTo(e.x, e.y);
        var l = t.start.x < 0 ? r.x + t.width : r.x, h = t.start.x < 0 ? r.x - 5 : r.x + 5;
        n.quadraticCurveTo(a.x, a.y, l, r.y), n.moveTo(e.x, e.y), n.stroke(), n.closePath(), 
        n.beginPath(), n.moveTo(r.x + t.width, r.y), n.arc(l, r.y, 2, 0, 2 * Math.PI), n.closePath(), 
        n.fill(), n.beginPath(), n.setFillStyle("#666666"), n.fillText(t.text, h, r.y + 3), 
        n.closePath(), n.stroke(), n.closePath();
    });
}

function _(t, e, i, n) {
    var o = i.padding, a = e.height - i.padding - i.xAxisHeight - i.legendHeight;
    n.beginPath(), n.setStrokeStyle("#cccccc"), n.setLineWidth(1), n.moveTo(t, o), n.lineTo(t, a), 
    n.stroke(), n.closePath();
}

function W(e, i, n, o, a) {
    var r = !1;
    (i = t({
        x: 0,
        y: 0
    }, i)).y -= 8;
    var s = e.map(function(t) {
        return l(t.text);
    }), h = 9 + 4 * o.toolTipPadding + Math.max.apply(null, s), c = 2 * o.toolTipPadding + e.length * o.toolTipLineHeight;
    i.x + 8 + h > n.width && (r = !0), a.beginPath(), a.setFillStyle(n.tooltip.option.background || o.toolTipBackground), 
    a.setGlobalAlpha(o.toolTipOpacity), r ? (a.moveTo(i.x, i.y + 10), a.lineTo(i.x - 8, i.y + 10 - 5), 
    a.lineTo(i.x - 8, i.y + 10 + 5), a.moveTo(i.x, i.y + 10), a.fillRect(i.x - h - 8, i.y, h, c)) : (a.moveTo(i.x, i.y + 10), 
    a.lineTo(i.x + 8, i.y + 10 - 5), a.lineTo(i.x + 8, i.y + 10 + 5), a.moveTo(i.x, i.y + 10), 
    a.fillRect(i.x + 8, i.y, h, c)), a.closePath(), a.fill(), a.setGlobalAlpha(1), e.forEach(function(t, e) {
        a.beginPath(), a.setFillStyle(t.color);
        var n = i.x + 8 + 2 * o.toolTipPadding, s = i.y + (o.toolTipLineHeight - o.fontSize) / 2 + o.toolTipLineHeight * e + o.toolTipPadding;
        r && (n = i.x - h - 8 + 2 * o.toolTipPadding), a.fillRect(n, s, 4, o.fontSize), 
        a.closePath();
    }), a.beginPath(), a.setFontSize(o.fontSize), a.setFillStyle("#ffffff"), e.forEach(function(t, e) {
        var n = i.x + 8 + 2 * o.toolTipPadding + 4 + 5;
        r && (n = i.x - h - 8 + 2 * o.toolTipPadding + 4 + 5);
        var s = i.y + (o.toolTipLineHeight - o.fontSize) / 2 + o.toolTipLineHeight * e + o.toolTipPadding;
        a.fillText(t.text, n, s + o.fontSize);
    }), a.stroke(), a.closePath();
}

function D(t, e, i, n) {
    var o = i.xAxisHeight + (e.height - i.xAxisHeight - l(t)) / 2;
    n.save(), n.beginPath(), n.setFontSize(i.fontSize), n.setFillStyle(e.yAxis.titleFontColor || "#333333"), 
    n.translate(0, e.height), n.rotate(-90 * Math.PI / 180), n.fillText(t, o, i.padding + .5 * i.fontSize), 
    n.stroke(), n.closePath(), n.restore();
}

function R(t, e, i, n) {
    var o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1, a = C(t, e, i).ranges, r = E(e.categories, e, i), s = r.xAxisPoints, l = r.eachSpacing, h = a.pop(), c = a.shift();
    e.height, i.padding, i.xAxisHeight, i.legendHeight;
    return t.forEach(function(a, r) {
        var f = F(a.data, h, c, s, l, e, i, o);
        f = M(f, l, t.length, r, i, e), n.beginPath(), n.setFillStyle(a.color), f.forEach(function(t, o) {
            if (null !== t) {
                var a = t.x - t.width / 2 + 1, r = e.height - t.y - i.padding - i.xAxisHeight - i.legendHeight;
                n.moveTo(a, t.y), n.rect(a, t.y, t.width - 2, r);
            }
        }), n.closePath(), n.fill();
    }), t.forEach(function(a, r) {
        var f = F(a.data, h, c, s, l, e, i, o);
        f = M(f, l, t.length, r, i, e), !1 !== e.dataLabel && 1 === o && k(f, a, i, n);
    }), s;
}

function B(t, e, i, o) {
    var a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1, r = C(t, e, i).ranges, s = E(e.categories, e, i), l = s.xAxisPoints, h = s.eachSpacing, c = r.pop(), f = r.shift(), d = e.height - i.padding - i.xAxisHeight - i.legendHeight, x = [];
    return e.tooltip && e.tooltip.textList && e.tooltip.textList.length && 1 === a && _(e.tooltip.offset.x, e, i, o), 
    t.forEach(function(t, r) {
        var s = F(t.data, c, f, l, h, e, i, a);
        if (x.push(s), m(s).forEach(function(i) {
            if (o.beginPath(), o.setStrokeStyle(t.color), o.setFillStyle(t.color), o.setGlobalAlpha(.6), 
            o.setLineWidth(2), i.length > 1) {
                var a = i[0], r = i[i.length - 1];
                o.moveTo(a.x, a.y), "curve" === e.extra.lineStyle ? i.forEach(function(t, e) {
                    if (e > 0) {
                        var a = n(i, e - 1);
                        o.bezierCurveTo(a.ctrA.x, a.ctrA.y, a.ctrB.x, a.ctrB.y, t.x, t.y);
                    }
                }) : i.forEach(function(t, e) {
                    e > 0 && o.lineTo(t.x, t.y);
                }), o.lineTo(r.x, d), o.lineTo(a.x, d), o.lineTo(a.x, a.y);
            } else {
                var s = i[0];
                o.moveTo(s.x - h / 2, s.y), o.lineTo(s.x + h / 2, s.y), o.lineTo(s.x + h / 2, d), 
                o.lineTo(s.x - h / 2, d), o.moveTo(s.x - h / 2, s.y);
            }
            o.closePath(), o.fill(), o.setGlobalAlpha(1);
        }), !1 !== e.dataPointShape) {
            var u = i.dataPointShape[r % i.dataPointShape.length];
            w(s, t.color, u, o);
        }
    }), !1 !== e.dataLabel && 1 === a && t.forEach(function(t, n) {
        k(F(t.data, c, f, l, h, e, i, a), t, i, o);
    }), e.tooltip && e.tooltip.textList && e.tooltip.textList.length && 1 === a && W(e.tooltip.textList, e.tooltip.offset, e, i, o), 
    {
        xAxisPoints: l,
        calPoints: x
    };
}

function G(t, e, i, o) {
    var a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1, r = C(t, e, i).ranges, s = E(e.categories, e, i), l = s.xAxisPoints, h = s.eachSpacing, c = r.pop(), f = r.shift(), d = [], x = [];
    return e.tooltip && e.tooltip.textList && e.tooltip.textList.length && 1 === a && _(e.tooltip.offset.x, e, i, o), 
    t.forEach(function(t, r) {
        var s = F(t.data, c, f, l, h, e, i, a);
        if (d.push(s), m(s).forEach(function(i, a) {
            o.beginPath(), o.setStrokeStyle(t.color), o.setLineWidth(2), 1 === i.length ? (o.moveTo(i[0].x, i[0].y), 
            o.arc(i[0].x, i[0].y, 1, 0, 2 * Math.PI)) : (o.moveTo(i[0].x, i[0].y), "curve" === e.extra.lineStyle ? i.forEach(function(t, e) {
                if (e > 0) {
                    var a = n(i, e - 1);
                    o.bezierCurveTo(a.ctrA.x, a.ctrA.y, a.ctrB.x, a.ctrB.y, t.x, t.y);
                }
            }) : i.forEach(function(t, e) {
                e > 0 && o.lineTo(t.x, t.y);
            }), o.moveTo(i[0].x, i[0].y)), o.closePath(), o.stroke();
        }), !1 !== e.dataPointShape) {
            var u = i.dataPointShape[r % i.dataPointShape.length];
            if (w(s, t.color, u, o), 0 == i.countRed.length) ; else for (var g = 0; g < i.countRed.length; g++) x.push(s[i.countRed[g] - 1]), 
            w(x, "red", u, o);
        }
    }), !1 !== e.dataLabel && 1 === a && t.forEach(function(t, n) {
        k(F(t.data, c, f, l, h, e, i, a), t, i, o);
    }), e.tooltip && e.tooltip.textList && e.tooltip.textList.length && 1 === a && W(e.tooltip.textList, e.tooltip.offset, e, i, o), 
    {
        xAxisPoints: l,
        calPoints: d
    };
}

function X(t, e, n, o) {
    var a = E(t, e, n), r = a.xAxisPoints, s = a.startX, h = a.endX, c = a.eachSpacing, f = e.height - n.padding - n.xAxisHeight - n.legendHeight, d = f + n.xAxisLineHeight;
    o.beginPath(), o.setStrokeStyle(e.xAxis.gridColor || "#cccccc"), o.setLineWidth(1), 
    o.moveTo(s, f), o.lineTo(h, f), !0 !== e.xAxis.disableGrid && ("calibration" === e.xAxis.type ? r.forEach(function(t, e) {
        e > 0 && (o.moveTo(t - c / 2, f), o.lineTo(t - c / 2, f + 4));
    }) : r.forEach(function(t, e) {
        o.moveTo(t, f), o.lineTo(t, d);
    })), o.closePath(), o.stroke();
    var x = e.width - 2 * n.padding - n.yAxisWidth - n.yAxisTitleWidth, u = Math.min(t.length, Math.ceil(x / n.fontSize / 1.5)), g = Math.ceil(t.length / u);
    t = t.map(function(t, e) {
        return e % g != 0 ? "" : t;
    }), 0 === n._xAxisTextAngle_ ? (o.beginPath(), o.setFontSize(n.fontSize), o.setFillStyle(e.xAxis.fontColor || "#666666"), 
    t.forEach(function(t, e) {
        var i = c / 2 - l(t) / 2;
        o.fillText(t, r[e] + i, f + n.fontSize + 5);
    }), o.closePath(), o.stroke()) : t.forEach(function(t, a) {
        o.save(), o.beginPath(), o.setFontSize(n.fontSize), o.setFillStyle(e.xAxis.fontColor || "#666666");
        var s = l(t), h = c / 2 - s, d = i(r[a] + c / 2, f + n.fontSize / 2 + 5, e.height), x = d.transX, u = d.transY;
        o.rotate(-1 * n._xAxisTextAngle_), o.translate(x, u), o.fillText(t, r[a] + h, f + n.fontSize + 5), 
        o.closePath(), o.stroke(), o.restore();
    });
}

function O(t, e, i, n) {
    if (!0 !== e.yAxis.disabled) {
        for (var o = C(t, e, i).rangesFormat, a = i.yAxisWidth + i.yAxisTitleWidth, r = e.height - 2 * i.padding - i.xAxisHeight - i.legendHeight, s = Math.floor(r / i.yAxisSplit), l = i.padding + a, h = e.width - i.padding, c = (i.padding, 
        e.height - i.padding - i.xAxisHeight - i.legendHeight), f = [], d = 0; d < i.yAxisSplit; d++) f.push(i.padding + s * d);
        n.beginPath(), n.setStrokeStyle(e.yAxis.gridColor || "#cccccc"), n.setLineWidth(1), 
        f.forEach(function(t, e) {
            n.moveTo(l, t), n.lineTo(h, t);
        }), n.closePath(), n.stroke(), n.beginPath(), n.setFontSize(i.fontSize), n.setFillStyle(e.yAxis.fontColor || "#666666"), 
        o.forEach(function(t, e) {
            var o = f[e] ? f[e] : c;
            n.fillText(t, i.padding + i.yAxisTitleWidth, o + i.fontSize / 2);
        }), n.closePath(), n.stroke(), e.yAxis.title && D(e.yAxis.title, e, i, n);
    }
}

function q(t, e, i, n) {
    if (e.legend) {
        var o = P(t, e, i), a = o.legendList;
        o.legendHeight;
        a.forEach(function(t, o) {
            var a = 0;
            t.forEach(function(t) {
                t.name = t.name || "undefined", a += 15 + l(t.name) + 15;
            });
            var r = (e.width - a) / 2 + 5, s = e.height - i.padding - i.legendHeight + o * (i.fontSize + 8) + 5 + 8;
            n.setFontSize(i.fontSize), t.forEach(function(t) {
                switch (e.type) {
                  case "line":
                    n.beginPath(), n.setLineWidth(1), n.setStrokeStyle(t.color), n.moveTo(r - 2, s + 5), 
                    n.lineTo(r + 17, s + 5), n.stroke(), n.closePath(), n.beginPath(), n.setLineWidth(1), 
                    n.setStrokeStyle("#ffffff"), n.setFillStyle(t.color), n.moveTo(r + 7.5, s + 5), 
                    n.arc(r + 7.5, s + 5, 4, 0, 2 * Math.PI), n.fill(), n.stroke(), n.closePath();
                    break;

                  case "pie":
                  case "ring":
                    n.beginPath(), n.setFillStyle(t.color), n.moveTo(r + 7.5, s + 5), n.arc(r + 7.5, s + 5, 7, 0, 2 * Math.PI), 
                    n.closePath(), n.fill();
                    break;

                  default:
                    n.beginPath(), n.setFillStyle(t.color), n.moveTo(r, s), n.rect(r, s, 15, 10), n.closePath(), 
                    n.fill();
                }
                r += 20, n.beginPath(), n.setFillStyle(e.extra.legendTextColor || "#333333"), n.fillText(t.name, r, s + 9), 
                n.closePath(), n.stroke(), r += l(t.name) + 10;
            });
        });
    }
}

function j(t, e, i, n) {
    var o = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1;
    t = A(t, o);
    var a = {
        x: e.width / 2,
        y: (e.height - i.legendHeight) / 2
    }, r = Math.min(a.x - i.pieChartLinePadding - i.pieChartTextPadding - i._pieTextMaxLength_, a.y - i.pieChartLinePadding - i.pieChartTextPadding);
    if (e.dataLabel ? r -= 10 : r -= 2 * i.padding, t.forEach(function(t) {
        n.beginPath(), n.setLineWidth(2), n.setStrokeStyle("#ffffff"), n.setFillStyle(t.color), 
        n.moveTo(a.x, a.y), n.arc(a.x, a.y, r, t._start_, t._start_ + 2 * t._proportion_ * Math.PI), 
        n.closePath(), n.fill(), !0 !== e.disablePieStroke && n.stroke();
    }), "ring" === e.type) {
        var s = .6 * r;
        "number" == typeof e.extra.ringWidth && e.extra.ringWidth > 0 && (s = Math.max(0, r - e.extra.ringWidth)), 
        n.beginPath(), n.setFillStyle("#ffffff"), n.moveTo(a.x, a.y), n.arc(a.x, a.y, s, 0, 2 * Math.PI), 
        n.closePath(), n.fill();
    }
    return !1 !== e.dataLabel && 1 === o && I(t, e, i, n, r, a), 1 === o && "ring" === e.type && H(e, i, n), 
    {
        center: a,
        radius: r,
        series: t
    };
}

function N(t, e, i, n) {
    var a = arguments.length > 4 && void 0 !== arguments[4] ? arguments[4] : 1, r = e.extra.radar || {}, s = d(e.categories.length), l = {
        x: e.width / 2,
        y: (e.height - i.legendHeight) / 2
    }, h = Math.min(l.x - (f(e.categories) + i.radarLabelTextMargin), l.y - i.radarLabelTextMargin);
    h -= i.padding, n.beginPath(), n.setLineWidth(1), n.setStrokeStyle(r.gridColor || "#cccccc"), 
    s.forEach(function(t) {
        var e = o(h * Math.cos(t), h * Math.sin(t), l);
        n.moveTo(l.x, l.y), n.lineTo(e.x, e.y);
    }), n.stroke(), n.closePath();
    for (var c = 1; c <= i.radarGridCount; c++) !function(t) {
        var e = {};
        n.beginPath(), n.setLineWidth(1), n.setStrokeStyle(r.gridColor || "#cccccc"), s.forEach(function(a, r) {
            var s = o(h / i.radarGridCount * t * Math.cos(a), h / i.radarGridCount * t * Math.sin(a), l);
            0 === r ? (e = s, n.moveTo(s.x, s.y)) : n.lineTo(s.x, s.y);
        }), n.lineTo(e.x, e.y), n.stroke(), n.closePath();
    }(c);
    return S(s, l, h, t, e, a).forEach(function(t, o) {
        if (n.beginPath(), n.setFillStyle(t.color), n.setGlobalAlpha(.6), t.data.forEach(function(t, e) {
            0 === e ? n.moveTo(t.position.x, t.position.y) : n.lineTo(t.position.x, t.position.y);
        }), n.closePath(), n.fill(), n.setGlobalAlpha(1), !1 !== e.dataPointShape) {
            var a = i.dataPointShape[o % i.dataPointShape.length];
            w(t.data.map(function(t) {
                return t.position;
            }), t.color, a, n);
        }
    }), z(s, h, l, e, i, n), {
        center: l,
        radius: h,
        angleList: s
    };
}

function Y(t, e) {
    e.draw();
}

function Z(t) {
    this.isStop = !1, t.duration = void 0 === t.duration ? 1e3 : t.duration, t.timing = t.timing || "linear";
    var e = "undefined" != typeof requestAnimationFrame ? requestAnimationFrame : "undefined" != typeof setTimeout ? function(t, e) {
        setTimeout(function() {
            var e = +new Date();
            t(e);
        }, e);
    } : function(t) {
        t(null);
    }, i = null, n = function(o) {
        if (null === o || !0 === this.isStop) return t.onProcess && t.onProcess(1), void (t.onAnimationFinish && t.onAnimationFinish());
        if (null === i && (i = o), o - i < t.duration) {
            var a = (o - i) / t.duration;
            a = (0, V[t.timing])(a), t.onProcess && t.onProcess(a), e(n, 17);
        } else t.onProcess && t.onProcess(1), t.onAnimationFinish && t.onAnimationFinish();
    };
    n = n.bind(this), e(n, 17);
}

function J(t, e, i, n) {
    var o = this, a = e.series, s = e.categories, l = P(a = r(a, i), e, i).legendHeight;
    i.legendHeight = l;
    var h = C(a, e, i).yAxisWidth;
    if (i.yAxisWidth = h, s && s.length) {
        var c = T(s, e, i), f = c.xAxisHeight, d = c.angle;
        i.xAxisHeight = f, i._xAxisTextAngle_ = d;
    }
    "pie" !== t && "ring" !== t || (i._pieTextMaxLength_ = !1 === e.dataLabel ? 0 : b(a));
    var x = e.animation ? 1e3 : 0;
    switch (this.animationInstance && this.animationInstance.stop(), t) {
      case "line":
        this.animationInstance = new Z({
            timing: "easeIn",
            duration: x,
            onProcess: function(t) {
                O(a, e, i, n), X(s, e, i, n);
                var r = G(a, e, i, n, t), l = r.xAxisPoints, h = r.calPoints;
                o.chartData.xAxisPoints = l, o.chartData.calPoints = h, q(e.series, e, i, n), Y(e, n);
            },
            onAnimationFinish: function() {
                o.event.trigger("renderComplete");
            }
        });
        break;

      case "column":
        this.animationInstance = new Z({
            timing: "easeIn",
            duration: x,
            onProcess: function(t) {
                O(a, e, i, n), X(s, e, i, n), o.chartData.xAxisPoints = R(a, e, i, n, t), q(e.series, e, i, n), 
                Y(e, n);
            },
            onAnimationFinish: function() {
                o.event.trigger("renderComplete");
            }
        });
        break;

      case "area":
        this.animationInstance = new Z({
            timing: "easeIn",
            duration: x,
            onProcess: function(t) {
                O(a, e, i, n), X(s, e, i, n);
                var r = B(a, e, i, n, t), l = r.xAxisPoints, h = r.calPoints;
                o.chartData.xAxisPoints = l, o.chartData.calPoints = h, q(e.series, e, i, n), Y(e, n);
            },
            onAnimationFinish: function() {
                o.event.trigger("renderComplete");
            }
        });
        break;

      case "ring":
      case "pie":
        this.animationInstance = new Z({
            timing: "easeInOut",
            duration: x,
            onProcess: function(t) {
                o.chartData.pieData = j(a, e, i, n, t), q(e.series, e, i, n), Y(e, n);
            },
            onAnimationFinish: function() {
                o.event.trigger("renderComplete");
            }
        });
        break;

      case "radar":
        this.animationInstance = new Z({
            timing: "easeInOut",
            duration: x,
            onProcess: function(t) {
                o.chartData.radarData = N(a, e, i, n, t), q(e.series, e, i, n), Y(e, n);
            },
            onAnimationFinish: function() {
                o.event.trigger("renderComplete");
            }
        });
    }
}

function K() {
    this.events = {};
}

var Q = {
    yAxisWidth: 15,
    yAxisSplit: 5,
    xAxisHeight: 15,
    xAxisLineHeight: 15,
    legendHeight: 15,
    yAxisTitleWidth: 15,
    padding: 12,
    columePadding: 3,
    fontSize: 12,
    dataPointShape: [ "circle", "diamond", "triangle", "rect" ],
    colors: [ "#87CEFA", "#EEEE00", "#9AFF9A", "#9370DB", "#f15c80", "#969696", "#8B0000", "#1C86EE", "#00FFFF", "#008B00", "#43CD80", "#A0522D", "#48D1CC", "#7A378B", "#8B7500" ],
    pieChartLinePadding: 10,
    pieChartTextPadding: 15,
    xAxisTextPadding: 3,
    titleColor: "#333333",
    titleFontSize: 20,
    subtitleColor: "#999999",
    subtitleFontSize: 15,
    toolTipPadding: 3,
    toolTipBackground: "#000000",
    toolTipOpacity: .7,
    toolTipLineHeight: 14,
    radarGridCount: 3,
    radarLabelTextMargin: 15,
    countRed: [],
    sort: [ "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨", "⑩", "⑪", "⑫", "⑬", "⑭" ]
}, U = {
    toFixed: function(t, e) {
        return e = e || 2, this.isFloat(t) && (t = t.toFixed(e)), t;
    },
    isFloat: function(t) {
        return t % 1 != 0;
    },
    approximatelyEqual: function(t, e) {
        return Math.abs(t - e) < 1e-10;
    },
    isSameSign: function(t, e) {
        return Math.abs(t) === t && Math.abs(e) === e || Math.abs(t) !== t && Math.abs(e) !== e;
    },
    isSameXCoordinateArea: function(t, e) {
        return this.isSameSign(t.x, e.x);
    },
    isCollision: function(t, e) {
        return t.end = {}, t.end.x = t.start.x + t.width, t.end.y = t.start.y - t.height, 
        e.end = {}, e.end.x = e.start.x + e.width, e.end.y = e.start.y - e.height, !(e.start.x > t.end.x || e.end.x < t.start.x || e.end.y > t.start.y || e.start.y < t.end.y);
    }
}, V = {
    easeIn: function(t) {
        return Math.pow(t, 3);
    },
    easeOut: function(t) {
        return Math.pow(t - 1, 3) + 1;
    },
    easeInOut: function(t) {
        return (t /= .5) < 1 ? .5 * Math.pow(t, 3) : .5 * (Math.pow(t - 2, 3) + 2);
    },
    linear: function(t) {
        return t;
    }
};

Z.prototype.stop = function() {
    this.isStop = !0;
}, K.prototype.addEventListener = function(t, e) {
    this.events[t] = this.events[t] || [], this.events[t].push(e);
}, K.prototype.trigger = function() {
    for (var t = arguments.length, e = Array(t), i = 0; i < t; i++) e[i] = arguments[i];
    var n = e[0], o = e.slice(1);
    this.events[n] && this.events[n].forEach(function(t) {
        try {
            t.apply(null, o);
        } catch (t) {
            console.error(t);
        }
    });
};

var $ = function(e) {
    e.title = e.title || {}, e.subtitle = e.subtitle || {}, e.yAxis = e.yAxis || {}, 
    e.xAxis = e.xAxis || {}, e.extra = e.extra || {}, e.legend = !1 !== e.legend, e.animation = !1 !== e.animation;
    var i = t({}, Q);
    i.yAxisTitleWidth = !0 !== e.yAxis.disabled && e.yAxis.title ? i.yAxisTitleWidth : 0, 
    i.pieChartLinePadding = !1 === e.dataLabel ? 0 : i.pieChartLinePadding, i.pieChartTextPadding = !1 === e.dataLabel ? 0 : i.pieChartTextPadding, 
    i.countRed = e.countRed || [], this.opts = e, this.config = i, this.context = wx.createCanvasContext(e.canvasId), 
    this.chartData = {}, this.event = new K(), J.call(this, e.type, e, i, this.context);
};

$.prototype.updateData = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
    this.opts.series = e.series || this.opts.series, this.opts.categories = e.categories || this.opts.categories, 
    this.opts.title = t({}, this.opts.title, e.title || {}), this.opts.subtitle = t({}, this.opts.subtitle, e.subtitle || {}), 
    J.call(this, this.opts.type, this.opts, this.config, this.context);
}, $.prototype.stopAnimation = function() {
    this.animationInstance && this.animationInstance.stop();
}, $.prototype.addEventListener = function(t, e) {
    this.event.addEventListener(t, e);
}, $.prototype.getCurrentDataIndex = function(t) {
    if (t.touches && t.touches.length) {
        var e = t.touches[0], i = e.x, n = e.y;
        return "pie" === this.opts.type || "ring" === this.opts.type ? y({
            x: i,
            y: n
        }, this.chartData.pieData) : "radar" === this.opts.type ? p({
            x: i,
            y: n
        }, this.chartData.radarData, this.opts.categories.length) : u({
            x: i,
            y: n
        }, this.chartData.xAxisPoints, this.opts, this.config);
    }
    return -1;
}, $.prototype.showToolTip = function(e) {
    var i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
    if ("line" === this.opts.type || "area" === this.opts.type) {
        var n = this.getCurrentDataIndex(e), o = t({}, this.opts, {
            animation: !1
        });
        if (n > -1) {
            var a = c(this.opts.series, n);
            if (0 === a.length) J.call(this, o.type, o, this.config, this.context); else {
                var r = x(a, this.chartData.calPoints, n), s = r.textList, l = r.offset;
                o.tooltip = {
                    textList: s,
                    offset: l,
                    option: i
                }, J.call(this, o.type, o, this.config, this.context);
            }
        } else J.call(this, o.type, o, this.config, this.context);
    }
}, module.exports = $;
module.exports = {
    timeSort: function(r) {
        for (var t = r.length, e = 0; e < t; e++) for (var o = 0; o < t - 1 - e; o++) {
            var a = r[o], i = r[o + 1];
            if (Date.parse(a.cTime) > Date.parse(a.cTime)) {
                var c = i;
                i = a, a = c;
            }
        }
        return r;
    },
    select: function(r, t) {
        "tzgm" == t && r.scaleShort(), "hzq" == t && r.termShort(), "rq" == t && r.timeShort();
    }
};
function FormData() {
    this.fake = !0, this.boundary = "--------FormData" + parseInt(1e5 * Math.random()), 
    this._fields = [];
}

function formateData(t) {
    var r, n = new FormData();
    for (r in t) try {
        n.append(r, t[r]);
    } catch (t) {
        console.error("formateData error: ", t);
    }
    return n;
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = formateData, FormData.prototype.append = function(t, r) {
    this._fields.push([ t, r ]);
}, FormData.prototype.toString = function() {
    var n = this.boundary, a = "";
    return this._fields.forEach(function(t) {
        var r;
        a += "--" + n + "\r\n", t[1] && t[1].name ? (r = t[1], a += 'Content-Disposition: form-data; name="' + t[0] + '"; filename="' + r.name + '"\r\n', 
        a += "Content-Type: " + r.type + "\r\n\r\n", a += r.getAsBinary() + "\r\n") : (a += 'Content-Disposition: form-data; name="' + t[0] + '";\r\n\r\n', 
        a += t[1] + "\r\n");
    }), a += "--" + n + "--";
};
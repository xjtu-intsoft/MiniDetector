Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.pageToLogin = exports.getCurrentPageUrl = void 0, exports.getComponentProps = getComponentProps, 
exports.getCurrentPage = getCurrentPage, exports.componentsDispatchDataReport = componentsDispatchDataReport, 
exports.ofoUnitTrigger = ofoUnitTrigger;

var _index = require("../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../config/index.js"), _index4 = _interopRequireDefault(_index3);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var getCurrentPageUrl = exports.getCurrentPageUrl = function() {
    var e = _index2.default.getCurrentPages();
    return e[e.length - 1].route;
}, isGoingTologin = !1, pageToLogin = exports.pageToLogin = function() {
    isGoingTologin || (isGoingTologin = !0, setTimeout(function() {
        isGoingTologin = !1;
    }, 110), getCurrentPageUrl().includes("pages/login/index") || _index2.default.navigateTo({
        url: "/pages/login/index"
    }));
};

function getComponentProps(e, t) {
    return -1 < _index4.default.PLATFORM.indexOf("ALIPAY_MINIAPP") ? e.props[t] : (console.log("===================================="), 
    console.log(e, t), console.log("===================================="), e.properties[t]);
}

function getCurrentPage() {
    var e = _index2.default.getCurrentPages();
    return e[e.length - 1];
}

function componentsDispatchDataReport(e, t) {
    var o = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : "dispatchDataReport", n = getCurrentPage();
    n[o] && n[o](e, t);
}

function ofoUnitTrigger(e, t) {
    var o = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {};
    t ? (-1 < _index4.default.PLATFORM.indexOf("ALIPAY_MINIAPP") || t.triggerEvent("" + e, o), 
    t.props[e] && t.props[e](o)) : console.log("需要传入this");
}
Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _index = require("../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _utils = require("./utils.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var customInterceptor = function(e) {
    var r = e.requestParams;
    return e.proceed(r).then(function(e) {
        return 200 !== e.statusCode ? Promise.reject() : 10003 === e.data.errorCode ? (_index2.default.getApp().removeToken(), 
        (0, _utils.pageToLogin)(), Promise.reject("需登录")) : e.data;
    });
};

exports.default = [ customInterceptor ];
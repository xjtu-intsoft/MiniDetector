Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), e;
    };
}(), _index = require("../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _formdata = require("./formdata.js"), _formdata2 = _interopRequireDefault(_formdata), _interceptors = require("./interceptors.js"), _interceptors2 = _interopRequireDefault(_interceptors), _index3 = require("../config/index.js"), _index4 = _interopRequireDefault(_index3);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

_interceptors2.default.forEach(function(e) {
    return _index2.default.addInterceptor(e);
});

var httpRequest = function() {
    function e() {
        _classCallCheck(this, e);
    }
    return _createClass(e, [ {
        key: "baseOptions",
        value: function(e, t, n, r) {
            var a = 1 < arguments.length && void 0 !== t ? t : "GET", o = 2 < arguments.length && void 0 !== n ? n : "", i = !(3 < arguments.length && void 0 !== r) || r, u = _index2.default.getApp(), l = e.url, d = e.data, s = u.getToken();
            s && i && (d.token = s), d.lat = u.latlng.lat, d.lng = u.latlng.lng, d.source = _index4.default.OFO_SOURCE, 
            d.location = u.location, d["source-version"] = _index4.default.OFO_SOURCE_VERSION;
            var c = "application/json", c = e.contentType || c, f = void 0;
            return "mult" === o && (c = "multipart/form-data; boundary=" + (f = (0, _formdata2.default)(d)).boundary), 
            _index2.default.request({
                url: l,
                method: a,
                header: {
                    "content-type": c
                },
                data: "mult" === o ? f.toString() : d
            });
        }
    }, {
        key: "mult",
        value: function(e, t, n) {
            var r = !(2 < arguments.length && void 0 !== n) || n, a = {
                url: e,
                data: 1 < arguments.length && void 0 !== t ? t : {}
            };
            return this.baseOptions(a, "POST", "mult", r);
        }
    }, {
        key: "get",
        value: function(e, t) {
            var n = {
                url: e,
                data: 1 < arguments.length && void 0 !== t ? t : {}
            };
            return this.baseOptions(n);
        }
    }, {
        key: "post",
        value: function(e, t, n) {
            var r = {
                url: e,
                data: t,
                contentType: n
            };
            return this.baseOptions(r, "POST");
        }
    } ]), e;
}();

exports.default = new httpRequest();
Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.commonAuthenticate = exports.ofoPayment = exports.getWxOpenId = exports.getWxOrderStr = exports.getAlipayOrderStr = exports.recharge = exports.unlock = exports.getBlueBar = exports.pay = exports.getUserInfo = exports.getPriceInfo = exports.getOrderInfo = exports.getWallet = exports.end = exports.getUnfinishedOrder = exports.ofoCheckBeforeBuy = exports.qaGetCardInfo = exports.getBuyableCardInfo = exports.wallet = exports.getConfig = exports.alipayAuthLogin = exports.alipayAutoLogin = exports.login = exports.getVerifyCodeV5 = exports.coupon = exports.getCardList = exports.getRedPacketList = exports.loginByBind = exports.loginByCode = void 0;

var _index = require("../config/index.js"), _index2 = _interopRequireDefault(_index), _request = require("./request.js"), _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var host = _index2.default.HOST, loginByCode = exports.loginByCode = function(e) {
    return _request2.default.mult(host.user + "/wechat/tiny/login", e, !1);
}, loginByBind = exports.loginByBind = function(e) {
    return _request2.default.mult(host.user + "/wechat/tiny/bind ", e);
}, getRedPacketList = exports.getRedPacketList = function(e) {
    return _request2.default.mult(host.order + "/ofo/Api/order/base/getValidCouponList", e);
}, getCardList = exports.getCardList = function(e) {
    return _request2.default.mult(host.order + "/ofo/Api/order/product/list", e);
}, coupon = exports.coupon = function(e) {
    return _request2.default.mult(host.user + "/ofo/Api/activity/coupon", e);
}, getVerifyCodeV5 = exports.getVerifyCodeV5 = function(e) {
    return _request2.default.mult(host.san + "/ofo/Api/v5/getVerifyCode", e);
}, login = exports.login = function(e) {
    return _request2.default.mult(host.san + "/ofo/Api/login", e);
}, alipayAutoLogin = exports.alipayAutoLogin = function(e) {
    return _request2.default.mult(host.user + "/alipay/autoLoginV2", e);
}, alipayAuthLogin = exports.alipayAuthLogin = function(e) {
    return _request2.default.mult(host.user + "/ofo/Api/alipay/login", e);
}, getConfig = exports.getConfig = function(e) {
    return _request2.default.mult(host.san + "/ofo/Api/config", e);
}, wallet = exports.wallet = function(e) {
    return _request2.default.mult(host.user + "/ofo/Api/v4/info/wallet", e);
}, getBuyableCardInfo = exports.getBuyableCardInfo = function(e) {
    return _request2.default.mult(host.order + "/ofo/Api/order/product/productList", e);
}, qaGetCardInfo = exports.qaGetCardInfo = function(e) {
    return _request2.default.mult(host.product + "/v2/product/info/productList", e);
}, ofoCheckBeforeBuy = exports.ofoCheckBeforeBuy = function(e) {
    return _request2.default.mult(host.product + "/v2/product/auth/checkBeforeBuy", e);
}, getUnfinishedOrder = exports.getUnfinishedOrder = function(e) {
    return _request2.default.mult(host.san + "/ofo/Api/v2/unfinished", e);
}, end = exports.end = function(e) {
    return _request2.default.mult(host.san + "/ofo/Api/v2/end", e);
}, getWallet = exports.getWallet = function() {
    return _request2.default.mult(host.user + "/ofo/Api/v4/info/wallet");
}, getOrderInfo = exports.getOrderInfo = function(e) {
    return _request2.default.mult(host.san + "//ofo/Api/v5/orderInfo", e);
}, getPriceInfo = exports.getPriceInfo = function(e) {
    return _request2.default.mult(host.order + "/ofo/Api/pricing/info", e);
}, getUserInfo = exports.getUserInfo = function() {
    return _request2.default.mult(host.san + "/ofo/Api/v4/info/user");
}, pay = exports.pay = function(e) {
    return _request2.default.mult(host.san + "/ofo/Api/v2/pay", e);
}, getBlueBar = exports.getBlueBar = function(e) {
    return _request2.default.mult(host.user + "/ofo/Api/user/bluebar", e);
}, unlock = exports.unlock = function(e) {
    return _request2.default.mult(host.san + "/ofo/Api/v2/carno", e);
}, recharge = exports.recharge = function(e) {
    return _request2.default.mult(host.order + "/ofo/Api/order/cash/activity/recharge", e);
}, getAlipayOrderStr = exports.getAlipayOrderStr = function(e) {
    return _request2.default.mult(host.san + "/ofo/Api/alipayDeposit", e);
}, getWxOrderStr = exports.getWxOrderStr = function(e) {
    return _request2.default.mult(host.san + "/ofo/Api/wechat/app/deposit", e);
}, getWxOpenId = exports.getWxOpenId = function(e) {
    return _request2.default.mult(host.san + "/ofo/Api/wechattiny/auth/getOpenIdByCode", e);
}, ofoPayment = exports.ofoPayment = function(e) {
    return console.log("===================================="), console.log(e), console.log("===================================="), 
    _request2.default.mult(host.san + "/ofo/Api/v3/payment", e);
}, commonAuthenticate = exports.commonAuthenticate = function(e) {
    return _request2.default.mult(host.user + "/ofo/Api/authenticate", e);
};
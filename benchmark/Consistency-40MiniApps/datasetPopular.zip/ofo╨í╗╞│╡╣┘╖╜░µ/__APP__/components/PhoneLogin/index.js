Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function n(e, t) {
        for (var o = 0; o < t.length; o++) {
            var n = t[o];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, o) {
        return t && n(e.prototype, t), o && n(e, o), e;
    };
}(), _get = function e(t, o, n) {
    null === t && (t = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(t, o);
    if (void 0 === r) {
        var s = Object.getPrototypeOf(t);
        return null === s ? void 0 : e(s, o, n);
    }
    if ("value" in r) return r.value;
    var a = r.get;
    return void 0 !== a ? a.call(n) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _api = require("../../services/api.js"), API = _interopRequireWildcard(_api);

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Index = (_temp2 = _class = function() {
    function a() {
        var e, t, r;
        _classCallCheck(this, a);
        for (var o = arguments.length, n = Array(o), s = 0; s < o; s++) n[s] = arguments[s];
        return (t = r = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(n)))).$usedState = [ "anonymousState__temp", "showCodePage", "telClose", "errorMsg", "showGetCodeBtn", "telText", "leftSeconds", "tel", "code" ], 
        r.state = {
            tel: "",
            telText: "",
            telClose: !1,
            errorMsg: "",
            showCodePage: !1,
            leftSeconds: "",
            showGetCodeBtn: !1,
            code: ""
        }, r.handleChange = function(e) {
            var t = (n = e.detail.value).replace(/\s/g, ""), o = t.length, n = 3 < o && o < 8 ? t.replace(/(\d{3})(\d{1,4})/, "$1 $2") : 7 < o ? t.replace(/(\d{3})(\d{4})(\d{1,4})/, "$1 $2 $3") : t;
            r.setState({
                tel: t,
                telText: n
            }), 0 < o ? r.setState({
                telClose: !0
            }) : r.setState({
                telClose: !1
            });
        }, r.getCaptchaV5 = function() {
            if (console.log("校验手机号，发送验证码"), !/^1[3-9]\d{9}$/.test(r.state.tel)) return _index2.default.showToast({
                title: "请输入正确的手机号",
                icon: "none",
                duration: 2e3
            }), console.log("手机号输入有误,弹框");
            r.getPhoneVerifyCodeV5();
        }, r.changeCode = function(e) {
            var t = e.detail.value;
            r.setState({
                code: t
            });
        }, r.customComponents = [], _possibleConstructorReturn(r, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function(e) {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentWillMount",
        value: function() {}
    }, {
        key: "componentDidMount",
        value: function() {}
    }, {
        key: "componentWillUnmount",
        value: function() {}
    }, {
        key: "componentDidShow",
        value: function() {}
    }, {
        key: "componentDidHide",
        value: function() {}
    }, {
        key: "getPhoneVerifyCodeV5",
        value: function() {
            var n = this;
            console.log("获取手机验证码"), API.getVerifyCodeV5({
                tel: this.state.tel
            }).then(function(e) {
                var t, o;
                200 == e.errorCode ? (n.setState({
                    errorMsg: "",
                    showCodePage: !0
                }), o = void 0 === (t = e.values.leftTime) ? 60 : t, n.getLeftTime(o), console.log("发送验证码成功======")) : n.setState({
                    errorMsg: e.msg
                });
            }).catch(function(e) {
                _index2.default.showToast({
                    title: e.msg,
                    icon: "none",
                    duration: 2e3
                });
            });
        }
    }, {
        key: "cleanTel",
        value: function() {
            this.setState({
                tel: "",
                telText: "",
                telClose: !1,
                errorMsg: ""
            });
        }
    }, {
        key: "getLeftTime",
        value: function(e) {
            !function e(t, o) {
                0 != o ? (t.setState({
                    leftSeconds: --o
                }), setTimeout(function() {
                    e(t, o);
                }, 1e3)) : t.setState({
                    leftSeconds: 60,
                    showGetCodeBtn: !0
                });
            }(this, e), this.setState({
                showGetCodeBtn: !1
            });
        }
    }, {
        key: "login",
        value: function() {
            var t = this;
            /^1[3-9]\d{9}$/.test(this.state.tel) ? /^\d{4}$/.test(this.state.code) ? (_index2.default.showLoading({
                title: "loading"
            }), API.login({
                tel: this.state.tel,
                code: this.state.code
            }).then(function(e) {
                200 == e.errorCode ? (console.log("登录成功"), t.props.onLogin(e.values.token, e.values.refreshToken)) : _index2.default.showToast({
                    title: e.msg,
                    icon: "none",
                    duration: 2e3
                });
            }).catch(function(e) {
                _index2.default.showToast({
                    title: e.msg,
                    icon: "none",
                    duration: 2e3
                });
            })) : _index2.default.showToast({
                title: "请您填写验证码",
                icon: "none",
                duration: 2e3
            }) : _index2.default.showToast({
                title: "请输入正确的手机号",
                icon: "none",
                duration: 2e3
            });
        }
    }, {
        key: "_createData",
        value: function(e, t, o) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            this.$prefix;
            var n = this.__state, r = n.telClose, s = (n.errorMsg, n.telText, n.showCodePage, 
            n.leftSeconds, n.showGetCodeBtn, r ? "/assets/login/clean.png" : null);
            return Object.assign(this.__state, {
                anonymousState__temp: s
            }), this.__state;
        }
    } ]), a;
}(), _class.$$events = [ "handleChange", "cleanTel", "getCaptchaV5", "getPhoneVerifyCodeV5", "changeCode", "login" ], 
_class.$$componentPath = "components/PhoneLogin/index", _temp2);

exports.default = Index, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index));
Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function n(t, e) {
        for (var o = 0; o < e.length; o++) {
            var n = e[o];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(t, e, o) {
        return e && n(t.prototype, e), o && n(t, o), t;
    };
}(), _get = function t(e, o, n) {
    null === e && (e = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(e, o);
    if (void 0 === r) {
        var a = Object.getPrototypeOf(e);
        return null === a ? void 0 : t(a, o, n);
    }
    if ("value" in r) return r.value;
    var i = r.get;
    return void 0 !== i ? i.call(n) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _classCallCheck(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, e) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !e || "object" != typeof e && "function" != typeof e ? t : e;
}

function _inherits(t, e) {
    if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + typeof e);
    t.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e);
}

var Loading = (_temp2 = _class = function() {
    function i() {
        var t, e, o;
        _classCallCheck(this, i);
        for (var n = arguments.length, r = Array(n), a = 0; a < n; a++) r[a] = arguments[a];
        return (e = o = _possibleConstructorReturn(this, (t = i.__proto__ || Object.getPrototypeOf(i)).call.apply(t, [ this ].concat(r)))).$usedState = [ "_isShow", "_type", "_data", "info" ], 
        o.state = {
            _isShow: !1,
            _type: "commonError",
            _data: {}
        }, o.closeConfirmModal = function() {
            o.props.onClose();
        }, o.ofoJump = function(t) {
            _index2.default.navigateTo({
                url: t.redirectUrl
            });
        }, o.dispatch = function(t) {
            var e = _index2.default.getApp().get(t, "currentTarget.dataset.obj", {});
            e.action && o[e.action](e), o.closeConfirmModal();
        }, o.customComponents = [], _possibleConstructorReturn(o, e);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function(t) {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).call(this, t), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentWillReceiveProps",
        value: function(t) {
            var e = t.info, o = e.isShow, n = e.type, r = e.data;
            o !== this.state._isShow && this.setState({
                _isShow: o,
                _type: n,
                _data: r
            });
        }
    }, {
        key: "_createData",
        value: function(t, e, o) {
            this.__state = t || this.state || {}, this.__props = e || this.props || {};
            this.$prefix;
            var n = this.__state, r = n._isShow, a = n._type;
            n._data;
            return r && a ? (Object.assign(this.__state, {}), this.__state) : null;
        }
    } ]), i;
}(), _class.$$events = [ "closeConfirmModal", "dispatch" ], _class.defaultProps = {
    info: {
        isShow: !1,
        type: "commonError"
    },
    onClose: function() {}
}, _class.$$componentPath = "components/UnlockPopup/index", _temp2);

exports.default = Loading, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Loading));
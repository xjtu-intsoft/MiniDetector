Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function n(e, t) {
        for (var o = 0; o < t.length; o++) {
            var n = t[o];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, o) {
        return t && n(e.prototype, t), o && n(e, o), e;
    };
}(), _get = function e(t, o, n) {
    null === t && (t = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(t, o);
    if (void 0 === r) {
        var s = Object.getPrototypeOf(t);
        return null === s ? void 0 : e(s, o, n);
    }
    if ("value" in r) return r.value;
    var a = r.get;
    return void 0 !== a ? a.call(n) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var success = "/assets/icon_success.png", error = "/assets/icon_error.png", fail = "/assets/icon_fail.png", ConfirmModal = (_temp2 = _class = function() {
    function a() {
        var e, t, o;
        _classCallCheck(this, a);
        for (var n = arguments.length, r = Array(n), s = 0; s < n; s++) r[s] = arguments[s];
        return (t = o = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(r)))).$usedState = [ "anonymousState__temp", "srcUrl", "title", "content", "closeBtn", "confirmModalData", "showExchangeModal" ], 
        o.customComponents = [], _possibleConstructorReturn(o, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function(e) {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "onCloseModal",
        value: function() {
            this.props.onClose();
        }
    }, {
        key: "_createData",
        value: function(e, t, o) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            this.$prefix;
            var n = this.__props, r = n.confirmModalData, s = r.showType, a = r.title, i = r.content, l = r.closeBtn, c = 1 == n.showExchangeModal ? "display: block" : "display: none", u = "success" === s ? success : "fail" === s ? fail : error, p = (0, 
            _index.internal_inline_style)(c);
            return Object.assign(this.__state, {
                anonymousState__temp: p,
                srcUrl: u,
                title: a,
                content: i,
                closeBtn: l
            }), this.__state;
        }
    } ]), a;
}(), _class.$$events = [ "onCloseModal" ], _class.defaultProps = {
    confirmModalData: {},
    showExchangeModal: Boolean,
    onClose: function() {}
}, _class.$$componentPath = "components/dtConfirmModal/index", _temp2);

exports.default = ConfirmModal, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(ConfirmModal));
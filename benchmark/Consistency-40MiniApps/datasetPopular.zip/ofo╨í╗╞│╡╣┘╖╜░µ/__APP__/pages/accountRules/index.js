Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), e;
    };
}(), _get = function e(t, n, o) {
    null === t && (t = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === r) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, n, o);
    }
    if ("value" in r) return r.value;
    var a = r.get;
    return void 0 !== a ? a.call(o) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Index = (_temp2 = _class = function() {
    function a() {
        var e, t, n;
        _classCallCheck(this, a);
        for (var o = arguments.length, r = Array(o), i = 0; i < o; i++) r[i] = arguments[i];
        return (t = n = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(r)))).$usedState = [ "rules" ], 
        n.config = {
            navigationBarTitleText: "用车计费规则"
        }, n.state = {}, n.customComponents = [], _possibleConstructorReturn(n, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function(e) {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentWillMount",
        value: function() {
            var t = void 0;
            try {
                var e = JSON.parse('{"version":200,"rules":[{"name":"","value":"","desc":"亲爱的ofo主人，ofo小黄车的计费规则为：输入车牌号获取密码后即开始计费，使用时间里包含了为用户预留的120秒报修时间，用车费率为1.00元/小时，不满1小时的按1小时来计费，请放心使用。","key":""},{"name":"非运营区域调度费","value":"5.00元","desc":"ofo将对骑行至非运营区域的订单进行调度费暂扣，请注意骑车要在限定的运营范围内哦。\\n1.城市运营区域，可在最新版本APP（版本号大于v 2.17.0）首页地图中查看; \\n2.由运营区域骑行至非运营区域，每次暂扣调度费5.00元; \\n3.暂扣调度费后的48小时内，把任意单车从非运营区骑行至运营区域支付成功后，调度费将退回至您的账户，若超过48小时则调度费不会返还;","key":"finePrice"}],"alertMsg":"起步价{1元}/小时，最高上限{1元}","alertTimes":3,"priceTimes":3,"scanMsg":"起步价1元/小时，最高上限1元","inPileArea":false,"pileCountDown":120,"pileReturnButton":"结束订单","pileBlock":true,"pileAreaVersion":"0","pileScanTime":15000,"mpPileScanTime":5000,"isUseExtraPiles":true,"isCheckMainPiles":false,"isUseOfoPiles":true,"mainPileNames":["ofo_station"],"alertShow":false}'), t = this.formatRules(e.rules);
            } catch (e) {
                t = {
                    desc: {
                        desc: "获取计费规则异常，请稍后重试"
                    }
                };
            }
            this.setState({
                rules: t
            });
        }
    }, {
        key: "componentWillUnmount",
        value: function() {}
    }, {
        key: "componentDidShow",
        value: function() {}
    }, {
        key: "componentDidHide",
        value: function() {}
    }, {
        key: "formatRules",
        value: function(e) {
            var t = {};
            return e.forEach(function(e) {
                t["" == e.key ? "desc" : e.key] = {
                    name: e.name,
                    desc: e.desc,
                    value: e.value
                };
            }), t;
        }
    }, {
        key: "_createData",
        value: function(e, t, n) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            this.$prefix;
            return Object.assign(this.__state, {}), this.__state;
        }
    } ]), a;
}(), _class.$$events = [], _class.$$componentPath = "pages/accountRules/index", 
_temp2);

exports.default = Index, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index, !0));
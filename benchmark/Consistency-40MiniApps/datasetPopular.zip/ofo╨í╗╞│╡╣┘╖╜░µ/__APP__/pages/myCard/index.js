Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _slicedToArray = function(e, t) {
    if (Array.isArray(e)) return e;
    if (Symbol.iterator in Object(e)) return function(e, t) {
        var r = [], n = !0, o = !1, a = void 0;
        try {
            for (var i, s = e[Symbol.iterator](); !(n = (i = s.next()).done) && (r.push(i.value), 
            !t || r.length !== t); n = !0) ;
        } catch (e) {
            o = !0, a = e;
        } finally {
            try {
                !n && s.return && s.return();
            } finally {
                if (o) throw a;
            }
        }
        return r;
    }(e, t);
    throw new TypeError("Invalid attempt to destructure non-iterable instance");
}, _createClass = function() {
    function n(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, r) {
        return t && n(e.prototype, t), r && n(e, r), e;
    };
}(), _get = function e(t, r, n) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === o) {
        var a = Object.getPrototypeOf(t);
        return null === a ? void 0 : e(a, r, n);
    }
    if ("value" in o) return o.value;
    var i = o.get;
    return void 0 !== i ? i.call(n) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _api = require("../../services/api.js"), API = _interopRequireWildcard(_api);

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Mycard = (_temp2 = _class = function() {
    function i() {
        var e, t, r;
        _classCallCheck(this, i);
        for (var n = arguments.length, o = Array(n), a = 0; a < n; a++) o[a] = arguments[a];
        return (t = r = _possibleConstructorReturn(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(o)))).$usedState = [ "$compid__4", "cardList", "showExchangeModal", "confirmModalData" ], 
        r.config = {
            navigationBarTitleText: "我的卡包"
        }, r.state = {
            cardList: [],
            showExchangeModal: !1,
            confirmModalData: {
                showType: "success",
                title: "兑换成功",
                content: "恭喜你获得1张ofo年卡",
                closeBtn: "我知道了"
            }
        }, r.customComponents = [ "ConfirmModal" ], _possibleConstructorReturn(r, t);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function(e) {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentDidMount",
        value: function() {
            this.getCardList();
        }
    }, {
        key: "getCardList",
        value: function() {
            var r = this;
            _index2.default.showLoading({
                title: "loading"
            }), API.getCardList({
                status: 1,
                curPage: 1,
                pageSize: 1e4
            }).then(function(e) {
                var t;
                _index2.default.hideLoading(), 200 == e.errorCode ? (t = e.values.info.data.data, 
                r.setState({
                    cardList: t
                })) : _index2.default.showToast({
                    title: e.msg,
                    icon: "none",
                    duration: 2e3
                });
            }).catch(function() {
                return _index2.default.hideLoading();
            });
        }
    }, {
        key: "onBuyCard",
        value: function() {
            _index2.default.navigateTo({
                url: "/pages/cardDetail/index"
            });
        }
    }, {
        key: "closeDTModalTap",
        value: function() {
            this.setState({
                showExchangeModal: !1
            });
        }
    }, {
        key: "_createData",
        value: function(e, t, r) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            var n = this.$prefix, o = (0, _index.genCompid)(n + "$compid__4"), a = _slicedToArray(o, 2), i = a[0], s = a[1], c = this.__state, l = c.cardList, u = c.confirmModalData, d = c.showExchangeModal;
            return l.length, _index.propsManager.set({
                showExchangeModal: d,
                confirmModalData: u,
                onClose: this.closeDTModalTap.bind(this)
            }, s, i), Object.assign(this.__state, {
                $compid__4: s
            }), this.__state;
        }
    } ]), i;
}(), _class.$$events = [], _class.$$componentPath = "pages/myCard/index", _temp2);

exports.default = Mycard, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Mycard, !0));
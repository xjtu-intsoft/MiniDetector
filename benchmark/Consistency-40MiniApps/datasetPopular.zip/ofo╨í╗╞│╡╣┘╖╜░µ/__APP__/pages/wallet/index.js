Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _dec, _class, _class2, _temp2, _createClass = function() {
    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), e;
    };
}(), _get = function e(t, n, o) {
    null === t && (t = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === r) {
        var a = Object.getPrototypeOf(t);
        return null === a ? void 0 : e(a, n, o);
    }
    if ("value" in r) return r.value;
    var s = r.get;
    return void 0 !== s ? s.call(o) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../../npm/@tarojs/mobx/index.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Index = (_dec = (0, _index3.inject)("walletStore"))(_class = (0, _index3.observer)((_temp2 = _class2 = function() {
    function s() {
        var e, t, n;
        _classCallCheck(this, s);
        for (var o = arguments.length, r = Array(o), a = 0; a < o; a++) r[a] = arguments[a];
        return (t = n = _possibleConstructorReturn(this, (e = s.__proto__ || Object.getPrototypeOf(s)).call.apply(e, [ this ].concat(r)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "balance", "packetnum", "isWxMp", "walletStore" ], 
        n.config = {
            navigationBarTitleText: "我的钱包"
        }, n.state = {
            isWxMp: _index2.default.getEnv() === _index2.default.ENV_TYPE.WEAPP
        }, n.getWallet = function() {
            n.props.walletStore.getWalletInfoAsync();
        }, n.customComponents = [], _possibleConstructorReturn(n, t);
    }
    return _inherits(s, _index.Component), _createClass(s, [ {
        key: "_constructor",
        value: function(e) {
            _get(s.prototype.__proto__ || Object.getPrototypeOf(s.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentDidShow",
        value: function() {
            this.getWallet();
        }
    }, {
        key: "_createData",
        value: function(e, t, n) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            this.$prefix;
            var o = this.__props.walletStore.wallet, r = o.balance, a = o.packetnum;
            this.anonymousFunc0 = function() {
                return _index2.default.navigateTo({
                    url: "/pages/purchase/purchase"
                });
            };
            this.anonymousFunc1 = function() {
                return _index2.default.navigateTo({
                    url: "/pages/packet/index"
                });
            };
            return Object.assign(this.__state, {
                anonymousState__temp: "/assets/wallet/ye.png",
                anonymousState__temp2: "/assets/wallet/yhq.png",
                balance: r,
                packetnum: a
            }), this.__state;
        }
    }, {
        key: "anonymousFunc0",
        value: function() {}
    }, {
        key: "anonymousFunc1",
        value: function() {}
    } ]), s;
}(), _class2.$$events = [ "anonymousFunc0", "anonymousFunc1" ], _class2.$$componentPath = "pages/wallet/index", 
_class = _temp2)) || _class) || _class;

exports.default = Index, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index, !0));
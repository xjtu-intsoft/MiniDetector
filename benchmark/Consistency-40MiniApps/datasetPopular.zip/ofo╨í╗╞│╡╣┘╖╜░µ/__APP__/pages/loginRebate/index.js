Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _slicedToArray = function(e, t) {
    if (Array.isArray(e)) return e;
    if (Symbol.iterator in Object(e)) return function(e, t) {
        var n = [], o = !0, r = !1, i = void 0;
        try {
            for (var a, s = e[Symbol.iterator](); !(o = (a = s.next()).done) && (n.push(a.value), 
            !t || n.length !== t); o = !0) ;
        } catch (e) {
            r = !0, i = e;
        } finally {
            try {
                !o && s.return && s.return();
            } finally {
                if (r) throw i;
            }
        }
        return n;
    }(e, t);
    throw new TypeError("Invalid attempt to destructure non-iterable instance");
}, _createClass = function() {
    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), e;
    };
}(), _get = function e(t, n, o) {
    null === t && (t = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === r) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, n, o);
    }
    if ("value" in r) return r.value;
    var a = r.get;
    return void 0 !== a ? a.call(o) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _api = require("../../services/api.js"), API = _interopRequireWildcard(_api), _index3 = require("../../constant/index.js");

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var app = _index2.default.getApp(), Index = (_temp2 = _class = function() {
    function a() {
        var e, t, i;
        _classCallCheck(this, a);
        for (var n = arguments.length, o = Array(n), r = 0; r < n; r++) o[r] = arguments[r];
        return (t = i = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(o)))).$usedState = [ "anonymousState__temp", "$compid__3", "isShowPhonePage", "isShowPhoneModal" ], 
        i.config = {
            navigationBarTitleText: "登录"
        }, i.state = {
            isShowPhoneModal: !1,
            isShowPhonePage: !1
        }, i.data = {
            code: "",
            userInfo: null
        }, i.showPhoneLogin = function() {
            i.setState({
                isShowPhonePage: !0
            });
        }, i.usePhoneLogin = function() {
            i.setState({
                isShowPhonePage: !0,
                isShowPhoneModal: !1
            });
        }, i.getCode = function() {
            return _index2.default.login().then(function(e) {
                i.data.code = e.code;
            });
        }, i.getUserInfo = function(r) {
            i.getCode().then(function() {
                var e = r.detail, t = e.errMsg, n = e.iv, o = e.encryptedData;
                if ("getUserInfo:ok" !== t) return _index2.default.showToast({
                    title: "授权已取消，请重新授权",
                    icon: "none"
                });
                i.loginByCode({
                    iv: n,
                    encryptedData: o,
                    code: i.data.code
                });
            });
        }, i.loginByCode = function(e) {
            API.loginByCode(e).then(function(e) {
                var t = e.errorCode, n = e.msg, o = e.values;
                if (200 !== t) return _index2.default.showToast({
                    title: n,
                    icon: "none"
                });
                o.accessToken && i.storeToken(o.accessToken, o.refreshToken), 13e5 === t && (i.data.userInfo = o, 
                i.setState({
                    isShowPhoneModal: !0
                }));
            }).catch(function(e) {
                _index2.default.showToast({
                    title: "登录失败，请重试",
                    icon: "none"
                }), console.error(e);
            });
        }, i.getPhoneNumber = function(e) {
            var t = e.detail;
            return t.errMsg.includes("ok") ? (i.setState({
                isShowPhoneModal: !1
            }), API.loginByBind({
                phoneIv: t.iv,
                phoneData: t.encryptedData,
                openid: i.data.userInfo.openid,
                unionid: i.data.userInfo.unionid
            }).then(function(e) {
                var t = e.errorCode, n = e.msg, o = e.values;
                if (200 !== t) return _index2.default.showModal({
                    title: "绑定失败",
                    content: 1400009 === t ? n : "请输入手机号注册/登录",
                    showCancel: !1,
                    confirmText: "我知道了"
                });
                o.accessToken && i.storeToken(o.accessToken, o.refreshToken);
            }).catch(function(e) {
                console.error(e);
            })) : _index2.default.showToast({
                title: "授权失败，请重试",
                icon: "none"
            });
        }, i.storeToken = function(e, t) {
            _index2.default.showToast({
                title: "登录成功",
                icon: "success"
            }), app.setToken(e), _index2.default.setStorageSync(_index3.STORE.REFRESH_TOKEN, t), 
            _index2.default.navigateBack({
                delta: 1
            });
        }, i.customComponents = [ "PhoneLogin" ], _possibleConstructorReturn(i, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function(e) {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "_createData",
        value: function(e, t, n) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            var o = this.$prefix, r = (0, _index.genCompid)(o + "$compid__3"), i = _slicedToArray(r, 2), a = i[0], s = i[1], u = this.__state;
            u.isShowPhoneModal;
            return u.isShowPhonePage && _index.propsManager.set({
                onLogin: this.storeToken.bind(this)
            }, s, a), Object.assign(this.__state, {
                anonymousState__temp: "/assets/login/ofo.png",
                $compid__3: s
            }), this.__state;
        }
    } ]), a;
}(), _class.$$events = [ "getUserInfo", "getPhoneNumber" ], _class.$$componentPath = "pages/loginRebate/index", 
_temp2);

exports.default = Index, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index, !0));
Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _slicedToArray = function(e, t) {
    if (Array.isArray(e)) return e;
    if (Symbol.iterator in Object(e)) return function(e, t) {
        var n = [], o = !0, r = !1, i = void 0;
        try {
            for (var a, s = e[Symbol.iterator](); !(o = (a = s.next()).done) && (n.push(a.value), 
            !t || n.length !== t); o = !0) ;
        } catch (e) {
            r = !0, i = e;
        } finally {
            try {
                !o && s.return && s.return();
            } finally {
                if (r) throw i;
            }
        }
        return n;
    }(e, t);
    throw new TypeError("Invalid attempt to destructure non-iterable instance");
}, _createClass = function() {
    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), e;
    };
}(), _get = function e(t, n, o) {
    null === t && (t = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === r) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, n, o);
    }
    if ("value" in r) return r.value;
    var a = r.get;
    return void 0 !== a ? a.call(o) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _api = require("../../services/api.js"), API = _interopRequireWildcard(_api), _index3 = require("../../config/index.js"), _index4 = _interopRequireDefault(_index3), _index5 = require("../../constant/index.js"), _aliPayAuth = require("../../utils/aliPayAuth.js");

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var app = _index2.default.getApp(), Index = (_temp2 = _class = function() {
    function i() {
        var e, t, a;
        _classCallCheck(this, i);
        for (var n = arguments.length, o = Array(n), r = 0; r < n; r++) o[r] = arguments[r];
        return (t = a = _possibleConstructorReturn(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(o)))).$usedState = [ "anonymousState__temp", "$compid__2", "isShowPhonePage", "isShowPhoneModal" ], 
        a.config = {
            navigationBarTitleText: "登录"
        }, a.state = {
            isShowPhoneModal: !1,
            isShowPhonePage: !1
        }, a.data = {
            userInfo: null
        }, a.showPhoneLogin = function() {
            a.setState({
                isShowPhonePage: !0
            });
        }, a.usePhoneLogin = function() {
            a.setState({
                isShowPhonePage: !0,
                isShowPhoneModal: !1
            });
        }, a.getCode = function() {
            return _index2.default.login().then(function(e) {
                return e.code;
            });
        }, a.getUserInfo = function(i) {
            a.getCode().then(function(e) {
                var t = i.detail, n = t.errMsg, o = t.iv, r = t.encryptedData;
                if ("getUserInfo:ok" !== n) return _index2.default.showToast({
                    title: "授权已取消，请重新授权",
                    icon: "none"
                });
                a.loginByCode({
                    iv: o,
                    encryptedData: r,
                    code: e
                });
            });
        }, a.loginByCode = function(e) {
            API.loginByCode(e).then(function(e) {
                var t = e.errorCode, n = e.msg, o = e.values;
                if (200 !== t) return _index2.default.showToast({
                    title: n,
                    icon: "none"
                });
                o.accessToken && a.storeToken(o.accessToken, o.refreshToken), 13e5 === t && (a.data.userInfo = o, 
                a.setState({
                    isShowPhoneModal: !0
                }));
            }).catch(function(e) {
                _index2.default.showToast({
                    title: "登录失败，请重试",
                    icon: "none"
                }), console.error(e);
            });
        }, a.loginByAlipay = function() {
            (0, _aliPayAuth.getAuthToken)().then(function() {
                return a.storeToken();
            }).catch(function() {
                return (0, _aliPayAuth.initUser)();
            }).then(function() {
                return a.storeToken();
            }).catch(console.error);
        }, a.getPhoneNumber = function(e) {
            var t = e.detail;
            return t.errMsg.includes("ok") ? (a.setState({
                isShowPhoneModal: !1
            }), API.loginByBind({
                phoneIv: t.iv,
                phoneData: t.encryptedData,
                openid: a.data.userInfo.openid,
                unionid: a.data.userInfo.unionid
            }).then(function(e) {
                var t = e.errorCode, n = e.msg, o = e.values;
                if (200 !== t) return _index2.default.showModal({
                    title: "绑定失败",
                    content: 1400009 === t ? n : "请输入手机号注册/登录",
                    showCancel: !1,
                    confirmText: "我知道了"
                });
                o.accessToken && a.storeToken(o.accessToken, o.refreshToken);
            }).catch(function(e) {
                console.error(e);
            })) : _index2.default.showToast({
                title: "授权失败，请重试",
                icon: "none"
            });
        }, a.storeToken = function(e, t) {
            _index2.default.showToast({
                title: "登录成功",
                icon: "success"
            }), e && (app.setToken(e), _index2.default.setStorageSync(_index5.STORE.REFRESH_TOKEN, t)), 
            _index2.default.navigateBack({
                delta: 1
            });
        }, a.customComponents = [ "PhoneLogin" ], _possibleConstructorReturn(a, t);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function(e) {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentDidShow",
        value: function() {
            "ali_mp" === _index4.default.OFO_SOURCE_STR && (_index2.default.getApp().isToLogin = !0);
        }
    }, {
        key: "_createData",
        value: function(e, t, n) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            var o = this.$prefix, r = (0, _index.genCompid)(o + "$compid__2"), i = _slicedToArray(r, 2), a = i[0], s = i[1], u = this.__state;
            u.isShowPhoneModal;
            return u.isShowPhonePage && _index.propsManager.set({
                onLogin: this.storeToken.bind(this)
            }, s, a), Object.assign(this.__state, {
                anonymousState__temp: "/assets/login/banner.png",
                $compid__2: s
            }), this.__state;
        }
    } ]), i;
}(), _class.$$events = [ "getUserInfo", "showPhoneLogin", "getPhoneNumber", "usePhoneLogin" ], 
_class.$$componentPath = "pages/login/index", _temp2);

exports.default = Index, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index, !0));
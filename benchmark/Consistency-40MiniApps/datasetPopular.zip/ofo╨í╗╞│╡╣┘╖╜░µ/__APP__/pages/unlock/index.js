Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _slicedToArray = function(e, t) {
    if (Array.isArray(e)) return e;
    if (Symbol.iterator in Object(e)) return function(e, t) {
        var r = [], n = !0, o = !1, a = void 0;
        try {
            for (var i, c = e[Symbol.iterator](); !(n = (i = c.next()).done) && (r.push(i.value), 
            !t || r.length !== t); n = !0) ;
        } catch (e) {
            o = !0, a = e;
        } finally {
            try {
                !n && c.return && c.return();
            } finally {
                if (o) throw a;
            }
        }
        return r;
    }(e, t);
    throw new TypeError("Invalid attempt to destructure non-iterable instance");
}, _createClass = function() {
    function n(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, r) {
        return t && n(e.prototype, t), r && n(e, r), e;
    };
}(), _get = function e(t, r, n) {
    null === t && (t = Function.prototype);
    var o = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === o) {
        var a = Object.getPrototypeOf(t);
        return null === a ? void 0 : e(a, r, n);
    }
    if ("value" in o) return o.value;
    var i = o.get;
    return void 0 !== i ? i.call(n) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _ofo = require("../../utils/ofo.js"), OFO = _interopRequireWildcard(_ofo);

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var app = _index2.default.getApp(), Index = (_temp2 = _class = function() {
    function i() {
        var e, t, o;
        _classCallCheck(this, i);
        for (var r = arguments.length, n = Array(r), a = 0; a < r; a++) n[a] = arguments[a];
        return (t = o = _possibleConstructorReturn(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(n)))).$usedState = [ "$compid__1", "canClick", "unlockCarAlert" ], 
        o.config = {
            navigationBarTitleText: "车辆解锁"
        }, o.state = {
            canClick: !1,
            unlockCarAlert: {
                isShow: !1
            }
        }, o.carno = "", o.inputCarNum = function(e) {
            var t = e.detail.value, r = app.get(t, "length", 0), n = 3 < r && r < 9;
            o.carno = t, o.setState({
                canClick: n
            });
        }, o.EVhandleScan = function() {
            var e = o.carno;
            e ? OFO.unlockCar(e, o, {
                type: "scanUnlock"
            }) : _index2.default.showToast({
                title: "车牌有误，请重试～",
                icon: "none"
            });
        }, o.EVclosePopup = function() {
            o.setState({
                unlockCarAlert: {
                    isShow: !1
                }
            });
        }, o.customComponents = [ "UnlockPopup" ], _possibleConstructorReturn(o, t);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function(e) {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "_createData",
        value: function(e, t, r) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            var n = this.$prefix, o = (0, _index.genCompid)(n + "$compid__1"), a = _slicedToArray(o, 2), i = a[0], c = a[1];
            this.__state.canClick;
            return _index.propsManager.set({
                info: this.__state.unlockCarAlert,
                onClose: this.EVclosePopup
            }, c, i), Object.assign(this.__state, {
                $compid__1: c
            }), this.__state;
        }
    } ]), i;
}(), _class.$$events = [ "inputCarNum", "EVhandleScan" ], _class.$$componentPath = "pages/unlock/index", 
_temp2);

exports.default = Index, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index, !0));
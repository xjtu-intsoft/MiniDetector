Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _extends = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n, o = arguments[t];
        for (n in o) Object.prototype.hasOwnProperty.call(o, n) && (e[n] = o[n]);
    }
    return e;
}, _createClass = function() {
    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), e;
    };
}(), _get = function e(t, n, o) {
    null === t && (t = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === r) {
        var a = Object.getPrototypeOf(t);
        return null === a ? void 0 : e(a, n, o);
    }
    if ("value" in r) return r.value;
    var i = r.get;
    return void 0 !== i ? i.call(o) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _api = require("../../services/api.js"), API = _interopRequireWildcard(_api);

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var DEFAULT_TITLE = {
    0: "抵扣券",
    1: "折扣券",
    "-10": "包天券",
    41: "月卡折扣券",
    50: "红包年卡券"
}, DEFAULT_COUPON_UNIT = {
    0: "元",
    1: "折",
    "-10": "天",
    41: "折",
    50: "元"
}, Packet = (_temp2 = _class = function() {
    function i() {
        var e, t, n;
        _classCallCheck(this, i);
        for (var o = arguments.length, r = Array(o), a = 0; a < o; a++) r[a] = arguments[a];
        return (t = n = _possibleConstructorReturn(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(r)))).$usedState = [ "packet", "noPacket", "self", "openConsoleCount", "logInfo" ], 
        n.config = {
            navigationBarTitleText: "我的优惠劵"
        }, n.state = {
            packet: [],
            noPacket: !1,
            self: !1,
            openConsoleCount: 0,
            logInfo: !1
        }, n.customComponents = [], _possibleConstructorReturn(n, t);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function(e) {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentWillMount",
        value: function() {}
    }, {
        key: "componentDidMount",
        value: function() {
            this.getRedPacketShowList();
        }
    }, {
        key: "getRedPacketShowList",
        value: function() {
            var o = this;
            _index2.default.showLoading({
                title: "loading"
            }), API.getRedPacketList().then(function(e) {
                var t = e.values.info;
                if (_index2.default.hideLoading(), !t.length) return o.setState({
                    noPacket: !0
                });
                var n = t.map(function(e) {
                    var t, n, o, r, a = "", i = e.ext, a = DEFAULT_TITLE[e.opp + ""], s = DEFAULT_COUPON_UNIT[e.opp + ""];
                    return i && ((n = void 0 === (t = i.title) ? "" : t) && (a = n), (r = void 0 === (o = i.prefixTitle) ? "" : o) && (a = r + a)), 
                    e.fullTitle = a, e.couponUnit = s, 1 == e.opp || 41 == e.opp ? _extends({}, e, {
                        amounts: (10 * e.amounts).toFixed(1)
                    }) : e;
                });
                o.setState({
                    packet: n,
                    noPacket: !1
                });
            }).catch(function() {
                return _index2.default.hideLoading();
            });
        }
    }, {
        key: "openConsole",
        value: function() {}
    }, {
        key: "_createData",
        value: function(e, t, n) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            this.$prefix;
            var o = this.__state;
            o.packet, o.noPacket, o.self;
            return Object.assign(this.__state, {}), this.__state;
        }
    } ]), i;
}(), _class.$$events = [ "openConsole" ], _class.$$componentPath = "pages/packet/index", 
_temp2);

exports.default = Packet, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Packet, !0));
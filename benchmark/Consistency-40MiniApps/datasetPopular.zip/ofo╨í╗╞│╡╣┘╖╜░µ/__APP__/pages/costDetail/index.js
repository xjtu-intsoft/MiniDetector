Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), e;
    };
}(), _get = function e(t, n, o) {
    null === t && (t = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === r) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, n, o);
    }
    if ("value" in r) return r.value;
    var a = r.get;
    return void 0 !== a ? a.call(o) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _api = require("../../services/api.js"), API = _interopRequireWildcard(_api), _ofo = require("../../utils/ofo.js");

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var Index = (_temp2 = _class = function() {
    function i() {
        var e, t, f;
        _classCallCheck(this, i);
        for (var n = arguments.length, o = Array(n), r = 0; r < n; r++) o[r] = arguments[r];
        return (t = f = _possibleConstructorReturn(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(o)))).$usedState = [ "billingTextItems", "totalValue", "discountPrice" ], 
        f.config = {
            navigationBarTitleText: "费用明细"
        }, f.updateBillsDetail = function() {
            var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {}, t = e.orderno, n = e.packetid, o = e.parameter, r = {};
            try {
                o && (r = JSON.parse(decodeURIComponent(o)));
            } catch (e) {}
            var i = r.realPay, a = void 0 === i ? 0 : i, u = r.detail;
            if (!u) return !1;
            var s = "", c = u.reduceTextItems, l = u.billingTextItems;
            if (1 <= c.length) for (var p in c) "couponReduce" == c[p].key && (s = c[p]);
            f.setState({
                orderno: t,
                packetid: n,
                discountPrice: s,
                billingTextItems: l,
                totalValue: (a / 100).toFixed(2)
            });
        }, f.pay = function() {
            var e = f.state, t = e.orderno, n = e.packetid;
            API.pay({
                orderno: t,
                packetid: n
            }).then(function(e) {
                if (0 <= [ 200, 40006, 40009 ].indexOf(e.errorCode) && (setTimeout(_ofo.goMapPage, 1500), 
                _index2.default.showToast({
                    title: "结束订单成功",
                    icon: "success",
                    duration: 2e3,
                    mask: !0
                })), 40003 === e.errorCode) throw new Error();
            }).catch(function() {
                _index2.default.showToast({
                    title: "结束订单失败",
                    icon: "none",
                    duration: 2e3,
                    mask: !0
                });
            });
        }, f.customComponents = [], _possibleConstructorReturn(f, t);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function(e) {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentWillMount",
        value: function() {
            var e = this.$router.params;
            this.updateBillsDetail(e);
        }
    }, {
        key: "componentWillUnmount",
        value: function() {}
    }, {
        key: "componentDidShow",
        value: function() {}
    }, {
        key: "componentDidHide",
        value: function() {}
    }, {
        key: "_createData",
        value: function(e, t, n) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            this.$prefix;
            return this.anonymousFunc0 = function() {
                return _index2.default.navigateTo({
                    url: "/pages/accountRules/index"
                });
            }, Object.assign(this.__state, {}), this.__state;
        }
    }, {
        key: "anonymousFunc0",
        value: function() {}
    } ]), i;
}(), _class.$$events = [ "pay", "anonymousFunc0" ], _class.$$componentPath = "pages/costDetail/index", 
_temp2);

exports.default = Index, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index, !0));
Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _slicedToArray = function(e, t) {
    if (Array.isArray(e)) return e;
    if (Symbol.iterator in Object(e)) return function(e, t) {
        var n = [], o = !0, r = !1, i = void 0;
        try {
            for (var a, u = e[Symbol.iterator](); !(o = (a = u.next()).done) && (n.push(a.value), 
            !t || n.length !== t); o = !0) ;
        } catch (e) {
            r = !0, i = e;
        } finally {
            try {
                !o && u.return && u.return();
            } finally {
                if (r) throw i;
            }
        }
        return n;
    }(e, t);
    throw new TypeError("Invalid attempt to destructure non-iterable instance");
}, _extends = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n, o = arguments[t];
        for (n in o) Object.prototype.hasOwnProperty.call(o, n) && (e[n] = o[n]);
    }
    return e;
}, _createClass = function() {
    function o(e, t) {
        for (var n = 0; n < t.length; n++) {
            var o = t[n];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, n) {
        return t && o(e.prototype, t), n && o(e, n), e;
    };
}(), _get = function e(t, n, o) {
    null === t && (t = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === r) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, n, o);
    }
    if ("value" in r) return r.value;
    var a = r.get;
    return void 0 !== a ? a.call(o) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../../config/index.js"), _index4 = _interopRequireDefault(_index3), _deposit = require("./deposit.js"), Deposit = _interopRequireWildcard(_deposit), _ofo = require("../../utils/ofo.js"), OFO = _interopRequireWildcard(_ofo), _api = require("../../services/api.js"), API = _interopRequireWildcard(_api), _index5 = require("../../constant/index.js"), _location = require("../../utils/location.js");

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var app = _index2.default.getApp(), Index = (_temp2 = _class = function() {
    function i() {
        var e, t, s;
        _classCallCheck(this, i);
        for (var n = arguments.length, o = Array(n), r = 0; r < n; r++) o[r] = arguments[r];
        return (t = s = _possibleConstructorReturn(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(o)))).$usedState = [ "anonymousState__temp", "anonymousState__temp2", "$compid__0", "avatar", "blueBar", "phoneNum", "bondDesc", "isReady", "isLogin", "isAuth", "unlockCarAlert" ], 
        s.config = {
            navigationBarTitleText: "ofo小黄车"
        }, s.state = {
            isReady: !1,
            isLogin: !1,
            phoneNum: "",
            isAuth: !1,
            blueBar: {
                action: "ofoJump",
                redirecturl: _index5.URL.BLUEBAR_DEFAULT,
                noticeText: "12 岁以下儿童禁止使用 ofo 小黄车！"
            },
            bondDesc: "免押金",
            avatar: "/assets/avatar.png",
            unlockCarAlert: {
                isShow: !1
            }
        }, s.isNeedInit = !0, s.position = {}, s.initShow = function(e) {
            s.position = {
                latitude: e.lat,
                longitude: e.lng
            }, s.checkLoginStatus().then(function() {
                return s.getPriceInfo();
            }).then(function() {
                return s.getUserInfo();
            }).then(function() {
                return s.checkUnfinishOrder();
            }).then(function() {
                return s.checkAppScanScene();
            }).then(function() {
                return s.getBlueBar();
            }).catch(function(e) {
                console.error(e), s.pageReady();
            });
        }, s.pageReady = function() {
            _index2.default.hideLoading(), s.setState({
                isReady: !0
            });
        }, s.ofoJump = function(e) {
            e && _index2.default.navigateTo({
                url: e
            });
        }, s.isLoginIntercept = function() {
            return !s.state.isLogin && (_index2.default.navigateTo({
                url: "/pages/login/index"
            }), !0);
        }, s.checkLoginStatus = function() {
            return app.getToken() ? (s.setState({
                isLogin: !0
            }), Promise.resolve()) : ((app.isFromScan || "ali_mp" === _index4.default.OFO_SOURCE_STR && !_index2.default.getApp().isToLogin) && _index2.default.navigateTo({
                url: "/pages/login/index"
            }), Promise.reject());
        }, s.getPriceInfo = function() {
            var e = s.position, t = e.latitude, n = e.longitude;
            return API.getPriceInfo({
                lat: t,
                lng: n
            }).then(function(e) {
                var t = e.errorCode, n = e.values;
                if (200 === t && n.info) return _index2.default.setStorage({
                    key: _index5.STORE.PRICE_INFO,
                    data: n.info
                });
            }).catch(function(e) {
                return app.err(e);
            }), Promise.resolve();
        }, s.getUserInfo = function() {
            return Promise.all([ API.getUserInfo(), API.getWallet() ]).then(function(e) {
                var t = e[0];
                if (200 !== t.errorCode) return s.pageReady();
                var n = app.get(t, "values.info.tel", ""), o = app.get(t, "values.info.img", ""), r = 0 < app.get(t, "values.info.oauth", 0), i = n.substring(0, 3) + "****" + n.substring(7);
                (n || o) && s.setState({
                    phoneNum: i,
                    avatar: o,
                    isAuth: r
                });
                var a = e[1];
                if (200 !== a.errorCode) return s.pageReady();
                var u = Deposit.getDeposit(t.values.info, a.values.info);
                s.setState({
                    bondDesc: u
                }), s.pageReady();
            }).catch(function() {
                return s.pageReady();
            }), Promise.resolve();
        }, s.checkUnfinishOrder = function() {
            return OFO.checkUnfinishOrder().then(function(e) {
                return e;
            }).catch(function() {
                return s.plate = null, Promise.reject();
            });
        }, s.checkAppScanScene = function() {
            if (app.globalData.qrCode) {
                var e = OFO.getPlate(decodeURIComponent(app.globalData.qrCode));
                return e ? (OFO.unlockCar(e, s, {
                    type: "scanUnlock"
                }), app.globalData = {}, Promise.reject()) : Promise.resolve();
            }
            return Promise.resolve();
        }, s.getBlueBar = function() {
            var e = s.position, t = e.latitude, n = e.longitude;
            return API.getBlueBar({
                lat: t,
                lng: n
            }).then(function(e) {
                var t, n, o;
                e && 200 === e.errorCode && e.values && (n = (t = e.values).text, o = t.action, 
                s.setState({
                    blueBar: _extends({}, s.state.blueBar, {
                        noticeText: n || s.state.blueBar.noticeText,
                        redirecturl: o || s.state.blueBar.redirecturl
                    })
                }));
            }).catch(function() {
                return "";
            });
        }, s.EVhandleBlueBar = function() {
            s.isLoginIntercept() || s.ofoJump(s.state.blueBar.redirecturl);
        }, s.EVhandleDeposit = function() {
            var e = Deposit.getDepositTip(s.state.bondDesc);
            e && _index2.default.showToast({
                title: e,
                icon: "none"
            });
        }, s.EVhandleWallet = function() {
            s.isLoginIntercept() || _index2.default.navigateTo({
                url: "/pages/wallet/index"
            });
        }, s.EVhandleScan = function() {
            s.isLoginIntercept() || (s.isNeedInit = !1, OFO.getUserAuth().then(function() {
                return _index2.default.scanCode({
                    onlyFromCamera: !1,
                    scanType: [ "qrCode" ]
                });
            }).then(function(e) {
                var t = e.result, n = OFO.getPlate(t);
                n ? OFO.unlockCar(n, s, {
                    type: "scanUnlock"
                }) : _index2.default.showToast({
                    title: "车牌有误，请重试～",
                    icon: "none"
                }), setTimeout(function() {
                    return s.isNeedInit = !0;
                });
            }).catch(function(e) {
                console.error(e), setTimeout(function() {
                    return s.isNeedInit = !0;
                });
            }));
        }, s.EVHandleInput = function() {
            s.isLoginIntercept() || OFO.getUserAuth().then(function() {
                _index2.default.navigateTo({
                    url: "/pages/unlock/index"
                });
            });
        }, s.EVhandleAuth = function() {
            s.isLoginIntercept() || _index2.default.navigateTo({
                url: "/pages/auth/nameVerify/nameVerify"
            });
        }, s.EVhandleGoApp = function() {
            s.isLoginIntercept() || _index2.default.showToast({
                title: "请前往ofo共享单车app修改相关信息",
                icon: "none"
            });
        }, s.EVclosePopup = function() {
            s.setState({
                unlockCarAlert: {
                    isShow: !1
                }
            });
        }, s.customComponents = [ "UnlockPopup" ], _possibleConstructorReturn(s, t);
    }
    return _inherits(i, _index.Component), _createClass(i, [ {
        key: "_constructor",
        value: function(e) {
            _get(i.prototype.__proto__ || Object.getPrototypeOf(i.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentDidMount",
        value: function() {}
    }, {
        key: "componentDidShow",
        value: function() {
            var t = this;
            this.isNeedInit && (0, _location.getGeo)().then(function(e) {
                return t.initShow(e);
            });
        }
    }, {
        key: "_createData",
        value: function(e, t, n) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            var o = this.$prefix, r = (0, _index.genCompid)(o + "$compid__0"), i = _slicedToArray(r, 2), a = i[0], u = i[1];
            if (!this.__state.isReady) return null;
            var s = this.__state;
            s.blueBar, s.phoneNum, s.avatar, s.bondDesc;
            return _index.propsManager.set({
                info: this.__state.unlockCarAlert,
                onClose: this.EVclosePopup
            }, u, a), Object.assign(this.__state, {
                anonymousState__temp: "/assets/map/wallet.png",
                anonymousState__temp2: "/assets/map/deposit.png",
                $compid__0: u
            }), this.__state;
        }
    } ]), i;
}(), _class.$$events = [ "EVhandleBlueBar", "EVhandleGoApp", "EVhandleAuth", "EVhandleWallet", "EVhandleDeposit", "EVhandleScan", "EVHandleInput" ], 
_class.$$componentPath = "pages/map/map", _temp2);

exports.default = Index, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index, !0));
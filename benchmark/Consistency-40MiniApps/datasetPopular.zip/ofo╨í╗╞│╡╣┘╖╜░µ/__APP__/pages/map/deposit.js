Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getDeposit = getDeposit, exports.getDepositTip = getDepositTip;

var _index = require("../../config/index.js"), _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function getDeposit(e, t) {
    if (!Object.keys(e).length || !Object.keys(t).length) return "";
    var n = "免押金", o = parseInt(t.freeBondType), d = t.delayWithdraw ? t.delayWithdraw.time : null;
    return void 0 !== t.freeBondSubType && "integralMall" == t.freeBondSubType ? "已免押" : 8192 == o ? "已享充值免押" : "FINANCE" == t.freeBondSubType ? "已免押" : void 0 !== t.aliAccount && 0 < t.aliAccount.withdrawQueuePos ? "排队中" : 2 == t.aliAccount.queuedStatus ? "退款异常" : 3 == t.aliAccount.queuedStatus || 2 == t.bondRefundState || 3 == t.bondRefundState ? "退款中" : -1 == t.bondRefundState || -2 == t.bondRefundState || -3 == t.bondRefundState ? "退款异常" : -4 == t.bondRefundState ? "已免押" : ("未交" === t.bondDesc && (t.bondDesc = n), 
    d ? t.bondDesc || n : 1 == t.depositStatus ? "已交" : 2048 <= o && o < 4096 || 256 <= o && o < 1024 ? "已免押" : 32 == o ? "玖富万卡用户,已享免押3个月" : "bondYearCard" == t.freeBondSubType ? "已免押" : "RED_YEAR_CARD" == t.freeBondSubType ? "红包年卡免押" : "CREDIT_SCORE了" == t.freeBondSubType ? "信用免押用户" : "CREDIT" == t.freeBondSubType ? "悟空理财免押" : "PPMONEY" == t.freeBondSubType ? "免押金" : 4096 == o ? "企业用户免押" : 64 == o ? "中信联名卡用户,免押金" : 8192 == o ? "已享充值免押" : 16384 == o || 32768 == o ? "已享永久免押" : 30 == e.cls || 301 == e.cls || 302 == e.cls ? "特权用户，无须交纳押金" : 1 == t.zhiMaState ? t.zhiMaMsg : t.bondDesc ? t.bondDesc : n);
}

function getDepositTip(e) {
    return -1 < e.indexOf("免押") ? "" : -5 === _index2.default.OFO_SOURCE ? "ofo小黄车小程序暂不支持查看押金详情\n请下载使用ofo小黄车APP" : -4 === _index2.default.OFO_SOURCE ? "请在ofo小黄车APP内查看押金详情" : void 0;
}
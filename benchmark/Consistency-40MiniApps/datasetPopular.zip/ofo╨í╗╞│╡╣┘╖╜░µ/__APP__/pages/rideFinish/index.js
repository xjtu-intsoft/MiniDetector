Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function r(e, t) {
        for (var o = 0; o < t.length; o++) {
            var r = t[o];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(e, t, o) {
        return t && r(e.prototype, t), o && r(e, o), e;
    };
}(), _get = function e(t, o, r) {
    null === t && (t = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(t, o);
    if (void 0 === n) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, o, r);
    }
    if ("value" in n) return n.value;
    var a = n.get;
    return void 0 !== a ? a.call(r) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _api = require("../../services/api.js"), API = _interopRequireWildcard(_api), _ = require("../../utils/_.js"), _index3 = require("../../config/index.js"), _index4 = _interopRequireDefault(_index3);

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var o in e) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var RideFinish = (_temp2 = _class = function() {
    function a() {
        var e, t, o;
        _classCallCheck(this, a);
        for (var r = arguments.length, n = Array(r), i = 0; i < r; i++) n[i] = arguments[i];
        return (t = o = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(n)))).$usedState = [ "finishTitle", "payCoupon" ], 
        o.config = {
            navigationBarTitleText: "骑行结束"
        }, o.state = {
            finishTitle: "",
            payCoupon: ""
        }, o.customComponents = [], _possibleConstructorReturn(o, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function(e) {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentDidMount",
        value: function() {
            var e = this.$router.params;
            console.log("options====", e);
            var t = e.orderno;
            this.getOrderInfo(t);
        }
    }, {
        key: "getOrderInfo",
        value: function(e) {
            var s = this;
            console.log("getOrderInfo", e), API.getOrderInfo({
                orderno: e
            }).then(function(e) {
                var t = e.values && e.values.info ? e.values.info : {}, o = t.actualCost.toFixed(2), r = t.totalCost.toFixed(2), n = t.redPacketCls, i = "", i = 0 < o ? "本次行程支付" + o + "元" : "本次行程免费", a = "未使用优惠券";
                t.isDiscount && (t.timeCardDiscount ? a = "已使用次卡" : t.monthCardDiscount ? a = "已使用月卡" : 0 == n ? a = "已使用抵扣券" : 1 == n ? a = "已使用折扣券" : -10 == n && (a = "已使用包天券")), 
                t.pricing && 200 == t.pricing.version || (a = "原价" + r + "元"), s.setState({
                    finishTitle: i,
                    payCoupon: a
                }), console.log("totalCost", i, a);
            }).catch(function(e) {
                _index2.default.showToast({
                    title: e.msg,
                    icon: "none",
                    duration: 2e3
                });
            });
        }
    }, {
        key: "goRepair",
        value: function() {
            var e = "test" == _index4.default.ENV ? "https://qa-common.ofo.so/about/repair/" : "https://common.ofo.so/about/repair/";
            (0, _.ofoRedirect)(e + "?orderno=" + this.state.orderno + "&from=ride_finish");
        }
    }, {
        key: "goDetail",
        value: function() {}
    }, {
        key: "_createData",
        value: function(e, t, o) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            this.$prefix;
            var r = this.__state;
            r.finishTitle, r.payCoupon;
            return Object.assign(this.__state, {}), this.__state;
        }
    } ]), a;
}(), _class.$$events = [ "goRepair" ], _class.$$componentPath = "pages/rideFinish/index", 
_temp2);

exports.default = RideFinish, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(RideFinish, !0));
Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), e;
    };
}(), _get = function e(t, n, r) {
    null === t && (t = Function.prototype);
    var i = Object.getOwnPropertyDescriptor(t, n);
    if (void 0 === i) {
        var o = Object.getPrototypeOf(t);
        return null === o ? void 0 : e(o, n, r);
    }
    if ("value" in i) return i.value;
    var a = i.get;
    return void 0 !== a ? a.call(r) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../../config/index.js"), _index4 = _interopRequireDefault(_index3), _url = require("../../utils/url.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var app = _index2.default.getApp(), Index = (_temp2 = _class = function() {
    function a() {
        var e, t, i;
        _classCallCheck(this, a);
        for (var n = arguments.length, r = Array(n), o = 0; o < n; o++) r[o] = arguments[o];
        return (t = i = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(r)))).$usedState = [ "url" ], 
        i.config = {
            navigationBarTitleText: ""
        }, i.state = {
            url: ""
        }, i.first = !0, i.handleMessage = function(e) {
            console.log("WEB传入数据", e);
            var t = void 0, n = JSON.parse(JSON.stringify(e.detail.data));
            if ("wx_mp" === _index4.default.OFO_SOURCE_STR ? t = n.pop() : "ali_mp" === _index4.default.OFO_SOURCE_STR && (t = n), 
            t) {
                var r = t.action;
                if (r && i[r]) return i[r](t);
            }
        }, i.handleLogin = function() {
            app.removeToken(), "rebate" === i.login_type && "wx_mp" === _index4.default.OFO_SOURCE_STR ? _index2.default.navigateTo({
                url: "/pages/loginRebate/index"
            }) : _index2.default.navigateTo({
                url: "/pages/login/index"
            });
        }, i.initPage = function() {
            var e = app.getToken(), t = i.webUrl, n = {};
            if (i.need_login && !e) return i.handleLogin();
            n.token = e, n.von = Date.now(), n.env = _index4.default.OFO_SOURCE_STR, t = (0, 
            _url.extendParamsToUrl)(t, n), (i.first || i.need_reset) && i.setState({
                url: t
            });
        }, i.updateRepairStatus = function(e) {
            _index2.default.getApp().repairStatus.isRepaired = e.isRepaired;
        }, i.customComponents = [], _possibleConstructorReturn(i, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function(e) {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentWillMount",
        value: function() {
            var e = this.$router.params, t = e.need_login, n = e.need_reset, r = e.login_type, i = e.webUrl;
            if (!i) return _index2.default.navigateBack({
                delta: 1
            });
            this.need_login = t, this.need_reset = n, this.login_type = r, this.webUrl = decodeURIComponent(i);
        }
    }, {
        key: "componentDidShow",
        value: function() {
            this.initPage(), this.first = !1;
        }
    }, {
        key: "_createData",
        value: function(e, t, n) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            this.$prefix;
            return Object.assign(this.__state, {}), this.__state;
        }
    } ]), a;
}(), _class.$$events = [ "handleMessage" ], _class.$$componentPath = "pages/webView/webView", 
_temp2);

exports.default = Index, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Index, !0));
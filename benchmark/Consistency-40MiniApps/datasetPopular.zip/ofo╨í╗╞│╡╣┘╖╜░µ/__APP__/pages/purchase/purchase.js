Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _extends = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var r, n = arguments[t];
        for (r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
    }
    return e;
}, _createClass = function() {
    function n(e, t) {
        for (var r = 0; r < t.length; r++) {
            var n = t[r];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, r) {
        return t && n(e.prototype, t), r && n(e, r), e;
    };
}(), _get = function e(t, r, n) {
    null === t && (t = Function.prototype);
    var a = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === a) {
        var o = Object.getPrototypeOf(t);
        return null === o ? void 0 : e(o, r, n);
    }
    if ("value" in a) return a.value;
    var i = a.get;
    return void 0 !== i ? i.call(n) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _api = require("../../services/api.js"), API = _interopRequireWildcard(_api), _payment = require("../../config/payment.js"), _location = require("../../utils/location.js"), _ = require("../../utils/_.js");

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var OFO_PAGE_NAME = "purchase", pageName = "purchase", initInfo = "**", pageConfig = {
    type: pageName,
    name: "余额充值",
    notes: [ {
        text: "其中充值余额 ",
        unit: " 元"
    } ],
    unit: "元",
    btns: [ {
        text: "立即充值",
        type: pageName,
        isShow: !0,
        event_name: "recharge_bottom_btn",
        event_id: "recharge",
        action: "handlePurchase",
        redirectUrl: ""
    } ],
    selectItem: {
        text: "充值金额",
        type: "rechargeItem",
        event_name: "recharge_block_item",
        event_id: "recharge_item",
        ordername: [ {
            name: "leftTop"
        }, {
            name: "rightTop"
        }, {
            name: "leftBottom"
        }, {
            name: "rightBottom"
        } ],
        action: "selectPur",
        redirectUrl: ""
    },
    more: {
        text: "《充值活动协议》",
        desc: "点击立即充值，即表示您已经同意",
        type: "agrt",
        isShow: !0,
        disabled: !0,
        action: "ofoJump",
        redirectUrl: "/pages/agreement/index",
        event_name: "bottom_more",
        event_id: "recharge_agreement"
    },
    ERROR_MSG: {
        RECHARGE_CASH_ERROR: "充值错误",
        RECHARGE_CASH_INVALID: "金额无效，请重试"
    }
}, Purchase = (_temp2 = _class = function() {
    function o() {
        var e, t, m;
        _classCallCheck(this, o);
        for (var r = arguments.length, n = Array(r), a = 0; a < r; a++) n[a] = arguments[a];
        return (t = m = _possibleConstructorReturn(this, (e = o.__proto__ || Object.getPrototypeOf(o)).call.apply(e, [ this ].concat(n)))).$usedState = [ "pageConfig", "loopArray4", "headBannerConfig", "currtPur", "balance", "realBalance", "payBtnDisabled", "ccsourcefrom", "from", "purchaseList", "resourceData" ], 
        m.config = {
            navigationBarTitleText: "余额充值"
        }, m.state = {
            currtPur: "",
            balance: initInfo,
            realBalance: initInfo,
            payBtnDisabled: !0,
            ccsourcefrom: "",
            from: "",
            purchaseList: [],
            resourceData: {
                adslotIds: "rechargeBanner",
                resourceType: 1,
                reqVersion: 1
            },
            headBannerConfig: {
                text: "",
                desc: "",
                type: "rechargebanner",
                event_name: "title_banner",
                imgLocation: "",
                event_id: "",
                action: "ofoJump",
                redirectUrl: ""
            },
            pageConfig: pageConfig
        }, m.selectPur = function(e) {
            var t = e.alphaBeta, r = e.position, n = e.money, a = e.addedmoney;
            m.setState({
                currtPur: t,
                curPosition: r,
                curRechargeMoney: n,
                curAddedRechargeMoney: a
            });
        }, m.ofoDispatch = function(e) {
            console.log("5555555555");
            var t = e.currentTarget.dataset, r = t.item, n = void 0 === r ? {} : r, a = t.evtobj, o = void 0 === a ? {} : a, i = t.position, c = o.type, s = void 0 === c ? "" : c, u = o.redirectUrl, l = void 0 === u ? "" : u, p = o.action, _ = void 0 === p ? "" : p, f = o.event_id, h = void 0 === f ? "" : f, d = (o.event_name, 
            n.val, n.payment, {
                event_type: "click",
                event_id: h
            });
            if (console.log("evtobj: ", o), -1 < s.indexOf("rechargeItem")) {
                var g = n.recharge, y = n.val, v = e.currentTarget.dataset.alphaBeta;
                return console.log("充值选项====：", v, _), m[_]({
                    alphaBeta: v,
                    position: i,
                    money: y,
                    addedmoney: g
                });
            }
            return "purchase" == s && _extends({}, d, {
                payment: m.state.purchaseList[m.state.currtPur].payment,
                position: m.state.curPosition,
                rechargeMoney: m.state.curRechargeMoney,
                addedRechargeMoney: m.state.curAddedRechargeMoney
            }), "agrt" == s && l && (l += "?purchaseList=" + JSON.stringify(m.state.purchaseList)), 
            _ && m[_] ? m[_](l, {
                type: h
            }) : console.log("无相关方法");
        }, m.customComponents = [], _possibleConstructorReturn(m, t);
    }
    return _inherits(o, _index.Component), _createClass(o, [ {
        key: "_constructor",
        value: function(e) {
            _get(o.prototype.__proto__ || Object.getPrototypeOf(o.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentDidMount",
        value: function() {
            this.getRechargeInfo(), this.getWalletInfo();
        }
    }, {
        key: "getRechargeInfo",
        value: function() {
            var o = this;
            (0, _location.getGeo)().then(function(e) {
                var t = e.lat, r = e.lng;
                API.recharge({
                    lat: t,
                    lng: r
                }).then(function(e) {
                    if (200 == e.errorCode) {
                        var t = e.values.isRechargeActivity, r = e.values.info, n = 0;
                        try {
                            for (var a in r) {
                                if (r[a].checked) {
                                    n = +a;
                                    break;
                                }
                            }
                        } catch (e) {
                            console.log(e);
                        }
                        o.setState({
                            payBtnDisabled: !1,
                            currtPur: n,
                            curPosition: o.state.pageConfig.selectItem.ordername[n].name,
                            curRechargeMoney: r[n].val,
                            curAddedRechargeMoney: r[n].recharge,
                            purchaseList: r,
                            isRechargeActivity: t
                        });
                    }
                });
            });
        }
    }, {
        key: "getWalletInfo",
        value: function() {
            var a = this;
            API.wallet({}).then(function(e) {
                var t, r, n;
                200 === e.errorCode && (r = (t = e.values.info).balance, n = t.realBalance, a.setState({
                    realBalance: n || 0,
                    balance: r.toString().match(/^-?\d+(?:\.\d{0,2})?/)[0]
                }));
            });
        }
    }, {
        key: "handlePurchase",
        value: function() {
            if (this.state.payBtnDisabled) return console.log("支付不可用哦");
            var e = this.state.purchaseList[this.state.currtPur], t = this.state.purchaseList[this.state.currtPur].isCoupon;
            if (!e) return console.log("未选中充值项");
            var r = e.payment;
            return r ? (0, _payment.ofoUnitedPayment)({
                payment: r,
                isCoupon: t,
                payType: "purchase_trade_pay"
            }).then(function(e) {
                console.log("支付成功后返回上一页: ", e), _index2.default.navigateBack();
            }).then(function() {
                return _index2.default.hideLoading();
            }).catch(function() {
                return _index2.default.hideLoading();
            }) : console.log("充送选项有误");
        }
    }, {
        key: "ofoJump",
        value: function(e, t) {
            var r = 1 < arguments.length && void 0 !== t ? t : {};
            console.log("协议跳转=======");
            var n = {
                from: OFO_PAGE_NAME
            };
            r.type && (n = _extends({}, n, {
                ccsourcefrom: r.type
            })), e = (0, _.urlParamsObjToString)(e, n), console.log("redirecturl========", e), 
            _index2.default.navigateTo({
                url: e
            });
        }
    }, {
        key: "_createData",
        value: function(e, t, r) {
            var n = this;
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            this.$prefix;
            var a = this.__state.payBtnDisabled ? [] : this.__state.purchaseList.map(function(e, t) {
                return e = {
                    $original: (0, _index.internal_get_original)(e)
                }, {
                    $loopState__temp2: n.__state.payBtnDisabled ? null : (0, _index.internal_inline_style)(e.$original.tips ? "" : "line-height: 140rpx"),
                    $original: e.$original
                };
            });
            return Object.assign(this.__state, {
                loopArray4: a
            }), this.__state;
        }
    } ]), o;
}(), _class.$$events = [ "ofoDispatch" ], _class.$$componentPath = "pages/purchase/purchase", 
_temp2);

exports.default = Purchase, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Purchase, !0));
Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function o(e, t) {
        for (var r = 0; r < t.length; r++) {
            var o = t[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
            Object.defineProperty(e, o.key, o);
        }
    }
    return function(e, t, r) {
        return t && o(e.prototype, t), r && o(e, r), e;
    };
}(), _get = function e(t, r, o) {
    null === t && (t = Function.prototype);
    var n = Object.getOwnPropertyDescriptor(t, r);
    if (void 0 === n) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, r, o);
    }
    if ("value" in n) return n.value;
    var a = n.get;
    return void 0 !== a ? a.call(o) : void 0;
}, _index = require("../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _api = require("../../services/api.js"), API = _interopRequireWildcard(_api), _ = require("../../utils/_.js"), _url = require("../../utils/url.js"), _index3 = require("../../config/index.js"), _index4 = _interopRequireDefault(_index3);

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && (t[r] = e[r]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var app = _index2.default.getApp(), Bike = (_temp2 = _class = function() {
    function a() {
        var e, t, r;
        _classCallCheck(this, a);
        for (var o = arguments.length, n = Array(o), i = 0; i < o; i++) n[i] = arguments[i];
        return (t = r = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(n)))).$usedState = [ "pwd", "carno", "timeStr", "orderno", "countTime" ], 
        r.config = {
            navigationBarTitleText: "骑行中"
        }, r.state = {
            orderno: "",
            carno: "",
            pwd: "",
            timeStr: "00:00:00",
            countTime: ""
        }, r.customComponents = [], _possibleConstructorReturn(r, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "_constructor",
        value: function(e) {
            _get(a.prototype.__proto__ || Object.getPrototypeOf(a.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentDidMount",
        value: function() {
            this.getUnfinishedOrder();
        }
    }, {
        key: "componentDidShow",
        value: function() {
            _index2.default.getApp().repairStatus.getRepaired() && this.endOrder();
        }
    }, {
        key: "componentWillUnmount",
        value: function() {
            clearInterval(this.recordTimer);
        }
    }, {
        key: "getUnfinishedOrder",
        value: function() {
            var t = this;
            API.getUnfinishedOrder({}).then(function(e) {
                console.log("carnocarnocarno", e.values), 30005 == e.errorCode && (t.flushData(e.values.info), 
                t.ridingRecord());
            }).catch(function(e) {
                _index2.default.showToast({
                    title: e.msg,
                    icon: "none",
                    duration: 2e3
                });
            });
        }
    }, {
        key: "flushData",
        value: function(e) {
            if (console.log("flushDataflushData", e), !e) return console.log("缺少flushData方法调用options参数");
            var t = e.orderno, r = e.carno, o = e.pwd, n = e.t, i = void 0 === n ? 0 : n;
            this.startTime = Date.now();
            var a = parseInt(i, 10);
            this.setState({
                pwd: o,
                carno: r,
                orderno: t,
                countTime: a
            });
        }
    }, {
        key: "ridingRecord",
        value: function() {
            var t = this;
            if (console.log("ridingRecord====", this.recordTimer), this.recordTimer) return console.log("已经开始计时");
            var r = 0;
            this.recordTimer = setInterval(function() {
                --r <= 0 && (r = 5, t.getUnfinishedOrder());
                var e = t.adjustTime();
                t.setTime(e);
            }, 1e3), this.startTime = Date.now();
        }
    }, {
        key: "adjustTime",
        value: function() {
            console.log("startTime=======", this.startTime, this.state.countTime);
            var e = Date.now();
            return Math.floor((e - this.startTime) / 1e3) + parseInt(this.state.countTime);
        }
    }, {
        key: "setTime",
        value: function(e) {
            var t, r = (0, _.formatTimeToDetail)(e, !1), o = "";
            for (t in r.time) r.time[t] < 10 && (o += "0"), o += r.time[t], t < 2 && (o += ":");
            this.setState({
                timeStr: o
            });
        }
    }, {
        key: "endOrder",
        value: function() {
            var o = this;
            API.end({
                orderno: this.state.orderno,
                closeLockType: 0
            }).then(function(e) {
                var t = e.errorCode;
                if (-1 < [ 200, 40002 ].indexOf(t)) {
                    var r = {
                        isNeedToPay: 1,
                        orderno: o.state.orderno,
                        packetid: app.get(e, "values.info.packetid", ""),
                        parameter: encodeURIComponent(JSON.stringify(app.get(e, "values.info.pricing", {})))
                    };
                    return _index2.default.redirectTo({
                        url: (0, _url.extendParamsToWp)("/pages/costDetail/index", r)
                    });
                }
                return Promise.reject(e);
            }).catch(function(e) {
                console.error(e), _index2.default.showToast({
                    title: e.msg || "还车失败",
                    icon: "none"
                });
            });
        }
    }, {
        key: "goRepair",
        value: function() {
            var e = "test" == _index4.default.ENV ? "https://qa-common.ofo.so/about/repair/" : "https://common.ofo.so/about/repair/";
            (0, _.ofoRedirect)(e + "?orderid=" + this.state.orderno + "&from=bike_riding");
        }
    }, {
        key: "_createData",
        value: function(e, t, r) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            this.$prefix;
            var o = this.__state;
            o.carno, o.pwd, o.timeStr;
            return Object.assign(this.__state, {}), this.__state;
        }
    } ]), a;
}(), _class.$$events = [ "goRepair", "endOrder" ], _class.$$componentPath = "pages/bike/index", 
_temp2);

exports.default = Bike, Component(require("../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Bike, !0));
Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _class, _temp2, _createClass = function() {
    function n(e, t) {
        for (var a = 0; a < t.length; a++) {
            var n = t[a];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(e, n.key, n);
        }
    }
    return function(e, t, a) {
        return t && n(e.prototype, t), a && n(e, a), e;
    };
}(), _get = function e(t, a, n) {
    null === t && (t = Function.prototype);
    var r = Object.getOwnPropertyDescriptor(t, a);
    if (void 0 === r) {
        var i = Object.getPrototypeOf(t);
        return null === i ? void 0 : e(i, a, n);
    }
    if ("value" in r) return r.value;
    var o = r.get;
    return void 0 !== o ? o.call(n) : void 0;
}, _index = require("../../../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _api = require("../../../services/api.js"), API = _interopRequireWildcard(_api), _ = require("../../../utils/_.js"), _ofo = require("../../../utils/ofo.js");

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

var app = _index2.default.getApp(), Auth = (_temp2 = _class = function() {
    function o() {
        var e, t, a;
        _classCallCheck(this, o);
        for (var n = arguments.length, r = Array(n), i = 0; i < n; i++) r[i] = arguments[i];
        return (t = a = _possibleConstructorReturn(this, (e = o.__proto__ || Object.getPrototypeOf(o)).call.apply(e, [ this ].concat(r)))).$usedState = [ "verifyOk", "nameState", "idCardState", "realName", "idCard" ], 
        a.config = {
            navigationBarTitleText: "实名认证"
        }, a.state = {
            verifyOk: !1,
            nameState: !1,
            idCardState: !1,
            realName: "",
            idCard: ""
        }, a.customComponents = [], _possibleConstructorReturn(a, t);
    }
    return _inherits(o, _index.Component), _createClass(o, [ {
        key: "_constructor",
        value: function(e) {
            _get(o.prototype.__proto__ || Object.getPrototypeOf(o.prototype), "_constructor", this).call(this, e), 
            this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "componentDidMount",
        value: function() {}
    }, {
        key: "componentWillUnmount",
        value: function() {}
    }, {
        key: "nameInput",
        value: function(e) {
            var t = this;
            1 < e.detail.value.length ? this.setState({
                nameState: !0
            }) : this.setState({
                nameState: !1
            }), this.setState({
                realName: e.detail.value
            }, function() {
                t.checkBtnState();
            });
        }
    }, {
        key: "idCardInput",
        value: function(e) {
            var t = this, a = e.detail.value;
            15 == a.length || 18 == a.length ? (0, _.isIdCardNo)(a) && this.setState({
                idCardState: !0
            }) : this.setState({
                idCardState: !1
            }), this.setState({
                idCard: a
            }, function() {
                t.checkBtnState();
            });
        }
    }, {
        key: "checkBtnState",
        value: function() {
            this.state.nameState && this.state.idCardState ? this.setState({
                verifyOk: !0
            }) : this.setState({
                verifyOk: !1
            });
        }
    }, {
        key: "submitData",
        value: function() {
            this.state.verifyOk && (_index2.default.showLoading({
                title: "loading"
            }), API.commonAuthenticate({
                realName: this.state.realName,
                idCard: this.state.idCard
            }).then(function(e) {
                console.log("res: ", e), _index2.default.hideLoading(), 200 == e.errorCode ? (_index2.default.showToast({
                    title: "认证成功",
                    icon: "success",
                    duration: 2e3
                }), setTimeout(_ofo.goMapPage, 2e3)) : (_index2.default.showToast({
                    title: e.msg,
                    icon: "none",
                    duration: 2e3
                }), 60099 == e.errorCode && setTimeout(_ofo.goMapPage, 2e3));
            }));
        }
    }, {
        key: "_createData",
        value: function(e, t, a) {
            this.__state = e || this.state || {}, this.__props = t || this.props || {};
            this.$prefix, this.__state.verifyOk;
            return Object.assign(this.__state, {}), this.__state;
        }
    } ]), o;
}(), _class.$$events = [ "nameInput", "idCardInput", "submitData" ], _class.$$componentPath = "pages/auth/nameVerify/nameVerify", 
_temp2);

exports.default = Auth, Component(require("../../../npm/@tarojs/taro-weapp/index.js").default.createComponent(Auth, !0));
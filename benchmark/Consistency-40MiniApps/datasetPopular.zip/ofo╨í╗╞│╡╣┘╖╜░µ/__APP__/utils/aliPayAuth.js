Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.getAuthToken = getAuthToken, exports.updateAuthToken = updateAuthToken, 
exports.initUser = initUser, exports.authRelationSolveCenter = authRelationSolveCenter, 
exports.ofoAliAuthLogin = ofoAliAuthLogin;

var _index = require("../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../config/index.js"), _index4 = _interopRequireDefault(_index3), _index5 = require("../constant/index.js"), _api = require("../services/api.js"), API = _interopRequireWildcard(_api);

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var t = {};
    if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    return t.default = e, t;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var authTokenPromise = null;

function getAuthCode(o) {
    return new Promise(function(n, t) {
        my.getAuthCode({
            scopes: o,
            success: function(e) {
                var t = e.authCode;
                n({
                    authCode: t,
                    scopes: o
                });
            },
            fail: function(e) {
                t(e);
            }
        });
    });
}

function getAuthToken() {
    var e = (0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {}).isForcedToRefresh;
    return void 0 !== e && e && (authTokenPromise = null), authTokenPromise || (authTokenPromise = _index2.default.getStorage({
        key: _index5.STORE.TOKEN
    }).then(function(e) {
        var t = e.data;
        return t || (authTokenPromise = null, updateAuthToken());
    }));
}

function updateAuthToken() {
    return authTokenPromise = getAuthCode(_index4.default.SCOPES_ALIPAY.USER_SILENCE).then(function(e) {
        var t = e.authCode;
        return Promise.all([ _index2.default.getStorage({
            key: _index5.STORE.TOKEN
        }), _index2.default.getStorage({
            key: _index5.STORE.REFRESH_TOKEN
        }) ]).then(function(e) {
            return API.alipayAutoLogin({
                authCode: t,
                cachedAccess: e[0].data,
                cachedRefresh: e[1].data
            });
        });
    }).catch(function() {
        return _index2.default.setStorageSync(_index5.STORE.TOKEN, ""), Promise.reject(222);
    }).then(function(e) {
        if (200 !== e.errorCode) return Promise.reject();
        var t = e.values, n = t.token, o = t.refreshToken, r = void 0 === o ? "" : o;
        return _index2.default.setStorageSync(_index5.STORE.TOKEN, n), _index2.default.setStorageSync(_index5.STORE.REFRESH_TOKEN, r), 
        Promise.resolve();
    }).then(function(e) {
        return authTokenPromise = null, e;
    }).catch(function(e) {
        return _index2.default.setStorageSync(_index5.STORE.TOKEN, ""), authTokenPromise = null, 
        Promise.reject(e);
    });
}

function initUser() {
    return getAuthCode(_index4.default.SCOPES_ALIPAY.COMMON_SCOPES).then(function(e) {
        return ofoAliAuthLogin({
            unsolicitedAuthCode: e.authCode,
            scopes: e.scopes
        });
    }).catch(function(e) {
        return Promise.reject(e);
    });
}

function authRelationSolveCenter(e) {
    var t = e.userAccountStatus;
    return _index2.default.showToast({
        icon: "none",
        duration: 5e3,
        title: t.msg || "网络错误"
    }), Promise.reject();
}

function ofoAliAuthLogin(e) {
    var u = e.unsolicitedAuthCode, i = e.scopes;
    if (!u) throw "authcode null";
    return API.alipayAuthLogin({
        auth_code: u,
        scopes: i
    }).then(function(e) {
        if (200 != e.errorCode) return authRelationSolveCenter({
            userAccountStatus: e,
            unsolicitedAuthCode: u,
            scopes: i
        });
        if (200 === e.errorCode && e.values && e.values.token) {
            var t = e.values, n = t.token, o = t.refreshToken, r = void 0 === o ? "" : o;
            return _index2.default.setStorageSync(_index5.STORE.TOKEN, n), _index2.default.setStorageSync(_index5.STORE.REFRESH_TOKEN, r), 
            n;
        }
    }).catch(function(e) {
        return Promise.reject(e);
    });
}
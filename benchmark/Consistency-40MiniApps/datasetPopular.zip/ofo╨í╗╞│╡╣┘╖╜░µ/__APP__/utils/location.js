Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n, r = arguments[t];
        for (n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n]);
    }
    return e;
};

exports.getGeo = getGeo, exports.getLastGeo = getLastGeo;

var _index = require("../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("../config/index.js"), _index4 = _interopRequireDefault(_index3), _index5 = require("../constant/index.js");

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function getGeo() {
    return _index2.default.getLocation({
        type: "gcj02",
        cacheTimeout: 5
    }).then(function(e) {
        var t = e.latitude, n = e.longitude, r = e.speed, i = void 0 === r ? 0 : r, a = e.accuracy, o = void 0 === a ? 0 : a, u = e.altitude, c = void 0 === u ? 0 : u, d = e.verticalAccuracy, l = void 0 === d ? 0 : d, _ = e.horizontalAccuracy, f = void 0 === _ ? 0 : _, g = {
            lat: t,
            lng: n,
            speed: i,
            accuracy: o,
            altitude: c,
            verticalAccuracy: l,
            horizontalAccuracy: f
        };
        try {
            var s = _index2.default.getApp();
            s.location = JSON.stringify([ t, n, c, Date.now(), i, f, 0, 0 ].map(function(e) {
                return String(e);
            })), s.latlng = {
                lat: t,
                lng: n
            };
        } catch (e) {}
        return _index2.default.setStorage({
            key: _index5.STORE.GEO_INFO,
            data: g
        }), g;
    }).catch(function() {
        return _index2.default.getApp().latlng = _index4.default.DEFAULT_LOCATION, _extends({
            fail: "default"
        }, _index4.default.DEFAULT_LOCATION);
    });
}

function getLastGeo() {
    return _index2.default.getStorage({
        key: _index5.STORE.GEO_INFO
    }).then(function(e) {
        return e || getGeo();
    }).catch(function() {
        return getGeo();
    });
}
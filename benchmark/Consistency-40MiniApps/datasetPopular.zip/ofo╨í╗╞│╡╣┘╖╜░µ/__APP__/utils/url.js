Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

exports.getHashs = getHashs, exports.getQuerys = getQuerys, exports.getUrlParams = getUrlParams, 
exports.parseParams = parseParams, exports.extendParamsToWp = extendParamsToWp, 
exports.extendParamsToUrl = extendParamsToUrl;

var _ = require("./_.js"), _jsUrl = require("../library/js-url.js"), _jsUrl2 = _interopRequireDefault(_jsUrl);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function getFormatUrl() {
    var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "", r = e.split("#");
    if (1 < r.length) {
        var t = r[1].split("?");
        return 1 < t.length ? r[0] + "#" + t[1] : r[0];
    }
    return e;
}

function getHashs(e) {
    return (0, _jsUrl2.default)("#", getFormatUrl(e)) || {};
}

function getQuerys(e) {
    return (0, _jsUrl2.default)("?", e) || {};
}

function getUrlParams(e) {
    return (0, _.extend)({}, getQuerys(e), getHashs(e));
}

function parseParams(e) {
    function s(e, r) {
        r = null == (r = "function" == typeof r ? r() : r) ? "" : r, l[l.length] = encodeURIComponent(e) + "=" + encodeURIComponent(r);
    }
    var l = [];
    return function e(r, t) {
        var n, a, o;
        if (r) if (Array.isArray(t)) for (n = 0, a = t.length; n < a; n++) e(r + "[" + ("object" === _typeof(t[n]) && t[n] ? n : "") + "]", t[n]); else if ("[object Object]" === String(t)) for (o in t) e(r + "[" + o + "]", t[o]); else s(r, t); else if (Array.isArray(t)) for (n = 0, 
        a = t.length; n < a; n++) s(t[n].name, t[n].value); else for (o in t) e(o, t[o]);
        return l;
    }("", e).join("&");
}

function extendParamsToWp(e, r) {
    var t = parseParams(r);
    return -1 < e.indexOf("?") ? e + "&" + t : e + "?" + t;
}

function extendParamsToUrl(e, r) {
    var t = getHashs(e), n = getQuerys(e), a = (0, _jsUrl2.default)("port", e), o = (0, 
    _jsUrl2.default)("protocol", e), s = "443" === a || "80" === a ? "" : ":" + a, l = 0 < e.indexOf("#");
    0 < e.indexOf("#/") ? t = (0, _.extend)({}, t, r) : n = (0, _.extend)({}, n, r);
    var u, f, i, p = (u = parseParams(n)) ? "?" + u : "", m = (f = parseParams(t)) ? "?" + f : "", y = (i = (0, 
    _jsUrl2.default)("hash", e)) ? "#" + i.split("?")[0] : "#/";
    return o + "://" + (0, _jsUrl2.default)("hostname", e) + s + (0, _jsUrl2.default)("path", e) + p + (l ? y : "") + (l ? m : "");
}
Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(e) {
    for (var r = 1; r < arguments.length; r++) {
        var t, n = arguments[r];
        for (t in n) Object.prototype.hasOwnProperty.call(n, t) && (e[t] = n[t]);
    }
    return e;
};

exports.goMapPage = goMapPage, exports.ofoPay = ofoPay, exports.checkUnfinishOrder = checkUnfinishOrder, 
exports.getPlate = getPlate, exports.unlockCar = unlockCar, exports.getUserAuth = getUserAuth;

var _index = require("../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _lodashGet = require("../library/lodash.get.js"), _lodashGet2 = _interopRequireDefault(_lodashGet), _index3 = require("../config/index.js"), _index4 = _interopRequireDefault(_index3), _location = require("./location.js"), _api = require("../services/api.js"), API = _interopRequireWildcard(_api), _url = require("./url.js");

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var r = {};
    if (null != e) for (var t in e) Object.prototype.hasOwnProperty.call(e, t) && (r[t] = e[t]);
    return r.default = e, r;
}

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function goBikePage(e, r) {
    var t = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : "", n = e.orderno, o = e.t, i = void 0 === o ? 0 : o, a = e.pwd, d = e.repairTime, u = void 0 === d ? 0 : d, s = e.lock, c = void 0 === s ? {} : s, l = e.unlockType, p = {
        t: i,
        pwd: a,
        carno: r,
        orderno: n,
        unlockType: void 0 === l ? [] : l,
        repairTime: u,
        lockTT: c.type,
        lock: JSON.stringify(c),
        btFlag: t
    };
    1 === _index2.default.getCurrentPages().length ? _index2.default.navigateTo({
        url: (0, _url.extendParamsToWp)("/pages/bike/index", p)
    }) : _index2.default.redirectTo({
        url: (0, _url.extendParamsToWp)("/pages/bike/index", p)
    });
}

function goMapPage() {
    try {
        var e = _index2.default.getCurrentPages().length;
        return 1 == e ? _index2.default.redirectTo({
            url: "/pages/map/map"
        }) : _index2.default.navigateBack({
            delta: e - 1
        });
    } catch (e) {}
}

function ofoPayMethod(e, r) {
    var a = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {}, t = a.isNotJump, d = void 0 !== t && t;
    return API.pay({
        orderno: e,
        packetid: r
    }).then(function(e) {
        if (200 === e.errorCode) {
            var r = e.values.info, t = r.show, n = r.orderno, o = {};
            try {
                o = JSON.parse(t);
            } catch (e) {}
            var i = "/pages/rideFinish/index?orderno=" + n, i = (0, _url.extendParamsToWp)(i, o);
            if (d) return i;
            goMapPage();
        }
        return 40003 === e.errorCode && _index2.default.showToast({
            title: "订单未结束",
            icon: "none",
            duration: 2e3
        }), (-1 < [ 40006, 40009 ].indexOf(e.errorCode) || "pay" === a.curPage) && goMapPage(), 
        Promise.reject();
    });
}

function ofoPay(e, r) {
    var t = (2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : {}).res, n = "";
    try {
        n = encodeURIComponent(JSON.stringify(t.values.info.pricing));
    } catch (e) {}
    var o = {
        orderno: e,
        packetid: r,
        parameter: n,
        isNeedToPay: 1
    };
    return _index2.default.redirectTo({
        url: (0, _url.extendParamsToWp)("/pages/costDetail/index", o)
    }), Promise.reject();
}

function checkUnfinishOrder() {
    var t = 0 < arguments.length && void 0 !== arguments[0] && arguments[0];
    return (0, _location.getGeo)().then(function() {
        return API.getUnfinishedOrder();
    }).then(function(e) {
        if (30005 !== e.errorCode) return e;
        if (!(0, _lodashGet2.default)(e, "values.info")) return Promise.reject();
        var r = e.values.info;
        return -1 < [ 40, 50 ].indexOf(r.orderStatus) ? ofoPay(r.orderno, r.packet.packetid, {
            res: e
        }) : ((r.t < r.repairTime || -1 < [ 10, 11, 12 ].indexOf(r.orderStatus)) && (t || goBikePage(r, r.carno, "btUnfinish")), 
        e);
    }).catch(function(e) {
        return console.warn("err", e), Promise.reject(e);
    });
}

function getPlate(e) {
    var r = e.replace(/\s+/g, "");
    return (r = r.match(/ofo\.so\/plate\/(\w+)/)) && 0 < r.length ? r.pop() : null;
}

function unlockCar(i, a) {
    return _index2.default.showLoading({
        title: "loading"
    }), -5 === _index4.default.OFO_SOURCE && _index2.default.postMessage && _index2.default.postMessage({
        txt: i,
        type: "ofo"
    }), (0, _location.getGeo)().then(function(e) {
        return API.unlock(_extends({
            carno: i
        }, e));
    }).then(function(e) {
        var r = e.errorCode, t = e.msg, n = e.values, o = void 0 === n ? "" : n;
        if (200 != r) return 30005 == r ? goMapPage() : 30004 == r ? a.setState({
            unlockCarAlert: {
                isShow: !0,
                type: "carnoError"
            }
        }) : 40014 == r ? a.setState({
            unlockCarAlert: {
                isShow: !0,
                type: "repairError"
            }
        }) : o && "1" === o.modalType ? a.setState({
            unlockCarAlert: {
                isShow: !0,
                type: "commonError",
                data: {
                    title: o.title,
                    content: o.content,
                    bannerImg: o.bannerImg || "https://ofo-static.oss-cn-qingdao.aliyuncs.com/_static/temp/recharge-banner.png",
                    primaryBtn: {
                        text: o.primaryBtn.text || "确认",
                        action: o.primaryBtn.action || "ofoJump",
                        redirectUrl: o.primaryBtn.redirectUrl
                    },
                    secondBtn: {
                        text: o.secondBtn.text || "取消",
                        action: o.secondBtn.action || "closeConfirmModal",
                        redirectUrl: o.secondBtn.redirectUrl
                    }
                }
            }
        }) : {
            type: "toast",
            msg: t
        };
        return goBikePage(e.values.info, i, "btUnlock", a);
    }).then(function(e) {
        _index2.default.hideLoading(), e && "toast" === e.type && _index2.default.showToast({
            title: e.msg,
            icon: "none",
            duration: 2e3
        });
    }).catch(function() {
        return _index2.default.hideLoading();
    });
}

function getUserAuth() {
    return "ali_mp" === _index4.default.OFO_SOURCE_STR ? new Promise(function(r, t) {
        my.getAuthCode({
            scopes: _index4.default.SCOPES_ALIPAY.COMMON_SCOPES,
            success: function(e) {
                return r(e);
            },
            fail: function(e) {
                return t(e);
            }
        });
    }) : Promise.resolve();
}
Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

exports.formatTimeToDetail = formatTimeToDetail, exports.type = type, exports.extend = extend, 
exports.ofoRedirect = ofoRedirect, exports.urlParamsObjToString = urlParamsObjToString, 
exports.isIdCardNo = isIdCardNo;

var _index = require("../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function formatTimeToDetail(e) {
    var t = !(1 < arguments.length && void 0 !== arguments[1]) || arguments[1], r = parseInt(e / 60 / 60), n = parseInt(e / 60 % 60), o = parseInt(e % 60);
    return t && 24 < r ? {
        unit: [ "天", "时", "分" ],
        time: [ parseInt(r / 24 % 24), r = parseInt(r % 24), n ]
    } : {
        unit: [ "时", "分", "秒" ],
        time: [ r, n, o ]
    };
}

var class2type = {};

function isPlainObject(e) {
    return "[object Object]" === toString.call(e) && Object.getPrototypeOf(e) === Object.prototype;
}

function innerExtend(e, t) {
    for (var r, n, o, i = t[0], a = 1, u = t.length; a < u; a++) {
        var c = t[a], f = Array.isArray(c);
        for (o in c) if (!f || c.hasOwnProperty(o)) {
            try {
                var s = i[o], p = c[o];
            } catch (e) {
                continue;
            }
            i !== p && (e && p && (isPlainObject(p) || (r = Array.isArray(p))) ? (n = r ? (r = !1, 
            s && Array.isArray(s) ? s : []) : s && isPlainObject(s) ? s : {}, i[o] = innerExtend(e, [ n, p ])) : void 0 !== p && (i[o] = p));
        }
    }
    return i;
}

function type(e) {
    return null == e ? e + "" : "object" === (void 0 === e ? "undefined" : _typeof(e)) || "function" == typeof e ? class2type[toString.call(e)] || "object" : void 0 === e ? "undefined" : _typeof(e);
}

function extend() {
    var e = arguments.length, t = !1, r = 0, n = [];
    for (!0 === arguments[0] && (t = !0, r = 1); r < e; r++) {
        var o = (o = arguments[r]) && /object|function/.test(void 0 === o ? "undefined" : _typeof(o)) ? o : {};
        n.push(o);
    }
    return 1 === n.length && n.unshift(this), innerExtend(t, n);
}

function ofoRedirect(o) {
    try {
        if (!o) return;
        try {
            o = o.replace(/\?(.*)\#\//g, function() {
                return "#/";
            }), /\?/.test(o) || (o = o.replace(/\&/, "?"));
        } catch (e) {}
        if (-1 < o.indexOf("https://") || -1 < o.indexOf("http://")) return _index2.default.getStorage({
            key: "_OFOAPP_token"
        }).then(function(e) {
            var t = e.data, r = encodeURIComponent(urlParamsObjToString(o, {
                token: t
            })), n = urlParamsObjToString("/pages/webView/webView", {
                webUrl: r
            });
            return _index2.default.navigateTo({
                url: n
            });
        }).catch(console.error);
    } catch (e) {
        console.error(e);
    }
}

function urlParamsObjToString(e, t) {
    for (var r in t) -1 == e.indexOf("?") ? e += "?" : e += "&", e += r, e += "=", e += t[r];
    return e;
}

function isIdCardNo(e) {
    return /(^\d{15}$)|(^\d{17}([0-9]|X)$)/.test(e);
}

"Boolean Number String Function Array Date RegExp Object Error".replace(/[^ ]+/g, function(e) {
    class2type["[object " + e + "]"] = e.toLowerCase();
});
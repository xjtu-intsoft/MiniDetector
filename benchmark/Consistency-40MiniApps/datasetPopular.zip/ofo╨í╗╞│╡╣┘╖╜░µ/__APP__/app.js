Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function r(e, t) {
        for (var n = 0; n < t.length; n++) {
            var r = t[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
            Object.defineProperty(e, r.key, r);
        }
    }
    return function(e, t, n) {
        return t && r(e.prototype, t), n && r(e, n), e;
    };
}(), _index = require("./npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _index3 = require("./npm/@tarojs/mobx/index.js"), _index4 = require("./store/index.js"), _index5 = _interopRequireDefault(_index4), _index6 = require("./config/index.js"), _index7 = _interopRequireDefault(_index6), _index8 = require("./constant/index.js"), _lodashGet = require("./library/lodash.get.js"), _lodashGet2 = _interopRequireDefault(_lodashGet);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

(0, _index3.setStore)(_index5.default);

var _App = function() {
    function a() {
        var e, t, n;
        _classCallCheck(this, a);
        for (var r = arguments.length, i = Array(r), o = 0; o < r; o++) i[o] = arguments[o];
        return (t = n = _possibleConstructorReturn(this, (e = a.__proto__ || Object.getPrototypeOf(a)).call.apply(e, [ this ].concat(i)))).config = {
            pages: [ "pages/map/map", "pages/unlock/index", "pages/login/index", "pages/loginRebate/index", "pages/packet/index", "pages/myCard/index", "pages/bike/index", "pages/wallet/index", "pages/webView/webView", "pages/costDetail/index", "pages/accountRules/index", "pages/rideFinish/index", "pages/purchase/purchase", "pages/auth/nameVerify/nameVerify", "pages/agreement/index" ],
            window: {
                backgroundTextStyle: "light",
                navigationBarBackgroundColor: "#fff",
                navigationBarTitleText: "ofo小黄车",
                navigationBarTextStyle: "black"
            },
            networkTimeout: {
                request: 1e4
            },
            permission: {
                "scope.userLocation": {
                    desc: "该位置信息将用于为你提供车辆骑行功能"
                }
            }
        }, n.get = _lodashGet2.default, n.location = "[]", n.globalData = {}, n.isFromScan = !1, 
        n.isToLogin = !1, n.repairStatus = {
            isRepaired: !1,
            getRepaired: function() {
                var e = this.isRepaired;
                return this.isRepaired = !1, e;
            }
        }, n.latlng = _index7.default.DEFAULT_LOCATION, n.err = function(e) {
            return console.error(e);
        }, n.getToken = function() {
            return _index2.default.getStorageSync(_index8.STORE.TOKEN);
        }, n.setToken = function(e) {
            return _index2.default.setStorageSync(_index8.STORE.TOKEN, e);
        }, n.removeToken = function() {
            return _index2.default.removeStorageSync(_index8.STORE.TOKEN);
        }, _possibleConstructorReturn(n, t);
    }
    return _inherits(a, _index.Component), _createClass(a, [ {
        key: "componentDidMount",
        value: function() {
            var e = this.$app.$router.params;
            1011 === (0, _lodashGet2.default)(e, "scene") && (0, _lodashGet2.default)(e, "query.q") && (this.isFromScan = !0, 
            this.globalData.qrCode = e.query.q);
        }
    }, {
        key: "componentDidShow",
        value: function() {}
    }, {
        key: "componentDidHide",
        value: function() {}
    }, {
        key: "componentDidCatchError",
        value: function() {}
    }, {
        key: "_createData",
        value: function() {}
    } ]), a;
}();

exports.default = _App, App(require("./npm/@tarojs/taro-weapp/index.js").default.createApp(_App)), 
_index2.default.initPxTransform({
    designWidth: 750,
    deviceRatio: {
        640: 1.17,
        750: 1,
        828: .905
    }
});
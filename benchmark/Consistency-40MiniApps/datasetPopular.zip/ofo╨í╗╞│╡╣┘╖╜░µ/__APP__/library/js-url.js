Object.defineProperty(exports, "__esModule", {
    value: !0
});

var jsUrl = function() {
    function n() {
        return new RegExp(/(.*?)\.?([^\.]*?)\.(gl|com|net|org|biz|ws|in|me|co\.uk|co|org\.uk|ltd\.uk|plc\.uk|me\.uk|edu|mil|br\.com|cn\.com|eu\.com|hu\.com|no\.com|qc\.com|sa\.com|se\.com|se\.net|us\.com|uy\.com|ac|co\.ac|gv\.ac|or\.ac|ac\.ac|af|am|as|at|ac\.at|co\.at|gv\.at|or\.at|asn\.au|com\.au|edu\.au|org\.au|net\.au|id\.au|be|ac\.be|adm\.br|adv\.br|am\.br|arq\.br|art\.br|bio\.br|cng\.br|cnt\.br|com\.br|ecn\.br|eng\.br|esp\.br|etc\.br|eti\.br|fm\.br|fot\.br|fst\.br|g12\.br|gov\.br|ind\.br|inf\.br|jor\.br|lel\.br|med\.br|mil\.br|net\.br|nom\.br|ntr\.br|odo\.br|org\.br|ppg\.br|pro\.br|psc\.br|psi\.br|rec\.br|slg\.br|tmp\.br|tur\.br|tv\.br|vet\.br|zlg\.br|br|ab\.ca|bc\.ca|mb\.ca|nb\.ca|nf\.ca|ns\.ca|nt\.ca|on\.ca|pe\.ca|qc\.ca|sk\.ca|yk\.ca|ca|cc|ac\.cn|com\.cn|edu\.cn|gov\.cn|org\.cn|bj\.cn|sh\.cn|tj\.cn|cq\.cn|he\.cn|nm\.cn|ln\.cn|jl\.cn|hl\.cn|js\.cn|zj\.cn|ah\.cn|gd\.cn|gx\.cn|hi\.cn|sc\.cn|gz\.cn|yn\.cn|xz\.cn|sn\.cn|gs\.cn|qh\.cn|nx\.cn|xj\.cn|tw\.cn|hk\.cn|mo\.cn|cn|cx|cz|de|dk|fo|com\.ec|tm\.fr|com\.fr|asso\.fr|presse\.fr|fr|gf|gs|co\.il|net\.il|ac\.il|k12\.il|gov\.il|muni\.il|ac\.in|co\.in|org\.in|ernet\.in|gov\.in|net\.in|res\.in|is|it|ac\.jp|co\.jp|go\.jp|or\.jp|ne\.jp|ac\.kr|co\.kr|go\.kr|ne\.kr|nm\.kr|or\.kr|li|lt|lu|asso\.mc|tm\.mc|com\.mm|org\.mm|net\.mm|edu\.mm|gov\.mm|ms|nl|no|nu|pl|ro|org\.ro|store\.ro|tm\.ro|firm\.ro|www\.ro|arts\.ro|rec\.ro|info\.ro|nom\.ro|nt\.ro|se|si|com\.sg|org\.sg|net\.sg|gov\.sg|sk|st|tf|ac\.th|co\.th|go\.th|mi\.th|net\.th|or\.th|tm|to|com\.tr|edu\.tr|gov\.tr|k12\.tr|net\.tr|org\.tr|com\.tw|org\.tw|net\.tw|ac\.uk|uk\.com|uk\.net|gb\.com|gb\.net|vg|sh|kz|ch|info|ua|gov|name|pro|ie|hk|com\.hk|org\.hk|net\.hk|edu\.hk|us|tk|cd|by|ad|lv|eu\.lv|bz|es|jp|cl|ag|mobi|eu|co\.nz|org\.nz|net\.nz|maori\.nz|iwi\.nz|io|la|md|sc|sg|vc|tw|travel|my|se|tv|pt|com\.pt|edu\.pt|asia|fi|com\.ve|net\.ve|fi|org\.ve|web\.ve|info\.ve|co\.ve|tel|im|gr|ru|net\.ru|org\.ru|hr|com\.hr|ly|xyz)$/);
    }
    function e(r, t) {
        var c = r.charAt(0), o = t.split(c);
        return c === r ? o : o[(r = parseInt(r.substring(1), 10)) < 0 ? o.length + r : r - 1];
    }
    function a(r, t) {
        for (var c, o, n = r.charAt(0), e = t.split("&"), a = [], m = {}, i = r.substring(1), s = 0, u = e.length; s < u; s++) if ("" !== (a = (a = e[s].match(/(.*?)=(.*)/)) || [ e[s], e[s], "" ])[1].replace(/\s/g, "")) {
            if (a[2] = (o = a[2] || "", decodeURIComponent(o.replace(/\+/g, " "))), i === a[1]) return a[2];
            (c = a[1].match(/(.*)\[([0-9]+)\]/)) ? (m[c[1]] = m[c[1]] || [], m[c[1]][c[2]] = a[2]) : m[a[1]] = a[2];
        }
        return n === r ? m : m[i];
    }
    return function(r, t) {
        var c, o = {};
        if ("tld?" === r) return n();
        if (t = t || window.location.toString(), !r) return t;
        if (r = r.toString(), c = t.match(/^mailto:([^\/].+)/)) o.protocol = "mailto", o.email = c[1]; else {
            if ((c = t.match(/(.*?)\/#\!(.*)/)) && (t = c[1] + c[2]), (c = t.match(/(.*?)#(.*)/)) && (o.hash = c[2], 
            t = c[1]), o.hash && r.match(/^#/)) return a(r, o.hash);
            if ((c = t.match(/(.*?)\?(.*)/)) && (o.query = c[2], t = c[1]), o.query && r.match(/^\?/)) return a(r, o.query);
            if ((c = t.match(/(.*?)\:?\/\/(.*)/)) && (o.protocol = c[1].toLowerCase(), t = c[2]), 
            (c = t.match(/(.*?)(\/.*)/)) && (o.path = c[2], t = c[1]), o.path = (o.path || "").replace(/^([^\/])/, "/$1"), 
            r.match(/^[\-0-9]+$/) && (r = r.replace(/^([^\/])/, "/$1")), r.match(/^\//)) return e(r, o.path.substring(1));
            if ((c = (c = e("/-1", o.path.substring(1))) && c.match(/(.*?)\.([^.]+)$/)) && (o.file = c[0], 
            o.filename = c[1], o.fileext = c[2]), (c = t.match(/(.*)\:([0-9]+)$/)) && (o.port = c[2], 
            t = c[1]), (c = t.match(/(.*?)@(.*)/)) && (o.auth = c[1], t = c[2]), o.auth && (c = o.auth.match(/(.*)\:(.*)/), 
            o.user = c ? c[1] : o.auth, o.pass = c ? c[2] : void 0), o.hostname = t.toLowerCase(), 
            "." === r.charAt(0)) return e(r, o.hostname);
            n() && (c = o.hostname.match(n())) && (o.tld = c[3], o.domain = c[2] ? c[2] + "." + c[3] : void 0, 
            o.sub = c[1] || void 0), o.port = o.port || ("https" === o.protocol ? "443" : "80"), 
            o.protocol = o.protocol || ("443" === o.port ? "https" : "http");
        }
        return r in o ? o[r] : "{}" === r ? o : void 0;
    };
}();

exports.default = jsUrl;
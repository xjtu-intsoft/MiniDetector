Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _mobx = require("../npm/mobx/lib/mobx.js"), _api = require("../services/api.js"), API = _interopRequireWildcard(_api), _lodashGet = require("../library/lodash.get.js"), _lodashGet2 = _interopRequireDefault(_lodashGet);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _interopRequireWildcard(e) {
    if (e && e.__esModule) return e;
    var r = {};
    if (null != e) for (var t in e) Object.prototype.hasOwnProperty.call(e, t) && (r[t] = e[t]);
    return r.default = e, r;
}

var walletStore = (0, _mobx.observable)({
    wallet: {
        balance: "**",
        packetnum: "**",
        monthCardEndTime: "**"
    },
    getWalletInfoAsync: function() {
        var r = this;
        API.getWallet().then(function(e) {
            200 === e.errorCode && (r.wallet = (0, _lodashGet2.default)(e, "values.info", {}));
        });
    }
});

exports.default = walletStore;
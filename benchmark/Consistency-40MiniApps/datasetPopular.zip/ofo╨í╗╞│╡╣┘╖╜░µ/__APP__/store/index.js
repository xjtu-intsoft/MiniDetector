Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _wallet = require("./wallet.js"), _wallet2 = _interopRequireDefault(_wallet);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

exports.default = {
    walletStore: _wallet2.default
};
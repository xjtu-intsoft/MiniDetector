Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(_) {
    for (var O = 1; O < arguments.length; O++) {
        var A, E = arguments[O];
        for (A in E) Object.prototype.hasOwnProperty.call(E, A) && (_[A] = E[A]);
    }
    return _;
}, PLATFORM = "WECHAT_MINIAPP_PLATFORM", MONTH_CARD = {
    qatest: "ecf26d43c2e80afb04a63bb49d0710d1",
    product: "ecf26d43c2e80afb04a63bb49d0710d1"
}, CHANNEL_MONTH_CARD = MONTH_CARD, ALI_SCOPES = {
    USER_SILENCE: "auth_base",
    CARD: "auth_ecard",
    ZHIMA: "auth_zhima",
    USER_YEAR: "auth_user_year",
    USER_ONCE: "auth_user",
    BIKE_AGRT: "bike_agrt"
}, config = {
    PLATFORM: PLATFORM,
    PLATFORM_NAME: "微信",
    PLATFORM_EN_NAME: "wx",
    PLATFORM_ICON: "https://ofo-static.oss-cn-qingdao.aliyuncs.com/t/mp/icon-wechat.png",
    PLATFORM_ENV: "wx_mp",
    UTM_NEW_MEDIUM: "wx_mini_program",
    COMMON_PROPS: {
        OFO_APP_VERSION: "5.4.6",
        OFO_SOURCE_VERSION: 11118,
        OFO_SOURCE: -5,
        OFO_DEV_VERSION: "",
        OFO_VERSION_DESC: "8.31-9.13",
        DATA_ANALYSIS_KEY: "20171219mvkrh43dqoju",
        CHANNEL_MONTH_CARD: MONTH_CARD,
        CHANNEL_NAME: "tinyapp-wechat"
    },
    SPECIFIC_PROPS: {
        OFO_MINIAPP_APPID: "",
        ALI_WEBH5_APPID: "",
        CHANNEL_SCOPES: _extends({}, ALI_SCOPES, {
            COMMON_SCOPES: [ ALI_SCOPES.USER_YEAR, ALI_SCOPES.BIKE_AGRT ]
        })
    }
};

exports.default = config;
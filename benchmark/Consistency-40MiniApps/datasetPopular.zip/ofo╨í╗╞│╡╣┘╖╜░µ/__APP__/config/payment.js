Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _extends = Object.assign || function(e) {
    for (var r = 1; r < arguments.length; r++) {
        var o, n = arguments[r];
        for (o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
    }
    return e;
};

exports.ofoAliThirdTradePay = ofoAliThirdTradePay, exports.ofoUnitedPayment = ofoUnitedPayment;

var _index = require("../npm/@tarojs/taro-weapp/index.js"), _index2 = _interopRequireDefault(_index), _api = require("../services/api.js"), _index3 = require("./index.js"), _index4 = _interopRequireDefault(_index3);

function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _defineProperty(e, r, o) {
    return r in e ? Object.defineProperty(e, r, {
        value: o,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[r] = o, e;
}

function ofoWxPay(r, o) {
    return new Promise(function(e, n) {
        _index2.default.requestPayment(_extends({}, r, {
            success: function() {
                e({
                    errorCode: 200,
                    msg: "支付成功",
                    outTradeNo: o
                });
            },
            fail: function(e) {
                console.warn("「微信支付接口」微信支付失败", e);
                var r = e.errMsg, o = "微信支付失败";
                -1 != r.indexOf("cancel") && (o = "微信支付取消"), n(o);
            }
        }));
    });
}

function ofoWxPayment(t, e) {
    console.log("微信支付");
    var r = t.payment, o = t.recharge, i = void 0 === o ? "" : o, n = t.productToken, a = void 0 === n ? "" : n, d = t.packetToken, u = void 0 === d ? "" : d;
    t.endPageData;
    return r ? _index2.default.login().then(function(e) {
        return (0, _api.getWxOpenId)({
            code: e.code
        });
    }).then(function(e) {
        var r = e.errorCode, o = (e.msg, e.values.openId);
        if (200 != r) return Promise.reject("getWxOpenid返回异常");
        var n = _extends({}, t, {
            openId: o
        });
        return i && (n = _extends({
            recharge: i
        }, n)), a && (n = _extends({
            productToken: a
        }, n)), u && (n = _extends({
            packetToken: u
        }, n)), (0, _api.getWxOrderStr)(n);
    }).then(function(e) {
        var r = e.errorCode, o = e.msg, n = e.values, t = n.info, i = void 0 === t ? {} : t, a = n.outTradeNo, d = void 0 === a ? "" : a;
        return 200 != r ? (console.log("支付失败：订单信息获取失败  ", o), Promise.reject(o)) : ofoWxPay(i, d);
    }).then(function(e) {
        return console.log("支付成功：", e), _index2.default.showToast({
            res: e,
            event_type: "view",
            event_id: "wx_tradepay_success"
        }), Promise.resolve(e);
    }).catch(function(e) {
        return console.log("支付失败：", e), _index2.default.showToast({
            error: e,
            event_type: "error",
            event_id: "wx_tradepay_fail"
        }), Promise.reject(e);
    }) : console.log("payment不能为空");
}

function ofoAliThirdTradePay(e) {
    return new Promise(function(r, o) {
        try {
            my.tradePay({
                orderStr: e,
                success: function(e) {
                    console.log("result222222: ", e), r({
                        result: e
                    });
                },
                fail: function(e) {
                    console.log("err22222222: ", e), o(e);
                }
            });
        } catch (e) {
            console.log("e: ", e), o(e);
        }
    });
}

function ofoAliPayment(e, r) {
    var n = "";
    return (0, _api.getAlipayOrderStr)(e).then(function(e) {
        console.log("#### 获取支付订单号 #######", e);
        var r = e.values && e.values.info;
        if (n = e.values && e.values.outTradeNo ? e.values.outTradeNo : "", 200 === e.errorCode && r) return ofoAliThirdTradePay(r);
        var o = e.msg || "交易失败: 创建订单异常";
        return Promise.reject(o);
    }).then(function(e) {
        console.log("#### 支付结果 #######", e);
        var r = e.result.resultCode;
        if (9e3 == r) {
            return Promise.resolve({
                status: !0,
                outTradeNo: n
            });
        }
        var o = "支付失败，请重试", o = _defineProperty({
            8000: "正在处理中",
            4000: "订单支付失败",
            6001: "支付中请勿退出",
            6002: "网络连接出错"
        }, "8000", "正在处理中")[r] || o;
        return Promise.reject(o);
    }).catch(function(e) {
        return Promise.reject("支付失败: 交易异常");
    });
}

function ofoUnitedPayment(e) {
    var r = e.payment, o = e.productToken, n = void 0 === o ? "" : o, t = e.packetToken, i = void 0 === t ? "" : t, a = e.payType, d = e.endPageData, u = {
        payment: r,
        endPageData: void 0 === d ? "" : d
    };
    return n && (u = _extends({}, u, {
        productToken: n
    })), i && (u = _extends({}, u, {
        packetToken: i
    })), u = _extends({}, e), -1 < _index4.default.PLATFORM.indexOf("ALIPAY_MINIAPP") ? ofoAliPayment(u, a) : -1 < _index4.default.PLATFORM.indexOf("WECHAT_MINIAPP") ? ofoWxPayment(u, a) : void 0;
}
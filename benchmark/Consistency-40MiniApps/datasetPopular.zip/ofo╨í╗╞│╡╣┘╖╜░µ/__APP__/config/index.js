Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _OFO_CONFIGWeapp = require("./OFO_CONFIG.weapp.js"), _OFO_CONFIGWeapp2 = _interopRequireDefault(_OFO_CONFIGWeapp);

function _interopRequireDefault(O) {
    return O && O.__esModule ? O : {
        default: O
    };
}

var ENV = "prod", OFO_SOURCE_VERSION = "11122", HOST_TEST = "https://qatest.api.ofo.com", HOST = {
    prod: {
        san: "https://san.ofo.so",
        user: "https://user.api.ofo.com",
        order: "https://order.api.ofo.com",
        base: "https://base.api.ofo.com",
        product: "https://product.api.ofo.com"
    },
    test: {
        san: HOST_TEST,
        user: HOST_TEST,
        order: HOST_TEST,
        base: HOST_TEST,
        product: HOST_TEST
    }
};

exports.default = {
    ENV: ENV,
    HOST: HOST[ENV],
    OFO_SOURCE_VERSION: OFO_SOURCE_VERSION,
    OFO_SOURCE: -5,
    OFO_SOURCE_STR: "wx_mp",
    DEFAULT_LOCATION: {
        lng: 116.31,
        lat: 39.99
    },
    SCOPES_ALIPAY: {
        USER_SILENCE: "auth_base",
        CARD: "auth_ecard",
        ZHIMA: "auth_zhima",
        USER_YEAR: "auth_user_year",
        USER_ONCE: "auth_user",
        BIKE_AGRT: "bike_agrt",
        COMMON_SCOPES: [ "auth_user_year", "bike_agrt" ]
    },
    PLATFORM: _OFO_CONFIGWeapp2.default.PLATFORM,
    PLATFORM_NAME: _OFO_CONFIGWeapp2.default.PLATFORM_NAME,
    PLATFORM_EN_NAME: _OFO_CONFIGWeapp2.default.PLATFORM_EN_NAME,
    PLATFORM_ICON: _OFO_CONFIGWeapp2.default.PLATFORM_ICON
};
Object.defineProperty(exports, "__esModule", {
    value: !0
});

var STORE = exports.STORE = {
    TOKEN: "_OFOAPP_token",
    REFRESH_TOKEN: "_OFOAPP_User.RefreshToken",
    GEO_INFO: "Trip.GeoInfo",
    PRICE_INFO: "Price.PriceInfo"
}, URL = exports.URL = {
    BLUEBAR_DEFAULT: "/pages/webView/webView?webUrl=https%3A%2F%2Fcommon.ofo.so%2Fcampaign%2Fdefault%2F%3Fimg%3Dhttps%3A%2F%2Fimg.ofo.so%2Fcms%2F2a0dc32d5341c580dc86ea2bc97a77f0.jpg%26title%3D%25E6%259C%25AA%25E6%25BB%25A112%25E5%2591%25A8%25E5%25B2%2581%25E4%25B8%25A5%25E7%25A6%2581%25E4%25B8%258A%25E8%25B7%25AF%26trackId%3Dmp_default_bluebar"
};
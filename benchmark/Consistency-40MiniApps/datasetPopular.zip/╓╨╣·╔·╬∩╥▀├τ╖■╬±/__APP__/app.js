var e = require("@babel/runtime/helpers/interopRequireDefault")(require("@babel/runtime/helpers/defineProperty"));

function n(e, n) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        n && (o = o.filter(function(n) {
            return Object.getOwnPropertyDescriptor(e, n).enumerable;
        })), t.push.apply(t, o);
    }
    return t;
}

var t = require("utils/util.js"), o = require("utils/qqmap-wx-jssdk.min.js");

App({
    util: t,
    config: {
        gateway: "https://xiaoqi.cnbg.com.cn/trace/api",
        terminalType: 1,
        token: "",
        openId: "",
        nickName: "",
        firstBook: !1,
        key: "JRXBZ-DMX6P-4KFDP-VGZGK-DRVZT-6NFE7"
    },
    RegExp: {
        password: /^(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9]).{8,30}/,
        idNumber: /^[1-9]\d{5}(18|19|([23]\d))\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\d{3}[0-9Xx]$/,
        mobile: /^[1]([3-9])[0-9]{9}$/,
        email: /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/
    },
    user: {
        nickName: "",
        avatarUrl: "",
        country: "",
        province: "",
        city: ""
    },
    authorize: {
        "scope.userInfo": !1,
        "scope.userLocation": !1
    },
    onLaunch: function() {
        this.cleanDate();
    },
    onShow: function() {
        this.wxLogin(), this.wxUpdateManager();
    },
    wxUpdateManager: function() {
        return new Promise(function(e, n) {
            if (wx.canIUse("getUpdateManager")) {
                var t = wx.getUpdateManager();
                t.onCheckForUpdate(function(o) {
                    o.hasUpdate ? (console.log("小程序有新版本，需要更新", o), t.onUpdateReady(function() {
                        t.applyUpdate(), e();
                    }), t.onUpdateFailed(function() {
                        wx.showModal({
                            title: "小程序已经发布新版本",
                            content: "请您删除当前小程序，到微信 “发现-小程序” 页，重新搜索打开"
                        }), n();
                    })) : (console.log("当前已经是新版本", o), e());
                });
            } else console.log("当前微信版本过低，请升级到最新微信版本"), wx.showModal({
                title: "溫馨提示",
                content: "当前微信版本过低，请升级到最新微信版本"
            }), n();
        });
    },
    cleanDate: function() {
        wx.clearStorage();
    },
    wxLogin: function() {
        var o = this;
        wx.login({
            success: function(i) {
                i.code ? t.post({
                    url: "/wx/login",
                    loadingTitle: "加载中...",
                    data: {
                        code: i.code
                    },
                    success: function(t) {
                        console.log("微信登录成功", t), o.config = function(t) {
                            for (var o = 1; o < arguments.length; o++) {
                                var i = null != arguments[o] ? arguments[o] : {};
                                o % 2 ? n(Object(i), !0).forEach(function(n) {
                                    (0, e.default)(t, n, i[n]);
                                }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : n(Object(i)).forEach(function(e) {
                                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(i, e));
                                });
                            }
                            return t;
                        }({}, o.config, {}, t), o.config.firstBook = 0 == t.secLogon, console.log("微信登录成功,设置完2次登录", o.config), 
                        wx.setStorageSync("config", o.config), o.getUserInfo();
                    },
                    fail: function(e) {
                        t.alert("登录失败！");
                    }
                }) : (t.hideLoading(), t.alert("登录失败！"));
            },
            fail: function(e) {
                t.hideLoading(), t.alert("登录失败！");
            }
        });
    },
    getUserInfo: function() {
        this.wxGetUserInfo().then(function() {}).catch(function(e) {});
    },
    wxGetSetting: function() {
        return new Promise(function(e, n) {
            wx.getSetting({
                success: function(n) {
                    e(n);
                },
                fail: function(e) {
                    n(e);
                }
            });
        });
    },
    wxAuthorize: function(e) {
        return new Promise(function(n, t) {
            wx.authorize({
                scope: e,
                success: function(e) {
                    n(e);
                },
                fail: function(e) {
                    t(e);
                }
            });
        });
    },
    wxOpenSetting: function() {
        return new Promise(function(e, n) {
            wx.openSetting({
                success: function(n) {
                    e(n);
                },
                fail: function(e) {
                    n(e);
                }
            });
        });
    },
    wxGetLocation: function() {
        return new Promise(function(e, n) {
            wx.getLocation({
                type: "gcj02",
                success: function(n) {
                    e(n);
                },
                fail: function(e) {
                    n(e);
                }
            });
        });
    },
    reverseGeocoder: function(e, n) {
        var t = new o({
            key: this.config.key
        });
        return new Promise(function(o, i) {
            t.reverseGeocoder({
                location: {
                    longitude: e,
                    latitude: n
                },
                success: function(e) {
                    o(e);
                },
                fail: function(e) {
                    i(e);
                }
            });
        });
    },
    geocoder: function(e, n) {
        var t = new o({
            key: this.config.key
        });
        return new Promise(function(o, i) {
            t.geocoder({
                address: e,
                region: n,
                success: function(e) {
                    o(e);
                },
                fail: function(e) {
                    i(e);
                }
            });
        });
    },
    wxGetUserInfo: function() {
        var e = this;
        return new Promise(function(n, t) {
            wx.getUserInfo({
                lang: "zh_CN",
                success: function(t) {
                    var o = t.userInfo;
                    o.openId = e.config.openId, e.user.nickName = o.nickName, e.user.avatarUrl = o.avatarUrl, 
                    e.user.country = o.country, e.user.province = o.province, e.user.city = o.city, 
                    wx.setStorageSync("userInfo", o), e.reportUserInfo(o), n(t);
                },
                fail: function(e) {
                    t(e);
                }
            });
        });
    },
    reportUserInfo: function(e) {
        return new Promise(function(n, o) {
            t.post({
                url: "/wx/user/report",
                data: e,
                loadingTitle: "加载中...",
                success: function(e) {
                    n(e);
                },
                fail: function(e) {
                    o(e);
                }
            });
        });
    }
});
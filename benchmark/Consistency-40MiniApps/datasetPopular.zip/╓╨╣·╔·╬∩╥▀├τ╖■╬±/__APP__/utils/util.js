function t(t) {
    var r = getApp().config, a = {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        "Terminal-Type": r.terminalType,
        Token: r.token
    };
    "/vaccination/pointInfo/pointList" != t.url && "vaccination/pointInfo/searchList" != t.url && "vaccination/pointInfo/vaccinePointInfo" != t.url && "/vaccination/pointInfo/vaccineList" != t.url && "/vaccination/pointInfo/confirm" != t.url && "/point/register/login" != t.url && "/point/register/register" != t.url && "/point/register/resetPassword" != t.url && "/point/register/modifyPassword" != t.url && "/vaccination/pointInfo/findPointList" != t.url && "/accination/pointInfo/cancelReservation" != t.url && "/evaluation/save" != t.url && 2 != t.TerminalType || (a["Terminal-Type"] = 2, 
    "/vaccination/pointInfo/confirm" != t.url && "/family/addFamily" != t.url && "/family/updateFamily" != t.url && "/point/register/register" != t.url && "/point/register/modifyPassword" != t.url && "/evaluation/save" != t.url && "/point/register/resetPassword" != t.url || (a["Content-Type"] = "application/json"));
    var s = r.gateway + t.url, l = t.data || {}, u = !0;
    0 == t.showLoading ? u = !1 : t.showLoading, u && e(t.loadingTitle);
    var c = t.formData;
    return c || (c = {}), wx.request({
        url: s,
        data: l,
        method: t.httpMethod,
        header: a,
        success: function(o) {
            !function(t, o) {
                console.log("请求结果success", JSON.parse(JSON.stringify(t)), o);
                var e = t.success, r = t.fail, a = o.errMsg, s = o.statusCode + "";
                if ("200" == s) {
                    var l = o.data, u = l.status, c = l.errorCode, f = l.errorMsg, g = l.data;
                    return "0" == u ? (console.log("statusCode=200，status=0时的报错信息：", f), t.showLoading && i(), 
                    "808" == c ? (n("无效的token"), r && r(c, f), void wx.switchTab({
                        url: "/pages/home/home/home"
                    })) : r ? void r(c, f) : void n(f)) : void (e && e(g));
                }
                "404" == s ? (console.log("statusCode=404时的报错信息：", a), t.showLoading && i(), n("服务不可用")) : "400" == s ? (console.log("statusCode=400时的报错信息：", a), 
                t.showLoading && i(), n("服务不可用")) : (console.log("statusCode=其他值时的报错信息：", a), n("服务不可用"));
            }(t, o);
        },
        fail: function(e) {
            !function(t, e) {
                console.log("请求结果fail", JSON.parse(JSON.stringify(t)), e);
                var r = t.fail, a = e.errMsg, s = e.errorCode;
                a && "request:fail timeout" == a && (a = "连接超时");
                o(a, "request:fail") && (a = "服务不可用");
                n(a), t.showLoading && i();
                console.log("fail", r), r && r(s, a);
            }(t, e);
        },
        complete: function(o) {
            !function(t, o) {
                t.complete;
                var n = !0;
                0 == t.autoHideLoading && (n = !1);
                n && i();
                t.complete && t.complete();
            }(t);
        }
    });
}

function o(t, o) {
    return null != t && "" != t && 0 != t.length && (null != o && "" != o && 0 != o.length && (!(o.length > t.length) && t.substr(0, o.length) == o));
}

function n(t, o) {
    wx.showModal({
        title: "",
        content: String(t),
        showCancel: !1,
        success: function(t) {
            t.confirm && o && o();
        }
    });
}

function e(t) {
    var o = t || "系统请求中...";
    wx.showLoading({
        title: o,
        mask: !0
    });
}

function i() {
    wx.hideLoading();
}

module.exports = {
    startWith: o,
    fixedLengthWithSpaceFormat: function(t, o) {
        for (var n = "", e = t.length / o, i = 0; i < e; i++) n += t.slice(o * i, o * (i + 1)) + " ";
        return n = n.substring(0, n.length - 1);
    },
    alert: n,
    loading: e,
    hideLoading: i,
    formatDate: function(t) {
        var o = t.getFullYear(), n = t.getMonth() + 1;
        n = n < 10 ? "0" + n : n;
        var e = t.getDate();
        return o + "-" + n + "-" + (e = e < 10 ? "0" + e : e);
    },
    get: function(o) {
        return o.httpMethod = "GET", t(o);
    },
    post: function(o) {
        return o.httpMethod = "POST", t(o);
    },
    debounce: function(t, o) {
        var n;
        return function() {
            var e = this, i = arguments;
            n && clearTimeout(n), n = setTimeout(function() {
                t.apply(e, i);
            }, o);
        };
    }
};
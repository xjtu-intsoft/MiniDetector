module.exports = {
    isValidPhone: function(t) {
        return !!/^[1]([3-9])[0-9]{9}$/.test(t);
    },
    isValidCard: function(t) {
        if (!/^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/.test(t)) return !1;
        if (18 == t.length) {
            for (var r = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2), n = new Array(1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2), i = 0, e = 0; e < 17; e++) i += t.substring(e, e + 1) * r[e];
            var d = i % 11, s = t.substring(17);
            return 2 == d ? "X" == s || "x" == s : s == n[d];
        }
    },
    isValidMail: function(t) {
        return console.log(t), /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/.test(t);
    },
    isValidAccountOrPwd: function(t) {
        return /^[a-zA-Z0-9_-]{4,16}$/.test(t);
    },
    isValidNumber: function(t) {
        return /^[0-9]*$/.test(t);
    }
};
var e = getApp();

Page({
    data: {
        showType: -1,
        list: []
    },
    onLoad: function(e) {
        this.request();
    },
    request: function() {
        var t = this, s = {};
        e.util.post({
            url: "/vaccine/product/inquirable/vaccine/list",
            loadingTitle: "加载中...",
            success: function(e) {
                var n = e.list;
                n && n.length > 0 ? (t.process(n), s.showType = 1) : s.showType = 0, s.list = n, 
                t.setData(s);
            }
        });
    },
    process: function(e) {
        for (var t in e) {
            e[t].menuOpen = 0;
        }
    },
    toggle: function(e) {
        var t = e.currentTarget.dataset.index, s = this.data, n = s.list[t], i = n.menuOpen;
        n.menuOpen = !i, this.setData(s);
    },
    onShareAppMessage: function(e) {
        console.log("分享页面", e), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    }
});
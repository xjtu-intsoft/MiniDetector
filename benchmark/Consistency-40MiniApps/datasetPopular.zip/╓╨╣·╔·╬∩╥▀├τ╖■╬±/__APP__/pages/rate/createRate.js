var t = require("../../dist/wux/index"), e = getApp();

Page({
    data: {
        banners: [ {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        }, {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        }, {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        } ],
        infos: [],
        infoPage: 1,
        typeList: [],
        localInfo: {},
        indexProvince: "全国",
        indexCity: "全国",
        isAuthorizeLocation: !1,
        visibleLandscape: !1,
        searchContent: "",
        selectedTag: [],
        selectedTagIndex: 0,
        bottomInput: "",
        cardInfo: [],
        starsService: 5,
        starsHealth: 5,
        starsWork: 5,
        starsDoctor: 5,
        content: ""
    },
    starTap: function(t) {
        console.log("starTap", t);
        var e = t.currentTarget.dataset.index, a = t.currentTarget.dataset.type;
        console.log("indexStar", e);
        for (var o = [], n = 0; n < parseInt(e) + 1; n++) o[n] = 1;
        console.log("arr", o), 0 == a && this.setData({
            starsService: o
        }), 1 == a && this.setData({
            starsHealth: o
        }), 2 == a && this.setData({
            starsWork: o
        }), 3 == a && this.setData({
            starsDoctor: o
        });
    },
    onLoad: function(t) {
        var e;
        console.log(t);
        try {
            e = JSON.parse(t.query), this.setData({
                currentMarker: e
            }), wx.setNavigationBarTitle({
                title: e.pointName
            });
        } catch (t) {}
    },
    loadType: function() {
        var t = this;
        e.util.post({
            url: "/question/getType",
            loadingTitle: "加载中...",
            success: function(e) {
                console.log("loadType success", e);
                var a = e.list;
                a.unshift({
                    id: 0,
                    questionType: "选择分类：",
                    typeDesc: "选择分类：",
                    createDate: "May 25, 2020, 12:00:00 AM"
                });
                t.setData({
                    typeList: a,
                    selectedTag: []
                });
            }
        });
    },
    loadQA: function() {
        this.data.bottomInput;
        var t = this.data.cardInfo;
        t.push({
            type: 0,
            bottomInput: "这个问题还没有相应解答"
        }), this.setData({
            cardInfo: t
        });
    },
    bindinputBottom: function(t) {
        console.log("bindinputBottom", t);
        var e = this.data.bottomInput;
        e = t.detail.value, this.setData({
            bottomInput: e
        });
    },
    searchTag: function(t) {
        console.log("searchTag", t);
        this.data.selectedTag;
        if (1 != this.data.selectedTag[t.currentTarget.dataset.id]) {
            var e = [];
            e[t.currentTarget.dataset.id] = e[t.currentTarget.dataset.id] ? 0 : 1, this.setData({
                selectedTag: e,
                selectedTagIndex: t.currentTarget.dataset.id
            });
            var a = this.data.cardInfo;
            a.push({
                type: 1,
                bottomInput: t.currentTarget.dataset.questiontype
            }), this.setData({
                cardInfo: a,
                bottomInput: ""
            }), this.loadQA();
        }
    },
    onTabItemTap: function(t) {
        console.log("切换tab", t), wx.removeStorageSync("currentCity"), wx.removeStorageSync("currentPoint");
    },
    gotoTypeList: function(t) {
        var a;
        try {
            a = t.currentTarget.dataset.type;
        } catch (t) {
            return void e.util.alert("无法显示该类型内容");
        }
        var o = {
            type: a
        };
        wx.navigateTo({
            url: "/pages/home/articleList/typeList/typeList?query=" + JSON.stringify(o)
        });
    },
    gotoMap: function() {
        wx.switchTab({
            url: "/pages/reserve/map/map"
        });
    },
    gotoCMSArticle: function(t) {
        var a, o;
        try {
            a = t.currentTarget.dataset.id, o = t.currentTarget.dataset.title;
        } catch (t) {
            return void e.util.alert("无法显示详情");
        }
        var n = {
            id: a,
            title: o
        };
        wx.navigateTo({
            url: "/pages/home/articleList/cmsarticle/cmsarticle?query=" + JSON.stringify(n)
        });
    },
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    },
    onReachBottom: function() {},
    kefuClick: function() {
        wx.navigateTo({
            url: "/pages/home/customerService/customerService"
        });
    },
    resetAuthorizeLocation: function() {
        var t = this, a = this;
        return this.setData({
            isAuthorizeLocation: !1
        }), new Promise(function(t, a) {
            e.wxGetSetting().then(function(o) {
                console.log("查看用户已授权情况", o), o.authSetting["scope.userLocation"] ? (console.log("用户已经授权获取地理位置信息"), 
                t()) : e.wxAuthorize("scope.userLocation").then(function(e) {
                    console.log("用户同意授权获取地理位置信息", e), t();
                }).catch(function(t) {
                    console.log("用户拒绝授权获取地理位置信息", t), a();
                });
            });
        }).then(function() {
            console.log("同意授权"), t.setData({
                isAuthorizeLocation: !0
            }), a.getLocation();
        }).catch(function() {
            console.log("拒绝授权"), t.setData({
                isAuthorizeLocation: !1
            });
        });
    },
    getLocation: function() {
        var t = this;
        e.wxGetLocation().then(function(e) {
            console.log("wx.getLocation获取当前坐标", e), e.longitude, e.latitude, t.setData({
                longitude: e.longitude,
                latitude: e.latitude
            }), t.reverseGeocoder(e.longitude, e.latitude);
        }).catch(function(t) {
            console.log("wx.getLocation获取当前坐标失败", t);
        });
    },
    reverseGeocoder: function(t, a) {
        var o = this;
        e.reverseGeocoder(t, a).then(function(t) {
            console.log("逆地址解析成功", t), o.setData({
                localInfo: t.result,
                indexCity: t.result.ad_info.city,
                indexProvince: t.result.ad_info.province,
                infos: [],
                banners: [],
                infoPage: 1
            }), o.loadBanner(), o.loadInfo(), wx.setStorageSync("indexCity", t.result.ad_info.city), 
            wx.setStorageSync("indexProvince", t.result.ad_info.province);
        }).catch(function(t) {
            console.log("逆地址解析失败", t), o.setData({
                localInfo: {}
            });
        });
    },
    wxOpenSetting: e.wxOpenSetting,
    onCloseLandscape: function() {
        this.setData({
            visibleLandscape: !1
        });
    },
    onChange: function(t) {
        console.log("onChange", t), this.setData({
            searchContent: t.detail.value
        });
    },
    onFocus: function(t) {
        console.log("onFocus", t);
    },
    onBlur: function(t) {
        console.log("onBlur", t);
    },
    onConfirm: function(t) {
        console.log("onConfirm", t);
    },
    onClear: function(t) {
        console.log("onClear", t), this.setData({
            searchContent: ""
        });
    },
    onCancel: function(t) {
        console.log("onCancel", t), this.setData({
            searchContent: ""
        });
    },
    gotoQArticle: function(t) {
        var a, o;
        try {
            a = t.currentTarget.dataset.id, o = t.currentTarget.dataset.title;
        } catch (t) {
            return void e.util.alert("无法显示详情");
        }
        var n = {
            id: a,
            title: o
        };
        wx.navigateTo({
            url: "/pages/home/articleList/qaarticle/qaarticle?query=" + JSON.stringify(n)
        });
    },
    send: function(e) {
        if (this.data.bottomInput) {
            console.log("send", e);
            var a = this.data.cardInfo;
            a.push({
                type: 1,
                bottomInput: this.data.bottomInput
            }), this.setData({
                cardInfo: a,
                bottomInput: ""
            }), this.loadQA();
        } else (0, t.$wuxToast)().show({
            type: "text",
            duration: 1500,
            color: "#fff",
            text: "关键词不能为空",
            success: function() {
                return console.log("关键词不能为空");
            }
        });
    },
    onChangeServie: function(t) {
        this.setData({
            starsService: t.detail.value
        }), console.log(t);
    },
    onChangeHealth: function(t) {
        this.setData({
            starsHealth: t.detail.value
        }), console.log(t);
    },
    onChangeWork: function(t) {
        this.setData({
            starsWork: t.detail.value
        }), console.log(t);
    },
    onChangeDoctor: function(t) {
        this.setData({
            starsDoctor: t.detail.value
        }), console.log(t);
    },
    submit: function() {
        var t = {};
        t.outpatientPointId = this.data.currentMarker.vaccinationPointId, t.evaluatorId = e.config.userId, 
        t.generateId = this.data.currentMarker.id, 1 != this.data.currentMarker.evaluatorStatus && 3 != this.data.currentMarker.evaluatorStatus && 4 != this.data.currentMarker.evaluatorStatus || (t.outpatientService = this.data.starsService, 
        t.sanitaryCondition = this.data.starsHealth, t.efficiency = this.data.starsWork, 
        t.physicianService = this.data.starsDoctor), 2 != this.data.currentMarker.evaluatorStatus && 3 != this.data.currentMarker.evaluatorStatus && 4 != this.data.currentMarker.evaluatorStatus || (t.evaluationContent = this.data.content), 
        e.util.post({
            url: "/evaluation/save",
            showLoading: !1,
            data: t,
            success: function(t) {
                console.log("评论成功", t), wx.navigateBack();
            },
            fail: function(t, a) {
                console.log("评论失败", t), e.util.alert("评论失败！" + a);
            }
        });
    },
    bindinputContent: function(t) {
        console.log("bindinputContent", t), this.setData({
            content: t.detail.value
        });
    }
});
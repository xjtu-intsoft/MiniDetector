var t, e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/defineProperty")), o = require("../../dist/wux/index"), n = getApp();

Page({
    data: (t = {
        banners: [ {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        }, {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        }, {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        } ],
        infos: [],
        infoPage: 1,
        typeList: [],
        localInfo: {},
        indexProvince: "全国",
        indexCity: "全国",
        isAuthorizeLocation: !1,
        visibleLandscape: !1,
        searchContent: "",
        selectedTag: [],
        selectedTagIndex: 0,
        bottomInput: "",
        cardInfo: [],
        currentMarker: {},
        rateInfo: [],
        activeKey: "1",
        msg1: {
            title: "暂无消息",
            text: ""
        }
    }, (0, e.default)(t, "infoPage", 1), (0, e.default)(t, "messageType", 1), (0, e.default)(t, "msgs", [ {
        id: 1,
        nickname: "133****7777",
        content: "啊实打实大苏打实打实大苏打实打实大苏打",
        date: "2020-05-03 18:11:22",
        rate: 3.1
    }, {
        id: 2,
        nickname: "133****7777",
        content: "啊实打实大苏打实打实大苏打实打实大苏打",
        date: "2020-05-03 18:11:22",
        rate: 1.7
    } ]), t),
    onLoad: function(t) {
        var e;
        console.log(t);
        try {
            e = JSON.parse(t.query), this.setData({
                currentMarker: e
            });
        } catch (t) {}
        this.loadRate();
    },
    onShow: function() {},
    loadRate: function() {
        var t = this, e = {
            page: t.data.infoPage,
            pageSize: 10,
            evaluatorId: n.config.userId
        };
        e.vaccinationPointId = this.data.currentMarker.id, n.util.post({
            url: "/evaluation/pageList",
            loadingTitle: "加载中...",
            data: e,
            success: function(e) {
                console.log("loadRate success", e);
                var n = e.list;
                0 == n.length && ((0, o.$wuxToast)().show({
                    type: "text",
                    duration: 1500,
                    color: "#fff",
                    text: "没有更多评价了",
                    success: function() {
                        return console.log("没有更多评价了");
                    }
                }), t.data.infoPage > 1 && t.setData({
                    infoPage: t.data.infoPage - 1
                }));
                var a = t.data.infos;
                a = a.concat(n), t.setData({
                    infos: a
                });
            }
        });
    },
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    },
    onReachBottom: function() {
        var t = this.data.infoPage;
        this.setData({
            infoPage: t + 1
        }), this.loadRate();
    },
    kefuClick: function() {
        wx.navigateTo({
            url: "/pages/home/customerService/customerService"
        });
    },
    resetAuthorizeLocation: function() {
        var t = this, e = this;
        return this.setData({
            isAuthorizeLocation: !1
        }), new Promise(function(t, e) {
            n.wxGetSetting().then(function(o) {
                console.log("查看用户已授权情况", o), o.authSetting["scope.userLocation"] ? (console.log("用户已经授权获取地理位置信息"), 
                t()) : n.wxAuthorize("scope.userLocation").then(function(e) {
                    console.log("用户同意授权获取地理位置信息", e), t();
                }).catch(function(t) {
                    console.log("用户拒绝授权获取地理位置信息", t), e();
                });
            });
        }).then(function() {
            console.log("同意授权"), t.setData({
                isAuthorizeLocation: !0
            }), e.getLocation();
        }).catch(function() {
            console.log("拒绝授权"), t.setData({
                isAuthorizeLocation: !1
            });
        });
    },
    getLocation: function() {
        var t = this;
        n.wxGetLocation().then(function(e) {
            console.log("wx.getLocation获取当前坐标", e), e.longitude, e.latitude, t.setData({
                longitude: e.longitude,
                latitude: e.latitude
            }), t.reverseGeocoder(e.longitude, e.latitude);
        }).catch(function(t) {
            console.log("wx.getLocation获取当前坐标失败", t);
        });
    },
    reverseGeocoder: function(t, e) {
        var o = this;
        n.reverseGeocoder(t, e).then(function(t) {
            console.log("逆地址解析成功", t), o.setData({
                localInfo: t.result,
                indexCity: t.result.ad_info.city,
                indexProvince: t.result.ad_info.province,
                infos: [],
                banners: [],
                infoPage: 1
            }), o.loadBanner(), o.loadInfo(), wx.setStorageSync("indexCity", t.result.ad_info.city), 
            wx.setStorageSync("indexProvince", t.result.ad_info.province);
        }).catch(function(t) {
            console.log("逆地址解析失败", t), o.setData({
                localInfo: {}
            });
        });
    },
    wxOpenSetting: n.wxOpenSetting,
    onCloseLandscape: function() {
        this.setData({
            visibleLandscape: !1
        });
    },
    onChange: function(t) {
        console.log("onChange", t), this.setData({
            searchContent: t.detail.value
        });
    },
    onFocus: function(t) {
        console.log("onFocus", t);
    },
    onBlur: function(t) {
        console.log("onBlur", t);
    },
    onConfirm: function(t) {
        console.log("onConfirm", t);
    },
    onClear: function(t) {
        console.log("onClear", t), this.setData({
            searchContent: ""
        });
    },
    onCancel: function(t) {
        console.log("onCancel", t), this.setData({
            searchContent: ""
        });
    },
    gotoQArticle: function(t) {
        var e, o;
        try {
            e = t.currentTarget.dataset.id, o = t.currentTarget.dataset.title;
        } catch (t) {
            return void n.util.alert("无法显示详情");
        }
        var a = {
            id: e,
            title: o
        };
        wx.navigateTo({
            url: "/pages/home/articleList/qaarticle/qaarticle?query=" + JSON.stringify(a)
        });
    },
    send: function(t) {
        if (this.data.bottomInput) {
            console.log("send", t);
            var e = this.data.cardInfo;
            e.push({
                type: 1,
                bottomInput: this.data.bottomInput
            }), this.setData({
                cardInfo: e,
                bottomInput: ""
            }), this.loadQA();
        } else (0, o.$wuxToast)().show({
            type: "text",
            duration: 1500,
            color: "#fff",
            text: "关键词不能为空",
            success: function() {
                return console.log("关键词不能为空");
            }
        });
    },
    gotoCreateRate: function() {
        wx.navigateTo({
            url: "/pages/rate/createRate?query=" + JSON.stringify(this.data.currentMarker)
        });
    }
});
var t = require("../../../../dist/wux/index"), e = getApp();

Page({
    data: {
        pageSize: 10,
        list: [],
        type: 0,
        detail: {},
        current: 1,
        totalPage: 0,
        loading: !1,
        indexProvince: "全国",
        indexCity: "全国"
    },
    onLoad: function(t) {
        var e;
        console.log("进入文章列表传入参数"), console.log(t);
        try {
            e = JSON.parse(t.query);
        } catch (t) {}
        var a = wx.getStorageSync("indexCity"), i = wx.getStorageSync("indexProvince");
        console.log("cmsTypeList city province", a, i), this.setData({
            type: e.type,
            indexProvince: i || "全国",
            indexCity: a || "全国"
        });
        var r = "轮播新闻";
        1 == e.type ? r = "疫苗知识" : 2 == e.type ? r = "接种知识" : 4 == e.type && (r = "活动推广"), 
        wx.setNavigationBarTitle({
            title: r
        }), this.query();
    },
    onShow: function() {},
    query: function() {
        var a = this, i = {
            page: this.data.current,
            pageSize: this.data.pageSize,
            cmsTypelist: this.data.type
        };
        this.data.indexProvince && "全国" != this.data.indexProvince && (i.provinceName = this.data.indexProvince), 
        this.data.indexCity && "全国" != this.data.indexCity && (i.cityName = this.data.indexCity), 
        e.util.post({
            url: "/point/cms/cmsPageList",
            loadingTitle: "加载中...",
            data: i,
            success: function(e) {
                var i = e.list;
                0 == i.length && ((0, t.$wuxToast)().show({
                    type: "text",
                    duration: 1500,
                    color: "#fff",
                    text: "没有更多了",
                    success: function() {
                        return console.log("没有更多了");
                    }
                }), a.data.current > 1 && a.setData({
                    current: a.data.current - 1
                }));
                var r = a.data.list;
                r = r.concat(i), a.setData({
                    list: r,
                    totalPage: e.totalPage
                });
            }
        });
    },
    handleChange: function(t) {
        var e = t.detail.type;
        "next" === e ? (this.setData({
            current: this.data.current + 1
        }), this.query()) : "prev" === e && (this.setData({
            current: this.data.current - 1
        }), this.query());
    },
    gotoCMSArticle: function(t) {
        var a, i;
        try {
            a = t.currentTarget.dataset.id, i = t.currentTarget.dataset.title;
        } catch (t) {
            return void e.util.alert("无法显示详情");
        }
        var r = {
            id: a,
            title: i
        };
        wx.navigateTo({
            url: "/pages/home/articleList/cmsarticle/cmsarticle?query=" + JSON.stringify(r)
        });
    },
    onReachBottom: function() {
        this.setData({
            current: this.data.current + 1
        }), this.query();
    }
});
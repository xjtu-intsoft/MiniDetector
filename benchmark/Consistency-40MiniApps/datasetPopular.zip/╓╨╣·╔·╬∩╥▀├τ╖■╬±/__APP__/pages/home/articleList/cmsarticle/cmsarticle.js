var t = getApp();

Page({
    data: {
        head: '  <div style="margin-top:10px;">\n\t\t<h3 style="color: #000;">支持的标签</h3>\n\t\t<blockquote>wxParse支持70%的html的标签</blockquote>\n\t\t<div style="margin-top:10px;">\n\t\t\t<span>span标签</span>\n\t\t\t<strong style="color: red;">strong标签</strong>\n\t\t</div>\n\t</div>',
        html: '\x3c!--注释: wxParse试验文本--\x3e\n\t\t\t<div style="text-align:center;margin-top:10px;">\n\t\t\t  <img src="https://weappdev.com/uploads/default/original/1X/84512e0f4591bcf0dee42c3293f826e0c24b560c.jpg" alt="wxParse-微信小程序富文本解析组件Logo">\n\t\t\t  <h1 style="color:red;">wxParse-微信小程序富文本解析组件</h1>\n\t\t\t  <h2 >支持Html及markdown转wxml可视化</h2>\n\t\t  </div>\n\t\t  <div style="margin-top:10px;">\n\t\t\t  <h3 style="color: #000;">支持video</h3>\n\t\t\t  <div style="margin-top:10px;">\n\t\t\t\t  <video src="http://wxsnsdy.tc.qq.com/105/20210/snsdyvideodownload?filekey=30280201010421301f0201690402534804102ca905ce620b1241b726bc41dcff44e00204012882540400&bizid=1023&hy=SH&fileparam=302c020101042530230204136ffd93020457e3c4ff02024ef202031e8d7f02030f42400204045a320a0201000400"></video>\n\t\t\t  </div>\n\t\t  </div>\n\t\t  \n\t  \n\t\t  <div style="margin-top:10px;">\n\t\t\t  <h3 style="color: #000;">支持的标签</h3>\n\t\t\t  <blockquote>wxParse支持70%的html的标签</blockquote>\n\t\t\t  <div style="margin-top:10px;">\n\t\t\t\t  <span>span标签</span>\n\t\t\t\t  <strong style="color: red;">strong标签</strong>\n\t\t\t  </div>\n\t\t  </div>\n\t  \n\t\t  <div style="margin-top:10px;">\n\t\t\t  <h3 style="color: #000;">支持的标签ul/li</h3>\n\t\t\t  <blockquote>带有内联的li</blockquote>\n\t\t\t  <div style="margin-top:10px;">\n\t\t\t\t  <ul>\n\t\t\t\t\t  <li style="color: red;">我是li 红色</li>\n\t\t\t\t\t  <li style="color: blue;">我是li 蓝色</li>\n\t\t\t\t\t  <li style="color: yelloe;">我是li 黄色</li>\n\t\t\t\t  </ul>\n\t\t\t  </div>\n\t\t  </div>\n\t  \n\t\t  <div style="margin-top:10px;">\n\t\t\t  <h3 style="color: #000;">支持内联样式style</h3>\n\t\t\t  <blockquote>wxParse可以渲染原html带有的style样式</blockquote>\n\t\t\t  <div style="margin-top:10px;">\n\t\t\t\t  <span>span标签</span>\n\t\t\t\t  <strong>strong标签</strong>\n\t\t\t  </div>\n\t\t  </div>\n\t  \n\t\t  <div style="margin-top:10px;">\n\t\t\t  <h3 style="color: #000;">支持class潜入</h3>\n\t\t\t  <blockquote>wxParse可以注入html带有的class属性</blockquote>\n\t\t  </div>\n\t  \n\t\t  <div style="margin-top:10px;">\n\t\t\t  <h3 style="color: #000;">支持emojis小表情</h3>\n\t\t\t  <blockquote>wxParse可以解析固定格式的小表情标签</blockquote>\n\t\t\t  <div style="margin-top:10px;">\n\t\t\t\t  <p>这里可以解析出emoji的表情[00][01][02][03][04][05][06][07][08][09]</p>\n\t\t\t  </div>\n\t\t  </div>\n\t  \n\t\t  <div style="margin-top:10px;">\n\t\t\t  <h3 style="color: #000;">支持图片自适应</h3>\n\t\t\t  <blockquote>wxParse可以动态计算图片大小并进行自适应适配</blockquote>\n\t\t\t  <div style="margin-top:10px;">\n\t\t\t\t  <img src="http://a.hiphotos.baidu.com/image/pic/item/9a504fc2d5628535959cf4cf94ef76c6a6ef63db.jpg" alt="">\n\t\t\t\t  <img src="http://e.hiphotos.baidu.com/image/pic/item/48540923dd54564e1e1ac2d7b7de9c82d0584fe4.jpg" alt="">\n\t\t\t  </div>\n\t\t  </div>\n\t  \n\t\t  <div style="margin-top:10px;">\n\t\t\t  <h3 style="color: #000;">支持图片点击预览,左右滑动预览</h3>\n\t\t\t  <blockquote>wxParse可以讲一篇文章中的几个图片一起预览</blockquote>\n\t\t\t  <div style="margin-top:10px;">\n\t\t\t\t  你可以点击上面的图片，将会进入预览视图，同时左右滑动可以切换图片预览\n\t\t\t  </div>\n\t\t  </div>\n\t  \n\t\t  <div style="margin-top:10px;">\n\t\t\t  <h3 style="color: #000;">支持多数据循环渲染</h3>\n\t\t\t  <blockquote>wxParse支持特定设置下的多数据渲染，适用于在评论、多文本分别渲染等</blockquote>\n\t\t\t  <div style="margin-top:10px; text-align:center;">\n\t\t\t\t  请继续向下看，循环渲染多条html评论\n\t\t\t  </div>\n\t\t  </div>\n\t\t  <div style="margin-top:10px;">\n\t\t\t  <h3 style="color: #000;">支持短table标签</h3>\n\t\t\t  <blockquote>wxParse目前对于table的支持比较有限</blockquote>\n\t\t\t  <div style="margin-top:10px; text-align:center;">\n\t\t\t\t  <table>\n\t\t\t<tr>\n\t\t\t\t  <th>标题1</th>\n\t\t\t\t  <th>标题2</th>\n\t\t\t\t  <th>标题3</th>\n\t\t\t\t  <th>标题4</th>\n\t\t\t\t  <th>标题5</th>\n\t\t\t  </tr>\n\t\t\t<tr>\n\t\t\t\t<td>cell1</td>\n\t\t\t\t  <td>cell2</td>\n\t\t\t\t  <td>cell3</td>\n\t\t\t\t  <td>cell4</td>\n\t\t\t\t  <td>cell5</td>\n\t\t\t  </tr>\n\t\t\t  <tr>\n\t\t\t\t<td>cell1</td>\n\t\t\t\t  <td>cell2</td>\n\t\t\t\t  <td>cell3</td>\n\t\t\t\t  <td>cell4</td>\n\t\t\t\t  <td>cell5</td>\n\t\t\t  </tr>\n\t\t  </table>\n\t\t\t  </div>\n\t\t  </div>\n\t\t  \x3c!--ap--\x3e\n\t\t  ',
        detail: {},
        query: {}
    },
    onLoad: function(n) {
        var e, l = this;
        console.log("进入CMS文章页面传入参数"), console.log(n);
        try {
            e = JSON.parse(n.query), l.setData({
                query: e
            });
        } catch (t) {}
        t.util.post({
            url: "/point/cms/cmsQuery",
            loadingTitle: "加载中...",
            data: {
                id: e.id
            },
            success: function(t) {
                console.log(t), wx.setNavigationBarTitle({
                    title: t.title
                }), l.setData({
                    detail: t
                });
            }
        });
    },
    onShow: function() {},
    onShareAppMessage: function(t) {
        console.log("分享页面", t);
        var n = this.data.detail.title || "标题", e = {
            id: this.data.query.id,
            title: n
        };
        return console.log("cmsar onShareAppMessage options ", e), {
            title: n,
            path: "/pages/home/articleList/cmsarticle/cmsarticle?query=" + JSON.stringify(e)
        };
    }
});
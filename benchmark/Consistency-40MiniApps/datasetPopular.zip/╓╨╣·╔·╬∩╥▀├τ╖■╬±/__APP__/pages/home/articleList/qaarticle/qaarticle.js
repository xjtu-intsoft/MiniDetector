var t = getApp();

Page({
    data: {
        head: "",
        html: "",
        detail: {},
        query: {}
    },
    onLoad: function(e) {
        var a, i = this;
        console.log("进入QA文章页面传入参数"), console.log(e);
        try {
            a = JSON.parse(e.query), i.setData({
                query: a
            });
        } catch (t) {}
        t.util.post({
            url: "/question/getQuestionById",
            loadingTitle: "加载中...",
            data: {
                id: a.id
            },
            success: function(t) {
                console.log(t), wx.setNavigationBarTitle({
                    title: t.questionTitle
                }), i.setData({
                    detail: t
                });
            }
        });
    },
    onShow: function() {},
    onShareAppMessage: function(t) {
        console.log("分享页面", t);
        var e = this.data.detail.title || "标题", a = {
            id: this.data.query.id,
            title: e
        };
        return console.log("cmsar onShareAppMessage options ", a), {
            title: e,
            path: "/pages/home/articleList/qaarticle/qaarticle?query=" + JSON.stringify(a)
        };
    }
});
getApp();

Page({
    data: {
        head: '  <div style="margin-top:10px;">\n\t\t<h3 style="color: #000;">支持的标签</h3>\n\t\t<blockquote>wxParse支持70%的html的标签</blockquote>\n\t\t<div style="margin-top:10px;">\n\t\t\t<span>span标签</span>\n\t\t\t<strong style="color: red;">strong标签</strong>\n\t\t</div>\n\t</div>',
        html: "",
        detail: {},
        query: {}
    },
    onLoad: function(t) {},
    onShow: function() {},
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    }
});
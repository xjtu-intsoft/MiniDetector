var t = require("../../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../../@babel/runtime/helpers/defineProperty")), i = t(require("../../../@babel/runtime/regenerator")), o = t(require("../../../@babel/runtime/helpers/asyncToGenerator")), n = require("../../../dist/wux/index"), a = getApp();

Page({
    data: {
        banners: [ {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        }, {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        }, {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        } ],
        infos: [],
        infoPage: 1,
        typeList: [],
        localInfo: {},
        indexProvince: "全国",
        indexCity: "全国",
        isAuthorizeLocation: !1,
        visibleLandscape: !1,
        popupshow: !1,
        vhot: {
            deleteFlag: 1,
            id: "28",
            vaccinationType: 2,
            vaccineId: "0",
            vaccineName: "流感"
        }
    },
    onLoad: function(t) {
        this.loadBanner(), this.loadInfo(), this.loadType();
    },
    onShow: function() {
        var t = (0, o.default)(i.default.mark(function t() {
            return i.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, this.resetAuthorizeLocation();

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    closepic: function() {
        this.setData({
            popupshow: !1
        });
    },
    loadType: function() {
        var t = this;
        a.util.post({
            url: "/point/popularVaccine/popularVaccineList",
            loadingTitle: "加载中...",
            success: function(e) {
                var i = e.list;
                t.setData({
                    typeList: i
                });
            }
        });
    },
    loadBanner: function() {
        var t = this, e = {
            page: 1,
            pageSize: 3,
            cmsTypelist: 3
        };
        this.data.indexProvince && "全国" != this.data.indexProvince && (e.provinceName = this.data.indexProvince), 
        this.data.indexCity && "全国" != this.data.indexCity && (e.cityName = this.data.indexCity), 
        a.util.post({
            url: "/point/cms/cmsPageList",
            loadingTitle: "加载中...",
            data: e,
            success: function(e) {
                var i = e.list;
                t.setData({
                    banners: i
                });
            }
        });
    },
    loadInfo: function() {
        var t, i = this, o = (t = {
            page: i.data.infoPage,
            pageSize: 3
        }, (0, e.default)(t, "pageSize", 5), (0, e.default)(t, "cmsTypelist", 4), t);
        this.data.indexProvince && "全国" != this.data.indexProvince && (o.provinceName = this.data.indexProvince), 
        this.data.indexCity && "全国" != this.data.indexCity && (o.cityName = this.data.indexCity), 
        a.util.post({
            url: "/point/cms/cmsPageList",
            loadingTitle: "加载中...",
            data: o,
            success: function(t) {
                var e = t.list;
                0 == e.length && ((0, n.$wuxToast)().show({
                    type: "text",
                    duration: 1500,
                    color: "#fff",
                    text: "没有更多活动了",
                    success: function() {
                        return console.log("没有更多活动了");
                    }
                }), i.data.infoPage > 1 && i.setData({
                    infoPage: i.data.infoPage - 1
                }));
                var o = i.data.infos;
                o = o.concat(e), i.setData({
                    infos: o
                });
            }
        });
    },
    onTabItemTap: function(t) {
        console.log("切换tab", t), wx.removeStorageSync("currentCity"), wx.removeStorageSync("currentPoint"), 
        wx.removeStorageSync("homeHot");
    },
    gotoTypeList: function(t) {
        var e;
        try {
            e = t.currentTarget.dataset.type;
        } catch (t) {
            return void a.util.alert("无法显示该类型内容");
        }
        var i = {
            type: e
        };
        wx.navigateTo({
            url: "/pages/home/articleList/typeList/typeList?query=" + JSON.stringify(i)
        });
    },
    gotoMap: function(t) {
        console.log("gotoMap", t), wx.setStorageSync("homeHot", t.currentTarget.dataset.item), 
        wx.switchTab({
            url: "/pages/reserve/map/map"
        });
    },
    gotoCMSArticle: function(t) {
        var e, i;
        try {
            e = t.currentTarget.dataset.id, i = t.currentTarget.dataset.title;
        } catch (t) {
            return void a.util.alert("无法显示详情");
        }
        var o = {
            id: e,
            title: i
        };
        wx.navigateTo({
            url: "/pages/home/articleList/cmsarticle/cmsarticle?query=" + JSON.stringify(o)
        });
    },
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    },
    onReachBottom: function() {
        var t = this.data.infoPage;
        this.setData({
            infoPage: t + 1
        }), this.loadInfo();
    },
    kefuClick: function() {
        wx.navigateTo({
            url: "/pages/home/customerService/customerService"
        });
    },
    resetAuthorizeLocation: function() {
        var t = this, e = this;
        return this.setData({
            isAuthorizeLocation: !1
        }), new Promise(function(t, e) {
            a.wxGetSetting().then(function(i) {
                console.log("查看用户已授权情况", i), i.authSetting["scope.userLocation"] ? (console.log("用户已经授权获取地理位置信息"), 
                t()) : a.wxAuthorize("scope.userLocation").then(function(e) {
                    console.log("用户同意授权获取地理位置信息", e), t();
                }).catch(function(t) {
                    console.log("用户拒绝授权获取地理位置信息", t), e();
                });
            });
        }).then(function() {
            console.log("同意授权"), t.setData({
                isAuthorizeLocation: !0,
                popupshow: !1
            }), e.getLocation();
        }).catch(function() {
            console.log("拒绝授权"), t.setData({
                isAuthorizeLocation: !1
            });
        });
    },
    getLocation: function() {
        var t = this;
        a.wxGetLocation().then(function(e) {
            console.log("wx.getLocation获取当前坐标", e), e.longitude, e.latitude, t.setData({
                longitude: e.longitude,
                latitude: e.latitude
            }), t.reverseGeocoder(e.longitude, e.latitude);
        }).catch(function(t) {
            console.log("wx.getLocation获取当前坐标失败", t);
        });
    },
    reverseGeocoder: function(t, e) {
        var i = this;
        a.reverseGeocoder(t, e).then(function(t) {
            console.log("逆地址解析成功", t), i.setData({
                localInfo: t.result,
                indexCity: t.result.ad_info.city,
                indexProvince: t.result.ad_info.province,
                infos: [],
                banners: [],
                infoPage: 1
            }), i.loadBanner(), i.loadInfo(), wx.setStorageSync("indexCity", t.result.ad_info.city), 
            wx.setStorageSync("indexProvince", t.result.ad_info.province);
        }).catch(function(t) {
            console.log("逆地址解析失败", t), i.setData({
                localInfo: {}
            });
        });
    },
    wxOpenSetting: a.wxOpenSetting,
    onCloseLandscape: function() {
        this.setData({
            visibleLandscape: !1
        });
    }
});
var t = require("../../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../../@babel/runtime/regenerator")), a = t(require("../../../@babel/runtime/helpers/asyncToGenerator")), n = require("../../../dist/wux/index"), o = getApp();

Page({
    data: {
        banners: [ {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        }, {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        }, {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        } ],
        infos: [],
        infoPage: 1,
        typeList: [],
        localInfo: {},
        indexProvince: "全国",
        indexCity: "全国",
        isAuthorizeLocation: !1,
        visibleLandscape: !1,
        searchContent: "",
        selectedTag: [],
        pageSize: 10,
        pageNum: 1,
        selectedTagIndex: 0
    },
    onLoad: function(t) {
        this.loadType(), this.loadQA();
    },
    onShow: function() {
        var t = (0, a.default)(e.default.mark(function t() {
            return e.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return t.next = 2, this.resetAuthorizeLocation();

                  case 2:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    loadType: function() {
        var t = this;
        o.util.post({
            url: "/question/getType",
            loadingTitle: "加载中...",
            success: function(e) {
                console.log("loadType success", e);
                var a = e.list;
                a.unshift({
                    id: 0,
                    questionType: "全部",
                    typeDesc: "全部",
                    createDate: "May 25, 2020, 12:00:00 AM"
                });
                var n = [];
                n[0] = 1, t.setData({
                    typeList: a,
                    selectedTag: n
                });
            }
        });
    },
    loadBanner: function() {
        var t = this, e = {
            page: 1,
            pageSize: 3,
            cmsTypelist: 3
        };
        this.data.indexProvince && "全国" != this.data.indexProvince && (e.provinceName = this.data.indexProvince), 
        this.data.indexCity && "全国" != this.data.indexCity && (e.cityName = this.data.indexCity), 
        o.util.post({
            url: "/point/cms/cmsPageList",
            loadingTitle: "加载中...",
            data: e,
            success: function(e) {
                var a = e.list;
                t.setData({
                    banners: a
                });
            }
        });
    },
    loadQA: function() {
        var t = this, e = {
            pageNo: t.data.infoPage,
            pageSize: 10
        };
        0 != this.data.selectedTagIndex && (e.type = this.data.selectedTagIndex), this.data.searchContent && (e.key = this.data.searchContent), 
        o.util.post({
            url: "/question/getQuestionPage",
            loadingTitle: "加载中...",
            data: e,
            success: function(e) {
                console.log("loadQA success", e);
                var a = e.list;
                0 == a.length && ((0, n.$wuxToast)().show({
                    type: "text",
                    duration: 1500,
                    color: "#fff",
                    text: "没有更多问答了",
                    success: function() {
                        return console.log("没有更多问答了");
                    }
                }), t.data.infoPage > 1 && t.setData({
                    infoPage: t.data.infoPage - 1
                }));
                var o = t.data.infos;
                o = o.concat(a), t.setData({
                    infos: o
                });
            }
        });
    },
    onTabItemTap: function(t) {
        console.log("切换tab", t), wx.removeStorageSync("currentCity"), wx.removeStorageSync("currentPoint");
    },
    gotoTypeList: function(t) {
        var e;
        try {
            e = t.currentTarget.dataset.type;
        } catch (t) {
            return void o.util.alert("无法显示该类型内容");
        }
        var a = {
            type: e
        };
        wx.navigateTo({
            url: "/pages/home/articleList/typeList/typeList?query=" + JSON.stringify(a)
        });
    },
    gotoMap: function() {
        wx.switchTab({
            url: "/pages/reserve/map/map"
        });
    },
    gotoQArticle: function(t) {
        var e, a;
        try {
            e = t.currentTarget.dataset.id, a = t.currentTarget.dataset.title;
        } catch (t) {
            return void o.util.alert("无法显示详情");
        }
        var n = {
            id: e,
            title: a
        };
        wx.navigateTo({
            url: "/pages/home/articleList/qaarticle/qaarticle?query=" + JSON.stringify(n)
        });
    },
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    },
    onReachBottom: function() {
        var t = this.data.infoPage;
        this.setData({
            infoPage: t + 1
        }), this.loadQA();
    },
    kefuClick: function() {
        wx.navigateTo({
            url: "/pages/home/customerService/customerService"
        });
    },
    resetAuthorizeLocation: function() {
        var t = this, e = this;
        return this.setData({
            isAuthorizeLocation: !1
        }), new Promise(function(t, e) {
            o.wxGetSetting().then(function(a) {
                console.log("查看用户已授权情况", a), a.authSetting["scope.userLocation"] ? (console.log("用户已经授权获取地理位置信息"), 
                t()) : o.wxAuthorize("scope.userLocation").then(function(e) {
                    console.log("用户同意授权获取地理位置信息", e), t();
                }).catch(function(t) {
                    console.log("用户拒绝授权获取地理位置信息", t), e();
                });
            });
        }).then(function() {
            console.log("同意授权"), t.setData({
                isAuthorizeLocation: !0
            }), e.getLocation();
        }).catch(function() {
            console.log("拒绝授权"), t.setData({
                isAuthorizeLocation: !1
            });
        });
    },
    getLocation: function() {
        var t = this;
        o.wxGetLocation().then(function(e) {
            console.log("wx.getLocation获取当前坐标", e), e.longitude, e.latitude, t.setData({
                longitude: e.longitude,
                latitude: e.latitude
            });
        }).catch(function(t) {
            console.log("wx.getLocation获取当前坐标失败", t);
        });
    },
    wxOpenSetting: o.wxOpenSetting,
    onCloseLandscape: function() {
        this.setData({
            visibleLandscape: !1
        });
    },
    onChange: function(t) {
        console.log("onChange", t), this.setData({
            searchContent: t.detail.value
        });
    },
    onFocus: function(t) {
        console.log("onFocus", t);
    },
    onBlur: function(t) {
        console.log("onBlur", t);
    },
    onConfirm: function(t) {
        console.log("onConfirm", t), this.setData({
            infos: [],
            infoPage: 1
        }), this.loadQA();
    },
    onClear: function(t) {
        console.log("onClear", t), this.setData({
            searchContent: ""
        });
    },
    onCancel: function(t) {
        console.log("onCancel", t), this.setData({
            searchContent: ""
        });
    },
    searchTag: function(t) {
        console.log("searchTag", t);
        var e = this.data.selectedTag;
        if (0 == t.currentTarget.dataset.id) {
            if (e[0]) return;
            var a = [];
            a[0] = 1, this.setData({
                infoPage: 1,
                selectedTag: a,
                selectedTagIndex: 0
            });
        } else {
            if (1 == this.data.selectedTag[t.currentTarget.dataset.id]) return;
            var n = [];
            n[t.currentTarget.dataset.id] = n[t.currentTarget.dataset.id] ? 0 : 1, this.setData({
                infoPage: 1,
                selectedTag: n,
                selectedTagIndex: t.currentTarget.dataset.id
            });
        }
        this.setData({
            infos: []
        }), this.loadQA();
    },
    gotoQA: function() {
        wx.navigateTo({
            url: "/pages/home/home/qa"
        });
    },
    gotoFreeCall: function() {
        wx.navigateTo({
            url: "/pages/home/customerService/customerService"
        });
    }
});
var t = require("../../../dist/wux/index"), e = getApp();

Page({
    data: {
        banners: [ {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        }, {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        }, {
            picUrl: "//xiaoqi.cnbg.com.cn/images/lunbo2-001.png"
        } ],
        infos: [],
        infoPage: 1,
        typeList: [],
        localInfo: {},
        indexProvince: "全国",
        indexCity: "全国",
        isAuthorizeLocation: !1,
        visibleLandscape: !1,
        searchContent: "",
        selectedTag: [],
        selectedTagIndex: 0,
        bottomInput: "",
        cardInfo: []
    },
    onLoad: function(t) {
        this.loadType();
    },
    loadType: function() {
        var t = this;
        e.util.post({
            url: "/question/getType",
            loadingTitle: "加载中...",
            success: function(e) {
                console.log("loadType success", e);
                var o = e.list;
                o.unshift({
                    id: 0,
                    questionType: "选择分类：",
                    typeDesc: "选择分类：",
                    createDate: "May 25, 2020, 12:00:00 AM"
                });
                t.setData({
                    typeList: o,
                    selectedTag: []
                });
            }
        });
    },
    loadQA: function() {
        var t = this, o = {
            key: this.data.searchContent
        };
        e.util.post({
            url: "/question/getQandA",
            loadingTitle: "加载中...",
            data: o,
            success: function(e) {
                console.log("loadQA success", e);
                var o = e.list, n = t.data.cardInfo;
                if (0 == o.length) n.push({
                    type: 0,
                    bottomInput: "这个问题还没有相应解答"
                }); else {
                    var a = {
                        type: 0,
                        showCard: !0,
                        cards: []
                    };
                    a.cards = a.cards.concat(o), n.push(a);
                }
                t.setData({
                    cardInfo: n,
                    searchContent: ""
                }), wx.createSelectorQuery().select("#j_page").boundingClientRect(function(t) {
                    wx.pageScrollTo({
                        scrollTop: t.height + 99999999,
                        duration: 300
                    });
                }).exec();
            }
        });
    },
    bindinputBottom: function(t) {
        console.log("bindinputBottom", t);
        var e = this.data.bottomInput;
        e = t.detail.value, this.setData({
            bottomInput: e
        });
    },
    searchTag: function(t) {
        console.log("searchTag", t);
        this.data.selectedTag;
        if (1 != this.data.selectedTag[t.currentTarget.dataset.id]) {
            var e = [];
            e[t.currentTarget.dataset.id] = e[t.currentTarget.dataset.id] ? 0 : 1, this.setData({
                selectedTag: e,
                selectedTagIndex: t.currentTarget.dataset.id
            }), this.setData({
                bottomInput: t.currentTarget.dataset.questiontype,
                searchContent: t.currentTarget.dataset.questiontype
            }), this.send();
        }
    },
    onTabItemTap: function(t) {
        console.log("切换tab", t), wx.removeStorageSync("currentCity"), wx.removeStorageSync("currentPoint");
    },
    gotoTypeList: function(t) {
        var o;
        try {
            o = t.currentTarget.dataset.type;
        } catch (t) {
            return void e.util.alert("无法显示该类型内容");
        }
        var n = {
            type: o
        };
        wx.navigateTo({
            url: "/pages/home/articleList/typeList/typeList?query=" + JSON.stringify(n)
        });
    },
    gotoMap: function() {
        wx.switchTab({
            url: "/pages/reserve/map/map"
        });
    },
    gotoCMSArticle: function(t) {
        var o, n;
        try {
            o = t.currentTarget.dataset.id, n = t.currentTarget.dataset.title;
        } catch (t) {
            return void e.util.alert("无法显示详情");
        }
        var a = {
            id: o,
            title: n
        };
        wx.navigateTo({
            url: "/pages/home/articleList/cmsarticle/cmsarticle?query=" + JSON.stringify(a)
        });
    },
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    },
    onReachBottom: function() {},
    kefuClick: function() {
        wx.navigateTo({
            url: "/pages/home/customerService/customerService"
        });
    },
    resetAuthorizeLocation: function() {
        var t = this, o = this;
        return this.setData({
            isAuthorizeLocation: !1
        }), new Promise(function(t, o) {
            e.wxGetSetting().then(function(n) {
                console.log("查看用户已授权情况", n), n.authSetting["scope.userLocation"] ? (console.log("用户已经授权获取地理位置信息"), 
                t()) : e.wxAuthorize("scope.userLocation").then(function(e) {
                    console.log("用户同意授权获取地理位置信息", e), t();
                }).catch(function(t) {
                    console.log("用户拒绝授权获取地理位置信息", t), o();
                });
            });
        }).then(function() {
            console.log("同意授权"), t.setData({
                isAuthorizeLocation: !0
            }), o.getLocation();
        }).catch(function() {
            console.log("拒绝授权"), t.setData({
                isAuthorizeLocation: !1
            });
        });
    },
    getLocation: function() {
        var t = this;
        e.wxGetLocation().then(function(e) {
            console.log("wx.getLocation获取当前坐标", e), e.longitude, e.latitude, t.setData({
                longitude: e.longitude,
                latitude: e.latitude
            }), t.reverseGeocoder(e.longitude, e.latitude);
        }).catch(function(t) {
            console.log("wx.getLocation获取当前坐标失败", t);
        });
    },
    reverseGeocoder: function(t, o) {
        var n = this;
        e.reverseGeocoder(t, o).then(function(t) {
            console.log("逆地址解析成功", t), n.setData({
                localInfo: t.result,
                indexCity: t.result.ad_info.city,
                indexProvince: t.result.ad_info.province,
                infos: [],
                banners: [],
                infoPage: 1
            }), n.loadBanner(), n.loadInfo(), wx.setStorageSync("indexCity", t.result.ad_info.city), 
            wx.setStorageSync("indexProvince", t.result.ad_info.province);
        }).catch(function(t) {
            console.log("逆地址解析失败", t), n.setData({
                localInfo: {}
            });
        });
    },
    wxOpenSetting: e.wxOpenSetting,
    onCloseLandscape: function() {
        this.setData({
            visibleLandscape: !1
        });
    },
    onChange: function(t) {
        console.log("onChange", t), this.setData({
            searchContent: t.detail.value
        });
    },
    onFocus: function(t) {
        console.log("onFocus", t);
    },
    onBlur: function(t) {
        console.log("onBlur", t);
    },
    onConfirm: function(e) {
        if (console.log("onConfirm", e), this.data.searchContent) {
            console.log("send", e);
            var o = this.data.cardInfo;
            o.push({
                type: 1,
                bottomInput: this.data.searchContent
            }), this.setData({
                cardInfo: o
            }), this.loadQA();
        } else (0, t.$wuxToast)().show({
            type: "text",
            duration: 1500,
            color: "#fff",
            text: "关键词不能为空",
            success: function() {
                return console.log("关键词不能为空");
            }
        });
    },
    onClear: function(t) {
        console.log("onClear", t), this.setData({
            searchContent: ""
        });
    },
    onCancel: function(t) {
        console.log("onCancel", t), this.setData({
            searchContent: ""
        });
    },
    gotoQArticle: function(t) {
        var o, n;
        try {
            o = t.currentTarget.dataset.id, n = t.currentTarget.dataset.title;
        } catch (t) {
            return void e.util.alert("无法显示详情");
        }
        var a = {
            id: o,
            title: n
        };
        wx.navigateTo({
            url: "/pages/home/articleList/qaarticle/qaarticle?query=" + JSON.stringify(a)
        });
    },
    send: function(e) {
        if (this.data.bottomInput) {
            console.log("send", e);
            var o = this.data.cardInfo;
            o.push({
                type: 1,
                bottomInput: this.data.bottomInput
            }), this.setData({
                cardInfo: o
            }), this.loadQA();
        } else (0, t.$wuxToast)().show({
            type: "text",
            duration: 1500,
            color: "#fff",
            text: "关键词不能为空",
            success: function() {
                return console.log("关键词不能为空");
            }
        });
    }
});
var e, a = getApp();

Page({
    data: {
        inputCode: "",
        showClearCodeIcon: 0,
        show: 0,
        showClearIcon: 0,
        showMsg: !1,
        vaccines: {
            selectedIndex: 0,
            selectedValue: "",
            values: []
        },
        manufacturers: {
            selectedIndex: 0,
            selectedValue: "请选择",
            values: [ {
                id: 0,
                name: "请选择"
            } ]
        }
    },
    onLoad: function(e) {
        this.getVaccineList();
    },
    onTabItemTap: function(e) {
        console.log("切换tab", e), wx.removeStorageSync("currentCity"), wx.removeStorageSync("currentPoint"), 
        wx.removeStorageSync("homeHot");
    },
    getVaccineList: function() {
        var e = this;
        a.util.post({
            url: "/vaccine/product/group/list",
            loadingTitle: "加载中...",
            success: function(a) {
                e.initVaccine(a.vaccines), e.setData({
                    show: 1
                });
            }
        });
    },
    initVaccine: function(e) {
        console.log("处理疫苗清单数据", e);
        var a = this.data.vaccines;
        if (a.values.push({
            id: 0,
            name: "请选择"
        }), e && e.length > 0) for (var t in e) a.values.push({
            id: e[t].id,
            name: e[t].name,
            manufacturers: e[t].manufacturers
        });
        a.selectedValue = a.values[a.selectedIndex].name, this.data.vaccines = a, this.setData(this.data);
    },
    toVaccineInventory: function() {
        wx.navigateTo({
            url: "/pages/tip/vaccine-inventory"
        });
    },
    vaccinePickerChange: function(e) {
        console.log("选择疫苗名称", e);
        var a = this.data, t = a.vaccines, n = a.manufacturers, o = e.detail.value, s = t.values[o].manufacturers;
        for (var c in t.selectedIndex = o, t.selectedValue = t.values[o].name, n.values = [], 
        n.values.push({
            id: 0,
            name: "请选择"
        }), s) n.values.push({
            id: s[c].id,
            name: s[c].name
        });
        n.selectedIndex = 0, n.selectedValue = n.values[0].name, a.vaccines = t, a.manufacturers = n, 
        this.setData(a);
    },
    manufacturerPickerChange: function(e) {
        console.log("选择生产企业", e);
        var a = this.data, t = a.manufacturers, n = e.detail.value;
        t.selectedIndex = n, t.selectedValue = t.values[n].name, a.manufacturers = t, this.setData(a);
    },
    inputChange: function(e) {
        console.log("输入疫苗批号", e);
        var a = {}, t = e.detail.value;
        a.showClearIcon = "" == t ? 0 : 1, a.inputTxt = t, this.setData(a);
    },
    clearInputText: function() {
        console.log("清除输入疫苗批号");
        var e = {
            inputTxt: "",
            showClearIcon: 0
        };
        this.setData(e);
    },
    inputCodeChange: function(e) {
        console.log("输入药品追溯码", e);
        var a = {}, t = e.detail.value;
        a.showClearCodeIcon = "" == t ? 0 : 1, a.inputCode = t, this.setData(a);
    },
    clearInputCode: function() {
        console.log("清除输入药品追溯码");
        var e = {
            inputCode: "",
            showClearCodeIcon: 0
        };
        this.setData(e);
    },
    scanGetUserInfo: function(e) {
        var t = this;
        console.log("获取用户信息", e), a.user.nickName ? (console.log("已经获取用户信息", a.user), this.scan()) : "getUserInfo:ok" == e.detail.errMsg ? (console.log("没有获取用户信息, 同意授权", e.detail), 
        a.wxGetUserInfo().then(function(e) {
            console.log("获取用户信息", e), t.scan();
        })) : console.log("没有获取用户信息, 拒绝授权", e.detail.errMsg);
    },
    scan: function() {
        wx.scanCode({
            scanType: [ "barCode" ],
            success: function(e) {
                wx.navigateTo({
                    url: "/pages/product/scan/detail?epcCode=" + e.result + "&operation=0"
                });
            },
            fail: function(e) {
                "scanCode:fail" == e.errMsg && (a.util.alert("扫码失败"), wx.hideLoading());
            }
        });
    },
    submitGetUserInfo: function(e) {
        var t = this;
        console.log("获取用户信息", e), a.user.nickName ? (console.log("已经获取用户信息", a.user), this.submitForm()) : "getUserInfo:ok" == e.detail.errMsg ? (console.log("没有获取用户信息, 同意授权", e.detail), 
        a.wxGetUserInfo().then(function() {
            t.submitForm();
        })) : console.log("没有获取用户信息, 拒绝授权", e.detail.errMsg);
    },
    submit: function(e) {
        var a = e.detail.value;
        wx.setStorageSync("form", a);
    },
    submitForm: function() {
        var e = this.data.vaccines.selectedValue, a = wx.getStorageSync("form"), t = this.data.manufacturers.selectedValue;
        if (console.log("选中的疫苗名称", e), console.log("输入的疫苗批号和药品追溯码", a), console.log("选中的生产企业", t), 
        a.epcCode) wx.navigateTo({
            url: "/pages/product/scan/detail?epcCode=" + a.epcCode + "&operation=0"
        }); else {
            if ("请选择" == e) return this.showErrorMsg("请选择疫苗名称！"), !1;
            if ("" == a.batch) return this.showErrorMsg("请输入疫苗批号！"), !1;
            var n = "/pages/product/batchrelease/list";
            n += "?vaccineName=" + e, n += "&batch=" + a.batch, "请选择" != t && (n += "&manufacturerName=" + t), 
            wx.navigateTo({
                url: n
            });
        }
    },
    showErrorMsg: function(a) {
        var t = this;
        e && clearTimeout(e), t.setData({
            showMsg: !0,
            msg: a
        }), e = setTimeout(function() {
            t.setData({
                showMsg: !1,
                msg: ""
            });
        }, 1200);
    },
    onShareAppMessage: function(e) {
        console.log("分享页面", e), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    }
});
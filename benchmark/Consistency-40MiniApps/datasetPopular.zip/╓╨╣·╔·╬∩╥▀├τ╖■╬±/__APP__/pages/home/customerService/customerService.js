Page({
    onLoad: function(n) {},
    onUnload: function() {},
    openDebug: function() {}
});
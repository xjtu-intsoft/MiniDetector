// pages/reserve/xgmap/xgmap.js
Page({data: {}})
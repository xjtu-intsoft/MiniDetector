var t, e, a, o = require("../../../@babel/runtime/helpers/interopRequireDefault"), i = o(require("../../../@babel/runtime/helpers/toConsumableArray")), n = o(require("../../../@babel/runtime/helpers/defineProperty")), s = o(require("../../../@babel/runtime/regenerator")), l = o(require("../../../@babel/runtime/helpers/asyncToGenerator")), c = require("../../../dist/wux/index"), r = getApp(), u = (new (require("../../../utils/qqmap-wx-jssdk.min.js"))({
    key: r.config.key
}), []);

Page((t = {
    data: {
        mapLoading: !0,
        isAuthorizeLocation: !1,
        scale: 13,
        longitude: 0,
        latitude: 0,
        localInfo: {},
        isSelected: !1,
        searchText: "",
        currentMarker: {},
        markers: [],
        currentCity: "",
        currentVac: null,
        currentPoint: {
            id: "",
            name: ""
        },
        firstBook: !0,
        value1: [],
        value3: [],
        displayValue1: "全部",
        displayValue2: "全部",
        displayValue3: "全部",
        options: [ {
            value: "bj",
            label: "北京市"
        }, {
            value: "zj",
            label: "浙江省"
        }, {
            value: "gd",
            label: "广东省",
            disabled: !0
        }, {
            value: "hn",
            label: "海南省"
        }, {
            value: "cq",
            label: "重庆市"
        }, {
            value: "sc",
            label: "四川省"
        } ],
        infos: [],
        usualPoint: {
            name: "",
            id: ""
        },
        page: 1,
        pageSize: 20,
        searched: !1,
        cityList: [],
        pointList: [],
        showSelectCity: !1,
        isShowCityList: !0,
        currentIndex: 0,
        hotVac: [],
        familyList: [],
        selectedFamily: "",
        statusList: [ {
            label: "全部",
            value: "2"
        }, {
            label: "可预约",
            value: "1"
        }, {
            label: "不可预约",
            value: "0"
        } ],
        selectedStatus: "2",
        tagList: [],
        selectedTag: "",
        pointListForSecond: [],
        showSwitch: !1,
        pageList: 0,
        pageSizeList: 10,
        showCommon: !1,
        onlyCommon: !1,
        needResearch: 0
    },
    getCityList: function() {
        var t = this;
        r.util.post({
            url: "/area/list",
            loadingTitle: "加载中...",
            TerminalType: 2,
            success: function(e) {
                console.log("获取城市列表成功", e), u = e, t.setData({
                    cityList: u
                }), wx.setStorageSync("cityList", u);
            },
            fail: function(t) {
                console.log("获取城市列表失败", t);
            }
        });
    },
    onLoad: function(t) {},
    loadCommonPoint: function() {
        var t = this;
        r.util.post({
            url: "/vaccination/pointInfo/commonPointList",
            loadingTitle: "定位中...",
            data: {
                pointY: a,
                pointX: e,
                userId: r.config.userId
            },
            success: function(e) {
                console.log("loadCommonPoint", e), t.setData({
                    pointListForSecond: e.markers
                });
            },
            fail: function(t) {
                console.log("获取附近接种点列表失败", t);
            }
        });
    },
    onShow: function() {
        var t = (0, l.default)(s.default.mark(function t() {
            var e, a, o, i, n;
            return s.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return (e = wx.getStorageSync("homeHot") || null) ? (this.setData({
                        currentIndex: e.id,
                        displayValue1: e.vaccineName,
                        selectedTag: e.vaccineName,
                        needResearch: 1
                    }), this.onTagConfirm({
                        currentTarget: {
                            dataset: {
                                index: "1"
                            }
                        },
                        detail: {
                            displayValue: [ e.vaccineName ],
                            label: e.vaccineName,
                            selectedIndex: [ e.id ],
                            selectedValue: [ e.id + "" ],
                            value: [ e.id + "" ]
                        }
                    }, 1), wx.removeStorageSync("homeHot")) : this.setData({
                        currentIndex: 0,
                        displayValue1: "全部",
                        selectedTag: ""
                    }), a = wx.getStorageSync("currentVac") || null, this.setData({
                        currentVac: a
                    }), (o = wx.getStorageSync("currentCity") || "") && this.setData({
                        searched: !0,
                        currentIndex: 0,
                        displayValue1: "全部",
                        selectedTag: ""
                    }), i = wx.getStorageSync("currentPoint") || {
                        id: "",
                        name: ""
                    }, o && this.setData({
                        currentCity: o
                    }), i && this.setData({
                        currentPoint: i
                    }), n = wx.getStorageSync("usualPoint"), console.log("添加家庭成员页面onShow生命周期", n), n && this.setData({
                        usualPoint: n
                    }), this.setData({
                        pointListForSecond: [],
                        pageList: 0
                    }), (a || o || i) && this.setData({
                        onlyCommon: !1
                    }), t.next = 16, this.resetAuthorizeLocation();

                  case 16:
                    this.data.isAuthorizeLocation && !this.myMap ? (console.log("首次成功进入地图"), this.myMap = wx.createMapContext("map"), 
                    this.getLocation()) : this.searchByCityPoint(), (u = wx.getStorageSync("cityList")) && u.length > 0 ? this.setData({
                        cityList: u
                    }) : this.getCityList();

                  case 19:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function() {
            return t.apply(this, arguments);
        };
    }(),
    loadHotVac: function() {
        var t = this;
        r.util.post({
            url: "/point/popularVaccine/topPopularVaccineList",
            loadingTitle: "加载中...",
            success: function(e) {
                console.log("loadHotVac列表成功", e);
                var a = [];
                a.push({
                    label: "全部",
                    value: ""
                });
                for (var o = 0; o < e.list.length; o++) a.push({
                    label: e.list[o].vaccineName,
                    value: e.list[o].id + ""
                });
                t.setData({
                    hotVac: e.list,
                    tagList: a
                }), console.log("loadHotVac", t.data.hotVac, a);
            },
            fail: function(t) {
                console.log("loadHotVac列表失败", t);
            }
        });
    },
    onTabItemTap: function(t) {
        console.log("切换tab", t), wx.removeStorageSync("currentCity"), wx.removeStorageSync("currentPoint"), 
        wx.removeStorageSync("currentVac"), wx.removeStorageSync("homeHot"), this.setData({
            currentVac: null,
            selectedFamily: "",
            displayValue1: "全部",
            displayValue2: "全部",
            displayValue3: "全部"
        }), "pages/reserve/map/map" == t.pagePath && this.setData({
            firstBook: !0,
            showSwitch: !1
        });
    },
    resetAuthorizeLocation: function() {
        var t = this;
        return this.setData({
            mapLoading: !0,
            isAuthorizeLocation: !1
        }), new Promise(function(t, e) {
            r.wxGetSetting().then(function(a) {
                console.log("查看用户已授权情况", a), a.authSetting["scope.userLocation"] ? (console.log("用户已经授权获取地理位置信息"), 
                t()) : r.wxAuthorize("scope.userLocation").then(function(e) {
                    console.log("用户同意授权获取地理位置信息", e), t();
                }).catch(function(t) {
                    console.log("用户拒绝授权获取地理位置信息", t), e();
                });
            });
        }).then(function() {
            console.log("同意授权"), t.setData({
                mapLoading: !1,
                isAuthorizeLocation: !0
            });
        }).catch(function() {
            console.log("拒绝授权"), t.setData({
                mapLoading: !1,
                isAuthorizeLocation: !1
            });
        });
    },
    getLocation: function() {
        var t = this;
        r.wxGetLocation().then(function(o) {
            console.log("wx.getLocation获取当前坐标", o), e = o.longitude, a = o.latitude, t.setData({
                longitude: o.longitude,
                latitude: o.latitude
            }), t.getMarkers(o.longitude, o.latitude), t.reverseGeocoder(o.longitude, o.latitude);
        }).catch(function(t) {
            console.log("wx.getLocation获取当前坐标失败", t);
        });
    },
    getMarkers: function(t, o) {
        var i = this, n = {
            pointY: o,
            pointX: t,
            distancePointY: a,
            distancePointX: e
        };
        if (console.log("request", n), i.data.currentIndex && i.data.currentIndex > 0) {
            n.id = i.data.currentIndex, console.log(i.data.hotVac);
            for (var s = 0; s < i.data.hotVac.length; s++) if (i.data.hotVac[s].id == i.data.currentIndex) {
                n.vaccinationType = i.data.hotVac[s].vaccination_type;
                break;
            }
        }
        r.util.post({
            url: "/vaccination/pointInfo/pointList",
            loadingTitle: "定位中...",
            data: {
                pointY: o,
                pointX: t,
                distancePointY: a,
                distancePointX: e,
                id: null == n.id ? "" : n.id
            },
            success: function(t) {
                console.log("获取附近接种点列表成功", t), i.resetMarkers(t);
            },
            fail: function(t) {
                console.log("获取附近接种点列表失败", t);
            }
        }), this.loadHotVac(), this.getFamilyList();
    },
    reverseGeocoder: function(t, e) {
        var a = this;
        r.reverseGeocoder(t, e).then(function(t) {
            console.log("逆地址解析成功", t), a.setData({
                localInfo: t.result,
                currentCity: t.result.ad_info.city
            }), wx.setStorageSync("currentCity", t.result.ad_info.city);
        }).catch(function(t) {
            console.log("逆地址解析失败", t), a.setData({
                localInfo: {}
            });
        });
    },
    resetMarkers: function() {
        var t = (0, l.default)(s.default.mark(function t(e) {
            return s.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    console.log("重新赋值标记点列表", e), this.setData({
                        markers: e.markers || []
                    }), this.data.markers.length > 0 ? this.setData({
                        currentMarker: this.data.markers[0],
                        isSelected: !0,
                        longitude: this.data.markers[0].longitude,
                        latitude: this.data.markers[0].latitude
                    }) : this.setData({
                        currentMarker: {},
                        isSelected: !1
                    }), this.data.needResearch && (this.setData({
                        needResearch: 0
                    }), this.searchByCityPoint());

                  case 4:
                  case "end":
                    return t.stop();
                }
            }, t, this);
        }));
        return function(e) {
            return t.apply(this, arguments);
        };
    }(),
    wxOpenSetting: r.wxOpenSetting,
    goToCityPage: function(t) {
        console.log("选择城市/选择接种点：", t), console.log("选择城市/选择接种点：", t.currentTarget.dataset.type), 
        wx.setStorageSync("currentCity", this.data.currentCity), wx.navigateTo({
            url: "/pages/reserve/map/city?type=" + t.currentTarget.dataset.type
        });
    },
    goToVacPage: function(t) {
        console.log("选择疫苗产品：", t), wx.navigateTo({
            url: "/pages/reserve/map/vaccine"
        });
    },
    scalePlus: function() {
        20 != this.data.scale && this.setData({
            scale: Number(this.data.scale) + 1
        });
    },
    scaleMinus: function() {
        5 != this.data.scale && this.setData({
            scale: this.data.scale - 1
        });
    },
    searchByCityPoint: function() {
        var t = this, o = {
            pointX: e,
            pointY: a,
            searchName: t.data.currentPoint.name,
            vaccinationPointId: t.data.currentPoint.id,
            cityName: t.data.currentCity,
            pageFlag: !1,
            inoculationId: t.data.selectedFamily,
            userId: r.config.userId,
            onlyCommon: t.data.onlyCommon
        };
        if (t.data.currentVac && t.data.currentVac.id > 0 && (o.vaccineId = t.data.currentVac.id), 
        t.data.currentIndex && t.data.currentIndex > 0) {
            o.id = t.data.currentIndex, console.log(t.data.hotVac);
            for (var i = 0; i < t.data.hotVac.length; i++) if (t.data.hotVac[i].id == t.data.currentIndex) {
                o.vaccinationType = t.data.hotVac[i].vaccination_type;
                break;
            }
        }
        o.vaccinationPointStatus = 2, t.data.firstBook || (t.data.onlyCommon || (o.pageFlag = !0, 
        t.setData({
            pageList: t.data.pageList + 1,
            searched: !0
        }), o.page = t.data.pageList, o.pageSize = t.data.pageSizeList), o.vaccinationPointStatus = this.data.selectedStatus), 
        console.log("searchByCityPoint request", o), r.util.post({
            url: "/vaccination/pointInfo/searchList",
            loadingTitle: "定位中...",
            data: o,
            success: function(e) {
                if (console.log("搜索接种点列表成功", e), t.data.firstBook) t.resetMarkers(e); else if (0 == e.markers.list.length) (0, 
                c.$wuxToast)().show({
                    type: "text",
                    duration: 1500,
                    color: "#fff",
                    text: "没有更多了",
                    success: function() {
                        return console.log("没有更多门诊了");
                    }
                }), t.data.pageList > 0 && t.setData({
                    infoPage: t.data.pageList - 1
                }); else {
                    var a = t.data.pointListForSecond.concat(e.markers.list);
                    t.setData({
                        pointListForSecond: a,
                        searched: !0
                    });
                }
            },
            fail: function(t, e) {
                (0, c.$wuxToast)().show({
                    type: "text",
                    duration: 1500,
                    color: "#fff",
                    text: "查询失败",
                    success: function() {
                        return console.log("查询失败", t, e);
                    }
                });
            }
        });
    },
    cancelInput: function() {
        console.log("cancelInput"), this.setData({
            isSelected: !1,
            searchText: ""
        });
    },
    markertap: function(t) {
        console.log("选中标记点", t);
        var e = this.data.markers.map(function(e) {
            return e.callout = e.id == t.markerId ? {
                content: e.name,
                display: "ALWAYS",
                fontSize: 12,
                bgColor: "#ffffff",
                color: "#000000",
                padding: 10,
                borderRadius: 5
            } : {
                content: "",
                display: "BYCLICK"
            }, e;
        });
        this.setData({
            markers: e,
            currentMarker: this.data.markers.filter(function(e) {
                return e.id == t.markerId;
            })[0],
            isSelected: !0
        });
    },
    openLocation: function() {
        var t = this.data.currentMarker, e = t.latitude, a = t.longitude, o = t.name;
        wx.openLocation({
            latitude: e,
            longitude: a,
            name: o,
            scale: 18
        });
    },
    makePhoneCall: function() {
        wx.makePhoneCall({
            phoneNumber: this.data.currentMarker.contactNumber
        });
    },
    goToReserve: function() {
        console.log("goToReserve", this.data.selectedFamily), wx.setStorageSync("currentMarker", this.data.currentMarker), 
        wx.navigateTo({
            url: "/pages/reserve/list/list?selectedFamily=" + this.data.selectedFamily
        });
    },
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    },
    regionchange: function(t) {},
    changeLocation: function() {
        var t = this;
        this.myMap.getCenterLocation({
            success: function(e) {
                console.log("获取当前地图中心点经纬度", e), t.setData({
                    longitude: e.longitude,
                    latitude: e.latitude
                }), t.getMarkers(e.longitude, e.latitude), t.reverseGeocoder(e.longitude, e.latitude);
            }
        });
    },
    openCalendar1: function() {
        var t = this;
        (0, c.$wuxCalendar)().open({
            value: this.data.value1,
            onChange: function(e, a) {
                console.log("onChange", e, a), t.setData({
                    value1: a
                });
            }
        });
    },
    onConfirm: function(t) {
        if (r.config.userId) {
            var e = t.currentTarget.dataset.index;
            this.setValue(t.detail, e), console.log("onConfirm".concat(e), t.detail);
            t.detail.selectedValue && this.setData({
                selectedFamily: t.detail.selectedValue[0],
                pointListForSecond: [],
                pageList: 0
            }), console.log("selectedFamily", t.detail.selectedValue), console.log("selectedFamily", t.detail.selectedValue[0]), 
            this.searchByCityPoint();
        } else wx.navigateTo({
            url: "/pages/mine/account/login?&to=mapListView"
        });
    },
    onValueChange: function(t) {
        var e = t.currentTarget.dataset.index;
        console.log("onValueChange".concat(e), t.detail);
    },
    onStatusConfirm: function(t, e) {
        console.log("onStatusConfirm", t);
        var a = t.currentTarget.dataset.index;
        this.setValue(t.detail, a), console.log("onStatusConfirm".concat(a), t.detail, e);
        t.detail.selectedValue && this.setData({
            pointListForSecond: [],
            selectedStatus: t.detail.selectedValue[0],
            pageList: 0
        }), console.log("onStatusConfirm", this.data.selectedStatus), e || this.searchByCityPoint();
    },
    onStatusValueChange: function(t) {
        var e = t.currentTarget.dataset.index;
        console.log("onValueChange".concat(e), t.detail);
    },
    onTagConfirm: function(t, e) {
        console.log("onTagConfirm", t);
        var a = t.currentTarget.dataset.index;
        this.setValue(t.detail, a), console.log("onConfirm".concat(a), t.detail, e);
        t.detail.selectedValue && this.setData({
            pointListForSecond: [],
            currentIndex: t.detail.selectedValue[0] ? t.detail.selectedValue[0] : 0,
            selectedTag: t.detail.selectedValue[0],
            pageList: 0
        }), console.log("onTagConfirm", this.data.selectedTag), e || this.searchByCityPoint();
    },
    onTagValueChange: function(t) {
        var e = t.currentTarget.dataset.index;
        console.log("onValueChange".concat(e), t.detail);
    },
    setValue: function(t, e) {
        var a;
        this.setData((a = {}, (0, n.default)(a, "value".concat(e), t.value), (0, n.default)(a, "displayValue".concat(e), t.label), 
        a));
    },
    loadInfo: function() {
        var t = this;
        r.util.post({
            url: "/point/cms/cmsPageList",
            loadingTitle: "加载中...",
            data: {
                page: 1,
                pageSize: 20,
                cmsTypelist: 4
            },
            success: function(e) {
                var a = e.list, o = t.data.infos;
                o = o.concat(a), t.setData({
                    infos: o
                });
            }
        });
    },
    goToSearchPoint: function() {
        wx.navigateTo({
            url: "/pages/mine/family/searchPoint"
        });
    },
    onUnload: function() {
        wx.removeStorageSync("usualPoint");
    },
    getPointList: function() {
        var t = this;
        r.util.post({
            url: "/vaccination/pointInfo/pageList",
            loadingTitle: "加载中...",
            TerminalType: 2,
            data: {
                page: t.data.page,
                pageSize: 20,
                cityName: t.data.city
            },
            success: function(e) {
                console.log("获取接种点列表成功", e), e.list.length < t.data.pageSize && (console.log("数据小于20条，页码归零，不再拉取"), 
                t.setData({
                    page: 0
                })), t.setData({
                    isShowCityList: !1,
                    pointList: [].concat((0, i.default)(t.data.pointList), (0, i.default)(e.list))
                });
            },
            fail: function(t) {
                console.log("获取接种点列表失败", t);
            }
        });
    },
    openSelectCity: function() {
        this.setData({
            showSelectCity: !0
        });
    },
    searchCity: function(t) {
        console.log("输入框搜索城市事件", t);
        var e = t.detail.value;
        if (e != this.data.city) if (e) {
            var a = JSON.parse(JSON.stringify(u));
            a.forEach(function(t) {
                t.cityList = t.cityList.filter(function(t) {
                    if (-1 != t.cityName.indexOf(e)) return console.log("返回命中城市", t), t;
                });
            }), this.setData({
                cityList: a,
                isShowCityList: !0
            }), wx.pageScrollTo({
                scrollTop: 0,
                duration: 300
            });
        } else this.setData({
            page: 1,
            currentCity: "",
            cityList: u,
            isShowCityList: !0
        });
    },
    selectCity: function(t) {
        console.log("事件委托选中城市", t.target.dataset.city), t.target.dataset.city && (t.target.dataset.city != this.data.currentCity && this.getPointList(), 
        this.setData({
            page: 1,
            currentCity: t.target.dataset.city
        }), this.setData({
            showSelectCity: !1
        }), wx.pageScrollTo({
            scrollTop: 0,
            duration: 300
        }));
    },
    inputCancel: function() {
        console.log("取消选择常用接种点，返回"), wx.setStorageSync("usualPoint", {
            name: "",
            id: ""
        }), this.setData({
            page: 1,
            currentCity: "",
            showSelectCity: !1
        });
    }
}, (0, n.default)(t, "getPointList", function() {
    var t = this;
    r.util.post({
        url: "/vaccination/pointInfo/pageList",
        loadingTitle: "加载中...",
        TerminalType: 2,
        data: {
            page: t.data.page,
            pageSize: 20,
            cityName: t.data.city
        },
        success: function(e) {
            console.log("获取接种点列表成功", e), e.list.length < t.data.pageSize && (console.log("数据小于20条，页码归零，不再拉取"), 
            t.setData({
                page: 0
            })), t.setData({
                isShowCityList: !1,
                pointList: [].concat((0, i.default)(t.data.pointList), (0, i.default)(e.list))
            });
        },
        fail: function(t) {
            console.log("获取接种点列表失败", t);
        }
    });
}), (0, n.default)(t, "onReachBottom", function() {
    if (!this.data.onlyCommon) if (this.data.firstBook) {
        if (this.data.isShowCityList) return;
        if (0 == this.data.page) return void r.util.alert("没有更多数据了");
        this.setData({
            page: this.data.page + 1
        }), this.getPointList();
    } else this.searchByCityPoint();
}), (0, n.default)(t, "searchPoint", function(t) {
    console.log("输入框搜索接种点事件", t.detail.value);
    var e = {
        name: t.detail.value,
        id: ""
    };
    this.setData({
        page: 1,
        pointList: [],
        usualPoint: e
    }), this.getPointList(), wx.pageScrollTo({
        scrollTop: 0,
        duration: 300
    });
}), (0, n.default)(t, "selectPoint", function(t) {
    console.log("事件委托选中接种点", t.target.dataset.point);
    var e = {
        name: t.target.dataset.point.vaccinationPointName,
        id: t.target.dataset.point.vaccinationPointId
    };
    this.setData({
        usualPoint: e
    }), wx.setStorageSync("usualPoint", e), wx.navigateBack();
}), (0, n.default)(t, "searchAndMarkType", function(t) {
    console.log("searchAndMarkType", t), t.currentTarget.dataset.index == this.data.currentIndex ? (this.setData({
        currentIndex: 0,
        displayValue1: "全部",
        selectedTag: ""
    }), this.onTagConfirm({
        currentTarget: {
            dataset: {
                index: "1"
            }
        },
        detail: {
            displayValue: [ "全部" ],
            label: "全部",
            selectedIndex: [ 0 ],
            selectedValue: [ "0" ],
            value: [ "0" ]
        }
    }, 1)) : (this.setData({
        currentIndex: t.currentTarget.dataset.index
    }), this.onTagConfirm({
        currentTarget: {
            dataset: {
                index: "1"
            }
        },
        detail: {
            displayValue: [ t.currentTarget.dataset.name ],
            label: t.currentTarget.dataset.name,
            selectedIndex: [ t.currentTarget.dataset.index ],
            selectedValue: [ t.currentTarget.dataset.index + "" ],
            value: [ t.currentTarget.dataset.index + "" ]
        }
    }, 1)), console.log("searchAndMarkType", this.data.selectedTag), this.searchByCityPoint();
}), (0, n.default)(t, "switchToList", function() {
    this.setData({
        firstBook: !this.data.firstBook,
        pageList: 0,
        onlyCommon: !1
    }), this.data.firstBook || this.setData({
        pointListForSecond: []
    }), this.searchByCityPoint();
}), (0, n.default)(t, "getFamilyList", function() {
    var t = this;
    this.setData({
        loading: !0
    }), r.util.post({
        url: "/family/familyList",
        loadingTitle: "加载中...",
        TerminalType: 2,
        data: {
            userId: r.config.userId
        },
        success: function(e) {
            console.log("获取家庭成员列表成功", e);
            var a = [];
            e.map(function(t, e, o) {
                a.push({
                    label: t.name,
                    value: t.familyId
                });
            }), a.unshift({
                label: "全部",
                value: ""
            }), console.log("data2", a), t.setData({
                loading: !1,
                familyList: a
            });
        },
        fail: function(e) {
            console.log("获取家庭成员列表失败", e), t.setData({
                loading: !1
            });
        }
    });
}), (0, n.default)(t, "loadSecLogin", function() {
    var t = this;
    r.util.post({
        url: "/wx/user/secLogonInfo",
        loadingTitle: "加载中...",
        data: {
            userId: r.config.userId
        },
        success: function(e) {
            console.log("loadSecLogin res", e), t.setData({
                firstBook: 1 != e.secLogon,
                showCommon: !0,
                onlyCommon: 1 == e.secLogon,
                showSwitch: 1 == e.secLogon
            });
        },
        fail: function(t) {
            console.log("loadSecLogin error", t);
        }
    });
}), (0, n.default)(t, "gotoRateDetail", function() {
    wx.navigateTo({
        url: "/pages/rate/rateDetail?query=" + JSON.stringify(this.data.currentMarker)
    });
}), t));
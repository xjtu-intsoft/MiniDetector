var t = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/toConsumableArray")), i = getApp(), e = [];

Page({
    data: {
        type: "point",
        city: "",
        cityList: [],
        pointList: [],
        currentPoint: {
            name: "",
            id: ""
        },
        isShowCityList: !0,
        page: 1,
        pageSize: 20,
        toViewId: ""
    },
    onLoad: function(t) {
        this.setData({
            type: t.type
        }), (e = wx.getStorageSync("cityList")) && e.length > 0 ? this.setData({
            cityList: e
        }) : this.getCityList();
        var i = wx.getStorageSync("currentCity") || "";
        this.setData({
            city: i
        }), "point" == this.data.type && i && this.getPointList();
    },
    getCityList: function() {
        var t = this;
        i.util.post({
            url: "/area/list",
            loadingTitle: "加载中...",
            TerminalType: 2,
            success: function(i) {
                console.log("获取城市列表成功", i), e = i, t.setData({
                    cityList: e
                }), wx.setStorageSync("cityList", e);
            },
            fail: function(t) {
                console.log("获取城市列表失败", t);
            }
        });
    },
    searchCity: function(t) {
        console.log("输入框搜索城市事件", t);
        var i = t.detail.value;
        if (!i) return console.log("如果没有输入城市或清空城市"), void this.setData({
            page: 1,
            city: "",
            cityList: e,
            isShowCityList: !0
        });
        var a = JSON.parse(JSON.stringify(e));
        a.forEach(function(t) {
            t.cityList = t.cityList.filter(function(t) {
                if (-1 != t.cityName.indexOf(i)) return console.log("返回命中城市", t), t;
            });
        }), this.setData({
            cityList: a,
            isShowCityList: !0
        }), wx.pageScrollTo({
            scrollTop: 0,
            duration: 300
        });
    },
    selectSort: function(t) {
        console.log("事件委托选中城市锚点", t.target.dataset.viewid);
        var i = "viewId-" + t.target.dataset.viewid;
        this.setData({
            toViewId: i
        });
    },
    selectCity: function(t) {
        if (console.log("事件委托选中城市", t.target.dataset.city), t.target.dataset.city) {
            if ("city" == this.data.type) return wx.setStorageSync("currentCity", t.target.dataset.city), 
            wx.removeStorageSync("currentPoint"), void wx.navigateBack();
            this.setData({
                page: 1,
                city: t.target.dataset.city,
                pointList: [],
                currentPoint: {
                    name: "",
                    id: ""
                }
            }), this.getPointList(), wx.pageScrollTo({
                scrollTop: 0,
                duration: 300
            });
        }
    },
    getPointList: function() {
        var e = this;
        i.util.post({
            url: "/vaccination/pointInfo/pageList",
            loadingTitle: "加载中...",
            TerminalType: 2,
            data: {
                page: e.data.page,
                pageSize: 20,
                name: e.data.currentPoint.name,
                cityName: e.data.city
            },
            success: function(i) {
                console.log("获取接种点列表成功", i), i.list.length < e.data.pageSize && (console.log("数据小于20条，页码归零，不再拉取"), 
                e.setData({
                    page: 0
                })), e.setData({
                    isShowCityList: !1,
                    pointList: [].concat((0, t.default)(e.data.pointList), (0, t.default)(i.list))
                });
            },
            fail: function(t) {
                console.log("获取接种点列表失败", t);
            }
        });
    },
    onReachBottom: function() {
        this.data.isShowCityList || (0 != this.data.page ? (this.setData({
            page: this.data.page + 1
        }), this.getPointList()) : i.util.alert("没有更多数据了"));
    },
    searchPoint: function(t) {
        if (this.data.city) {
            console.log("输入框搜索接种点事件", t.detail.value);
            var e = {
                name: t.detail.value,
                id: ""
            };
            this.setData({
                page: 1,
                pointList: [],
                currentPoint: e
            }), this.getPointList(), wx.pageScrollTo({
                scrollTop: 0,
                duration: 300
            });
        } else i.util.alert("请先选择城市");
    },
    selectPoint: function(t) {
        console.log("事件委托选中接种点", t.target.dataset.point);
        var i = {
            name: t.target.dataset.point.vaccinationPointName,
            id: t.target.dataset.point.vaccinationPointId
        };
        wx.setStorageSync("currentCity", this.data.city), wx.setStorageSync("currentPoint", i), 
        wx.navigateBack();
    },
    inputCancel: function() {
        console.log("取消选择常用接种点，返回"), wx.navigateBack();
    },
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    }
});
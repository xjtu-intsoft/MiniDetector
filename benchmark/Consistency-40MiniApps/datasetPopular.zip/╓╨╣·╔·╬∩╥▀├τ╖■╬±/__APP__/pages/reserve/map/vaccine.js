var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/defineProperty")), t = require("../../../dist/wux/index"), a = getApp();

Page({
    data: {
        visible2: !1,
        vacInfos: [],
        classInfos: [],
        summary: "",
        effect: "",
        isRuleTrue: !1,
        selectCategoryName: ""
    },
    onLoad: function(e) {
        this.loadClass();
    },
    loadClass: function() {
        var e = this;
        a.util.post({
            url: "/vaccination/pointInfo/getAllVaccineCategoryList",
            loadingTitle: "加载中",
            success: function(t) {
                console.log("loadClass", t), e.setData({
                    classInfos: t
                });
            },
            fail: function(e) {}
        });
    },
    open2: function(e) {
        console.log("open2", e), this.setData({
            visible2: !0,
            summary: e.currentTarget.dataset.summary,
            effect: e.currentTarget.dataset.effect
        });
    },
    close2: function() {
        this.setData({
            visible2: !1
        });
    },
    onClose: function(t) {
        console.log("onClose"), this.setData((0, e.default)({}, t, !1));
    },
    onClose2: function() {
        this.onClose("visible2");
    },
    selectVac: function(e) {
        console.log("selectVac", e), e.currentTarget.dataset.type ? wx.setStorageSync("currentVac", void 0) : wx.setStorageSync("currentVac", e.currentTarget.dataset.vac), 
        wx.navigateBack();
    },
    alert: function(e) {
        console.log("alert", e), (0, t.$wuxDialog)().alert({
            resetOnClose: !0,
            title: e.currentTarget.dataset.effect,
            content: e.currentTarget.dataset.summary,
            onConfirm: function(e) {
                console.log("感谢上帝，你没吃鞋帮！");
            }
        });
    },
    hideRule: function() {
        this.setData({
            isRuleTrue: !1
        });
    },
    getVaccineList: function(e) {
        console.log("getVaccineList", e), this.setData({
            vacInfos: []
        });
        var t = this;
        a.util.post({
            url: "/vaccination/pointInfo/vaccineInfoList",
            loadingTitle: "加载中...",
            data: {
                vaccineCategory: e.target.dataset.vac.vaccineTypeId
            },
            success: function(a) {
                console.log("获取疫苗列表成功", a), t.setData({
                    vacInfos: a,
                    isRuleTrue: !0,
                    selectCategoryName: e.target.dataset.vac.vaccineTypeName
                });
            },
            fail: function(e) {
                console.log("获取疫苗列表失败", e);
            }
        });
    }
});
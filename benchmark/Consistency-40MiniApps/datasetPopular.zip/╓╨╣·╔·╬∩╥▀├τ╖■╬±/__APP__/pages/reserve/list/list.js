var t = require("../../../dist/wux/index"), e = getApp();

Page({
    data: {
        currentMarker: {},
        vaccineList: [],
        vaccineProductList: [],
        appointDate: [],
        selectedFamily: "",
        isRuleTrue: !1,
        selectCategoryName: ""
    },
    onShow: function() {
        console.log("onLoad生命周期"), this.setData({
            currentMarker: wx.getStorageSync("currentMarker")
        }), console.log("进入列表，缓存获取当前选中接种点", this.data.currentMarker), this.getVaccineCategoryList();
    },
    onLoad: function(t) {
        console.log(t), console.log("options.selectedFamily", t.selectedFamily);
        var e = new Date(), a = e.getFullYear(), i = e.getMonth() + 1, n = e.getDate(), o = [];
        o.push(a + "-" + (i < 10 ? "0" + i : i) + "-" + (n < 10 ? "0" + n : n)), console.log("currentDate", o), 
        this.setData({
            appointDate: o,
            selectedFamily: t.selectedFamily
        });
    },
    getVaccineCategoryList: function() {
        var t = this;
        e.util.post({
            url: "/vaccination/pointInfo/vaccineTypesList",
            loadingTitle: "加载中...",
            data: {
                vaccinationPointId: t.data.currentMarker.id,
                pointDate: t.data.appointDate
            },
            success: function(e) {
                console.log("获取疫苗分类成功", e), t.setData({
                    vaccineProductList: e
                });
            },
            fail: function(t) {
                console.log("获取疫苗分类失败", t);
            }
        });
    },
    getVaccineList: function(t) {
        this.setData({
            isRuleTrue: !0
        });
        var a = this;
        e.util.post({
            url: "/vaccination/pointInfo/vaccineList",
            loadingTitle: "加载中...",
            data: {
                pointId: a.data.currentMarker.id,
                date: a.data.appointDate,
                vaccineTypeId: t
            },
            success: function(t) {
                console.log("获取疫苗列表成功", t), a.setData({
                    vaccineList: t
                });
            },
            fail: function(t) {
                console.log("获取疫苗列表失败", t);
            }
        });
    },
    shwoReserveList: function(t) {
        var a;
        try {
            a = t.currentTarget.dataset.id;
        } catch (t) {
            return void e.util.alert("该疫苗分类无法预约");
        }
        this.setData({
            selectCategoryName: t.currentTarget.dataset.name
        }), this.getVaccineList(a);
    },
    goToReserve: function(t) {
        var a;
        console.log("点击疫苗预约", t.currentTarget.dataset), wx.setStorageSync("currentVaccine", t.currentTarget.dataset.name);
        try {
            a = t.currentTarget.dataset.id;
        } catch (t) {
            return void e.util.alert("该疫苗无法预约");
        }
        e.config.userId ? wx.navigateTo({
            url: "/pages/reserve/detail/detail?id=" + a + "&pointId=" + this.data.currentMarker.id + "&selectedFamily=" + this.data.selectedFamily + "&selectedDate=" + this.data.appointDate
        }) : wx.navigateTo({
            url: "/pages/mine/account/login?id=" + a + "&pointId=" + this.data.currentMarker.id + "&selectedFamily=" + this.data.selectedFamily
        });
    },
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    },
    openCalendar1: function() {
        var e = new Date(), a = e.setDate(e.getDate() - 1), i = e.setDate(e.getDate() + 3650), n = this;
        (0, t.$wuxCalendar)().open({
            value: this.data.appointDate,
            minDate: a,
            maxDate: i,
            onChange: function(t, e) {
                console.log("onChange", t, e), n.setData({
                    appointDate: e
                }), n.getVaccineCategoryList();
            }
        });
    },
    hideRule: function() {
        this.setData({
            isRuleTrue: !1
        });
    }
});
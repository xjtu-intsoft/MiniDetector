require("../../../dist/wux/index");

var t, e = getApp(), a = [];

Page({
    data: {
        options: {},
        startDate: "",
        endDate: "",
        currentDate: "",
        appointmentDate: "",
        settingAttId: "",
        vaccineData: {},
        generateId: "",
        isDisable: !1,
        familyList: [],
        familyData: {
            name: "",
            relationship: "",
            relationshipLabel: "",
            documentType: "",
            documentTypeLabel: "",
            identificationNumber: "",
            sex: ""
        },
        documentTypeList: [],
        relationshipList: [],
        msg: "请填写完整预约信息",
        showMsg: !1,
        calendarConfig: {
            multi: !1,
            theme: "elegant",
            showLunar: !0,
            inverse: !1,
            chooseAreaMode: !1,
            markToday: "今",
            defaultDay: !0,
            highlightToday: !0,
            takeoverTap: !1,
            preventSwipe: !0,
            firstDayOfWeek: "Mon",
            onlyShowCurrentMonth: !0,
            hideHeadOnWeekMode: !1,
            showHandlerOnWeekMode: !0
        },
        defaultFamilyIndex: 0,
        vaccineStatus: -1,
        selectPlanId: "",
        firstPlanId: "",
        history: [],
        injectTimes: [],
        linewidth: [ 2, 3, 4, 5, 6, 7, 8, 9 ],
        currentLinewidth: 0,
        color: [ "#000", "#8a3022", "#ffc3b0", "#ffa300", "#66b502", "#148bfd", "#000", "#9700c2", "#8a8989" ],
        currentColor: 0,
        cancelChange: !1,
        isStart: !1,
        cms: '  <div style="margin-top:10px;">\n\t\t\t<h3 style="color: #000;">支持的标签</h3>\n\t\t\t<blockquote>wxParse支持70%的html的标签</blockquote>\n\t\t\t<div style="margin-top:10px;">\n\t\t\t\t<span>span标签</span>\n\t\t\t\t<strong style="color: red;">strong标签</strong>\n\t\t\t</div>\n\t\t</div>',
        isRuleTrue: !1,
        notifyChecked: !1,
        isRuleTrueNotify: !1,
        showNotify: !1,
        showAck: !1,
        informedConsentText: "",
        notificationText: "",
        injectPlanText: ""
    },
    onLoad: function(t) {
        this.setData({
            options: t
        }), console.log("传入预约详情页参数", t);
    },
    onShow: function() {
        var t = this, e = this, a = wx.getStorageSync("familyForm");
        a.userId && (console.log("添加家庭成员成功，带回的提交表单数据", a), this.getFamilyList().then(function(n) {
            var i = n, o = i.filter(function(t) {
                return t.name == a.name;
            })[0];
            o.relationshipLabel = t.data.relationshipList.filter(function(t) {
                return t.id == o.relationship;
            })[0].name, o.documentTypeLabel = o.documentType ? t.data.documentTypeList.filter(function(t) {
                return t.id == o.documentType;
            })[0].name : "", t.setData({
                familyList: i,
                familyData: o
            }), e.loadPlan(o);
        })), this.loadAckAndNotifyStatus();
        var n = this.data;
        this.mycanvas = wx.createCanvasContext("canvas"), this.mycanvas.setLineCap("round"), 
        this.mycanvas.setLineJoin("round"), this.mycanvas.setStrokeStyle(n.color[n.currentColor]), 
        this.mycanvas.setLineWidth(n.linewidth[n.currentLinewidth]);
    },
    initDate: function() {
        this.setData({
            startDate: e.util.formatDate(new Date()),
            endDate: e.util.formatDate(new Date(new Date().getTime() + 6048e5)),
            appointmentDate: e.util.formatDate(new Date()),
            currentDate: e.util.formatDate(new Date())
        });
    },
    getVaccineReserveDetail: function() {
        var t = this;
        return new Promise(function(n, i) {
            e.util.post({
                url: "/vaccination/pointInfo/vaccinePointInfo",
                loadingTitle: "加载中...",
                data: {
                    vaccinationPointId: t.data.options.pointId,
                    vaccineId: t.data.options.id,
                    pointDate: t.data.appointmentDate
                },
                success: function(e) {
                    console.log("获取疫苗预约详情成功", e), a = e.list, t.setData({
                        documentTypeList: e.documentTypeList,
                        relationshipList: e.relationshipList,
                        vaccineStatus: e.vaccineStatus
                    }), t.handleVaccineData(e.list), Promise.all([ t.getFamilyList() ]).then(function(e) {
                        console.log("获取家庭成员列表和疫苗预约详情", e), t.handleFamilyData(e[0]);
                    }).catch(function(t) {
                        console.log(t);
                    }), n(e);
                },
                fail: function(t) {
                    console.log("获取疫苗预约详情失败", t), i(t);
                }
            });
        });
    },
    handleVaccineData: function(t) {
        console.log("重组疫苗事件", t);
        var e = {
            name: wx.getStorageSync("currentVaccine"),
            am: [],
            pm: []
        };
        t && t.length > 0 && t.forEach(function(t) {
            e.vaccineId = t.vaccineId, e.vaccinationPointId = t.vaccinationPointId, "上午" == t.meridiem ? e.am.push(t) : e.pm.push(t);
        }), this.setData({
            vaccineData: e
        });
    },
    handleFamilyData: function(t) {
        console.log("handleFamilyData", t);
        var e, a = t;
        if (this.options.selectedFamily) for (var n = 0; n < a.length; n++) {
            var i = a[n];
            if (console.log(i.familyId, this.options.selectedFamily), i.familyId == this.options.selectedFamily) {
                e = i, this.setData({
                    defaultFamilyIndex: n
                });
                break;
            }
        } else e = a[0];
        e.relationshipLabel = this.data.relationshipList.filter(function(t) {
            return t.id == e.relationship;
        })[0].name, e.documentTypeLabel = e.documentType ? this.data.documentTypeList.filter(function(t) {
            return t.id == e.documentType;
        })[0].name : "", this.setData({
            familyList: a,
            familyData: e
        }), this.loadPlan(e);
    },
    getFamilyList: function() {
        return new Promise(function(t, a) {
            e.util.post({
                url: "/family/familyList",
                loadingTitle: "加载中...",
                TerminalType: 2,
                data: {
                    userId: e.config.userId
                },
                success: function(e) {
                    console.log("获取家庭成员列表成功", e), t(e);
                },
                fail: function(t) {
                    console.log("获取家庭成员列表失败", t), a(t);
                }
            });
        });
    },
    selectDate: function(t) {
        console.log("日历组件点击日期传入父组件，选择预约日期", t);
        var e = t.detail.year + "-" + (t.detail.month < 10 ? "0" + t.detail.month : t.detail.month) + "-" + (t.detail.day < 10 ? "0" + t.detail.day : t.detail.day);
        console.log("selectDate", e), this.setData({
            appointmentDate: e
        }), this.getVaccineReserveDetail();
    },
    selectTime: function(t) {
        console.log("选择预约时间：", t.detail.value), this.setData({
            settingAttId: t.detail.value
        });
    },
    selectPlan: function(t) {
        console.log("选择接种计划：", t.detail.value), this.setData({
            selectPlanId: t.detail.value
        });
    },
    selectFamily: function(t) {
        console.log("选择受种人（家庭成员）", t.detail), console.log("选中的受种人（家庭成员）", this.data.familyList[t.detail.value]);
        var e = this.data.familyList[t.detail.value];
        e.relationshipLabel = this.data.relationshipList.filter(function(t) {
            return t.id == e.relationship;
        })[0].name, e.documentTypeLabel = e.documentType ? this.data.documentTypeList.filter(function(t) {
            return t.id == e.documentType;
        })[0].name : "", this.setData({
            familyData: e
        }), this.loadPlan(e);
    },
    goToAddFamily: function(t) {
        console.log("添加家庭成员操作", t.currentTarget.dataset.familyitem);
        var e = {
            source: getCurrentPages()[getCurrentPages().length - 1].route,
            handle: "reserve-add"
        };
        wx.navigateTo({
            url: "/pages/mine/family/addfamily?query=" + JSON.stringify(e)
        });
    },
    formSubmit: function(t) {
        var n = t.detail.value;
        if (n.appointmentDate = this.data.appointmentDate, n.settingAttId = this.data.settingAttId, 
        a.forEach(function(t) {
            t.aId == n.settingAttId && (n.settingId = t.id, n.startTime = t.startTime, n.endTime = t.endTime);
        }), n.documentType = this.data.familyData.documentType, n.relationship = this.data.familyData.relationship, 
        n.name = this.data.familyData.name, n.birthday = this.data.familyData.birthday, 
        n.idCard = this.data.familyData.identificationNumber, n.sex = this.data.familyData.sex, 
        n.vaccineId = this.data.vaccineData.vaccineId, n.vaccinationPointId = this.data.vaccineData.vaccinationPointId || wx.getStorageSync("currentMarker").id, 
        n.openId = e.config.openId, n.userId = e.config.userId, console.log("组装完成的预约参数data", JSON.parse(JSON.stringify(n))), 
        !this.data.notifyChecked) return this.showErrorMsg("请阅读告知书！"), !1;
        if (!n.settingAttId) return this.showErrorMsg("请选择预约时段！"), !1;
        if (!n.relationship) return this.showErrorMsg("请选择受种人！"), !1;
        if (!n.sex) return this.showErrorMsg("请选择受种人性别！"), !1;
        var i = this;
        wx.setStorageSync("reserveForm", n), i.setData({
            isRuleTrue: !1,
            isRuleTrueNotify: !1,
            isDisable: !0
        }), this.data.showAck ? setTimeout(function() {
            console.log("开始输出图片----"), wx.canvasToTempFilePath({
                canvasId: "canvas",
                destWidth: 400,
                destHeight: 300,
                success: function(t) {
                    console.log("获得新图片----输出 res,", t);
                    var a = "data:image/png;base64," + wx.getFileSystemManager().readFileSync(t.tempFilePath, "base64");
                    console.log(a), n.signatureImage = a, e.util.post({
                        url: "/vaccination/pointInfo/confirm",
                        loadingTitle: "加载中...",
                        data: n,
                        success: function(t) {
                            wx.reLaunch({
                                url: "/pages/reserve/success/success"
                            });
                        },
                        fail: function(t, a) {
                            console.log("提交预约失败"), e.util.alert("提交预约失败，" + a), i.setData({
                                isDisable: !1
                            });
                        }
                    });
                },
                fail: function(t) {
                    console.log("输出图片报错"), console.error("err:", t), i.setData({
                        isComplete: !0,
                        isDisable: !1
                    }), wx.hideLoading();
                }
            }, this);
        }, 1e3) : (n.signatureImage = "", e.util.post({
            url: "/vaccination/pointInfo/confirm",
            loadingTitle: "加载中...",
            data: n,
            success: function(t) {
                wx.reLaunch({
                    url: "/pages/reserve/success/success"
                });
            },
            fail: function(t, a) {
                console.log("提交预约失败"), e.util.alert("提交预约失败，" + a), i.setData({
                    isDisable: !1
                });
            }
        })), console.log("开始输出图片"), wx.canvasToTempFilePath({
            canvasId: "canvas",
            destWidth: 400,
            destHeight: 300,
            success: function(t) {
                console.log("获得新图片输出 res,", t);
                var a = "data:image/png;base64," + wx.getFileSystemManager().readFileSync(t.tempFilePath, "base64");
                console.log(a), n.signatureImage = a, e.util.post({
                    url: "/vaccination/pointInfo/confirm",
                    loadingTitle: "加载中...",
                    data: n,
                    success: function(t) {
                        wx.reLaunch({
                            url: "/pages/reserve/success/success"
                        });
                    },
                    fail: function(t, a) {
                        i.setData({
                            isDisable: !1
                        }), console.log("提交预约失败"), e.util.alert("提交预约失败，" + a);
                    }
                });
            },
            fail: function(t) {
                console.log("输出图片报错"), console.error("err:", t), i.setData({
                    isComplete: !0
                }), wx.hideLoading();
            }
        }, this);
    },
    showErrorMsg: function(e) {
        var a = this;
        t && clearTimeout(t), a.setData({
            showMsg: !0,
            msg: e
        }), t = setTimeout(function() {
            a.setData({
                showMsg: !1,
                msg: ""
            });
        }, 1200);
    },
    onUnload: function() {
        wx.removeStorageSync("familyForm"), wx.removeStorageSync("newPlan");
    },
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    },
    afterTapDay: function(t) {
        console.log("afterTapDay", t.detail), console.log("afterTapDay", this.calendar.getCalendarDates());
        this.calendar.setDateStyle([ {
            year: 2020,
            month: 5,
            day: 19,
            class: "orange-date other-class"
        } ]);
    },
    onSwipe: function(t) {
        console.log("onSwipe", t.detail);
        this.calendar.getCalendarDates();
    },
    whenChangeMonth: function(t) {
        console.log("whenChangeMonth", t.detail), this.loadDayTag(t.detail.next.year, t.detail.next.month);
    },
    whenChangeWeek: function(t) {
        console.log("whenChangeWeek", t.detail);
    },
    onTapDay: function(t) {
        console.log("onTapDay", t.detail);
    },
    afterCalendarRender: function(t) {
        console.log("afterCalendarRender", t);
        var e = new Date(), a = e.getFullYear(), n = e.getMonth() + 1, i = e.getDate();
        e.getHours(), e.getMinutes(), e.getSeconds();
        if (console.log("afterCalendarRender,", a + "-" + n + "-" + i), this.calendar.enableArea([ a + "-" + n + "-" + i, "2999-12-31" ]), 
        this.data.options.selectedDate) {
            var o = this.data.options.selectedDate.split("-");
            this.calendar.jump(o[0], o[1], o[2]).then(function(t) {});
            var s = {}, l = {
                year: o[0],
                month: parseInt(o[1]),
                day: parseInt(o[2])
            };
            s.detail = l, this.selectDate(s), this.loadDayTag(o[0], parseInt(o[1]));
        } else this.loadDayTag(a, n);
    },
    loadDayTag: function(t, a) {
        var n = this;
        e.util.post({
            url: "/holiday/holidayQuery",
            loadingTitle: "加载中...",
            data: {
                year: t,
                month: a,
                id: n.data.options.pointId,
                vaccineId: n.data.options.id
            },
            success: function(t) {
                console.log("获取诊所休息日成功", t), n.calendar.setDateStyle(t);
                for (var e = [], a = 0; a < t.length; a++) "stop-date" != t[a].class && "rest-date" != t[a].class || e.push(t[a]);
                console.log("获取诊所休息日成功 tmp", e), n.calendar.disableDay(e);
            },
            fail: function(t) {
                console.log("获取诊所休息日失败", t), reject(t);
            }
        }), e.util.post({
            url: "/vaccination/pointInfo/appointmentDate",
            loadingTitle: "加载中...",
            data: {
                year: t,
                month: a,
                vaccinationPointId: n.data.options.pointId,
                vaccineId: n.data.options.id
            },
            success: function(t) {
                console.log("获取诊所预约成功日期", t), n.calendar.setDateStyle(t);
            },
            fail: function(t) {
                console.log("获取诊所预约失败", t), reject(t);
            }
        });
    },
    loadPlan: function(t) {
        if (console.log("loadPlan(familyData)", t), this.setData({
            injectPlanText: ""
        }), t.name) {
            var a = this;
            e.util.post({
                url: "/vaccinationPlan/selectPlan",
                loadingTitle: "加载中...",
                data: {
                    familyId: t.familyId,
                    vaccinationPointId: a.data.options.pointId,
                    vaccineId: a.data.options.id,
                    appointmentDate: a.data.appointmentDate
                },
                success: function(t) {
                    console.log("接种计划成功", t), a.setData({
                        injectPlanText: t.vaccinationTimes
                    });
                },
                fail: function(t) {
                    console.log("接种计划失败", t), reject(t);
                }
            });
        }
    },
    addHistory: function() {
        console.log("添加接种历史");
        for (var t = "", a = this.data.injectTimes.length - 1; a > 0; a--) this.data.injectTimes[a].id == this.data.selectPlanId && (t = this.data.injectTimes[a - 1].id);
        if (t) {
            var n = {
                prevPlanId: t,
                selectPlanId: this.data.selectPlanId,
                vaccineData: this.data.vaccineData
            };
            wx.navigateTo({
                url: "/pages/reserve/addhistory/addhistory?query=" + JSON.stringify(n)
            });
        } else e.util.alert("获取要补充的接种计划信息失败");
    },
    diy: function() {
        this.setData({
            alertShow: !1
        });
    },
    alertClick: function() {
        this.setData({
            alertShow: !0
        });
    },
    changeColor: function(t) {
        var e = t.currentTarget.id;
        this.setData({
            cancelChange: !1,
            currentColor: e
        }), this.mycanvas.setStrokeStyle(this.data.color[this.data.currentColor]);
    },
    changeLineWidth: function(t) {
        var e = t.currentTarget.id;
        this.setData({
            currentLinewidth: e
        }), this.mycanvas.setLineWidth(this.data.linewidth[this.data.currentLinewidth]);
    },
    chengCancel: function() {
        this.setData({
            cancelChange: !0
        }), this.mycanvas.setStrokeStyle("#fff");
    },
    canvasStart: function(t) {
        var e = t.touches[0].x, a = t.touches[0].y;
        this.mycanvas.moveTo(e, a);
    },
    canvasMove: function(t) {
        var e = t.touches[0].x, a = t.touches[0].y;
        this.mycanvas.lineTo(e, a), this.mycanvas.stroke(), this.mycanvas.draw(!0), this.mycanvas.moveTo(e, a);
    },
    canvasEnd: function() {
        this.setData({
            isStart: !0
        });
    },
    clearCanvas: function() {
        this.mycanvas.clearRect(0, 0, 400, 400), this.mycanvas.draw(!0);
    },
    fabu: function() {
        var t = this;
        wx.showLoading({
            title: "图片上传中...",
            mask: !0,
            success: function() {}
        }), wx.canvasToTempFilePath({
            canvasId: "canvas",
            destWidth: 400,
            destHeight: 300,
            success: function(t) {
                console.log("获得新图片输出 res,", t), console.log("data:image/png;base64," + wx.getFileSystemManager().readFileSync(t.tempFilePath, "base64"));
            },
            fail: function(e) {
                console.error("err:" + e), t.setData({
                    isComplete: !0
                }), wx.hideLoading();
            }
        }, this);
    },
    hideRule: function() {
        this.setData({
            isRuleTrue: !1
        });
    },
    openNotify: function() {
        var t = this;
        e.util.post({
            url: "/point/notification/queryNotice",
            loadingTitle: "加载中...",
            data: {
                outpatientId: t.data.options.pointId,
                vaccineId: t.data.options.id
            },
            success: function(e) {
                console.log("获取告知书&知情同意书详情成功", e), t.setData({
                    informedConsentText: e.informedConsentText,
                    notificationText: e.notificationText,
                    isDisable: !1
                });
            },
            fail: function(a, n) {
                console.log("获取告知书&知情同意书详情成功", a), e.util.alert("告知书&知情同意书获取失败，" + n), t.setData({
                    isDisable: !1
                });
            }
        }), this.setData({
            isRuleTrue: !0,
            isDisable: !1
        });
    },
    hideRuleNotify: function() {
        this.setData({
            isRuleTrue: !0,
            isRuleTrueNotify: !1
        });
    },
    openNotifyInner: function() {
        this.setData({
            isRuleTrue: !1,
            isRuleTrueNotify: !0
        });
    },
    checkboxChange: function(t) {
        console.log("checkbox发生change事件，携带value值为：", t.detail.value), console.log("长度:" + t.detail.value.length), 
        this.setData({
            notifyChecked: !this.data.notifyChecked
        });
    },
    loadAckAndNotifyStatus: function() {
        var t = this;
        e.util.post({
            url: "/point/notification/queryJudge",
            loadingTitle: "加载中...",
            data: {
                outpatientId: t.data.options.pointId,
                vaccineId: t.data.options.id
            },
            success: function(e) {
                console.log("获取告知书&知情同意书状态成功", e);
                var a = !1, n = !1, i = !1;
                e.informedConsentIfOpening && 1 == e.informedConsentIfOpening ? a = !0 : i = !0, 
                e.noticeIfOpening && 1 == e.noticeIfOpening ? n = !0 : e.informedConsentIfOpening && 1 == e.informedConsentIfOpening && (i = !0), 
                t.setData({
                    showAck: a,
                    showNotify: n,
                    notifyChecked: i
                });
            },
            fail: function(t) {
                console.log("获取告知书&知情同意书状态成功", t), reject(t);
            }
        });
    }
});
Page({
    data: {
        reserveIns: {},
        reserveData: {},
        currentVaccine: ""
    },
    onLoad: function(e) {
        this.setData({
            reserveIns: wx.getStorageSync("currentMarker"),
            reserveForm: wx.getStorageSync("reserveForm"),
            currentVaccine: wx.getStorageSync("currentVaccine")
        });
    },
    goToMy: function() {
        wx.switchTab({
            url: "/pages/mine/my"
        });
    },
    onUnload: function() {
        wx.removeStorageSync("currentCity"), wx.removeStorageSync("currentMarker"), wx.removeStorageSync("currentPoint"), 
        wx.removeStorageSync("reserveForm"), wx.removeStorageSync("currentVaccine");
    }
});
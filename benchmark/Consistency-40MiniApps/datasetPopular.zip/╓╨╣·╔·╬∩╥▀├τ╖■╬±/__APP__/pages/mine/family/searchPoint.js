var t = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/toConsumableArray")), i = getApp(), a = [];

Page({
    data: {
        city: "",
        cityList: [],
        pointList: [],
        usualPoint: {
            name: "",
            id: ""
        },
        isShowCityList: !0,
        page: 1,
        pageSize: 20
    },
    onLoad: function(t) {
        (a = wx.getStorageSync("cityList")) && a.length > 0 ? this.setData({
            cityList: a
        }) : this.getCityList();
    },
    getCityList: function() {
        var t = this;
        i.util.post({
            url: "/area/list",
            loadingTitle: "加载中...",
            TerminalType: 2,
            success: function(i) {
                console.log("获取城市列表成功", i), a = i, t.setData({
                    cityList: a
                }), wx.setStorageSync("cityList", a);
            },
            fail: function(t) {
                console.log("获取城市列表失败", t);
            }
        });
    },
    searchCity: function(t) {
        console.log("输入框搜索城市事件", t);
        var i = t.detail.value;
        if (i != this.data.city) if (i) {
            var e = JSON.parse(JSON.stringify(a));
            e.forEach(function(t) {
                t.cityList = t.cityList.filter(function(t) {
                    if (-1 != t.cityName.indexOf(i)) return console.log("返回命中城市", t), t;
                });
            }), this.setData({
                cityList: e,
                isShowCityList: !0
            }), wx.pageScrollTo({
                scrollTop: 0,
                duration: 300
            });
        } else this.setData({
            page: 1,
            city: "",
            cityList: a,
            isShowCityList: !0
        });
    },
    selectCity: function(t) {
        console.log("事件委托选中城市", t.target.dataset.city), t.target.dataset.city && (this.setData({
            page: 1,
            city: t.target.dataset.city,
            pointList: [],
            usualPoint: {
                name: "",
                id: ""
            }
        }), this.getPointList(), wx.pageScrollTo({
            scrollTop: 0,
            duration: 300
        }));
    },
    getPointList: function() {
        var a = this;
        i.util.post({
            url: "/vaccination/pointInfo/pageList",
            loadingTitle: "加载中...",
            TerminalType: 2,
            data: {
                page: a.data.page,
                pageSize: 20,
                name: a.data.usualPoint.name,
                cityName: a.data.city
            },
            success: function(i) {
                console.log("获取接种点列表成功", i), i.list.length < a.data.pageSize && (console.log("数据小于20条，页码归零，不再拉取"), 
                a.setData({
                    page: 0
                })), a.setData({
                    isShowCityList: !1,
                    pointList: [].concat((0, t.default)(a.data.pointList), (0, t.default)(i.list))
                });
            },
            fail: function(t) {
                console.log("获取接种点列表失败", t);
            }
        });
    },
    onReachBottom: function() {
        this.data.isShowCityList || (0 != this.data.page ? (this.setData({
            page: this.data.page + 1
        }), this.getPointList()) : i.util.alert("没有更多数据了"));
    },
    searchPoint: function(t) {
        console.log("输入框搜索接种点事件", t.detail.value);
        var i = {
            name: t.detail.value,
            id: ""
        };
        this.setData({
            page: 1,
            pointList: [],
            usualPoint: i
        }), this.getPointList(), wx.pageScrollTo({
            scrollTop: 0,
            duration: 300
        });
    },
    selectPoint: function(t) {
        console.log("事件委托选中接种点", t.target.dataset.point);
        var i = {
            name: t.target.dataset.point.vaccinationPointName,
            id: t.target.dataset.point.vaccinationPointId
        };
        this.setData({
            usualPoint: i
        }), wx.setStorageSync("usualPoint", i), wx.navigateBack();
    },
    inputCancel: function() {
        console.log("取消选择常用接种点，返回"), wx.setStorageSync("usualPoint", {
            name: "",
            id: ""
        }), wx.navigateBack();
    }
});
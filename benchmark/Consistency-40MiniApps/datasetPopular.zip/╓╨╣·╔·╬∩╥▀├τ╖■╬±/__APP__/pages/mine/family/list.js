var t = getApp();

Page({
    data: {
        loading: !1,
        familyList: [],
        relationship: {}
    },
    onLoad: function() {
        this.getFamilyList();
        var t = wx.getStorageSync("pickerList");
        if (t) {
            var i = {};
            t.relationshipList.forEach(function(t) {
                i[t.id] = t.name;
            }), this.setData({
                relationship: i
            });
        } else this.getPickerList();
    },
    getPickerList: function() {
        var i = this;
        t.util.post({
            url: "/family/typeList",
            loadingTitle: "加载中...",
            TerminalType: 2,
            success: function(t) {
                console.log("获取证件类型和关系列表成功", t), t.documentTypeList.unshift({
                    name: "未选择",
                    id: ""
                }), wx.setStorageSync("pickerList", t);
                var a = {};
                t.relationshipList.forEach(function(t) {
                    a[t.id] = t.name;
                }), i.setData({
                    relationship: a
                });
            },
            fail: function(t) {
                console.log("获取证件类型和关系列表失败", t);
            }
        });
    },
    getFamilyList: function() {
        var i = this;
        this.setData({
            loading: !0
        }), t.util.post({
            url: "/family/familyList",
            loadingTitle: "加载中...",
            TerminalType: 2,
            data: {
                userId: t.config.userId
            },
            success: function(t) {
                console.log("获取家庭成员列表成功", t), i.setData({
                    loading: !1,
                    familyList: t
                });
            },
            fail: function(t) {
                console.log("获取家庭成员列表失败", t), i.setData({
                    loading: !1
                });
            }
        });
    },
    goToAddfamily: function() {
        wx.navigateTo({
            url: "/pages/mine/family/addfamily"
        });
    },
    editFamily: function(t) {
        console.log("编辑操作", t.currentTarget.dataset.familyitem);
        var i = {
            source: getCurrentPages()[getCurrentPages().length - 1].route,
            data: t.currentTarget.dataset.familyitem,
            handle: "edit"
        };
        wx.navigateTo({
            url: "/pages/mine/family/addfamily?query=" + JSON.stringify(i)
        });
    },
    deleteFamily: function(i) {
        if (!this.data.loading) {
            this.setData({
                loading: !0
            }), console.log("删除操作", i.currentTarget.dataset.familyid);
            var a = this;
            wx.showModal({
                title: "提示",
                content: "是否删除该成员信息？",
                success: function(e) {
                    e.cancel ? a.setData({
                        loading: !1
                    }) : t.util.post({
                        url: "/family/delFamily",
                        loadingTitle: "加载中...",
                        TerminalType: 2,
                        data: {
                            familyId: i.currentTarget.dataset.familyid
                        },
                        success: function(t) {
                            console.log("删除家庭成员成功", t), a.setData({
                                loading: !1
                            }), a.getFamilyList();
                        },
                        fail: function(t) {
                            console.log("删除家庭成员失败", t), a.setData({
                                loading: !1
                            });
                        }
                    });
                },
                fail: function() {
                    a.setData({
                        loading: !1
                    });
                }
            });
        }
    },
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    }
});
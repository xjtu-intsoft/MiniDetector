var t, e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/defineProperty")), i = require("../../../dist/wux/index"), a = getApp();

new Date();

Page({
    data: {
        isEdit: !1,
        query: "",
        name: "",
        sex: 2,
        identificationNumber: "",
        vaccinationCertificateCode: "",
        basicDisease: "",
        contacts: "",
        contactsPhone: "",
        relationshipList: [],
        relationshipLabel: "",
        relationship: 0,
        selectedDate: "",
        documentTypeList: [],
        documentTypeLabel: "",
        documentType: 0,
        usualPoint: {
            name: "",
            id: ""
        },
        msg: "请填写完整预约信息",
        showMsg: !1,
        showCalender: !1,
        date: ""
    },
    onLoad: function(t) {
        if (console.log("进入家庭成员页面传入参数", t), t.query) {
            var e;
            try {
                e = JSON.parse(t.query);
            } catch (t) {}
            this.setData({
                query: e
            }), "edit" == e.handle ? (wx.setNavigationBarTitle({
                title: "修改家庭成员"
            }), this.setData({
                isEdit: !0
            }), this.initEditData()) : e.handle;
        }
        var i = wx.getStorageSync("pickerList"), a = this.data.query.data;
        i ? ("未选择" != i.documentTypeList[0].name && i.documentTypeList.unshift({
            name: "未选择",
            id: ""
        }), this.setData({
            documentTypeList: i.documentTypeList,
            relationshipList: i.relationshipList,
            documentTypeLabel: this.data.isEdit ? i.documentTypeList.filter(function(t) {
                return t.id == a.documentType;
            })[0].name : i.documentTypeList[0].name,
            documentType: this.data.isEdit ? a.documentType : i.documentTypeList[0].id,
            relationshipLabel: this.data.isEdit ? i.relationshipList.filter(function(t) {
                return t.id == a.relationship;
            })[0].name : i.relationshipList[0].name,
            relationship: this.data.isEdit ? a.relationship : i.relationshipList[0].id
        })) : this.getPickerList();
    },
    onShow: function() {
        var t = wx.getStorageSync("usualPoint");
        console.log("添加家庭成员页面onShow生命周期", t), t && this.setData({
            usualPoint: t
        });
    },
    initEditData: function() {
        console.log("解析参数", this.data.query);
        var t = {
            name: this.data.query.data.vaccinationName || "",
            id: this.data.query.data.vaccinationPointId
        };
        this.setData({
            name: this.data.query.data.name,
            selectedDate: this.data.query.data.birthday,
            sex: this.data.query.data.sex,
            identificationNumber: this.data.query.data.identificationNumber,
            vaccinationCertificateCode: this.data.query.data.vaccinationCertificateCode,
            basicDisease: this.data.query.data.basicDisease,
            contacts: this.data.query.data.contacts,
            contactsPhone: this.data.query.data.contactsPhone,
            usualPoint: t
        }), console.log("initEditData selectedDate", this.data.selectedDate);
    },
    getPickerList: function() {
        var t = this, e = this.data.query.data;
        a.util.post({
            url: "/family/typeList",
            loadingTitle: "加载中...",
            showLoading: !1,
            TerminalType: 2,
            success: function(i) {
                console.log("获取证件类型和关系列表成功", i), i.documentTypeList.unshift({
                    name: "未选择",
                    id: ""
                }), t.setData({
                    documentTypeList: i.documentTypeList,
                    relationshipList: i.relationshipList,
                    documentTypeLabel: t.data.isEdit ? i.documentTypeList.filter(function(t) {
                        return t.id == e.documentType;
                    })[0].name : i.documentTypeList[0].name,
                    documentType: t.data.isEdit ? e.documentType : i.documentTypeList[0].id,
                    relationshipLabel: t.data.isEdit ? i.relationshipList.filter(function(t) {
                        return t.id == e.relationship;
                    })[0].name : i.relationshipList[0].name,
                    relationship: t.data.isEdit ? e.relationship : i.relationshipList[0].id
                }), wx.setStorageSync("pickerList", i);
            },
            fail: function(t) {
                console.log("获取证件类型和关系列表失败", t);
            }
        });
    },
    verifyInput: function(t) {
        console.log("确认输入事件", t);
        var i = t.currentTarget.dataset.type, a = t.detail.value.replace(/\s+/g, "");
        this.setData((0, e.default)({}, i, a));
    },
    selectRelation: function(t) {
        console.log("选择受种人关系", t.detail.value), console.log("选中的受种人关系", this.data.relationshipList[t.detail.value]);
        var e = this.data.relationshipList[t.detail.value];
        this.setData({
            relationshipLabel: e.name,
            relationship: e.id
        });
    },
    selectBirthday: function(t) {
        console.log("选中日期", t.detail), this.setData({
            selectedDate: t.detail.value
        });
    },
    selectCertify: function(t) {
        console.log("选择证件类型", t.detail), console.log("选中的证件类型", this.data.documentTypeList[t.detail.value]);
        var e = this.data.documentTypeList[t.detail.value];
        this.setData({
            documentTypeLabel: e.name,
            documentType: e.id
        }), 0 == t.detail.value && this.setData({
            identificationNumber: ""
        });
    },
    goToSearchPoint: function() {
        wx.navigateTo({
            url: "/pages/mine/family/searchPoint"
        });
    },
    formSubmit: function(t) {
        var e = t.detail.value;
        return e.userId = a.config.userId, e.documentType = this.data.documentType ? this.data.documentType : "", 
        e.relationship = this.data.relationship ? this.data.relationship : "", e.birthday = this.data.selectedDate, 
        e.vaccinationPointId = this.data.usualPoint.id, e.vaccinationName = this.data.usualPoint.name, 
        console.log("组装完成的添加家庭成员参数", JSON.parse(JSON.stringify(e))), e.relationship ? e.name ? e.name.length > 6 ? (this.showErrorMsg("姓名长度超限"), 
        !1) : e.birthday ? e.sex ? 1 != e.documentType || a.RegExp.idNumber.test(e.identificationNumber) ? (e.documentType || (e.identificationNumber = "", 
        e.documentType = 0), e.contacts.length > 6 ? (this.showErrorMsg("联系人姓名长度超限"), !1) : e.contactsPhone && !a.RegExp.mobile.test(e.contactsPhone) ? (this.showErrorMsg("手机号格式错误！"), 
        !1) : e.vaccinationPointId ? e.basicDisease && e.basicDisease.length > 100 ? (this.showErrorMsg("基础病长度超限"), 
        !1) : e.vaccinationCertificateCode && e.vaccinationCertificateCode.length > 30 ? (this.showErrorMsg("预防接种证编码长度超限"), 
        !1) : void (this.data.isEdit ? this.submitEdit(e) : this.submitAdd(e)) : (this.showErrorMsg("请选择常用接种单位"), 
        !1)) : (this.showErrorMsg("身份证号格式错误！"), !1) : (this.showErrorMsg("请选择性别！"), !1) : (this.showErrorMsg("请选择出生日期"), 
        !1) : (this.showErrorMsg("请输入姓名！"), !1) : (this.showErrorMsg("请选择与我的关系！"), !1);
    },
    submitEdit: function(t) {
        var e = this;
        t.generateId = this.data.query.data.familyId, a.util.post({
            url: "/family/updateFamily",
            loadingTitle: "加载中...",
            TerminalType: 2,
            data: t,
            success: function(i) {
                console.log("修改家庭成员成功", i), e.submitSuccess(t);
            },
            fail: function(t) {
                console.log("修改家庭成员失败", t);
            }
        });
    },
    submitAdd: function(t) {
        var e = this;
        a.util.post({
            url: "/family/addFamily",
            loadingTitle: "加载中...",
            TerminalType: 2,
            data: t,
            success: function(i) {
                console.log("添加家庭成员成功", i), e.submitSuccess(t);
            },
            fail: function(t) {
                console.log("添加家庭成员失败", t);
            }
        });
    },
    submitSuccess: function(t) {
        wx.setStorageSync("familyForm", t), "reserve-add" == this.data.query.handle ? wx.navigateBack() : wx.reLaunch({
            url: "/pages/mine/family/list"
        });
    },
    showErrorMsg: function(e) {
        var i = this;
        t && clearTimeout(t), i.setData({
            showMsg: !0,
            msg: e
        }), t = setTimeout(function() {
            i.setData({
                showMsg: !1,
                msg: ""
            });
        }, 1200);
    },
    onUnload: function() {
        wx.removeStorageSync("usualPoint");
    },
    openCalendar1: function() {
        var t = this;
        (0, i.$wuxCalendar)().open({
            value: this.data.selectedDate,
            onChange: function(e, i) {
                console.log("onChange", e, i), t.setData({
                    selectedDate: i
                });
            }
        });
    },
    bindDate: function(t) {
        console.log("bindDate"), this.setData({
            showCalender: !0
        });
    }
});
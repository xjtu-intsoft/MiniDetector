var e = require("../../../dist/wux/index"), t = getApp();

Page({
    data: {
        activeKey: "1",
        msg1: {
            title: "暂无消息",
            text: ""
        },
        msgNum: 1,
        infoPage: 1,
        messageType: 1,
        msgs: []
    },
    onShow: function() {
        this.setData({
            activeKey: "1",
            messageType: 1,
            msgs: [],
            infoPage: 1
        }), this.loadMsg();
    },
    onChange: function(e) {
        console.log("onChange", e), this.setData({
            activeKey: e.detail.key,
            messageType: e.detail.key,
            msgs: [],
            infoPage: 1
        }), this.loadMsg();
    },
    buttonClicked: function(e) {
        console.log("buttonClicked", e);
    },
    onGotUserInfo: function(e) {
        console.log("onGotUserInfo", e);
    },
    onReachBottom: function() {
        var e = this.data.infoPage;
        this.setData({
            infoPage: e + 1
        }), this.loadMsg();
    },
    loadMsg: function() {
        var s = this, a = {
            page: s.data.infoPage,
            pageSize: 10,
            messageType: s.data.messageType,
            userId: t.config.userId
        };
        t.util.post({
            url: "/point/message/messagePageList",
            loadingTitle: "加载中...",
            data: a,
            success: function(t) {
                console.log("loadMsg success", t);
                var a = t.list;
                0 == a.length && ((0, e.$wuxToast)().show({
                    type: "text",
                    duration: 1500,
                    color: "#fff",
                    text: "没有更多消息了",
                    success: function() {
                        return console.log("没有更多消息了");
                    }
                }), s.data.infoPage > 1 && s.setData({
                    infoPage: s.data.infoPage - 1
                }));
                var o = s.data.msgs;
                o = o.concat(a), s.setData({
                    msgs: o
                });
            }
        });
    },
    gotoMsgDetail: function(e) {
        console.log("gotoMsgDetail", e);
        var s = e.currentTarget.dataset.item, a = s.userAppointmentInfo;
        if (0 == s.messageStatus && t.util.post({
            url: "/point/message/updateRead",
            data: {
                id: s.id
            },
            success: function(e) {}
        }), 0 != this.data.activeKey) {
            var o = s.messageContent.split(/[ ]+/)[4], n = o.split(",")[0].substring(0, o.length - 3), i = s.messageContent.match(/您已成功预约\s{0,}([^\s]*)/)[1];
            t.util.post({
                url: "/family/typeList",
                loadingTitle: "加载中...",
                showLoading: !1,
                TerminalType: 2,
                success: function(e) {
                    console.log("获取证件类型和关系列表成功", e), wx.setStorageSync("pickerList", e), wx.navigateTo({
                        url: "/pages/mine/reserve/detail?id=" + a.generateId + "&name=" + n + "&pointname=" + i
                    });
                },
                fail: function(e) {
                    console.log("获取证件类型和关系列表失败", e);
                }
            });
        } else this.onChange({
            detail: {
                key: "0"
            }
        });
    }
});
var t = getApp(), e = !1;

Page({
    data: {
        nickName: "",
        avatarUrl: "",
        reserveList: [],
        relationshipList: [],
        relationshipLabel: "",
        relationship: 0
    },
    onShow: function() {
        console.log("我的页面onShow生命周期"), wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: "#55CEAE"
        }), this.setData({
            nickName: t.user.nickName,
            avatarUrl: t.user.avatarUrl
        }), this.getReserveList(), this.getPickerList();
    },
    getReserveList: function() {
        var e = this, i = {
            userId: t.config.userId
        };
        0 != e.data.relationship && (i.relationship = e.data.relationship), t.util.post({
            url: "/vaccination/pointInfo/findPointList",
            loadingTitle: "加载中...",
            showLoading: !1,
            data: i,
            success: function(t) {
                console.log("获取预约接种记录成功", t), e.setData({
                    reserveList: t
                });
            },
            fail: function(e) {
                t.util.alert("获取预约接种记录失败"), console.log("获取预约接种记录失败", e);
            }
        });
    },
    goToDetail: function(t) {
        console.log("e.detail", t), wx.navigateTo({
            url: "/pages/mine/reserve/detail?id=" + t.currentTarget.dataset.id + "&name=" + t.currentTarget.dataset.name + "&pointname=" + t.currentTarget.dataset.pointname
        });
    },
    cancelReserve: function(i) {
        if (!e) {
            e = !0, console.log("e.detail", i.currentTarget.dataset.id);
            var o = this;
            wx.showModal({
                title: "提示",
                content: "是否取消接种预约？",
                success: function(a) {
                    if (a.confirm) {
                        var n;
                        try {
                            n = i.currentTarget.dataset.id;
                        } catch (e) {
                            t.util.alert("该预约记录无法取消");
                        }
                        t.util.post({
                            url: "/vaccination/pointInfo/cancelReservation",
                            showLoading: !1,
                            data: {
                                generateId: n
                            },
                            success: function(t) {
                                console.log("取消预约成功", t), e = !1, wx.showToast({
                                    title: "取消预约成功",
                                    icon: "success",
                                    duration: 1200,
                                    complete: function(t) {
                                        console.log("showToaste", t);
                                    }
                                }), o.getReserveList();
                            },
                            fail: function(t) {
                                e = !1, console.log("取消预约失败", t);
                            }
                        });
                    } else a.cancel && (e = !1);
                }
            });
        }
    },
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    },
    selectRelation: function(t) {
        console.log("选择受种人关系", t.detail.value), console.log("选中的受种人关系", this.data.relationshipList[t.detail.value]);
        var e = this.data.relationshipList[t.detail.value];
        this.setData({
            relationshipLabel: e.name,
            relationship: e.id
        }), this.getReserveList();
    },
    getPickerList: function() {
        var e = this;
        t.util.post({
            url: "/family/typeList",
            loadingTitle: "加载中...",
            showLoading: !1,
            TerminalType: 2,
            success: function(t) {
                console.log("获取证件类型和关系列表成功", t), t.relationshipList.unshift({
                    name: "全部",
                    id: ""
                }), e.setData({
                    relationshipList: t.relationshipList,
                    relationshipLabel: t.relationshipList[0].name,
                    relationship: t.relationshipList[0].id
                }), wx.setStorageSync("pickerList", t);
            },
            fail: function(t) {
                console.log("获取证件类型和关系列表失败", t);
            }
        });
    },
    gotoCreateRate: function(t) {
        console.log("gotoCreateRate,", t), wx.navigateTo({
            url: "/pages/rate/createRate?query=" + JSON.stringify(t.currentTarget.dataset.item)
        });
    },
    gotoComplete: function(e) {
        console.log("gotoComplete,", e);
        var i = this, o = {};
        o.generateId = e.currentTarget.dataset.item.id, t.util.post({
            url: "/vaccination/pointInfo/modifyInoculation",
            loadingTitle: "加载中...",
            showLoading: !1,
            data: o,
            success: function(t) {
                console.log("确认接种成功", t), i.getReserveList();
            },
            fail: function(e) {
                t.util.alert("确认接种失败"), console.log("确认接种失败", e);
            }
        });
    }
});
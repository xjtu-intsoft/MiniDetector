var e, a = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/defineProperty")), t = getApp();

Page({
    data: {
        reserveInfo: {},
        pickerObj: {
            relationshipObj: {},
            documentTypeObj: {}
        },
        vaccineName: "",
        pointName: "",
        qrdata: "",
        generateId: "",
        nowTime: "",
        value1: "",
        value2: "",
        value3: "",
        displayValue1: "请选择",
        displayValue2: "请选择",
        displayValue3: "请选择",
        options1: [],
        options2: [],
        options3: [],
        vaccindValue1: "",
        vaccindValue2: "",
        vaccindValue3: "",
        vaccineNo: ""
    },
    onLoad: function(e) {
        console.log("进入预约详情参数", e), wx.setNavigationBarTitle({
            title: "预约详情"
        }), wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: "#CAEEE4"
        }), this.handlePickerObj(), this.findPointInfo(e.id), this.getVaccineList(), this.setData({
            generateId: e.id,
            vaccineName: e.name,
            pointName: e.pointname
        }), this.addDate(), console.log(this.addDate());
    },
    getVaccineList: function() {
        var e = this;
        t.util.post({
            url: "/point/popularVaccine/getVaccineList",
            loadingTitle: "加载中...",
            showLoading: !1,
            TerminalType: 2,
            success: function(a) {
                console.log("获取预约详情成功", a), e.setData({
                    options1: a
                });
            },
            fail: function(e) {
                console.log("获取下拉疫苗失败", e);
            }
        });
    },
    onConfirmVacc: function(e) {
        var a = e.currentTarget.dataset.index;
        this.setValue(e.detail, a), this.vaccindValue1 = e.detail.label;
        var n = this;
        t.util.post({
            url: "/point/popularVaccine/getVaccineListSub",
            loadingTitle: "加载中...",
            showLoading: !1,
            TerminalType: 2,
            data: {
                vaccineId: e.detail.value
            },
            success: function(e) {
                console.log("获取预约详情成功", e), n.setData({
                    options2: e
                });
            },
            fail: function(e) {
                console.log("疫苗产品失败", e);
            }
        }), t.util.post({
            url: "/point/popularVaccine/getVaccineFilm",
            loadingTitle: "加载中...",
            showLoading: !1,
            TerminalType: 2,
            data: {
                vaccineId: e.detail.value
            },
            success: function(e) {
                console.log("获取预约详情成功", e), n.setData({
                    options3: e
                });
            },
            fail: function(e) {
                console.log("疫苗产品失败", e);
            }
        });
    },
    onConfirm2: function(e) {
        var a = e.currentTarget.dataset.index;
        this.setValue(e.detail, a), this.vaccindValue2 = e.detail.label;
    },
    handlePickerObj: function() {
        e = wx.getStorageSync("pickerList");
        var a = {
            relationshipObj: {},
            documentTypeObj: {}
        };
        console.log("pickerList", JSON.parse(JSON.stringify(e))), e.relationshipList.forEach(function(e) {
            e.id && (a.relationshipObj[e.id] = e.name);
        }), e.documentTypeList.forEach(function(e) {
            e.id && (a.documentTypeObj[e.id] = e.name);
        }), this.setData({
            pickerObj: a
        });
    },
    findPointInfo: function(e) {
        var a = this;
        t.util.post({
            url: "/vaccination/pointInfo/findPointInfo",
            loadingTitle: "加载中...",
            showLoading: !1,
            TerminalType: 2,
            data: {
                generateId: e
            },
            success: function(e) {
                console.log("获取预约详情成功", e);
                var t = {};
                t.appointmentName = e.appointmentName, t.appointmentPhone = e.appointmentPhone, 
                t.appointmentDate = e.appointmentDate + " " + e.startTime + "-" + e.endTime, t.vaccineName = a.data.vaccineName, 
                t.name = e.name, t.pointName = a.data.pointName, t.batchId = e.batchId, t.manufacturerName = e.manufacturerName, 
                t.epcCode = e.epcCode, t.vaccineName = e.vaccineName;
                var n = new Date(), i = n.getMonth() + 1, o = n.getDate();
                i >= 1 && i <= 9 && (i = "0" + i), o >= 0 && o <= 9 && (o = "0" + o);
                var c = n.getFullYear() + "-" + i + "-" + o;
                e.appointmentDate.replace(/-/g, "") <= c.replace(/-/g, "") ? e.showBtn = !0 : e.showBtn = !1, 
                a.setData({
                    reserveInfo: e,
                    qrdata: JSON.stringify(t)
                });
            },
            fail: function(e) {
                console.log("获取预约详情失败", e);
            }
        });
    },
    onShareAppMessage: function() {},
    previewImage: function() {
        var e = this.selectComponent("#qrcode");
        wx.canvasToTempFilePath({
            canvasId: "wux-qrcode",
            success: function(e) {
                wx.previewImage({
                    urls: [ e.tempFilePath ]
                });
            }
        }, e);
    },
    gotoComplete: function(e) {
        console.log("gotoComplete,", e);
        var a = this, n = {};
        n.generateId = e.currentTarget.dataset.item.id, t.util.post({
            url: "/vaccination/pointInfo/modifyInoculation",
            loadingTitle: "加载中...",
            showLoading: !1,
            data: n,
            success: function(e) {
                console.log("确认接种成功", e), a.getReserveList();
            },
            fail: function(e) {
                t.util.alert("确认接种失败"), console.log("确认接种失败", e);
            }
        });
    },
    onBlur: function(e) {
        this.vaccineNo = e.detail.value;
    },
    submitStatus: function(e) {
        console.log(this.vaccindValue1), console.log(this.vaccindValue2), console.log(this.vaccindValue3), 
        console.log(this.vaccineNo);
        var a = {};
        a.generateId = e.currentTarget.dataset.id, a.vaccineName = null == this.vaccindValue1 ? "" : this.vaccindValue1, 
        a.vaccineSub = null == this.vaccindValue2 ? "" : this.vaccindValue2, a.filmName = null == this.vaccindValue3 ? "" : this.vaccindValue3, 
        a.vaccineNo = null == this.vaccineNo ? "" : this.vaccineNo, t.util.post({
            url: "/vaccination/pointInfo/updateSubmit",
            loadingTitle: "加载中...",
            showLoading: !1,
            data: a,
            success: function(e) {
                console.log("确认接种成功", e), t.util.alert("确认接种成功"), wx.navigateBack();
            },
            fail: function(e) {
                t.util.alert("确认接种失败"), console.log("确认接种失败", e);
            }
        });
    },
    addDate: function() {},
    openScan: function() {
        var e = this;
        wx.scanCode({
            scanType: [ "barCode" ],
            success: function(a) {
                var n = {}, i = {}, o = 0, c = "", l = 0, s = a.result;
                i.epcCode = s, i.type = 1, void 0 === l && (l = 0), i.operation = l, i["user.country"] = t.user.country, 
                i["user.province"] = t.user.province, i["user.city"] = t.user.city, t.util.post({
                    url: "/vaccine/product/detail",
                    data: i,
                    loadingTitle: "查询中...",
                    success: function(a) {
                        console.log("openScan疫苗详情", a), a.logisticsInfos.forEach(function(e) {
                            e.validDate = e.validDateFrom.split(" ")[0];
                        });
                        var i = a.validDataDiffDay, l = a.recallStatus, r = a.batchReleasePath;
                        (n = a).showType = 1, n.validDataDiffDay = i < 1 ? 0 : i, n.epcCode = t.util.fixedLengthWithSpaceFormat(s, 5), 
                        i < 0 ? (o = 1, c = "该疫苗已过期", n.validDateColour = 0) : n.validDateColour = 1, 1 == l && (o = 1, 
                        c = "该疫苗属于召回疫苗"), r && "" != r && (n.showBatchRelease = 1), n.showTips = o, n.tipsText = c, 
                        console.log("that.data.reserveInfo", e.data.reserveInfo);
                        var u = {
                            batchId: n.batch,
                            generateId: e.data.generateId,
                            vaccineName: n.name,
                            manufacturerName: n.company,
                            epcCode: n.epcCode
                        };
                        t.util.post({
                            url: "/vaccination/pointInfo/updatetUserAppointmentInfo",
                            loadingTitle: "加载中...",
                            showLoading: !1,
                            data: u,
                            success: function(a) {
                                console.log("上传扫码得到的疫苗信息成功", a), t.util.alert("查询成功");
                                var i = e.data.reserveInfo;
                                i.epcCode = n.epcCode, i.manufacturerName = n.company, i.batchId = n.batch, i.vaccineName = n.name, 
                                i.reservationStatus = 4;
                                var o = JSON.parse(e.data.qrdata);
                                o.batchId = i.batchId, o.manufacturerName = i.manufacturerName, o.epcCode = i.epcCode, 
                                o.vaccineName = i.vaccineName, e.setData({
                                    reserveInfo: i,
                                    qrdata: JSON.stringify(o)
                                });
                            },
                            fail: function(e, a) {
                                t.util.alert("查询失败," + a), console.log("上传扫码得到的疫苗信息失败", e);
                            }
                        });
                    },
                    fail: function(a, i) {
                        if ("810" == a) t.util.alert("当前访问人数过多，请稍后重试！"); else if ("90403" == a) {
                            t.util.alert("未查询到数据"), n.showType = 2, e.setData(n);
                            var o = {
                                epcCode: s
                            };
                            t.config.userId && (o.userId = t.config.userId), t.util.post({
                                url: "/vaccination/pointInfo/saveScanCode",
                                data: o,
                                success: function(e) {
                                    console.log("回传为查询到疫苗信息成功");
                                },
                                fail: function(e, a) {
                                    console.log("回传为查询到疫苗信息失败", a);
                                }
                            });
                        } else t.util.alert(i || "服务调用失败！", function() {
                            wx.navigateBack();
                        });
                    }
                });
            },
            fail: function(e) {
                "scanCode:fail" == e.errMsg && (t.util.alert("扫码失败"), wx.hideLoading());
            }
        });
    },
    setValue: function(e, t) {
        var n;
        this.setData((n = {}, (0, a.default)(n, "value".concat(t), e.value), (0, a.default)(n, "displayValue".concat(t), e.label), 
        n));
    },
    onConfirm: function(e) {
        var a = e.currentTarget.dataset.index;
        this.setValue(e.detail, a), this.vaccindValue3 = e.detail.label, console.log("onConfirm".concat(a), e.detail);
    },
    onValueChange: function(e) {
        var a = e.currentTarget.dataset.index;
        console.log("onValueChange".concat(a), e.detail);
    },
    onVisibleChange: function(e) {
        this.setData({
            visible: e.detail.visible
        });
    },
    onClick: function() {
        this.setData({
            visible: !0
        });
    }
});
var e = getApp();

Page({
    data: {
        show: 0,
        loadMoreType: -1,
        pageSize: 30,
        pageIndex: 1,
        list: []
    },
    onLoad: function(e) {
        this.request();
    },
    request: function() {
        var t = this, a = t.data, o = a.list, i = a.pageSize, s = a.pageIndex, r = {};
        r.pageSize = i, r.pageIndex = s, e.util.post({
            url: "/vaccine/query/history/list",
            data: r,
            loadingTitle: "加载中...",
            success: function(e) {
                var r = e.list;
                r.length == i ? (a.pageIndex = parseInt(s) + 1, a.loadMoreType = 1) : a.loadMoreType = 0, 
                a.show = 1, a.list = o.concat(r), t.setData(a);
            }
        });
    },
    toDetail: function(e) {
        var t = e.currentTarget.dataset.index, a = this.data.list[t], o = a.epcCode, i = a.id, s = a.type, r = "";
        "1" == s ? (r = "/pages/product/scan/detail?", r += "epcCode=" + o, r += "&operation=1") : "2" == s && (r = "/pages/product/batchrelease/detail?", 
        r += "id=" + i, r += "&operation=1"), wx.navigateTo({
            url: r
        });
    },
    toLoadMore: function(e) {
        var t = this.data;
        1 == t.loadMoreType && (t.loadMoreType = 2, this.setData(t), this.request());
    }
});
var o = getApp();

Page({
    data: {
        nickName: "",
        avatarUrl: "",
        config: {},
        visibleLogout: !1,
        logoutAlert: "确认退出登录?",
        showBadge: !1
    },
    onLoad: function() {
        wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: "#55CEAE"
        });
    },
    onShow: function() {
        console.log("我的页面onShow生命周期"), this.setData({
            nickName: o.user.nickName,
            avatarUrl: o.user.avatarUrl,
            config: o.config
        }), console.log(this.data.config, this.data.config.userId), this.loadMsgStatus();
    },
    onTabItemTap: function(o) {
        console.log("切换tab", o), wx.removeStorageSync("homeHot"), wx.removeStorageSync("currentCity"), 
        wx.removeStorageSync("currentPoint");
    },
    myGetUserInfo: function(e) {
        var n = this;
        "getUserInfo:ok" == e.detail.errMsg ? (console.log("没有获取用户信息, 同意授权", e.detail), 
        o.wxGetUserInfo().then(function(o) {
            var e = o.userInfo;
            n.setData({
                nickName: e.nickName
            }), n.setData({
                avatarUrl: e.avatarUrl
            });
        })) : console.log("没有获取用户信息, 拒绝授权", e.detail.errMsg);
    },
    toVaccineQueryList: function() {
        wx.navigateTo({
            url: "/pages/mine/vaccine/query/list"
        });
    },
    toAccountInfo: function() {
        o.config.userId ? wx.navigateTo({
            url: "/pages/mine/account/accountInfo"
        }) : wx.navigateTo({
            url: "/pages/mine/account/login?to=mineReserveList"
        });
    },
    toReserveList: function() {
        o.config.userId ? wx.navigateTo({
            url: "/pages/mine/reserve/list"
        }) : wx.navigateTo({
            url: "/pages/mine/account/login?to=mineReserveList"
        });
    },
    toFamilyList: function() {
        o.config.userId ? wx.navigateTo({
            url: "/pages/mine/family/list"
        }) : wx.navigateTo({
            url: "/pages/mine/account/login?to=mineFamilyList"
        });
    },
    goToLogin: function() {
        wx.navigateTo({
            url: "/pages/mine/account/login?to=mineMy"
        });
    },
    handleConfirmLogout: function() {
        this.setData({
            visibleLogout: !1
        }), o.config.userId = "", o.config.phone = "", o.config.nickName = "", o.config.firstBook = !0, 
        wx.clearStorageSync("config"), wx.navigateTo({
            url: "/pages/mine/account/login?to=mineMy"
        });
    },
    handleCloseLogout: function() {
        this.setData({
            visibleLogout: !1
        });
    },
    goToLogout: function() {
        this.setData({
            visibleLogout: !0
        });
    },
    onShareAppMessage: function(o) {
        console.log("分享页面", o), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    },
    loadMsgStatus: function() {
        var e = this;
        o.util.post({
            url: "/point/message/getUnreadMessage",
            loadingTitle: "加载中...",
            TerminalType: 2,
            data: {
                userId: o.config.userId
            },
            success: function(o) {
                console.log("获取未读消息数目成功", o), e.setData({
                    loading: !1,
                    showBadge: o.list.length > 0
                });
            },
            fail: function(o) {
                console.log("获取未读消息数目失败", o), e.setData({
                    loading: !1
                });
            }
        });
    },
    gotoMsg: function() {
        wx.navigateTo({
            url: "/pages/mine/msg/msg"
        });
    }
});
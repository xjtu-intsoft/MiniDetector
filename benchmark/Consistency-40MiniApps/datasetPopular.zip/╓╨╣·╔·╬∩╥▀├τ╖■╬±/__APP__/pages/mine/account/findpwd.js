var t, e, o = require("../../../dist/wux/index"), s = require("../../../utils/check.js"), i = getApp();

Page({
    data: {
        msg: "请填写完整预约信息",
        showMsg: !1,
        sendBtnMsg: "发送验证码",
        nickname: "",
        mobile: "",
        password: "",
        rePassword: "",
        verifyCode: "",
        alreadySend: !1,
        second: 60,
        sendCount: 0
    },
    onLoad: function(t) {
        e = t, console.log("注册页面传入参数", e);
    },
    timer: function() {
        var t = this;
        new Promise(function(e, o) {
            var s = setInterval(function() {
                t.setData({
                    second: t.data.second - 1
                }), t.data.second <= 0 && (t.setData({
                    second: 60,
                    alreadySend: !1
                }), e(s));
            }, 1e3);
        }).then(function(t) {
            clearInterval(t);
        });
    },
    sendVerifyCode: function() {
        console.log("发送验证码");
        var t = this;
        return this.data.mobile ? s.isValidPhone(this.data.mobile) ? void i.util.post({
            url: "/point/register/resetPasswordSend",
            loadingTitle: "发送中...",
            data: {
                phone: this.data.mobile
            },
            success: function(e) {
                console.log("验证码发送成功", e), t.setData({
                    alreadySend: !0,
                    sendCount: 1
                }), t.timer();
            },
            fail: function(t, e) {
                console.log("验证码发送失败", t, e), i.util.alert(e || "验证码发送失败");
            }
        }) : (wx.showModal({
            title: "错误信息",
            content: "手机号输入不正确",
            showCancel: !1
        }), !1) : (wx.showModal({
            title: "错误信息",
            content: "请输入手机号！",
            showCancel: !1
        }), !1);
    },
    goToOthers: function() {
        return console.log("注册页面传入参数", e), e.to && "mineReserveList" == e.to ? (wx.redirectTo({
            url: "/pages/mine/reserve/list"
        }), !0) : e.to && "vaccineQueryList" == e.to ? (wx.redirectTo({
            url: "/pages/mine/vaccine/query/list"
        }), !0) : e.to && "mineMy" == e.to ? (wx.switchTab({
            url: "/pages/mine/my"
        }), !0) : !(!e.to || "mineFamilyList" != e.to) && (wx.redirectTo({
            url: "/pages/mine/family/list"
        }), !0);
    },
    bindinputNickname: function(t) {
        this.setData({
            nickname: t.detail.detail.value
        });
    },
    bindinputMobile: function(t) {
        console.log(t), this.setData({
            mobile: t.detail.detail.value
        }), console.log(this.data);
    },
    bindinputPassword: function(t) {
        this.setData({
            password: t.detail.detail.value
        });
    },
    bindinputRePassword: function(t) {
        this.setData({
            rePassword: t.detail.detail.value
        });
    },
    bindinputVerifyCode: function(t) {
        this.setData({
            verifyCode: t.detail.detail.value
        });
    },
    findpwd: function() {
        console.log("findpwd");
    },
    regist: function() {
        console.log("注册");
        if (!this.data.mobile) return this.showErrorMsg("请输入手机号！"), !1;
        if (!i.RegExp.mobile.test(this.data.mobile)) return this.showErrorMsg("手机号格式错误！"), 
        !1;
        if (!i.RegExp.password.test(this.data.password)) return this.showErrorMsg("新密码至少8位，请使用大小写字母、数字、特殊符号组合！"), 
        !1;
        if (!this.data.password) return this.showErrorMsg("请输入新密码！"), !1;
        if (!this.data.rePassword) return this.showErrorMsg("请输入确认新密码！"), !1;
        if (this.data.password != this.data.rePassword) return this.showErrorMsg("两次输入密码不一致"), 
        !1;
        if (!this.data.verifyCode) return this.showErrorMsg("请输入验证码！"), !1;
        if (0 == this.data.sendCount) return this.showErrorMsg("请先获取验证码！"), !1;
        var t = {
            phone: this.data.mobile,
            password: this.data.password,
            confirmPassword: this.data.rePassword,
            verifyCode: this.data.verifyCode
        };
        i.util.post({
            url: "/point/register/resetPassword",
            loadingTitle: "加载中...",
            data: t,
            success: function(t) {
                console.log("密码重置成功", t), (0, o.$wuxDialog)().alert({
                    resetOnClose: !0,
                    title: "密码重置成功",
                    content: "请登录",
                    onConfirm: function(t) {
                        wx.redirectTo({
                            url: "/pages/mine/account/login?to=mineMy"
                        });
                    }
                });
            },
            fail: function(t, e) {
                console.log("密码重置失败", t, e), i.util.alert(e || "密码重置失败");
            }
        });
    },
    showErrorMsg: function(e) {
        var o = this;
        t && clearTimeout(t), o.setData({
            showMsg: !0,
            msg: e
        }), t = setTimeout(function() {
            o.setData({
                showMsg: !1,
                msg: ""
            });
        }, 1200);
    },
    goToLogin: function() {
        console.log("跳转的登录页面传递参数", e), wx.redirectTo({
            url: "/pages/mine/account/login?id=" + e.id + "&pointId=" + e.pointId + "&to=" + e.to
        });
    }
});
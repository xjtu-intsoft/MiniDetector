var e, o, t = require("../../../utils/check.js"), i = getApp();

Page({
    data: {
        msg: "请填写完整预约信息",
        showMsg: !1,
        verifyCode: "",
        mobile: "",
        sendBtnMsg: "发送验证码",
        alreadySend: !1,
        second: 60,
        sendCount: 0
    },
    onLoad: function(e) {
        o = e, console.log("登录页面传入参数", o);
    },
    openTerm1: function() {
        wx.navigateTo({
            url: "/pages/mine/terms/terms1"
        });
    },
    openTerm2: function() {
        wx.navigateTo({
            url: "/pages/mine/terms/terms2"
        });
    },
    openTerm3: function() {
        wx.navigateTo({
            url: "/pages/mine/terms/terms3"
        });
    },
    goToOthers: function() {
        return console.log("注册页面传入参数", o), o.to && "mineReserveList" == o.to ? (wx.redirectTo({
            url: "/pages/mine/reserve/list"
        }), !0) : o.to && "vaccineQueryList" == o.to ? (wx.redirectTo({
            url: "/pages/mine/vaccine/query/list"
        }), !0) : o.to && "mineMy" == o.to ? (wx.switchTab({
            url: "/pages/mine/my"
        }), !0) : o.to && "mineFamilyList" == o.to ? (wx.redirectTo({
            url: "/pages/mine/family/list"
        }), !0) : !(!o.to || "mapListView" != o.to) && (wx.switchTab({
            url: "/pages/reserve/map/map"
        }), !0);
    },
    formSubmit: function(e) {
        console.log("登录表单提交", e.detail.value);
        var t = e.detail.value, n = this;
        return t.mobile ? i.RegExp.mobile.test(t.mobile) ? t.password ? t.verifyCode ? void i.util.post({
            url: "/point/register/login",
            loadingTitle: "加载中...",
            data: {
                phone: t.mobile,
                password: t.password,
                code: t.verifyCode
            },
            success: function(e) {
                console.log("登录成功", e), console.log("跳转预约页面传递参数", o), i.config.openId = e.openId, 
                i.config.userId = e.generateId, i.config.phone = t.mobile, i.config.nickName = e.nickName, 
                console.log("res.secLogon", e.secLogon), i.config.firstBook = 0 == e.secLogon, wx.setStorageSync("config", i.config), 
                console.log("app.config", i.config), n.goToOthers() || wx.redirectTo({
                    url: "/pages/reserve/detail/detail?id=" + o.id + "&pointId=" + o.pointId + "&to=" + o.to
                });
            },
            fail: function(e, o) {
                console.log("登录失败", e, o), 401 == e ? i.util.alert(o) : i.util.alert(o || "登录失败");
            }
        }) : (this.showErrorMsg("请输入验证码！"), !1) : (this.showErrorMsg("请输入密码！"), !1) : (this.showErrorMsg("手机号格式错误！"), 
        !1) : (this.showErrorMsg("请输入手机号！"), !1);
    },
    indinputMobile: function(e) {
        console.log(e), this.setData({
            mobile: e.detail.detail.value
        }), console.log(this.data);
    },
    bindinputMobile: function(e) {
        console.log(e), this.data.mobile = e.detail.value, console.log(this.data.mobile);
    },
    sendVerifyCode: function() {
        console.log("发送验证码");
        this.data.mobile;
        console.log(this.data.mobile);
        var e = this;
        return this.data.mobile ? t.isValidPhone(this.data.mobile) ? void i.util.post({
            url: "/point/register/singleSend",
            loadingTitle: "发送中...",
            data: {
                phone: this.data.mobile,
                type: 1
            },
            success: function(o) {
                console.log("验证码发送成功", o), e.setData({
                    alreadySend: !0,
                    sendCount: 1
                }), e.timer();
            },
            fail: function(e, o) {
                console.log("验证码发送失败", e, o), i.util.alert(o || "验证码发送失败");
            }
        }) : (wx.showModal({
            title: "错误信息",
            content: "手机号输入不正确",
            showCancel: !1
        }), !1) : (wx.showModal({
            title: "提示",
            content: "请输入手机号！",
            showCancel: !1
        }), !1);
    },
    timer: function() {
        var e = this;
        new Promise(function(o, t) {
            var i = setInterval(function() {
                e.setData({
                    second: e.data.second - 1
                }), e.data.second <= 0 && (e.setData({
                    second: 60,
                    alreadySend: !1
                }), o(i));
            }, 1e3);
        }).then(function(e) {
            clearInterval(e);
        });
    },
    showErrorMsg: function(o) {
        var t = this;
        e && clearTimeout(e), t.setData({
            showMsg: !0,
            msg: o
        }), e = setTimeout(function() {
            t.setData({
                showMsg: !1,
                msg: ""
            });
        }, 1200);
    },
    goToRegister: function() {
        console.log("跳转注册页面传递参数", o), wx.redirectTo({
            url: "/pages/mine/account/register?id=" + o.id + "&pointId=" + o.pointId + "&to=" + o.to
        });
    },
    goToFindPWD: function() {
        wx.redirectTo({
            url: "/pages/mine/account/findpwd"
        });
    }
});
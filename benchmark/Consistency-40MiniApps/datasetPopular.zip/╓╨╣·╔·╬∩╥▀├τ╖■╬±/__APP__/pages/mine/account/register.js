var t, e, o = require("../../../utils/check.js"), i = getApp();

Page({
    data: {
        msg: "请填写完整预约信息",
        showMsg: !1,
        sendBtnMsg: "发送验证码",
        nickname: "",
        mobile: "",
        password: "",
        rePassword: "",
        verifyCode: "",
        alreadySend: !1,
        second: 60,
        sendCount: 0,
        belongTo: "",
        visible1: !1,
        selectedPandC: {},
        option1: []
    },
    onLoad: function(t) {
        e = t, console.log("注册页面传入参数", e), this.loadProvinceAndCity();
    },
    timer: function() {
        var t = this;
        new Promise(function(e, o) {
            var i = setInterval(function() {
                t.setData({
                    second: t.data.second - 1
                }), t.data.second <= 0 && (t.setData({
                    second: 60,
                    alreadySend: !1
                }), e(i));
            }, 1e3);
        }).then(function(t) {
            clearInterval(t);
        });
    },
    sendVerifyCode: function() {
        console.log("发送验证码");
        var t = this;
        return this.data.mobile ? o.isValidPhone(this.data.mobile) ? void i.util.post({
            url: "/point/register/singleSend",
            loadingTitle: "发送中...",
            data: {
                phone: this.data.mobile
            },
            success: function(e) {
                console.log("验证码发送成功", e), t.setData({
                    alreadySend: !0,
                    sendCount: 1
                }), t.timer();
            },
            fail: function(t, e) {
                console.log("验证码发送失败", t, e), i.util.alert(e || "验证码发送失败");
            }
        }) : (wx.showModal({
            title: "错误信息",
            content: "手机号输入不正确",
            showCancel: !1
        }), !1) : (wx.showModal({
            title: "错误信息",
            content: "请输入手机号！",
            showCancel: !1
        }), !1);
    },
    goToOthers: function() {
        return console.log("注册页面传入参数", e), e.to && "mineReserveList" == e.to ? (wx.redirectTo({
            url: "/pages/mine/reserve/list"
        }), !0) : e.to && "vaccineQueryList" == e.to ? (wx.redirectTo({
            url: "/pages/mine/vaccine/query/list"
        }), !0) : e.to && "mineMy" == e.to ? (wx.switchTab({
            url: "/pages/mine/my"
        }), !0) : !(!e.to || "mineFamilyList" != e.to) && (wx.redirectTo({
            url: "/pages/mine/family/list"
        }), !0);
    },
    bindinputNickname: function(t) {
        this.setData({
            nickname: t.detail.detail.value
        });
    },
    bindinputMobile: function(t) {
        console.log(t), this.setData({
            mobile: t.detail.detail.value
        }), console.log(this.data);
    },
    bindinputPassword: function(t) {
        this.setData({
            password: t.detail.detail.value
        });
    },
    bindinputRePassword: function(t) {
        this.setData({
            rePassword: t.detail.detail.value
        });
    },
    bindinputVerifyCode: function(t) {
        this.setData({
            verifyCode: t.detail.detail.value
        });
    },
    regist: function() {
        console.log("注册");
        var t = this;
        if (!this.data.mobile) return this.showErrorMsg("请输入手机号！"), !1;
        if (!i.RegExp.mobile.test(this.data.mobile)) return this.showErrorMsg("手机号格式错误！"), 
        !1;
        if (!i.RegExp.password.test(this.data.password)) return this.showErrorMsg("新密码至少8位，请使用大小写字母、数字、特殊符号组合！"), 
        !1;
        if (!this.data.password) return this.showErrorMsg("请输入密码！"), !1;
        if (!this.data.rePassword) return this.showErrorMsg("请输入确认密码！"), !1;
        if (this.data.password != this.data.rePassword) return this.showErrorMsg("两次输入密码不一致"), 
        !1;
        if (!this.data.nickname) return this.showErrorMsg("请输入昵称！"), !1;
        if (!this.data.verifyCode) return this.showErrorMsg("请输入验证码！"), !1;
        if (0 == this.data.sendCount) return this.showErrorMsg("请先获取验证码！"), !1;
        if (!this.data.selectedPandC.detail || !this.data.selectedPandC.detail.options || 2 != this.data.selectedPandC.detail.options.length) return this.showErrorMsg("归属地请选择完整！"), 
        !1;
        var o = {
            phone: this.data.mobile,
            password: this.data.password,
            confirmPassword: this.data.rePassword,
            openId: i.config.openId,
            verifyCode: this.data.verifyCode,
            nickName: this.data.nickname,
            provinceName: this.data.selectedPandC.detail.options[0].label,
            provinceCode: this.data.selectedPandC.detail.options[0].value,
            cityName: this.data.selectedPandC.detail.options[1].label,
            cityCode: this.data.selectedPandC.detail.options[1].value
        };
        i.util.post({
            url: "/point/register/register",
            loadingTitle: "加载中...",
            data: o,
            success: function(o) {
                console.log("注册成功", o), console.log("跳转预约页面传递参数", e), i.config.userId = o, i.config.phone = t.data.mobile, 
                i.config.nickName = t.data.nickname, wx.setStorageSync("config", i.config), console.log("app.config", i.config), 
                t.goToOthers() || wx.redirectTo({
                    url: "/pages/reserve/detail/detail?id=" + e.id + "&pointId=" + e.pointId + "&to=" + e.to
                });
            },
            fail: function(t, e) {
                console.log("注册失败", t, e), i.util.alert(e || "注册失败");
            }
        });
    },
    showErrorMsg: function(e) {
        var o = this;
        t && clearTimeout(t), o.setData({
            showMsg: !0,
            msg: e
        }), t = setTimeout(function() {
            o.setData({
                showMsg: !1,
                msg: ""
            });
        }, 1200);
    },
    goToLogin: function() {
        console.log("跳转的登录页面传递参数", e), wx.redirectTo({
            url: "/pages/mine/account/login?id=" + e.id + "&pointId=" + e.pointId + "&to=" + e.to
        });
    },
    goToApply: function() {
        wx.navigateTo({
            url: "/pages/home/articleList/apply/apply",
            success: function() {},
            fail: function() {},
            complete: function() {}
        });
    },
    onOpen1: function() {
        this.setData({
            visible1: !0
        });
    },
    onClose1: function() {
        this.setData({
            visible1: !1
        });
    },
    onChange1: function(t) {
        this.setData({
            belongTo: t.detail.options.map(function(t) {
                return t.label;
            }).join("-"),
            selectedPandC: t
        }), console.log("onChange1", t);
    },
    loadProvinceAndCity: function() {
        var t = this;
        i.util.post({
            url: "/area/provinceList",
            success: function(e) {
                console.log("省市信息加载成功", e), t.setData({
                    option1: e
                });
            },
            fail: function(t, e) {
                console.log("省市信息加载失败", t, e), i.util.alert(e || "省市信息加载失败");
            }
        });
    }
});
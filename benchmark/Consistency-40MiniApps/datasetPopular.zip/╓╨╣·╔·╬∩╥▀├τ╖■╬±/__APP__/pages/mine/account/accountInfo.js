var e, t, i, o = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/defineProperty")), a = require("../../../utils/check.js"), n = getApp();

Page((e = {
    data: {
        msg: "请填写完整预约信息",
        showMsg: !1,
        sendBtnMsg: "发送验证码",
        nickname: "",
        mobile: "",
        password: "",
        rePassword: "",
        verifyCode: "",
        alreadySend: !1,
        second: 60,
        sendCount: 0,
        info: {},
        belongTo: "",
        visible1: !1,
        selectedPandC: {},
        option1: []
    },
    onLoad: function(e) {
        i = e, console.log("注册页面传入参数", i), this.loadInfo(), this.loadProvinceAndCity();
    },
    timer: function() {
        var e = this;
        new Promise(function(t, i) {
            var o = setInterval(function() {
                e.setData({
                    second: e.data.second - 1
                }), e.data.second <= 0 && (e.setData({
                    second: 60,
                    alreadySend: !1
                }), t(o));
            }, 1e3);
        }).then(function(e) {
            clearInterval(e);
        });
    },
    loadInfo: function() {
        var e = this;
        n.util.post({
            url: "/personal/personalInfo",
            loadingTitle: "请求中...",
            data: {
                userId: n.config.userId
            },
            success: function(t) {
                console.log("loadInfo成功", t);
                var i = "", o = {};
                t.provinceName && t.cityName && (i = t.provinceName + "-" + t.cityName, o = {
                    detail: {
                        options: [ {
                            label: t.provinceName,
                            value: t.provinceCode
                        }, {
                            label: t.cityName,
                            value: t.cityCode
                        } ]
                    }
                }), e.setData({
                    info: t,
                    belongTo: i,
                    selectedPandC: o
                });
            },
            fail: function(e, t) {
                console.log("验证码发送失败", e, t), n.util.alert(t || "获取个人资料失败");
            }
        });
    },
    sendVerifyCode: function() {
        console.log("发送验证码");
        var e = this;
        return this.data.mobile ? a.isValidPhone(this.data.mobile) ? void n.util.post({
            url: "/point/register/singleSend",
            loadingTitle: "发送中...",
            data: {
                phone: this.data.mobile
            },
            success: function(t) {
                console.log("验证码发送成功", t), e.setData({
                    alreadySend: !0,
                    sendCount: 1
                }), e.timer();
            },
            fail: function(e, t) {
                console.log("验证码发送失败", e, t), n.util.alert(t || "验证码发送失败");
            }
        }) : (wx.showModal({
            title: "错误信息",
            content: "手机号输入不正确",
            showCancel: !1
        }), !1) : (wx.showModal({
            title: "错误信息",
            content: "请输入手机号！",
            showCancel: !1
        }), !1);
    },
    goToOthers: function() {
        return console.log("注册页面传入参数", i), i.to && "mineReserveList" == i.to ? (wx.redirectTo({
            url: "/pages/mine/reserve/list"
        }), !0) : i.to && "vaccineQueryList" == i.to ? (wx.redirectTo({
            url: "/pages/mine/vaccine/query/list"
        }), !0) : i.to && "mineMy" == i.to ? (wx.switchTab({
            url: "/pages/mine/my"
        }), !0) : !(!i.to || "mineFamilyList" != i.to) && (wx.redirectTo({
            url: "/pages/mine/family/list"
        }), !0);
    },
    bindinputNickname: function(e) {
        this.setData({
            nickname: e.detail.detail.value
        });
    },
    bindinputMobile: function(e) {
        console.log(e), this.setData({
            mobile: e.detail.detail.value
        }), console.log(this.data);
    },
    bindinputPassword: function(e) {
        this.setData({
            password: e.detail.detail.value
        });
    },
    bindinputRePassword: function(e) {
        this.setData({
            rePassword: e.detail.detail.value
        });
    },
    bindinputVerifyCode: function(e) {
        this.setData({
            verifyCode: e.detail.detail.value
        });
    },
    findpwd: function() {
        console.log("findpwd"), wx.redirectTo({
            url: "/pages/mine/account/changepwd?mobile=" + this.data.mobile
        });
    },
    regist: function() {
        console.log("注册");
        var e = this;
        if (!this.data.mobile) return this.showErrorMsg("请输入手机号！"), !1;
        if (!n.RegExp.mobile.test(this.data.mobile)) return this.showErrorMsg("手机号格式错误！"), 
        !1;
        if (!n.RegExp.password.test(this.data.password)) return this.showErrorMsg("密码至少6位，不允许特殊字符！"), 
        !1;
        if (!this.data.password) return this.showErrorMsg("请输入密码！"), !1;
        if (!this.data.rePassword) return this.showErrorMsg("请输入确认密码！"), !1;
        if (this.data.password != this.data.rePassword) return this.showErrorMsg("两次输入密码不一致"), 
        !1;
        if (!this.data.nickname) return this.showErrorMsg("请输入昵称！"), !1;
        if (!this.data.verifyCode) return this.showErrorMsg("请输入验证码！"), !1;
        if (0 == this.data.sendCount) return this.showErrorMsg("请先获取验证码！"), !1;
        var t = {
            phone: this.data.mobile,
            password: this.data.password,
            confirmPassword: this.data.rePassword,
            openId: n.config.openId,
            verifyCode: this.data.verifyCode,
            nickName: this.data.nickname
        };
        n.util.post({
            url: "/point/register/register",
            loadingTitle: "加载中...",
            data: t,
            success: function(t) {
                console.log("注册成功", t), console.log("跳转预约页面传递参数", i), n.config.userId = t, n.config.phone = e.data.mobile, 
                n.config.nickName = e.data.nickname, wx.setStorageSync("config", n.config), console.log("app.config", n.config), 
                e.goToOthers() || wx.redirectTo({
                    url: "/pages/reserve/detail/detail?id=" + i.id + "&pointId=" + i.pointId + "&to=" + i.to
                });
            },
            fail: function(e, t) {
                console.log("注册失败", e, t), n.util.alert(t || "注册失败");
            }
        });
    },
    showErrorMsg: function(e) {
        var i = this;
        t && clearTimeout(t), i.setData({
            showMsg: !0,
            msg: e
        }), t = setTimeout(function() {
            i.setData({
                showMsg: !1,
                msg: ""
            });
        }, 1200);
    },
    goToLogin: function() {
        console.log("跳转的登录页面传递参数", i), wx.redirectTo({
            url: "/pages/mine/account/login?id=" + i.id + "&pointId=" + i.pointId + "&to=" + i.to
        });
    },
    changeInfo: function() {
        if (!this.data.info.nickName) return this.showErrorMsg("请输入昵称！"), !1;
        if (!this.data.selectedPandC.detail || !this.data.selectedPandC.detail.options || 2 != this.data.selectedPandC.detail.options.length) return this.showErrorMsg("归属地请选择完整！"), 
        !1;
        var e = {
            userId: n.config.userId,
            nickName: this.data.info.nickName,
            provinceName: this.data.selectedPandC.detail.options[0].label,
            provinceCode: this.data.selectedPandC.detail.options[0].value,
            cityName: this.data.selectedPandC.detail.options[1].label,
            cityCode: this.data.selectedPandC.detail.options[1].value
        };
        n.util.post({
            url: "/personal/updatePersonalInfo",
            loadingTitle: "加载中...",
            data: e,
            success: function(e) {
                console.log("个人资料修改成功", e), n.util.alert("个人资料修改成功");
            },
            fail: function(e, t) {
                console.log("个人资料修改失败", e, t), n.util.alert(t || "个人资料修改失败");
            }
        });
    },
    onOpen1: function() {
        this.setData({
            visible1: !0
        });
    },
    onClose1: function() {
        this.setData({
            visible1: !1
        });
    },
    onChange1: function(e) {
        this.setData({
            belongTo: e.detail.options.map(function(e) {
                return e.label;
            }).join("-"),
            selectedPandC: e
        }), console.log("onChange1", e);
    }
}, (0, o.default)(e, "bindinputNickname", function(e) {
    var t = this.data.info;
    t.nickName = e.detail.detail.value, this.setData({
        info: t
    });
}), (0, o.default)(e, "loadProvinceAndCity", function() {
    var e = this;
    n.util.post({
        url: "/area/provinceList",
        success: function(t) {
            console.log("省市信息加载成功", t), e.setData({
                option1: t
            });
        },
        fail: function(e, t) {
            console.log("省市信息加载失败", e, t), n.util.alert(t || "省市信息加载失败");
        }
    });
}), e));
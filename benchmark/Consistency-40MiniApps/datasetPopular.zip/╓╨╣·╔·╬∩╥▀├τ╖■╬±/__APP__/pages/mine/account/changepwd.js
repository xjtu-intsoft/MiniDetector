var t, o, s = require("../../../dist/wux/index"), i = require("../../../utils/check.js"), e = getApp();

Page({
    data: {
        msg: "请填写完整预约信息",
        showMsg: !1,
        sendBtnMsg: "发送验证码",
        nickname: "",
        mobile: "",
        password: "",
        rePassword: "",
        verifyCode: "",
        alreadySend: !1,
        second: 60,
        sendCount: 0,
        oldPassword: "",
        source: 1
    },
    onLoad: function(t) {
        o = t, console.log("注册页面传入参数", o), this.setData({
            mobile: e.config.phone
        });
    },
    timer: function() {
        var t = this;
        new Promise(function(o, s) {
            var i = setInterval(function() {
                t.setData({
                    second: t.data.second - 1
                }), t.data.second <= 0 && (t.setData({
                    second: 60,
                    alreadySend: !1
                }), o(i));
            }, 1e3);
        }).then(function(t) {
            clearInterval(t);
        });
    },
    sendVerifyCode: function() {
        console.log("发送验证码");
        var t = this;
        return this.data.mobile ? i.isValidPhone(this.data.mobile) ? void e.util.post({
            url: "/point/register/singleSend",
            loadingTitle: "发送中...",
            data: {
                phone: this.data.mobile
            },
            success: function(o) {
                console.log("验证码发送成功", o), t.setData({
                    alreadySend: !0,
                    sendCount: 1
                }), t.timer();
            },
            fail: function(t, o) {
                console.log("验证码发送失败", t, o), e.util.alert(o || "验证码发送失败");
            }
        }) : (wx.showModal({
            title: "错误信息",
            content: "手机号输入不正确",
            showCancel: !1
        }), !1) : (wx.showModal({
            title: "错误信息",
            content: "请输入手机号！",
            showCancel: !1
        }), !1);
    },
    goToOthers: function() {
        return console.log("注册页面传入参数", o), o.to && "mineReserveList" == o.to ? (wx.redirectTo({
            url: "/pages/mine/reserve/list"
        }), !0) : o.to && "vaccineQueryList" == o.to ? (wx.redirectTo({
            url: "/pages/mine/vaccine/query/list"
        }), !0) : o.to && "mineMy" == o.to ? (wx.switchTab({
            url: "/pages/mine/my"
        }), !0) : !(!o.to || "mineFamilyList" != o.to) && (wx.redirectTo({
            url: "/pages/mine/family/list"
        }), !0);
    },
    bindinputNickname: function(t) {
        this.setData({
            nickname: t.detail.detail.value
        });
    },
    bindinputMobile: function(t) {
        console.log(t), this.setData({
            mobile: t.detail.detail.value
        }), console.log(this.data);
    },
    bindinputOldPassword: function(t) {
        this.setData({
            oldPassword: t.detail.detail.value
        });
    },
    bindinputPassword: function(t) {
        this.setData({
            password: t.detail.detail.value
        });
    },
    bindinputRePassword: function(t) {
        this.setData({
            rePassword: t.detail.detail.value
        });
    },
    bindinputVerifyCode: function(t) {
        this.setData({
            verifyCode: t.detail.detail.value
        });
    },
    findpwd: function() {
        console.log("findpwd");
    },
    changpwd: function() {
        return this.data.oldPassword ? e.RegExp.password.test(this.data.password) ? this.data.password ? this.data.rePassword ? this.data.password != this.data.rePassword ? (this.showErrorMsg("两次输入新密码不一致"), 
        !1) : void e.util.post({
            url: "/point/register/modifyPassword",
            loadingTitle: "加载中...",
            data: {
                phone: e.config.phone,
                oldPassword: this.data.oldPassword,
                newPassword: this.data.password,
                confirmPassword: this.data.rePassword
            },
            success: function(t) {
                console.log("修改密码成功", t), (0, s.$wuxDialog)().alert({
                    resetOnClose: !0,
                    title: "系统消息",
                    content: "修改密码成功",
                    onConfirm: function(t) {
                        wx.navigateBack();
                    }
                });
            },
            fail: function(t, o) {
                console.log("修改密码成功失败", t, o), e.util.alert(o || "修改密码成功");
            }
        }) : (this.showErrorMsg("请输入确认新密码！"), !1) : (this.showErrorMsg("请输入新密码！"), !1) : (this.showErrorMsg("新密码至少8位，请使用大小写字母、数字、特殊符号组合！"), 
        !1) : (this.showErrorMsg("请输入旧密码！"), !1);
    },
    regist: function() {
        console.log("注册");
        var t = this;
        if (!this.data.mobile) return this.showErrorMsg("请输入手机号！"), !1;
        if (!e.RegExp.mobile.test(this.data.mobile)) return this.showErrorMsg("手机号格式错误！"), 
        !1;
        if (!this.data.password) return this.showErrorMsg("请输入密码！"), !1;
        if (!this.data.rePassword) return this.showErrorMsg("请输入确认密码！"), !1;
        if (this.data.password != this.data.rePassword) return this.showErrorMsg("两次输入密码不一致"), 
        !1;
        if (!this.data.nickname) return this.showErrorMsg("请输入昵称！"), !1;
        if (!this.data.verifyCode) return this.showErrorMsg("请输入验证码！"), !1;
        if (0 == this.data.sendCount) return this.showErrorMsg("请先获取验证码！"), !1;
        var s = {
            phone: this.data.mobile,
            password: this.data.password,
            confirmPassword: this.data.rePassword,
            openId: e.config.openId,
            verifyCode: this.data.verifyCode,
            nickName: this.data.nickname
        };
        e.util.post({
            url: "/point/register/register",
            loadingTitle: "加载中...",
            data: s,
            success: function(s) {
                console.log("注册成功", s), console.log("跳转预约页面传递参数", o), e.config.userId = s, e.config.phone = t.data.mobile, 
                e.config.nickName = t.data.nickname, wx.setStorageSync("config", e.config), console.log("app.config", e.config), 
                t.goToOthers() || wx.redirectTo({
                    url: "/pages/reserve/detail/detail?id=" + o.id + "&pointId=" + o.pointId + "&to=" + o.to
                });
            },
            fail: function(t, o) {
                console.log("注册失败", t, o), e.util.alert(o || "注册失败");
            }
        });
    },
    showErrorMsg: function(o) {
        var s = this;
        t && clearTimeout(t), s.setData({
            showMsg: !0,
            msg: o
        }), t = setTimeout(function() {
            s.setData({
                showMsg: !1,
                msg: ""
            });
        }, 1200);
    },
    goToLogin: function() {
        console.log("跳转的登录页面传递参数", o), wx.redirectTo({
            url: "/pages/mine/account/login?id=" + o.id + "&pointId=" + o.pointId + "&to=" + o.to
        });
    }
});
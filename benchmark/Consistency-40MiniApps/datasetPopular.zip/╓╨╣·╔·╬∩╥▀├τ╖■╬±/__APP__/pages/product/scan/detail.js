var e = getApp();

Page({
    data: {
        showType: 0,
        showTips: 0,
        tipsText: "",
        validDateColour: -1,
        showBatchRelease: 0
    },
    onLoad: function(e) {
        this.request(e);
    },
    request: function(t) {
        var a = this, o = {}, i = {}, s = 0, l = "", c = t.operation, n = t.epcCode;
        i.epcCode = n, i.type = 1, void 0 === c && (c = 0), i.operation = c, i["user.country"] = e.user.country, 
        i["user.province"] = e.user.province, i["user.city"] = e.user.city, e.util.post({
            url: "/vaccine/product/detail",
            data: i,
            loadingTitle: "查询中...",
            success: function(t) {
                console.log("疫苗详情", t), t.logisticsInfos.forEach(function(e) {
                    e.validDate = e.validDateFrom.split(" ")[0];
                });
                var i = t.validDataDiffDay, c = t.recallStatus, r = t.batchReleasePath;
                (o = t).showType = 1, o.validDataDiffDay = i < 1 ? 0 : i, o.epcCode = e.util.fixedLengthWithSpaceFormat(n, 5), 
                i < 0 ? (s = 1, l = "该疫苗已过期", o.validDateColour = 0) : o.validDateColour = 1, 1 == c && (s = 1, 
                l = "该疫苗属于召回疫苗"), r && "" != r && (o.showBatchRelease = 1), o.showTips = s, o.tipsText = l, 
                a.setData(o);
            },
            fail: function(t, i) {
                if ("810" == t) o.showType = 3, a.setData(o); else if ("90403" == t) {
                    o.showType = 2, a.setData(o);
                    var s = {
                        epcCode: n
                    };
                    e.config.userId && (s.userId = e.config.userId), e.util.post({
                        url: "/vaccination/pointInfo/saveScanCode",
                        data: s,
                        success: function(e) {
                            console.log("回传为查询到疫苗信息成功");
                        },
                        fail: function(e, t) {
                            console.log("回传为查询到疫苗信息失败", t);
                        }
                    });
                } else e.util.alert(i || "服务调用失败！", function() {
                    wx.navigateBack();
                });
            }
        });
    },
    toLogisticsDetail: function() {
        var e = this.data.logisticsInfos, t = "../logistics/detail?info=" + JSON.stringify(e);
        wx.navigateTo({
            url: t
        });
    },
    toBatchReleaseFile: function() {
        var e = "../batchrelease/file/detail?filePath=" + this.data.batchReleasePath;
        wx.navigateTo({
            url: e
        });
    },
    onShareAppMessage: function(e) {
        console.log("分享页面", e), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    }
});
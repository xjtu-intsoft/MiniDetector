var a = getApp();

Page({
    data: {
        showType: -1,
        loadMoreType: -1,
        list: [],
        pageSize: 30,
        pageIndex: 0
    },
    onLoad: function(a) {
        var e = this.data, t = a.batch, n = a.vaccineName, c = a.manufacturerName;
        e.vaccineName = n, e.batch = t, c && (e.manufacturerName = c), this.request();
    },
    request: function() {
        var e = this, t = e.data, n = t.list, c = t.pageSize, o = t.pageIndex, i = t.vaccineName, r = t.batch, s = t.manufacturerName, u = {};
        s && (u.manufacturerName = s), u.vaccineName = i, u.batch = r, u.pageSize = c, u.pageIndex = o, 
        a.util.post({
            url: "/vaccine/product/batchrelease/query/list",
            data: u,
            loadingTitle: "加载中...",
            success: function(a) {
                var i = a.list;
                i.length == c ? (t.pageIndex = parseInt(o) + 1, t.loadMoreType = 1) : t.loadMoreType = 0, 
                t.showType = 1, t.list = n.concat(i), e.setData(t);
            },
            fail: function(n, c) {
                if ("810" == n) {
                    t.showType = 3, t.showType = 2, e.setData(t);
                    var o = {
                        vaccineName: t.vaccineName,
                        batchId: t.batch,
                        manufacturerName: t.manufacturerName
                    };
                    a.config.userId && (o.userId = a.config.userId), a.util.post({
                        url: "/vaccination/pointInfo/saveScanCode",
                        data: o,
                        success: function(a) {
                            console.log("回传为查询到疫苗信息成功");
                        },
                        fail: function(a, e) {
                            console.log("回传为查询到疫苗信息失败", e);
                        }
                    });
                } else "90404" == n ? a.util.alert(c || "服务调用失败！", function() {
                    wx.navigateBack();
                }) : a.util.alert("服务调用失败！", function() {
                    wx.navigateBack();
                });
            }
        });
    },
    toDetail: function(a) {
        var e = a.currentTarget.dataset.index, t = this.data.list[e], n = "/pages/product/batchrelease/detail?", c = !1;
        for (var o in t) {
            c ? n += "&" : c = !0, n += o + "=" + t[o].toString().replace("?", "@").replace("=", "$");
        }
        console.info(n), wx.navigateTo({
            url: n
        });
    },
    toLoadMore: function(a) {
        var e = this.data;
        1 == e.loadMoreType && (e.loadMoreType = 2, this.setData(e), this.request());
    },
    onShareAppMessage: function(a) {
        console.log("分享页面", a), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    }
});
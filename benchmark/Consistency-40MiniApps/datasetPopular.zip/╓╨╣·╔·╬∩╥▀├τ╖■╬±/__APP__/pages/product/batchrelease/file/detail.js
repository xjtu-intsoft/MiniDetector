getApp();

Page({
    data: {},
    onLoad: function(t) {
        var e = this;
        wx.getSystemInfo({
            success: function(i) {
                e.init(t, i);
            }
        });
    },
    init: function(t, e) {
        var i = {}, a = e.windowWidth, n = e.windowHeight - 6, o = t.filePath;
        i.filePath = o, i.width = a + "px", i.height = n + "px", this.setData(i);
    },
    previewImage: function() {
        var t = this.data.filePath;
        wx.previewImage({
            urls: [ t ]
        });
    },
    onShareAppMessage: function(t) {
        console.log("分享页面", t), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    }
});
var a = getApp();

Page({
    data: {
        show: 0,
        validDateColour: -1,
        showTips: 0,
        tipsText: ""
    },
    onLoad: function(a) {
        var t = {};
        for (var e in a) {
            var i = a[e].toString().replace("@", "?").replace("$", "=");
            t[e] = i;
        }
        this.request(t);
    },
    request: function(t) {
        var e = this, i = {}, r = {};
        for (var o in t) r[o] = t[o].toString();
        r["user.country"] = a.user.country, r["user.province"] = a.user.province, r["user.city"] = a.user.city, 
        r.type = 2, a.util.post({
            url: "/vaccine/product/batchrelease/detail",
            data: r,
            loadingTitle: "加载中...",
            success: function(a) {
                var t = 0, r = "", o = a.validDataDiffDay, c = a.recallStatus;
                i.validDataDiffDay = o < 1 ? 0 : o, o < 0 ? (t = 1, r = "该疫苗已过期", i.validDateColour = 0) : i.validDateColour = 1, 
                1 == c && (t = 1, r = "该疫苗属于召回疫苗"), i.showTips = t, i.tipsText = r, i.productName = a.productName, 
                i.batch = a.batch, i.manufacturerName = a.manufacturerName, i.packingSpecificationName = a.packingSpecificationName, 
                i.vaildDate = a.vaildDate, i.recallStatus = a.recallStatus, i.batchCode = a.batchCode, 
                i.quantity = a.quantity, i.path = a.path, i.show = 1, e.setData(i);
            }
        });
    },
    toBatchReleaseFile: function() {
        var a = "file/detail?filePath=" + this.data.path;
        wx.navigateTo({
            url: a
        });
    },
    onShareAppMessage: function(a) {
        console.log("分享页面", a), myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    }
});
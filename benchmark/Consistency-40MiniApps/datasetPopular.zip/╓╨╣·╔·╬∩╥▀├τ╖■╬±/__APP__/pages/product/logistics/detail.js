getApp();

Page({
    data: {
        showType: 0
    },
    onLoad: function(e) {
        var t = {}, o = JSON.parse(e.info);
        o.length > 0 ? (t.showType = 1, this.wrapScreen(o)) : t.showType = 2, this.setData(t), 
        this.handleList(o);
    },
    handleList: function(e) {
        console.log(JSON.stringify(e)), e.forEach(function(e) {
            console.log("indexOfCDC", e.logisticsStage.indexOf("CDC")), console.log("indexOf接种", e.logisticsStage.indexOf("接种")), 
            -1 != e.logisticsStage.indexOf("CDC") || -1 != e.logisticsStage.indexOf("接种") ? (console.log("CDC/接种", e.logisticsStage), 
            e.DateFormat = e.validDate, e.unitName = "") : (console.log("不是CDC/接种", e), e.DateFormat = e.validDateFromFrom.split(" ")[0] + " 至 " + e.validDate);
        }), console.log("info", JSON.parse(JSON.stringify(e))), this.setData({
            list: e
        });
    },
    wrapScreen: function(e) {
        var t = !0, o = !0;
        for (var i in e) {
            var s = e[i];
            t = !0, o = !0;
            "接种" == s.logisticsStage && (t = !1, o = !1), s.showTemperatureStatus = t, s.showConsignmentCode = o;
        }
    },
    onShareAppMessage: function(e) {
        myRes = {
            from: "",
            target: "",
            webViewUrl: ""
        };
    }
});
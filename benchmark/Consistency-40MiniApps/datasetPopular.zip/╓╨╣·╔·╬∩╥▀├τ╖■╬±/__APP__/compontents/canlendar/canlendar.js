Component({
    data: {
        hasEmptyGrid: !1,
        cur_year: "",
        cur_month: ""
    },
    lifetimes: {
        attached: function() {
            console.log("进入组件生命周期", this), this.setNowDate();
        }
    },
    methods: {
        setNowDate: function() {
            console.log("this", this);
            var t = new Date(), e = t.getFullYear(), a = t.getMonth() + 1, s = t.getDate() - 1;
            console.log("日期：".concat(s));
            this.calculateEmptyGrids(e, a), this.calculateDays(e, a), this.setData({
                cur_year: e,
                cur_month: a,
                weeks_ch: [ "日", "一", "二", "三", "四", "五", "六" ],
                todayIndex: s
            });
        },
        calculateEmptyGrids: function(t, e) {
            var a = this.getFirstDayOfWeek(t, e), s = [];
            if (a > 0) {
                for (var r = 0; r < a; r++) s.push(r);
                this.setData({
                    hasEmptyGrid: !0,
                    empytGrids: s
                });
            } else this.setData({
                hasEmptyGrid: !1,
                empytGrids: []
            });
        },
        calculateDays: function(t, e) {
            for (var a = [], s = this.getThisMonthDays(t, e), r = 1; r <= s; r++) a.push(r);
            this.setData({
                days: a
            });
        },
        getThisMonthDays: function(t, e) {
            return new Date(t, e, 0).getDate();
        },
        getFirstDayOfWeek: function(t, e) {
            return new Date(Date.UTC(t, e - 1, 1)).getDay();
        },
        handleCalendar: function(t) {
            var e = t.currentTarget.dataset.handle, a = this.data.cur_year, s = this.data.cur_month;
            if ("prev" === e) {
                var r = s - 1, i = a;
                r < 1 && (i = a - 1, r = 12), console.log("月份向前，月份：", r, "年份：", i), this.calculateDays(i, r), 
                this.calculateEmptyGrids(i, r), this.setData({
                    cur_year: i,
                    cur_month: r
                });
            } else {
                var c = s + 1, n = a;
                c > 12 && (n = a + 1, c = 1), console.log("月份向后，月份：", c, "年份：", n), this.calculateDays(n, c), 
                this.calculateEmptyGrids(n, c), this.setData({
                    cur_year: n,
                    cur_month: c
                });
            }
        },
        dateSelectAction: function(t) {
            var e = t.currentTarget.dataset.idx;
            this.setData({
                todayIndex: e
            }), e = 2 == (e = (Number(e) + 1).toString()).length ? e : "0" + e, console.log(e);
            var a = Number(this.data.cur_month).toString();
            a = 2 == a.length ? a : "0" + a, console.log(a), this.triggerEvent("selectdate", this.data.cur_year + "-" + a + "-" + e);
        }
    }
});
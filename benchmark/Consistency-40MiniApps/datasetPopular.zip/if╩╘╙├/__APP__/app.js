var e = require("utils/kissy.js"), o = require("utils/io.js"), t = require("config.js"), n = (require("utils/stat.js"), 
require("./utils/ald-stat.js"), t.MEMBER_PASSPORT_KEY), a = require("pages/tools/wetoast.js").WeToast;

App({
    WeToast: a,
    onLaunch: function() {
        var e = this;
        console.log("onLaunch"), e._loginWithCode(), wx.getUpdateManager && e.checkForUpdate(), 
        wx.cloud && wx.cloud.init({
            env: "release-ae89eb",
            traceUser: !0
        });
    },
    onShow: function(e) {
        console.log("onShow");
        var o = e.scene;
        1058 == o ? wx.setStorageSync("needShowHomeButtonInTryDetail", "true") : wx.setStorageSync("needShowHomeButtonInTryDetail", "fail"), 
        console.log("scene in App onshow = ", o);
    },
    checkForUpdate: function() {
        var e = wx.getUpdateManager();
        e.onCheckForUpdate(function(e) {
            var o = e.hasUpdate;
            console.log("onCheckForUpdate, hasUpdate = ", o);
        }), e.onUpdateReady(function() {
            wx.showModal({
                title: "发现新版本啦",
                content: "【if试用】发布了新版本，建议您立即更新，来体验最新的功能。",
                cancelText: "暂时放弃",
                confirmText: "一键更新",
                success: function(o) {
                    o.confirm && setTimeout(function() {
                        e.applyUpdate();
                    }, 600);
                }
            }), console.log("onUpdateReady");
        }), e.onUpdateFailed(function() {
            console.log("onUpdateReady");
        }), console.log("checkForUpdate method called");
    },
    canBackToHome: function() {
        return !!this.checkThePageHasOpen("pages/index/index");
    },
    checkThePageHasOpen: function(e) {
        for (var o = getCurrentPages(), t = -1, n = 0; n < o.length; n++) if (o[n].route == e) {
            t = n;
            break;
        }
        return t >= 0;
    },
    isLogin: function() {
        var o = this;
        return !e.isEmptyObject(o.getUser());
    },
    getUser: function() {
        return wx.getStorageSync(n) || {};
    },
    logout: function() {
        try {
            wx.removeStorageSync(n);
        } catch (e) {}
        return !0;
    },
    registerAccount: function(e, t, a, c, s, i) {
        wx.showLoading && wx.showLoading({
            title: "授权中..."
        });
        var r = {
            rd: 10001,
            code: e,
            encryptedData: t,
            iv: a
        };
        o.post({
            data: r,
            success: function(e) {
                var o = e.data;
                wx.setStorageSync(n, o), wx.showToast({
                    title: "授权成功"
                }), c && c();
            },
            fail: function(e) {
                s && s(), U.showErrorToast(e), console.log("注册失败！" + e);
            }
        });
    },
    login: function() {
        this._loginWithCode();
    },
    _loginWithCode: function() {
        wx.login({
            success: function(e) {
                if (e.code) {
                    var t = e.code;
                    o.post({
                        data: {
                            rd: 10001,
                            code: t
                        },
                        success: function(e) {
                            var o = e.data;
                            wx.setStorageSync(n, o);
                        }
                    });
                }
                console.log("wx.login = ", e);
            }
        });
    }
});
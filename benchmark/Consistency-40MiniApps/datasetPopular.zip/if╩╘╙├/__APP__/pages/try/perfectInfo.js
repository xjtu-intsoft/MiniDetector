var a = require("../../utils/kissy.js"), t = require("../../utils/io.js");

Page({
    data: {
        result: {},
        params: {}
    },
    onLoad: function(a) {
        var t = this, e = JSON.parse(decodeURIComponent(a.finishUrl)).url, s = JSON.parse(decodeURIComponent(a.data));
        t.setData({
            naviagteUrl: e,
            result: s
        }), t.handleData();
    },
    handleData: function() {
        var t = this, e = t.data.params;
        a.each(t.data.result, function(t, s) {
            a.each(t.options, function(a, s) {
                a.val == t.default && (e[t.field_name] = a.val);
            });
        }), t.setData({
            params: e
        });
    },
    bindItemClick: function(t) {
        var e = this, s = t.currentTarget.dataset.type, n = t.currentTarget.dataset.value, r = e.data.params, l = e.data.result;
        a.each(l, function(t, e) {
            t.field_name == s && a.each(t.options, function(a, e) {
                a.val == n ? (a.select = !0, r[t.field_name] = a.val) : a.select = !1;
            });
        }), e.setData({
            result: l,
            params: r
        });
    },
    bindFinish: function() {
        var e = this;
        console.log("self.data.params = ", e.data.params);
        var s = 0;
        if (a.each(e.data.params, function(a, t) {
            s++;
        }), console.log("params count = ", s), console.log("data.length = ", e.data.result.length), 
        s == e.data.result.length) {
            var n = JSON.stringify(e.data.params);
            t.post({
                data: {
                    rd: 10056,
                    info: n
                },
                success: function(a) {
                    wx.setStorageSync("needRefreshUserInfo", "true");
                }
            }), wx.redirectTo({
                url: e.data.naviagteUrl
            });
        } else wx.showModal({
            title: "提示",
            content: "请选择完整信息",
            showCancel: !1
        });
    }
});
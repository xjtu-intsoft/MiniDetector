require("../../utils/kissy.js");

var t = require("../../utils/io.js"), a = require("../../wxParse/wxParse.js");

Page({
    data: {
        tryid: 0,
        tryInfo: {},
        trial_list: []
    },
    onLoad: function(t) {
        var a = this;
        a.setData({
            tryid: t.tryid,
            label: t.label
        });
        var e = "LABEL_TYPE_WELFARE" === a.data.label ? "查看福利详情" : "查看试用详情";
        wx.setNavigationBarTitle({
            title: e
        }), a.requestPageData();
    },
    requestPageData: function() {
        var e = this;
        t.get({
            data: {
                rd: 10067,
                tryid: e.data.tryid
            },
            success: function(t) {
                var r = t.data;
                e.setData({
                    tryInfo: r
                }), e.data.tryInfo.content && a.wxParse("content", "html", e.data.tryInfo.content, e, 0);
            },
            fail: function(t) {
                console.log(t);
            }
        });
    },
    bindEnterApplyUser: function() {
        var t = this;
        wx.navigateTo({
            url: "/pages/try/applyUsers?type=0&tryid=" + t.data.tryid + "&label=" + t.data.label
        });
    },
    bindShowTryList: function() {
        var t = this;
        wx.navigateTo({
            url: "/pages/try/applyUsers?type=1&tryid=" + t.data.tryid + "&label=" + t.data.label
        });
    }
});
var t = require("../../utils/kissy.js"), e = require("../../utils/io.js"), i = require("../../config.js"), a = require("../../utils/util.js"), o = require("../../thirds/WxNotificationCenter.js");

Page({
    data: {
        videoPath: "",
        videoTocken: "",
        allowSubmit: !1,
        isSubmitting: !1,
        subButtonTitle: "完成",
        video_info: "",
        tryid: "",
        subject: "",
        text: "",
        starList: [ {
            isSelect: !1
        }, {
            isSelect: !1
        }, {
            isSelect: !1
        }, {
            isSelect: !1
        }, {
            isSelect: !1
        } ],
        score: 0,
        isfilm: "0"
    },
    onLoad: function(e) {
        var i = this;
        i.requestVidoTocken();
        var a = e.tryid, o = e.videoPath, s = e.isfilm;
        i.setData({
            tryid: a,
            videoPath: o,
            isfilm: s
        }), !t.isUndefined(e.productid) && e.productid > 0 && i.setData({
            productid: e.productid
        }), console.log("videoPath and productid = ", o, i.data.productid);
    },
    requestVidoTocken: function() {
        var t = this;
        e.get({
            data: {
                rd: 10061
            },
            success: function(e) {
                t.setData({
                    videoTocken: e.data.token
                });
            }
        });
    },
    bindSubjectInput: function(t) {
        var e = this, i = t.detail.value;
        console.log("bindSubjectInput ", i), e.setData({
            subject: i
        }), e.checkAllowSubmit();
    },
    bindTextInput: function(t) {
        var e = this, i = t.detail.value;
        console.log("bindTextInput", i), e.setData({
            text: i
        }), e.checkAllowSubmit();
    },
    checkAllowSubmit: function() {
        var t = this, e = !1;
        e = !!(t.data.videoPath.length > 0 && t.data.text && t.data.subject) && ("1" != t.data.isfilm || t.data.score > 0), 
        t.setData({
            allowSubmit: e
        });
    },
    formSubmit: function() {
        console.log("formSubmit"), this.uploadData();
    },
    uploadData: function() {
        var t = this, e = {
            token: t.data.videoTocken,
            key: t._getVedioKey(t.data.videoPath)
        };
        wx.showLoading({
            title: "发布中...",
            mask: !0
        }), t.setData({
            allowSubmit: !1,
            subButtonTitle: "正在发布..."
        }), wx.uploadFile({
            url: i.QN_UPLOAD_URL,
            filePath: t.data.videoPath,
            name: "file",
            header: {
                "content-type": "multipart/form-data"
            },
            formData: e,
            success: function(e) {
                console.log("上传成功", e);
                var i = JSON.parse(e.data), a = JSON.stringify(i);
                t.setData({
                    video_info: a
                }), t.requestSubmit();
            },
            fail: function(e) {
                console.log("上传失败", e), t.setData({
                    allowSubmit: !0
                }), a.showErrorToast(e.errMsg);
            }
        });
    },
    requestSubmit: function() {
        var t = this, i = {
            rd: 10062,
            tryid: t.data.tryid,
            subject: t.data.subject,
            text: t.data.text,
            video_info: t.data.video_info,
            productid: t.data.productid
        };
        "1" == t.data.isfilm && (i.points = t.data.score), console.log("评分 ", i.points), 
        e.post({
            data: i,
            success: function(e) {
                wx.setStorageSync("apply_report", "yes"), wx.showToast({
                    title: "发布成功"
                }), "1" == t.data.isfilm && o.postNotificationName("publishFilmPostSuccessNotification"), 
                wx.navigateBack();
            },
            fail: function(e) {
                a.showErrorToast(e), console.log("发布失败:" + e), t.setData({
                    allowSubmit: !0
                });
            }
        });
    },
    _getVedioKey: function(t) {
        var e = t.split(".").pop().toLowerCase();
        Date.prototype.format = function(t) {
            var e = {
                "M+": this.getMonth() + 1,
                "d+": this.getDate(),
                "h+": this.getHours(),
                "m+": this.getMinutes(),
                "s+": this.getSeconds(),
                "q+": Math.floor((this.getMonth() + 3) / 3),
                S: this.getMilliseconds()
            };
            /(y+)/.test(t) && (t = t.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length)));
            for (var i in e) new RegExp("(" + i + ")").test(t) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? e[i] : ("00" + e[i]).substr(("" + e[i]).length)));
            return t;
        };
        var i = new Date();
        return "video/" + i.format("yyyy") + "/" + i.format("MM") + i.format("dd") + "/" + i.format("hh") + i.format("mm") + i.format("ss") + "_" + Math.ceil(1e5 * Math.random()) + "." + e;
    },
    bindClickStar: function(e) {
        var i = this, a = i.data.starList, o = e.currentTarget.dataset.index, s = 2 * (o + 1);
        i.setData({
            score: s
        }), i.checkAllowSubmit(), t.each(a, function(t, e) {
            t.isSelect = e <= o;
        }), i.setData({
            starList: a
        });
    }
});
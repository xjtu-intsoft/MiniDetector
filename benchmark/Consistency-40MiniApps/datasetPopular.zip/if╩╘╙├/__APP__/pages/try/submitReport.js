var t = require("../../utils/kissy.js"), e = require("../../utils/io.js"), a = require("../../config.js"), i = require("../../utils/util.js"), s = require("../../thirds/WxNotificationCenter.js");

Page({
    data: {
        tryid: 0,
        collectid: 0,
        pid: 0,
        text: "",
        imageMaxNum: 9,
        imagePaths: [],
        qnToken: "",
        images: [],
        allowSubmit: !1,
        imagesInfo: {},
        delkey: 10,
        tmplongtapevent: !1,
        isSubmitting: !1,
        subButtonTitle: "完成",
        starList: [ {
            isSelect: !1
        }, {
            isSelect: !1
        }, {
            isSelect: !1
        }, {
            isSelect: !1
        }, {
            isSelect: !1
        } ],
        score: 0,
        isfilm: "0"
    },
    onLoad: function(a) {
        var i = this;
        if (!t.isUndefined(a.tryid) && a.tryid > 0 && i.setData({
            tryid: a.tryid
        }), !t.isUndefined(a.collectid) && a.collectid > 0 && i.setData({
            collectid: a.collectid
        }), !t.isUndefined(a.productid) && a.productid > 0 && i.setData({
            productid: a.productid
        }), i.setData({
            isfilm: a.isfilm
        }), !t.isUndefined(a.post)) {
            var s = JSON.parse(decodeURIComponent(a.post));
            i.setData({
                pid: s.pid,
                subject: s.subject,
                text: s.text,
                imageMaxNum: i.data.imageMaxNum - s.images.length,
                imagePaths: s.imagesBig,
                imagesInfo: s.imagesInfo,
                allowSubmit: !0
            }), s.subject || i.setData({
                allowSubmit: !1
            });
        }
        console.log("self.data.imagesInfo in onload = ", i.data.imagesInfo), e.get({
            data: {
                rd: 10050
            },
            success: function(t) {
                i.setData({
                    qnToken: t.data.token
                });
            }
        });
    },
    bindAddImageBtn: function() {
        var t = this;
        wx.chooseImage({
            count: t.data.imageMaxNum,
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(e) {
                var a = e.tempFilePaths, i = t.data.imagePaths.concat(a);
                t.setData({
                    imagePaths: i,
                    imageMaxNum: t.data.imageMaxNum - a.length
                }), t.checkAllowSubmit();
            }
        });
    },
    bindPreviewImages: function(t) {
        var e = this, a = t.currentTarget.dataset.src;
        e.data.tmplongtapevent ? e.setData({
            tmplongtapevent: !1
        }) : wx.previewImage({
            current: a,
            urls: e.data.imagePaths
        });
    },
    bindSubjectFocusOut: function(t) {
        var e = this;
        e.setData({
            subject: t.detail.value
        }), e.checkAllowSubmit();
    },
    bindTextFocusOut: function(t) {
        var e = this;
        e.setData({
            text: t.detail.value
        }), e.checkAllowSubmit();
    },
    bindShowDeleteBtn: function(t) {
        var e = this, a = t.currentTarget.dataset.key;
        e.setData({
            tmplongtapevent: !0,
            delkey: a
        }), setTimeout(function() {
            e.setData({
                delkey: 10
            });
        }, 3500);
    },
    bindHideDeleteBtn: function() {
        this.setData({
            delkey: 10
        });
    },
    bindDeleteImg: function(e) {
        var a = this, i = e.currentTarget.dataset.key, s = a.data.imagePaths, o = [];
        t.each(s, function(t, e) {
            e != i && o.push(t);
        }), a.setData({
            delkey: 10,
            imagePaths: o,
            imageMaxNum: 9 - o.length
        }), a.checkAllowSubmit();
    },
    checkAllowSubmit: function() {
        var t = this, e = !1;
        e = !!(t.data.imagePaths.length > 0 && t.data.text && t.data.subject) && ("1" != t.data.isfilm || t.data.score > 0), 
        t.setData({
            allowSubmit: e
        });
    },
    formSubmit: function(t) {
        var e = this;
        t.detail.value;
        e.setData({
            allowSubmit: !1,
            isSubmitting: !0,
            subButtonTitle: "正在发布..."
        }), wx.showLoading ? wx.showLoading({
            title: "发布中...",
            mask: !0
        }) : wx.showToast({
            title: "发布中...",
            icon: "loading",
            duration: 6e4,
            mask: !0
        }), wx.setStorageSync("apply_report", "yes"), e._QNUpload(e.data.imagePaths);
    },
    publishReport: function() {
        var a = this, o = a.data.tryid, n = a.data.collectid, l = a.data.text, c = JSON.stringify(a.data.images), d = {
            rd: 10014,
            pid: a.data.pid,
            tryid: o,
            collectid: n,
            productid: a.data.productid,
            subject: a.data.subject,
            text: l,
            images: c
        };
        "1" == a.data.isfilm && (d.points = a.data.score), console.log("评分 ", d.points), 
        e.post({
            data: d,
            success: function(t) {
                a.setData({
                    isSubmitting: !1
                }), wx.showToast({
                    title: "发布成功",
                    icon: "success"
                }), "1" == a.data.isfilm && s.postNotificationName("publishFilmPostSuccessNotification"), 
                wx.navigateBack({
                    delta: 1
                });
            },
            fail: function(e) {
                t.log("发布失败: " + e), i.showErrorToast(e), a.setData({
                    isSubmitting: !1,
                    allowSubmit: !0
                });
            }
        });
    },
    _QNUpload: function(e) {
        var s = this;
        if (t.isEmptyObject(e)) s.publishReport(); else {
            var o = e[0], n = {
                token: s.data.qnToken,
                key: s._getImageKey(o)
            };
            if (o.indexOf("iffashion.cn") >= 0) {
                var l = s.data.imagesInfo[o];
                return console.log("self.data.imagesInfo in _QNUpload = ", s.data.imagesInfo), console.log("tmpPath = ", o), 
                s.setData({
                    images: s.data.images.concat({
                        image: o,
                        width: l.width,
                        height: l.height,
                        size: l.size,
                        imageAve: l.imageAve
                    })
                }), e.splice(0, 1), void s._QNUpload(e);
            }
            wx.uploadFile({
                url: a.QN_UPLOAD_URL,
                filePath: o,
                name: "file",
                header: {
                    "content-type": "multipart/form-data"
                },
                formData: n,
                success: function(a) {
                    var i = JSON.parse(a.data);
                    t.log(i), s.setData({
                        images: s.data.images.concat({
                            image: i.key,
                            width: i.width,
                            height: i.height,
                            size: i.size,
                            imageAve: i.imageAve
                        })
                    }), e.splice(0, 1), s._QNUpload(e);
                },
                fail: function(t) {
                    s.setData({
                        isSubmitting: !1
                    }), i.showErrorToast(t.errMsg), console.log("发布失败", t), s.setData({
                        allowSubmit: !0
                    }), s.setData({
                        images: []
                    });
                }
            });
        }
    },
    _getImageKey: function(t) {
        var e = t.split(".").pop().toLowerCase();
        Date.prototype.format = function(t) {
            var e = {
                "M+": this.getMonth() + 1,
                "d+": this.getDate(),
                "h+": this.getHours(),
                "m+": this.getMinutes(),
                "s+": this.getSeconds(),
                "q+": Math.floor((this.getMonth() + 3) / 3),
                S: this.getMilliseconds()
            };
            /(y+)/.test(t) && (t = t.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length)));
            for (var a in e) new RegExp("(" + a + ")").test(t) && (t = t.replace(RegExp.$1, 1 == RegExp.$1.length ? e[a] : ("00" + e[a]).substr(("" + e[a]).length)));
            return t;
        };
        var a = new Date();
        return "member/" + a.format("yyyy") + "/" + a.format("MM") + a.format("dd") + "/" + a.format("hh") + a.format("mm") + a.format("ss") + "_" + Math.ceil(1e5 * Math.random()) + "." + e;
    },
    bindFloatView: function(e) {
        t.log("bindFloatView click event");
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {
        console.log("onHide");
    },
    onUnload: function() {
        var t = this;
        console.log("onUnload"), t.setData({
            images: []
        });
    },
    bindClickStar: function(e) {
        var a = this, i = a.data.starList, s = e.currentTarget.dataset.index, o = 2 * (s + 1);
        a.setData({
            score: o
        }), a.checkAllowSubmit(), t.each(i, function(t, e) {
            t.isSelect = e <= s;
        }), a.setData({
            starList: i
        });
    }
});
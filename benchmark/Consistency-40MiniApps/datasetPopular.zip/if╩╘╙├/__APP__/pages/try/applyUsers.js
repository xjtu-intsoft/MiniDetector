var t = require("../../utils/kissy.js"), a = require("../../utils/io.js");

Page({
    data: {
        tryid: 0,
        type: 0,
        totals: 0,
        list: [],
        users: {},
        page: 1,
        load_done: !1,
        first_load_done: !1
    },
    onLoad: function(t) {
        var a = this;
        a.setData({
            tryid: t.tryid,
            type: t.type,
            label: t.label
        });
        var e = "0" === a.data.type ? "申请名单" : "LABEL_TYPE_WELFARE" === a.data.label ? "福利名单" : "试用名单";
        wx.setNavigationBarTitle({
            title: e
        });
        var i = "LABEL_TYPE_WELFARE" === a.data.label ? "福利" : "试用";
        a.setData({
            shortTit: i
        }), a.loadData();
    },
    onReachBottom: function() {
        this.loadData();
    },
    loadData: function() {
        var e = this;
        1 != e.data.load_done && a.get({
            data: {
                rd: 10005,
                tryid: e.data.tryid,
                type: e.data.type,
                page: e.data.page
            },
            success: function(a) {
                var i = a.data;
                0 != i.list.length ? e.setData({
                    list: e.data.list.concat(e.canvertData(i.list)),
                    users: t.merge(e.data.users, i.users),
                    totals: i.totals,
                    page: ++e.data.page,
                    first_load_done: !0
                }) : e.setData({
                    load_done: !0,
                    first_load_done: !0
                });
            }
        });
    },
    canvertData: function(a) {
        return t.each(a, function(e, i) {
            a[i].time = t.simpleTime(e.time), a[i].replyTime = t.simpleTime(e.reply_time);
        }), a;
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {}
});
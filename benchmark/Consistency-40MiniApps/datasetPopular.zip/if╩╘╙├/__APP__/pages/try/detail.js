var t = require("../../utils/kissy.js"), a = require("../../utils/io.js"), o = require("../../utils/util.js"), e = require("../../wxParse/wxParse.js"), i = getApp();

Page({
    data: {
        tryid: 0,
        tryInfo: {},
        latest_apply_uids: [],
        latest_try_uids: [],
        tryInfoJson: "",
        tryInfoLoadDone: !1,
        posts: [],
        users: {},
        canBackHome: !1,
        report_num: 0,
        report_page: 1,
        posts_load_done: !1,
        loadEndDataLock: !1,
        fromShare: !1,
        tryNum: 0,
        loginUser: {},
        fromUid: 0,
        isFromWelfare: "0",
        showPopView: !1,
        savedPostion: 0,
        copying: !1,
        windowType: 0,
        hasVideo: !1,
        isfilm: "0",
        isSellProduct: !1,
        isGrowGrassType: !1,
        goodsInfo: {}
    },
    onLoad: function(o) {
        console.log("参数", o);
        var e = this, s = decodeURIComponent(o.scene);
        if (s && "undefined" !== s && s.length > 0 && (o.tryid = s), o.productid && !t.isUndefined(o.productid)) {
            var n = JSON.parse(decodeURIComponent(o.headJson));
            n.status = 400, n.report_num = n.post_num;
            var r = {
                id: o.productid,
                name: n.goods_name,
                min_price: n.min_price
            };
            return e.setData({
                productid: o.productid,
                tryInfo: n,
                isSellProduct: !0,
                tryInfoLoadDone: !0,
                goodsInfo: r,
                isGrowGrassType: !0
            }), e.loadGoodsReoportListData(), void wx.setNavigationBarTitle({
                title: "if 试用详情"
            });
        }
        var d = o.isFromWelfare;
        e.setData({
            tryid: o.tryid,
            isFromWelfare: d
        }), t.isUndefined(o.tryInfo) || (e.setData({
            tryInfo: JSON.parse(decodeURIComponent(o.tryInfo))
        }), e.setData({
            view_num: e.data.tryInfo.view_num
        }), console.log("info= ", e.data.tryInfo));
        try {
            e.setData({
                fromUid: wx.getStorageSync("share_detail_fromUid" + o.tryid) || 0
            });
        } catch (t) {}
        t.isUndefined(o.fromUid) || (e.setData({
            fromUid: o.fromUid
        }), wx.setStorage({
            key: "share_detail_fromUid" + o.tryid,
            data: o.fromUid
        }));
        var p = "true" == wx.getStorageSync("needShowHomeButtonInTryDetail");
        console.log("from1058 = ", p), t.isUndefined(o.fromShare) && !p || a.get({
            data: {
                rd: 10021
            },
            success: function(t) {
                var a = t.data;
                e.setData({
                    fromShare: !0,
                    tryNum: a.tryNum
                });
            }
        });
        var l = i.canBackToHome();
        this.setData({
            showHomeBtn: !l
        }), e.requestTryInfo();
    },
    onShow: function(t) {
        var a = this, o = i.getUser();
        a.setData({
            loginUser: o
        }), wx.getStorageSync("apply_report") && (a.setData({
            posts_load_done: !1,
            posts: [],
            users: {},
            report_page: 1
        }), wx.removeStorage({
            key: "apply_report"
        }), a.data.isGrowGrassType ? a.loadGoodsReoportListData() : a.loadEndData()), wx.getStorageSync("tmp_show_bestie_tap") && (wx.showModal({
            title: "申请提醒",
            content: "你的申请已提交，快邀请好友共同来完成试用申请吧",
            showCancel: !1
        }), wx.removeStorage({
            key: "tmp_show_bestie_tap"
        })), a.requestTryInfo(), a.requestAdditionalUserInfo();
    },
    onUnload: function() {
        wx.setStorageSync("needShowHomeButtonInTryDetail", "fail");
    },
    onReachBottom: function() {
        var t = this;
        t.data.isGrowGrassType ? t.loadGoodsReoportListData() : t.loadEndData();
    },
    requestTryInfo: function() {
        var o = this;
        a.get({
            data: {
                rd: 10004,
                tryid: o.data.tryid,
                fromUid: o.data.fromUid
            },
            success: function(a) {
                o.getVipInfo();
                var i = o.canvertData(a.data);
                t.isEmptyObject(i.bestie) ? i.hasBestie = !1 : i.hasBestie = !0;
                var s = o.reverseArr(i.latest_apply_uids), n = o.reverseArr(i.latest_try_uids), r = "LABEL_TYPE_WELFARE" === i.label ? "if 福利详情" : "if 试用详情";
                wx.setNavigationBarTitle({
                    title: r
                });
                var d = i.average_points ? "1" : "0";
                o.setData({
                    tryInfo: i,
                    latest_apply_uids: s,
                    latest_try_uids: n,
                    tryInfoJson: encodeURIComponent(JSON.stringify(i)),
                    tryInfoLoadDone: !0,
                    isfilm: d
                }), o.loadEndData(), o.data.tryInfo.content && e.wxParse("content", "html", o.data.tryInfo.content, o, 0);
                var p = i.goods_info;
                p && p.id > 0 && o.setData({
                    isSellProduct: !0,
                    goodsInfo: p
                });
            }
        });
    },
    loadEndData: function() {
        var o = this;
        400 == o.data.tryInfo.status && 1 != o.data.posts_load_done && (o.data.loadEndDataLock || (o.setData({
            loadEndDataLock: !0
        }), a.get({
            data: {
                rd: 10013,
                tryid: o.data.tryid,
                page: o.data.report_page
            },
            success: function(a) {
                var e = a.data;
                0 != e.posts.length ? o.setData({
                    posts: o.data.posts.concat(o.canvertPostsData(e.posts)),
                    users: t.merge(o.data.users, e.users),
                    report_page: ++o.data.report_page
                }) : o.setData({
                    posts_load_done: !0
                });
            },
            complete: function() {
                o.setData({
                    loadEndDataLock: !1
                });
            }
        })));
    },
    reverseArr: function(t) {
        for (var a = [], o = t.length - 1; o >= 0; o--) a.push(t[o]);
        return a;
    },
    loadGoodsReoportListData: function() {
        var o = this;
        1 != o.data.posts_load_done && (o.data.loadEndDataLock || (o.setData({
            loadEndDataLock: !0
        }), a.get({
            data: {
                rd: 10069,
                productid: o.data.productid,
                page: o.data.report_page
            },
            success: function(a) {
                var e = a.data;
                0 != e.posts.length ? (o.setData({
                    posts: o.data.posts.concat(o.canvertPostsData(e.posts)),
                    users: t.merge(o.data.users, e.users),
                    report_page: ++o.data.report_page
                }), console.log("posts for goods = ", o.data.posts)) : o.setData({
                    posts_load_done: !0
                });
            },
            complete: function() {
                o.setData({
                    loadEndDataLock: !1
                });
            }
        })));
    },
    requestAdditionalUserInfo: function() {
        var o = this;
        a.get({
            data: {
                rd: 10055
            },
            success: function(a) {
                console.log("10055", a);
                var e = a.data;
                o.data.params;
                t.each(e, function(a, o) {
                    t.each(a.options, function(t, o) {
                        t.val == a.default ? t.select = !0 : t.select = !1;
                    });
                }), o.setData({
                    additionalInfo: e
                });
            },
            fail: function(t) {
                console.log(t);
            }
        });
    },
    bindApplyBtn: function() {
        var o = this;
        i.isLogin() ? o.data.additionalInfo ? o.applyAction() : a.get({
            data: {
                rd: 10055
            },
            success: function(a) {
                console.log("10055", a);
                var e = a.data;
                o.data.params;
                t.each(e, function(a, o) {
                    t.each(a.options, function(t, o) {
                        t.val == a.default ? t.select = !0 : t.select = !1;
                    });
                }), o.setData({
                    additionalInfo: e
                }), o.applyAction();
            },
            fail: function(t) {
                console.log(t);
            }
        }) : wx.navigateTo({
            url: "/pages/login"
        });
    },
    applyAction: function() {
        var a = this, o = {};
        o.tryid = a.data.tryid, 1 == a.data.tryInfo.isApply || t.isUndefined(a.data.tryInfo.bestie.fromUid) || (o.fromUid = a.data.tryInfo.bestie.fromUid), 
        2e3 == a.data.tryInfo.category && (o.isBestie = 1), wx.setStorageSync("cache_apply_params", o);
        var e = "/pages/try/formApply?tryid=" + a.data.tryid;
        if (console.log("self.data.additionalInfo before submit =", a.data.additionalInfo), 
        t.isEmptyObject(a.data.additionalInfo) || "{}" == JSON.stringify(a.data.additionalInfo) || "[]" == JSON.stringify(a.data.additionalInfo) || !a.data.additionalInfo) console.log("000"), 
        wx.navigateTo({
            url: e
        }); else {
            console.log("111");
            var i = {
                url: e
            }, s = "/pages/try/perfectInfo?finishUrl=" + encodeURIComponent(JSON.stringify(i)) + "&data=" + encodeURIComponent(JSON.stringify(a.data.additionalInfo));
            wx.navigateTo({
                url: s
            });
        }
    },
    bindPreviewImage: function(a) {
        var o = this, e = a.currentTarget.dataset.postkey, i = a.currentTarget.dataset.imgkey, s = o.data.posts[e].imagesBig;
        t.log(s[i]), t.log(s), wx.previewImage({
            current: s[i],
            urls: s,
            success: function(t) {}
        });
    },
    bindWriteReportBtn: function() {
        this.setData({
            windowType: 1
        });
        var t = this, a = t.data.scrollTop;
        t.setData({
            showPopView: !0,
            savedPostion: a
        }), t.setData({
            scrollPostion: 0
        });
    },
    bindImageReport: function() {
        var t = this;
        i.isLogin() ? (wx.navigateTo({
            url: "/pages/try/submitReport?tryid=" + t.data.tryid + "&isfilm=" + t.data.isfilm + "&productid=" + t.data.productid
        }), t.bindClose()) : wx.navigateTo({
            url: "/pages/login"
        });
    },
    bindVideoReport: function() {
        var a = this;
        if (i.isLogin()) {
            var o = "ios" == t.system.platform ? [ "拍摄（最长20秒）", "从手机相册选择" ] : [ "拍摄", "从手机相册选择" ];
            wx.showActionSheet({
                itemList: o,
                itemColor: "#000000",
                success: function(t) {
                    0 == t.tapIndex ? a.chooseVideoWithType("camera") : 1 == t.tapIndex && a.chooseVideoWithType("album");
                },
                fail: function(a) {
                    t.log(a.errMsg);
                }
            });
        } else wx.navigateTo({
            url: "/pages/login"
        });
    },
    chooseVideoWithType: function(t) {
        var a = this, e = [];
        e.push(t), wx.chooseVideo({
            sourceType: e,
            maxDuration: 20,
            camera: [ "front", "back" ],
            success: function(t) {
                console.log("成功选取视频了", t.tempFilePath), console.log(t), wx.navigateTo({
                    url: "/pages/try/submitVideoReport?tryid=" + a.data.tryid + "&videoPath=" + t.tempFilePath + "&isfilm=" + a.data.isfilm + "&productid=" + a.data.productid
                }), a.bindClose();
            },
            fail: function(t) {
                console.log(t), t.errMsg && -1 == t.errMsg.indexOf("fail cancel") && o.showErrorToast(t.errMsg), 
                a.bindClose();
            }
        });
    },
    bindLikesBtn: function(t) {
        var o = this, e = t.currentTarget.dataset.postkey, s = t.currentTarget.dataset.pid, n = t.currentTarget.dataset.status;
        i.isLogin() ? (1 == n && (o.data.posts[e].isLike = 1, o.data.posts[e].likes = Number(o.data.posts[e].likes) + 1), 
        2 == n && (o.data.posts[e].isLike = 0, o.data.posts[e].likes = Number(o.data.posts[e].likes) - 1), 
        o.setData({
            posts: o.data.posts
        }), a.get({
            data: {
                rd: 10034,
                pid: s,
                status: n
            },
            success: function(t) {},
            complete: function() {}
        })) : wx.navigateTo({
            url: "/pages/login"
        });
    },
    bindVideoClick: function(t) {
        var a = t.currentTarget.dataset.pid;
        wx.navigateTo({
            url: "/pages/experience/expDetail?pid=" + a
        });
    },
    bindShowMoreBtn: function(a) {
        var o = this, e = a.currentTarget.dataset.pid;
        t.each(o.data.posts, function(t) {
            t.pid == e && (t.showMore = !0);
        }), o.setData({
            posts: o.data.posts
        });
    },
    bindOperateReport: function(a) {
        var o = this, e = a.currentTarget.dataset.pid;
        wx.showActionSheet({
            itemList: [ "编辑" ],
            itemColor: "#000000",
            success: function(a) {
                if (0 == a.tapIndex) {
                    var i = {};
                    t.each(o.data.posts, function(t) {
                        t.pid == e && (i = t);
                    }), i = encodeURIComponent(JSON.stringify(i)), wx.navigateTo({
                        url: "/pages/try/submitReport?tryid=" + o.data.tryid + "&post=" + i
                    });
                }
            },
            fail: function(a) {
                t.log(a.errMsg);
            }
        });
    },
    canvertData: function(a) {
        return t.each(a.rich_text, function(o, e) {
            if ("img" == o.type) {
                var i = t.system.windowWidth - .12 * t.system.windowWidth, s = o.spans.width, n = o.spans.height;
                a.rich_text[e].spans.width = i, a.rich_text[e].spans.height = i / s * n;
            }
        }), a;
    },
    canvertPostsData: function(a) {
        return t.each(a, function(o, e) {
            a[e].pubtime = t.simpleTime(o.time), a[e].replyTime = t.simpleTime(o.reply_time);
        }), a;
    },
    onShareAppMessage: function() {
        var a = this, o = a.data.tryInfo, e = "/pages/try/detail?tryid=" + a.data.tryid + "&fromShare=1";
        return !t.isUndefined(o.bestie.fromUid) && o.bestie.fromUid == a.data.loginUser.uid && t.isUndefined(o.bestie.toUid) && (e = "/pages/try/detail?tryid=" + a.data.tryid + "&fromShare=1&fromUid=" + a.data.loginUser.uid), 
        {
            title: a.data.tryInfo.subject,
            desc: "试用份数：" + a.data.tryInfo.amount,
            path: e
        };
    },
    bindShowFloatView: function() {
        this.setData({
            windowType: 0
        });
        var t = this, a = t.data.scrollTop;
        t.setData({
            showPopView: !0,
            savedPostion: a
        }), t.setData({
            scrollPostion: 0
        });
    },
    showFlowViewOrOpenMiniProg: function() {
        var t = this, a = t.data.tryInfo.product.links.length;
        if (a > 1) t.bindShowFloatView(); else if (1 == a) {
            if ("小程序" !== t.data.tryInfo.product.links[0].origin) return void t.bindShowFloatView();
            var o = t.data.tryInfo.product.links[0].url;
            console.log("product id = ", o), t.openShopMiniProgram(o);
        }
    },
    openShopMiniProgram: function(t) {
        wx.navigateToMiniProgram({
            appId: "wx9882cde4aa06d0f7",
            path: "pages/index/productDetail?id=" + t,
            extraData: {
                foo: "bar"
            },
            envVersion: "trial",
            success: function(t) {}
        });
    },
    bindPopupClick: function() {
        console.log("图层点击了"), this.bindClose();
    },
    bindClose: function() {
        console.log("bindClose");
        var t = this;
        t.setData({
            showPopView: !1,
            nomalShow: !1
        });
        var a = t.data.savedPostion;
        a > 0 && (t.setData({
            scrollPostion: a
        }), t.setData({
            savedPostion: 0
        }));
    },
    bindCopyOrBuy: function(t) {
        var a = this, o = t.currentTarget.dataset.origin, e = t.currentTarget.dataset.value;
        "小程序" === o ? (a.openShopMiniProgram(e), a.bindClose()) : (console.log("复制了 ", e), 
        wx.setClipboardData({
            data: e,
            success: function(t) {
                a.bindClose(), a.setData({
                    copying: !0
                }), setTimeout(function() {
                    a.setData({
                        copying: !1
                    });
                }, 2e3);
            }
        }));
    },
    getVipInfo: function() {
        var t = this, a = i.getUser(), o = !1;
        a && a.vip_info && a.vip_info.uid && (o = !0), t.setData({
            isVip: o
        });
    },
    goTobuy: function(t) {
        var a = this;
        1 == a.data.isSellProduct ? a.openShopMiniProgram(a.data.goodsInfo.id) : a.showFlowViewOrOpenMiniProg();
    },
    bindEnterRules: function() {
        var t = this;
        wx.navigateTo({
            url: "/pages/try/detail_introduce?tryid=" + t.data.tryid + "&label=" + t.data.tryInfo.label
        });
    },
    bindEnterApplyUser: function() {
        var t = this;
        wx.navigateTo({
            url: "/pages/try/applyUsers?tryid=" + t.data.tryid + "&type=0&apply_num=" + t.data.tryInfo.apply_num + "&isFromWelfare=" + t.data.isFromWelfare
        });
    },
    goToIfShop: function() {
        wx.navigateToMiniProgram({
            appId: "wx9882cde4aa06d0f7",
            path: "pages/personal/vip/vipExplain",
            extraData: {
                source: "ifTry"
            }
        });
    }
});
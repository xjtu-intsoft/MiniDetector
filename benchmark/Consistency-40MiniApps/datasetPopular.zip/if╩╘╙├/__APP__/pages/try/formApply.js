var e = require("../../utils/kissy.js"), s = require("../../utils/io.js"), a = require("../../utils/util.js");

Page({
    data: {
        tryid: 0,
        fromUid: 0,
        message: "",
        def_address: {},
        allowSubmit: !1,
        tmp_show_bestie_tap: !1,
        address_id: 0,
        inputText: "",
        completeAddress: ""
    },
    onLoad: function(s) {
        var a = this;
        a.setData({
            tryid: s.tryid
        });
        var d = !1, t = wx.getStorageSync("cache_apply_params");
        e.isUndefined(t.fromUid) || a.setData({
            fromUid: t.fromUid
        }), e.isUndefined(t.isBestie) || (d = !0), wx.removeStorage({
            key: "cache_apply_params"
        }), a.requestTryAddressInfo(a.data.tryid), d && !a.data.fromUid && a.setData({
            tmp_show_bestie_tap: !0
        });
    },
    onShow: function() {
        var s = this, a = wx.getStorageSync("tmpSelectAddress");
        if (a && !e.isEmptyObject(a)) {
            e.log("select_address = " + a);
            var d = a.addressid;
            a.id = d;
            var t = a.location.province.name + a.location.region.name + a.location.conty.name + a.location.other;
            console.log("options点addressID在上级页 onShow" + d), s.setData({
                address_id: d
            }), s.setData({
                def_address: a,
                completeAddress: t
            }), wx.removeStorage({
                key: "tmpSelectAddress"
            });
        }
        var o = wx.getStorageSync("tmpRemovedAddress");
        o && (e.log("removed_address and self.data.address_id = " + s.data.address_id), 
        e.each(o, function(a, d) {
            e.log("addressId = " + a), a == s.data.address_id && (e.log("被删除了"), s.requestTryAddressInfo(s.data.tryid));
        }), wx.removeStorage({
            key: "tmpRemovedAddress"
        }));
        var r = wx.getStorageSync("tmpNeedRefreshTryInfo");
        e.log("needRefresh = " + r), 1 == r && (s.requestTryAddressInfo(s.data.tryid), wx.removeStorage({
            key: "tmpNeedRefreshTryInfo"
        }));
    },
    requestTryAddressInfo: function(a) {
        var d = this;
        s.get({
            data: {
                rd: 10020,
                tryid: a,
                is_new_address: 1
            },
            success: function(a) {
                var t = a.data;
                e.isEmptyObject(t) ? s.get({
                    data: {
                        rd: 10052
                    },
                    success: function(s) {
                        if (s.data.def_address.location) {
                            var a = s.data.def_address.location.province.name + s.data.def_address.location.region.name + s.data.def_address.location.conty.name + s.data.def_address.location.other;
                            d.setData({
                                def_address: s.data.def_address,
                                completeAddress: a
                            }), d.setData({
                                address_id: s.data.def_address.id
                            }), console.log("options点addressID在 申请页 onLoad " + d.data.address_id), e.log(s), 
                            s.data.def_address.location ? (e.log("has_address true in 10052"), d.setData({
                                has_address: !0
                            })) : (e.log("has_address false in 10052"), d.setData({
                                has_address: !1
                            })), d.checkAllowSubmit();
                        }
                    }
                }) : (d.setData({
                    inputText: t.message,
                    def_address: {
                        id: t.address.addressid,
                        consignee: t.address.consignee,
                        mobile: t.address.mobile,
                        completeAddress: t.address.location,
                        postcode: t.address.postcode
                    },
                    completeAddress: t.address.location
                }), d.data.message || d.setData({
                    message: t.message
                }), t.address.location ? (e.log("has_address true in 10020"), d.setData({
                    has_address: !0
                })) : (e.log("has_address false in 10020"), d.setData({
                    has_address: !1
                })), d.checkAllowSubmit(), d.setData({
                    address_id: t.address.addressid
                }), console.log("options点addressID在 申请页 onLoad " + d.data.address_id));
            }
        });
    },
    bindMessageFocusOut: function(e) {
        var s = this;
        s.data.inputText = e.detail.value, s.checkAllowSubmit();
    },
    checkAllowSubmit: function() {
        var s = this;
        e.trim(s.data.inputText) && s.data.has_address ? s.setData({
            allowSubmit: !0
        }) : s.setData({
            allowSubmit: !1
        });
    },
    bindSelectAddress: function() {
        var e = this.data.address_id;
        wx.navigateTo({
            url: "/pages/home/address/list?isSelect=1&isApply=1&selected_addressid=" + e
        });
    },
    bindAdd: function() {
        wx.navigateTo({
            url: "/pages/home/address/add?&tryid=" + this.data.tryid
        });
    },
    formSubmit: function(e) {
        var a = this, d = a.data.tryid, t = a.data.fromUid;
        t ? s.post({
            data: {
                rd: 10041,
                tryid: d,
                fromUid: t
            },
            success: function(s) {
                s.data.hasExistToUid > 0 ? wx.showModal({
                    title: "申请提醒",
                    content: "申请失败，你的好友已经与其他人共同完成了试用申请。你还可以建立新的申请，邀请你的好友共同完成。建立申请请点击确定。",
                    success: function(s) {
                        s.confirm && a._submit(e);
                    }
                }) : a._submit(e);
            },
            fail: function(e) {}
        }) : a._submit(e);
    },
    _submit: function(e) {
        var d = this, t = e.detail.value, o = t.tryid, r = t.message, i = e.detail.formId, n = d.data.fromUid, c = d.data.def_address.consignee, l = d.data.def_address.postcode, m = d.data.def_address.mobile, f = d.data.completeAddress;
        d.setData({
            allowSubmit: !1
        }), wx.showLoading({
            title: "..."
        }), s.post({
            data: {
                rd: 10035,
                tryid: o,
                message: r,
                form_id: i,
                fromUid: n,
                consignee: c,
                postcode: l,
                mobile: m,
                location: f
            },
            success: function(e) {
                try {
                    d.data.tmp_show_bestie_tap && wx.setStorageSync("tmp_show_bestie_tap", 1);
                } catch (e) {}
                a.showSuccessToast("申请完成，在if种草机有购买记录的用户申请成功率更高哦～"), setTimeout(function() {
                    wx.navigateBack({
                        delta: 1
                    });
                }, 2e3);
            },
            fail: function(e) {
                a.showErrorToast(e), d.setData({
                    allowSubmit: !0
                });
            }
        });
    }
});
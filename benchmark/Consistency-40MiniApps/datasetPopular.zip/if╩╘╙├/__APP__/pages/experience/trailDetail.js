require("../../utils/kissy.js");

var a = require("../../utils/io.js"), e = require("../../wxParse/wxParse.js");

Page({
    data: {
        result: {},
        article: ""
    },
    onLoad: function(a) {
        var e = this, t = a.aid;
        e.requestData(t);
    },
    wxParseTagATap: function(a) {
        console.log("wxParseTagATap called");
        var e = a.currentTarget.dataset.src;
        wx.navigateTo({
            url: e
        });
    },
    requestData: function(t) {
        var r = this;
        a.get({
            data: {
                rd: 10060,
                aid: t
            },
            success: function(a) {
                var t = a.data;
                r.setData({
                    result: t,
                    article: t.message
                }), e.wxParse("article", "html", r.data.article, r, 0);
            }
        });
    }
});
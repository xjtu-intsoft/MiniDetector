var e = require("../../utils/kissy.js"), t = require("../../utils/io.js"), a = getApp();

Page({
    data: {
        pid: "",
        data: {},
        famaleIcon: "",
        maleIcon: "",
        isLike: !1,
        isSelf: !1,
        scrollTop: 0,
        hasVideo: !0,
        screenHeight: 0,
        imageList: [ "http://img02.iffashion.cn/member/2017/0831/101840_51194.jpg", "http://img02.iffashion.cn/member/2017/0831/101840_51194.jpg", "http://img02.iffashion.cn/member/2017/0831/101840_51194.jpg", "http://img02.iffashion.cn/member/2017/0831/101840_51194.jpg", "http://img02.iffashion.cn/member/2017/0831/101840_51194.jpg", "http://img02.iffashion.cn/member/2017/0831/101840_51194.jpg", "http://img02.iffashion.cn/member/2017/0831/101840_51194.jpg", "http://img02.iffashion.cn/member/2017/0831/101840_51194.jpg", "http://img02.iffashion.cn/member/2017/0831/101840_51194.jpg", "http://img02.iffashion.cn/member/2017/0831/101840_51194.jpg" ]
    },
    onLoad: function(t) {
        var a = this, i = t.pid;
        a.setData({
            pid: i
        });
        var o = "true" == wx.getStorageSync("needShowHomeButtonInTryDetail");
        console.log("options.fromShare = ", t.fromShare), e.isUndefined(t.fromShare) && !o || a.setData({
            fromShare: !0
        });
        var s = e.system.windowHeight;
        console.log("screenHeight = ", s), a.setData({
            screenHeight: s
        });
    },
    onUnload: function() {
        wx.setStorageSync("needShowHomeButtonInTryDetail", "fail");
    },
    onShow: function() {
        this.requestData();
    },
    requestData: function() {
        var e = this;
        t.get({
            data: {
                rd: 10057,
                pid: e.data.pid
            },
            success: function(t) {
                var i = t.data, o = "0" != i.is_like;
                e.setData({
                    data: i,
                    isLike: o
                }), console.log("self.data = ", e.data.data);
                var s = a.getUser().uid, n = i.user.uid, r = s == n;
                console.log("dataUid = ", n), console.log("myUid = ", s), e.setData({
                    isSelf: r
                });
            },
            fail: function(e) {
                console.log(e);
            }
        });
    },
    bindPreviewImage: function(e) {
        console.log("bindPreviewImage called");
        var t = this, a = e.currentTarget.dataset.imgkey;
        wx.previewImage({
            current: t.data.data.images_big[a],
            urls: t.data.data.images_big,
            success: function(e) {},
            fail: function(e) {
                console.log(e);
            },
            complete: function() {}
        });
    },
    onClickLike: function() {
        if (getApp().isLogin()) {
            var e = this, a = e.data.data, i = "";
            e.data.isLike ? (a.likes--, i = "STATUS_CANCELLIKE") : (a.likes++, i = "STATUS_LIKE"), 
            t.get({
                data: {
                    rd: 10023,
                    pid: e.data.pid,
                    status: i
                },
                success: function(e) {},
                fail: function(e) {}
            }), e.setData({
                data: a,
                isLike: !e.data.isLike
            });
        } else wx.navigateTo({
            url: "/pages/login"
        });
    },
    onShareAppMessage: function() {
        var e = this;
        return {
            title: e.data.data.subject ? e.data.data.subject : e.data.data.user.username + "的试用报告",
            path: "/pages/experience/expDetail?pid=" + e.data.pid + "&fromShare=1"
        };
    },
    onClickShare: function() {},
    bindOperateReport: function(t) {
        var a = this;
        wx.showActionSheet({
            itemList: [ "编辑" ],
            itemColor: "#000000",
            success: function(t) {
                if (0 == t.tapIndex) {
                    var i = a.data.data;
                    i.imagesBig = i.images_big;
                    var o = {};
                    e.each(i.origin_imgs, function(e, t) {
                        o[i.images_big[t]] = e;
                    }), i.imagesInfo = o, console.log("imagesInfo = ", o);
                    var s = encodeURIComponent(JSON.stringify(i));
                    console.log("tryid = ", a.data.tryid), console.log("post = ", i), wx.navigateTo({
                        url: "/pages/try/submitReport?tryid=" + a.data.data.tryid + "&post=" + s
                    });
                }
            },
            fail: function(t) {
                e.log(t.errMsg);
            }
        });
    },
    scroll: function(e) {
        this.setData({
            scrollTop: e.detail.scrollTop
        }), console.log("滚动距离scroll-dis=" + this.data.scrollTop);
    }
});
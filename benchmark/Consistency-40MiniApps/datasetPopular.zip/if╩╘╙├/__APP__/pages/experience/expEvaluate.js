var t = require("../../utils/kissy.js"), e = require("../../utils/io.js"), a = require("../../utils/util.js"), s = require("../../thirds/WxNotificationCenter.js");

Page({
    data: {
        pagetime: "",
        users: {},
        list: [],
        isLoading: !1,
        scrollLeft: 0,
        category_options: [],
        currentType: 0,
        currentTypeId: "",
        filmCateId: "",
        growGrassPage: 1
    },
    onLoad: function(t) {
        var e = this;
        e.requestTypeData(), s.addNotification("publishFilmPostSuccessNotification", e.refreshFilmList, e);
    },
    bindChangeType: function(t) {
        var e = this, a = t.currentTarget.dataset.index, s = e.data.category_options[a];
        e.changeTypeActionWithId(s.id), e.setData({
            currentType: a,
            currentTypeId: s.id
        });
    },
    changeTypeActionWithId: function(e) {
        var a = this;
        a.data.pagetime = "", a.data.selectId = e;
        var s = 0, i = a.data.category_options;
        t.each(i, function(t, a) {
            t.id == e ? (t.isSelect = "true", s = a) : t.isSelect = "false";
        }), a.setData({
            category_options: i
        }), a.setScrollLeft(s), a.setData({
            list: []
        }), a.requestListWithTypeId(e, !0);
    },
    swiperChange: function(e) {
        var a = this, s = e.detail.current, i = a.data.category_options[s], o = a.data.category_options;
        t.each(o, function(t) {
            t.id === i.id ? t.isSelect = "true" : t.isSelect = "false";
        }), a.setData({
            category_options: o
        }), a.setScrollLeft(s);
    },
    setScrollLeft: function(e) {
        for (var a = this, s = 0, i = 0, o = 0; o <= e; o++) {
            var r = 15 * a.data.category_options[o].name.length + 60;
            console.log("currentWidth = ", r), s += r, o == e && (i = r);
        }
        var n = s - i / 2 - t.system.windowWidth / 2;
        n < 0 && (n = 0), a.setData({
            scrollLeft: n
        }), console.log("result = ", n);
    },
    onPullDownRefresh: function() {
        console.log("onPullDownRefresh called");
        var t = this;
        if (!t.data.isLoading) {
            var e = t.data.currentType, a = t.data.category_options[e].id;
            t.requestListWithTypeId(a, !0);
        }
    },
    onReachBottom: function() {
        console.log("onReachBottom called");
        var t = this;
        if (!t.data.isLoading) {
            var e = t.data.currentType, a = t.data.category_options[e].id;
            9999 == a ? t.requestGrowGrassList() : t.requestListWithTypeId(a);
        }
    },
    onShareAppMessage: function() {
        return {
            title: "【if 粉丝评测】 - 选化妆品，看看大家都在怎么说~",
            path: "/pages/experience/expEvaluate"
        };
    },
    requestTypeData: function() {
        var a = this;
        e.get({
            data: {
                rd: 10065
            },
            success: function(e) {
                var s = e.data;
                t.each(s, function(t, e) {
                    0 == e ? (t.isSelect = "true", a.requestListWithTypeId(t.id, !0)) : t.isSelect = "false", 
                    "电影" === t.name && a.setData({
                        filmCateId: t.id
                    });
                }), s.push({
                    id: "9999",
                    name: "种草机"
                }), a.setData({
                    category_options: s
                });
            },
            fail: function(t) {
                console.log(t);
            }
        });
    },
    requestListWithTypeId: function(a, s) {
        var i = this;
        if (9999 != a) {
            i.setData({
                isLoading: !0
            });
            var o = i.data.pagetime;
            s && (o = ""), console.log("pagetime and refresh = ", o, s), e.get({
                data: {
                    rd: 10066,
                    catid: a,
                    pagetime: o
                },
                success: function(e) {
                    var a = e.data.pagetime;
                    i.setData({
                        pagetime: a
                    });
                    var o = e.data.list, r = i.data.list;
                    r = !r || r === [] || s ? o : r.concat(o), console.log("list = ", r), i.setData({
                        list: r
                    });
                    var n = e.data.users, c = i.data.users;
                    t.each(n, function(t, e) {
                        c[e] = t;
                    }), i.setData({
                        users: c
                    }), console.log("users = ", i.data.users), i.setData({
                        isLoading: !1
                    });
                },
                fail: function(t) {
                    console.log(t), i.setData({
                        isLoading: !1
                    });
                },
                complete: function() {
                    wx.stopPullDownRefresh();
                }
            });
        } else i.requestGrowGrassList(s);
    },
    requestGrowGrassList: function(a) {
        var s = this;
        s.setData({
            isLoading: !0
        }), a && (s.data.growGrassPage = 1), e.get({
            data: {
                rd: 10068,
                page: s.data.growGrassPage
            },
            success: function(e) {
                var i = e.data.list;
                t.each(i, function(t) {
                    t.id = t.productid, t.keyword = t.name, t.subject = t.sub_name, t.view_num = t.views;
                });
                var o = s.data.list;
                o = !o || o === [] || a ? i : o.concat(i), console.log("list = ", o), s.setData({
                    list: o
                });
                var r = e.data.users, n = s.data.users;
                t.each(r, function(t, e) {
                    n[e] = t;
                }), s.setData({
                    users: n
                }), console.log("users = ", s.data.users), s.setData({
                    isLoading: !1
                }), s.data.growGrassPage++;
            },
            fail: function(t) {
                console.log(t), s.setData({
                    isLoading: !1
                });
            },
            complete: function() {
                wx.stopPullDownRefresh();
            }
        });
    },
    refreshFilmList: function() {
        console.log("refreshFilmList");
        var t = this, e = t.data.filmCateId;
        t.requestListWithTypeId(e, !0);
    },
    bindItemClick: function(t) {
        var e = this, a = t.currentTarget.dataset.tryid, s = (t.currentTarget.dataset.keyword, 
        "/pages/try/detail?tryid=" + a + "&isfilm=" + (t.currentTarget.dataset.isfilm ? "1" : "0")), i = "", o = t.currentTarget.dataset.productid;
        if (o) {
            var r = t.currentTarget.dataset.idx, n = e.data.list[r];
            s = "/pages/try/detail?productid=" + o + "&headJson=" + (i = encodeURIComponent(JSON.stringify(n)));
        }
        wx.navigateTo({
            url: s
        }), console.log("url = ", s), console.log("itemJson = ", i);
    },
    formSubmit: function(t) {
        var e = t.detail.formId;
        a.postFormId(e), console.log("the formId = ", e);
    }
});
var t = require("../../utils/kissy.js"), e = require("../../utils/io.js"), a = getApp();

Page({
    data: {
        user: {},
        posts: [],
        trys: {},
        activityItems: {},
        page: 1,
        load_done: !1
    },
    onLoad: function(t) {
        var e = this, s = a.getUser();
        e.setData({
            user: s
        });
    },
    onReachBottom: function() {
        var t = this;
        1 != t.data.load_done && t.loadData();
    },
    loadData: function() {
        var a = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], s = this;
        if (a || 1 != s.data.load_done) {
            var i = s.data.page;
            a && (i = 1), e.get({
                data: {
                    rd: 10016,
                    page: i
                },
                success: function(e) {
                    var r = e.data;
                    0 != r.list.length ? a ? s.setData({
                        posts: s.canvertPostsData(r.list),
                        trys: r.trys,
                        activityItems: r.activityItems,
                        users: r.users,
                        page: ++i
                    }) : s.setData({
                        posts: s.data.posts.concat(s.canvertPostsData(r.list)),
                        trys: t.merge(s.data.trys, r.trys),
                        activityItems: t.merge(s.data.activityItems, r.activityItems),
                        users: t.merge(s.data.users, r.users),
                        page: ++i
                    }) : s.setData({
                        load_done: !0
                    });
                }
            });
        }
    },
    bindShowMoreBtn: function(e) {
        var a = this, s = e.currentTarget.dataset.pid;
        t.each(a.data.posts, function(t) {
            t.pid == s && (t.showMore = !0);
        }), a.setData({
            posts: a.data.posts
        });
    },
    bindPreviewImage: function(t) {
        var e = this, a = t.currentTarget.dataset.postkey, s = t.currentTarget.dataset.imgkey, i = e.data.posts[a].imagesBig;
        wx.previewImage({
            current: i[s],
            urls: i,
            success: function(t) {}
        });
    },
    bindVideoClick: function(t) {
        var e = t.currentTarget.dataset.pid;
        wx.navigateTo({
            url: "/pages/experience/expDetail?pid=" + e
        });
    },
    bindOperateReport: function(e) {
        var a = this, s = e.currentTarget.dataset.pid;
        wx.showActionSheet({
            itemList: [ "编辑" ],
            itemColor: "#000000",
            success: function(e) {
                if (0 == e.tapIndex) {
                    var i = {};
                    if (t.each(a.data.posts, function(t) {
                        t.pid == s && (i = t);
                    }), i.tryid > 0) {
                        var r = i.tryid;
                        i = encodeURIComponent(JSON.stringify(i)), wx.navigateTo({
                            url: "/pages/try/submitReport?tryid=" + r + "&post=" + i
                        });
                    }
                    if (i.collectid > 0) {
                        var o = i.collectid;
                        i = encodeURIComponent(JSON.stringify(i)), wx.navigateTo({
                            url: "/pages/try/submitReport?collectid=" + o + "&post=" + i
                        });
                    }
                }
            },
            fail: function(e) {
                t.log(e.errMsg);
            }
        });
    },
    canvertPostsData: function(e) {
        return t.each(e, function(a, s) {
            e[s].pubtime = t.simpleTime(a.time), e[s].replyTime = t.simpleTime(a.reply_time);
        }), e;
    },
    onShow: function() {
        this.loadData(!0);
    },
    showGrowGrassDetail: function(t) {
        var e = this, a = t.currentTarget.dataset.index, s = e.data.posts[a], i = s.product_info;
        i.keyword = i.name, i.subject = i.sub_name, i.view_num = i.views;
        var r = s.productid, o = encodeURIComponent(JSON.stringify(i));
        wx.navigateTo({
            url: "/pages/try/detail?productid=" + r + "&headJson=" + o
        });
    }
});
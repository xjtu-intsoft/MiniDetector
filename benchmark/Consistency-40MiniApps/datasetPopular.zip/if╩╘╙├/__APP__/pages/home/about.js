var n = require("../../config.js");

Page({
    data: {
        version: ""
    },
    onLoad: function(o) {
        this.setData({
            version: n.version
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    bindCopyEmail: function() {
        wx.setClipboardData({
            data: "ifsy@iffashion.cn",
            success: function() {
                wx.showToast({
                    title: "邮箱已复制"
                });
            }
        });
    }
});
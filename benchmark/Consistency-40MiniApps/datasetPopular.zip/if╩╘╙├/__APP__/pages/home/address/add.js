var e = require("../../../utils/kissy.js"), i = require("../../../utils/io.js"), t = require("../../../utils/util.js");

Page({
    data: {
        tryid: 0,
        collectid: 0,
        name: "",
        mobile: "",
        location_other: "",
        postcode: "",
        required_fields: [ "name", "mobile" ],
        isOk: !1,
        provinces: [],
        province_id: 0,
        province: "",
        index: 0,
        cities: [],
        city_id: 0,
        city: "",
        indexCity: 0,
        areas: [],
        area_id: 0,
        area: "",
        indexArea: 0
    },
    requestProvinceCityList: function(t, a) {
        var n = this;
        i.get({
            data: {
                rd: 10045,
                parentId: t > 0 ? t : 1e5
            },
            success: function(e) {
                0 == a ? n.setData({
                    provinces: e.data
                }) : 1 == a ? n.setData({
                    cities: e.data
                }) : 2 == a && n.setData({
                    areas: e.data
                });
            },
            fail: function(i) {
                e.log("请求地址List信息失败，原因：" + i);
            }
        });
    },
    bindPickerChangeProvince: function(i) {
        var t = this, a = i.detail.value, n = t.data.provinces[a].id, d = t.data.provinces[a].name;
        e.log("选择的省份id为" + n + "index = " + a + "indexCity = " + t.data.indexCity), t.setData({
            index: a,
            province_id: n,
            province: d,
            city_id: 0,
            area_id: 0,
            cities: [ {
                name: "请先选择省份"
            } ],
            areas: [ {
                name: "请先选择城市"
            } ],
            indexCity: 0,
            indexArea: 0
        }), t.checkIsOk(), n > 0 && t.requestProvinceCityList(n, 1);
    },
    bindPickerChangeCity: function(i) {
        var t = this, a = i.detail.value, n = t.data.cities[a].id, d = t.data.cities[a].name;
        e.log("选择的城市id为" + n), t.setData({
            indexCity: a,
            indexArea: 0,
            city_id: n,
            city: d,
            area_id: 0,
            areas: [ {
                name: "请先选择城市"
            } ]
        }), t.checkIsOk(), n > 0 && t.requestProvinceCityList(n, 2);
    },
    bindPickerChangeArea: function(i) {
        var t = this, a = i.detail.value, n = t.data.areas[a].id, d = t.data.areas[a].name;
        e.log("选择的区县id为" + n), t.setData({
            indexArea: a,
            area_id: n,
            area: d
        }), t.checkIsOk();
    },
    bindNameInput: function(i) {
        this.setData({
            name: e.trim(i.detail.value)
        }), this.checkIsOk();
    },
    bindMobileInput: function(i) {
        this.setData({
            mobile: e.trim(i.detail.value)
        }), this.checkIsOk();
    },
    bindLocationOther: function(i) {
        this.setData({
            location_other: e.trim(i.detail.value)
        }), this.checkIsOk();
    },
    checkIsOk: function() {
        var i = this, t = !0;
        e.each(i.data.required_fields, function(e) {
            i.data[e] && i.data.area_id && i.data.location_other || (t = !1);
        }), i.setData({
            isOk: t
        });
    },
    formSubmit: function(a) {
        var n = this, d = a.detail.value, o = d.mobile;
        if (/^1[3-8][0-9]{9}$/.test(o)) {
            var c = d.name, s = (d.location_name, d.location_address, d.location_other), r = d.postcode;
            n.setData({
                isOk: !1
            }), i.post({
                data: {
                    rd: 10046,
                    province: n.data.province,
                    provinceId: n.data.province_id,
                    region: n.data.city,
                    regionId: n.data.city_id,
                    conty: n.data.area,
                    contyId: n.data.area_id,
                    other: s,
                    postcode: r,
                    consignee: c,
                    mobile: o
                },
                success: function(e) {
                    n.data.tryid && wx.setStorageSync("tmpNeedRefreshTryInfo", 1), n.data.collectid ? wx.redirectTo({
                        url: "/pages/try/submitReport?collectid=" + n.data.collectid
                    }) : wx.navigateBack({
                        delta: 1
                    });
                },
                fail: function(i) {
                    n.setData({
                        isOk: !0
                    }), t.showErrorToast(i), e.log(errmsg);
                }
            });
        } else wx.showModal({
            title: "提示",
            content: "请确认手机号是否正确",
            showCancel: !1
        });
    },
    onLoad: function(i) {
        var t = this;
        e.isUndefined(i.collectid) || t.setData({
            collectid: i.collectid
        }), e.isUndefined(i.tryid) || t.setData({
            tryid: i.tryid
        }), t.requestProvinceCityList(0, 0), t.setData({
            cities: [ {
                name: "请先选择省份"
            } ],
            areas: [ {
                name: "请先选择省份"
            } ]
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {}
});
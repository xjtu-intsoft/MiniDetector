var a = require("../../../utils/kissy.js"), e = require("../../../utils/io.js"), i = require("../../../utils/util.js");

Page({
    data: {
        addressid: 0,
        name: "",
        mobile: "",
        location_other: "",
        postcode: "",
        required_fields: [ "name", "mobile" ],
        isOk: !0,
        provinces: [],
        province_id: 0,
        province: "",
        index: 0,
        cities: [],
        city_id: 0,
        city: "",
        indexCity: 0,
        areas: [],
        area_id: 0,
        area: "",
        indexArea: 0,
        provinceObj: {},
        cityObj: {},
        areaObj: {}
    },
    onLoad: function(e) {
        var i = this;
        e.addressid;
        a.log(e);
        var t = JSON.parse(decodeURIComponent(e.province)), d = JSON.parse(decodeURIComponent(e.city)), n = JSON.parse(decodeURIComponent(e.area));
        a.log(t), a.log(d), a.log(n), a.log("options province = " + e.province), i.setData({
            addressid: e.addressid,
            mobile: e.mobile,
            name: e.consignee,
            province_id: t.id,
            province: t.name,
            city_id: d.id,
            city: d.name,
            area_id: n.id,
            area: n.name,
            location_other: e.other,
            postcode: e.postcode,
            provinceObj: t,
            cityObj: d,
            areaObj: n
        }), i.requestProvinceCityList(0, 0), i.data.province_id > 0 && i.requestProvinceCityList(i.data.province_id, 1), 
        i.data.city_id > 0 && i.requestProvinceCityList(i.data.city_id, 2), a.log("province_id in onLoad = " + e.province), 
        0 == i.data.province_id ? i.setData({
            cities: [ {
                name: "请先选择省份"
            } ],
            areas: [ {
                name: "请先选择省份"
            } ]
        }) : 0 == i.data.city_id && i.setData({
            areas: [ {
                name: "请先选择城市"
            } ]
        });
    },
    requestProvinceCityList: function(i, t) {
        var d = this;
        e.get({
            data: {
                rd: 10045,
                parentId: i > 0 ? i : 1e5
            },
            success: function(a) {
                if (0 == t) {
                    for (e = 0; e < a.data.length; e++) if (a.data[e].id == d.data.province_id) {
                        d.setData({
                            index: e
                        });
                        break;
                    }
                    d.setData({
                        provinces: a.data
                    });
                } else if (1 == t) {
                    for (e = 0; e < a.data.length; e++) if (a.data[e].id == d.data.city_id) {
                        d.setData({
                            indexCity: e
                        });
                        break;
                    }
                    d.setData({
                        cities: a.data
                    });
                } else if (2 == t) {
                    for (var e = 0; e < a.data.length; e++) if (a.data[e].id == d.data.area_id) {
                        d.setData({
                            indexArea: e
                        });
                        break;
                    }
                    d.setData({
                        areas: a.data
                    });
                }
            },
            fail: function(e) {
                a.log("请求地址List信息失败，原因：" + e);
            }
        });
    },
    bindPickerChangeProvince: function(e) {
        var i = this, t = e.detail.value, d = i.data.provinces[t].id, n = i.data.provinces[t].name;
        a.log("选择的省份id为" + d), i.setData({
            index: e.detail.value,
            indexCity: 0,
            indexArea: 0,
            province_id: d,
            province: n,
            city_id: 0,
            area_id: 0,
            cities: [ {
                name: "请先选择省份"
            } ],
            areas: [ {
                name: "请先选择城市"
            } ]
        }), this.checkIsOk(), d > 0 && i.requestProvinceCityList(d, 1);
    },
    bindPickerChangeCity: function(e) {
        var i = this, t = e.detail.value, d = i.data.cities[t].id, n = i.data.cities[t].name;
        a.log("选择的城市id为" + d), i.setData({
            indexCity: t,
            indexArea: 0,
            city_id: d,
            city: n,
            area_id: 0,
            areas: [ {
                name: "请先选择城市"
            } ]
        }), this.checkIsOk(), d > 0 && i.requestProvinceCityList(d, 2);
    },
    bindPickerChangeArea: function(e) {
        var i = this, t = e.detail.value, d = i.data.areas[t].id, n = i.data.areas[t].name;
        a.log("选择的区县id为" + d), i.setData({
            indexArea: t,
            area_id: d,
            area: n
        }), this.checkIsOk();
    },
    bindNameInput: function(e) {
        a.log(e.detail.value), this.setData({
            name: a.trim(e.detail.value)
        }), this.checkIsOk();
    },
    bindMobileInput: function(e) {
        this.setData({
            mobile: a.trim(e.detail.value)
        }), this.checkIsOk();
    },
    bindLocationOther: function(e) {
        this.setData({
            location_other: a.trim(e.detail.value)
        }), this.checkIsOk();
    },
    checkIsOk: function() {
        var e = this, i = !0;
        a.each(e.data.required_fields, function(t) {
            a.log("self.data.area_id = " + e.data.area_id), e.data[t] && e.data.area_id && e.data.location_other || (i = !1);
        }), e.setData({
            isOk: i
        });
    },
    formSubmit: function(t) {
        var d = this, n = t.detail.value, o = n.mobile;
        if (/^1[3-8][0-9]{9}$/.test(o)) {
            var r = n.name, s = (n.location_name, n.location_address, n.location_other), c = n.postcode;
            d.setData({
                isOk: !1
            }), e.post({
                data: {
                    rd: 10049,
                    addressid: d.data.addressid,
                    province: d.data.province,
                    provinceId: d.data.province_id,
                    region: d.data.city,
                    regionId: d.data.city_id,
                    conty: d.data.area,
                    contyId: d.data.area_id,
                    other: s,
                    postcode: c,
                    consignee: r,
                    mobile: o
                },
                success: function(a) {
                    wx.navigateBack({
                        delta: 1
                    });
                },
                fail: function(e) {
                    d.setData({
                        isOk: !0
                    }), i.showErrorToast(e), a.log(e);
                }
            });
        } else wx.showModal({
            title: "提示",
            content: "请确认手机号是否正确",
            showCancel: !1
        });
    }
});
var e = require("../../../utils/kissy.js"), t = require("../../../utils/io.js"), s = require("../../../utils/util.js");

Page({
    data: {
        isSelect: !1,
        isApply: !1,
        selected_addressid: 0,
        list: [],
        removed_list: []
    },
    onLoad: function(t) {
        var s = this;
        e.log("isApply before set = " + s.data.isApply + " options.selected_addressid = " + t.selected_addressid), 
        1 == t.isSelect && (s.data.isSelect = !0), 1 == t.isApply && (s.setData({
            isApply: !0
        }), e.log("isApply after set = " + s.data.isApply)), t.selected_addressid > 0 && (s.setData({
            selected_addressid: t.selected_addressid
        }), e.log("options点addressID在列表页after setdata " + s.data.selected_addressid));
    },
    loadListData: function() {
        var e = this;
        t.get({
            data: {
                rd: 10047
            },
            success: function(t) {
                e.setData({
                    list: t.data.list
                });
            }
        });
    },
    bindSelect: function(t) {
        var s = this, i = t.currentTarget.id;
        if (s.data.isSelect) {
            var a = {};
            e.each(s.data.list, function(e) {
                e.addressid == i && (a = e);
            }), wx.setStorageSync("tmpSelectAddress", a), wx.navigateBack({
                delta: 1
            });
        }
    },
    bindAdd: function() {
        wx.navigateTo({
            url: "/pages/home/address/add"
        });
    },
    bindSetDefault: function(e) {
        var i = this, a = e.currentTarget.id;
        t.get({
            data: {
                rd: 10048,
                addressid: a
            },
            success: function(e) {
                i.loadListData(), wx.showToast({
                    title: "修改成功",
                    icon: "success",
                    duration: 1e3
                });
            },
            fail: function(e) {
                s.showErrorToast(e);
            }
        });
    },
    bindEdit: function(t) {
        var s = this, i = t.currentTarget.id, a = {};
        e.each(s.data.list, function(e) {
            e.addressid == i && (a = e);
        });
        var d = e.isUndefined(a.postcode) ? "" : a.postcode, o = a.location.province;
        o = encodeURIComponent(JSON.stringify(o));
        var n = a.location.region;
        n = encodeURIComponent(JSON.stringify(n));
        var r = a.location.conty;
        r = encodeURIComponent(JSON.stringify(r)), e.log("province str = " + o), wx.navigateTo({
            url: "/pages/home/address/edit?addressid=" + a.addressid + "&consignee=" + a.consignee + "&mobile=" + a.mobile + "&province=" + o + "&city=" + n + "&area=" + r + "&other=" + a.location.other + "&postcode=" + d
        });
    },
    bindDelete: function(e) {
        var i = this, a = e.currentTarget.id;
        wx.showModal({
            content: "确定要删除?",
            showCancel: !0,
            cancelText: "取消",
            cancelColor: "#000",
            confirmText: "确定",
            confirmColor: "#3CC51F",
            success: function(e) {
                e.confirm && t.post({
                    data: {
                        rd: 10051,
                        addressid: a
                    },
                    success: function() {
                        i.loadListData(), wx.showToast({
                            title: "删除成功",
                            icon: "success",
                            duration: 1e3
                        }), i.data.removed_list.push(a), wx.setStorageSync("tmpRemovedAddress", i.data.removed_list);
                    },
                    fail: function(e) {
                        s.showErrorToast(e);
                    }
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {
        this.loadListData();
    },
    onHide: function() {},
    onUnload: function() {}
});
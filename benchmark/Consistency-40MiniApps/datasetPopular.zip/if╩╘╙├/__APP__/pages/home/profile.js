var a = require("../../utils/kissy.js"), t = require("../../utils/io.js"), e = require("../../utils/util.js"), s = require("../../config.js"), i = getApp();

Page({
    data: {
        user: {},
        isSave: !1,
        qnToken: "",
        isClick: !1,
        isDismiss: !1,
        isToast: !1,
        isAge: !1,
        additionalInfo: {},
        ageInfo: {},
        skinInfo: {},
        additionalInfoParam: {}
    },
    onLoad: function(a) {
        var e = this, s = a.user;
        console.log("userStr = ", s);
        var i = JSON.parse(s);
        e.setData({
            user: i
        }), e.requestAdditionalData(), t.get({
            data: {
                rd: 10050
            },
            success: function(a) {
                e.setData({
                    qnToken: a.data.token
                });
            }
        });
    },
    requestAdditionalData: function() {
        var e = this;
        t.get({
            data: {
                rd: 10055,
                force_show: 1
            },
            success: function(t) {
                var s = t.data;
                a.each(s, function(t, s) {
                    a.each(t.options, function(a, e) {
                        a.val == t.default ? a.select = !0 : a.select = !1;
                    }), "age_range" == t.field_name ? e.setData({
                        ageInfo: t
                    }) : "skin_type" == t.field_name && e.setData({
                        skinInfo: t
                    });
                }), e.setData({
                    additionalInfo: s
                }), console.log("additionalInfo = ", e.data.additionalInfo), console.log("skinInfo = ", e.data.skinInfo);
            },
            fail: function(a) {}
        });
    },
    bindUsernameBlur: function(a) {
        var t = this, e = t.data.user;
        e.username = a.detail.value, t.setData({
            user: e
        });
    },
    bindModifyAvatar: function() {
        var a = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(t) {
                var e = t.tempFilePaths, s = a.data.user;
                s.avatar = e[0], a.setData({
                    user: s,
                    isSave: !0
                });
            },
            fail: function() {},
            complete: function() {}
        });
    },
    bindRemoveName: function() {
        var a = this, t = a.data.user;
        t.username = "", a.setData({
            user: t
        });
    },
    formSubmit: function(a) {
        var n = this, o = a.detail.value, r = n.data.isSave, c = o.username, l = o.avatar;
        if ("" != c) {
            if (wx.showToast({
                icon: "loading",
                title: "保存\b中",
                duration: 1e4,
                mask: !0
            }), r) {
                var d = {
                    token: n.data.qnToken,
                    key: n._getImageKey(l)
                };
                wx.uploadFile({
                    url: s.QN_UPLOAD_URL,
                    filePath: l,
                    name: "file",
                    header: {
                        "content-type": "multipart/form-data"
                    },
                    formData: d,
                    success: function(a) {
                        console.log("上传成功", a);
                        var s = JSON.parse(a.data);
                        t.post({
                            data: {
                                rd: 10017,
                                username: c,
                                avatar: s.key
                            },
                            success: function(a) {
                                wx.setStorageSync("needRefreshUserInfo", "true"), i.login(), wx.showToast({
                                    icon: "success",
                                    title: "保存成功",
                                    duration: 1e4,
                                    mask: !0
                                }), setTimeout(function() {
                                    wx.navigateBack({
                                        delta: 1
                                    });
                                }, 800);
                            },
                            fail: function(a) {
                                e.showErrorToast(a);
                            }
                        });
                    }
                });
            } else t.post({
                data: {
                    rd: 10017,
                    username: c
                },
                success: function(a) {
                    wx.setStorageSync("needRefreshUserInfo", "true"), i.login(), wx.showToast({
                        icon: "success",
                        title: "保存成功"
                    }), setTimeout(function() {
                        wx.navigateBack({
                            delta: 1
                        });
                    }, 800);
                },
                fail: function(a) {
                    e.showErrorToast(a);
                }
            });
            var u = n.data.additionalInfoParam, f = JSON.stringify(u);
            "{}" != f && t.post({
                data: {
                    rd: 10056,
                    info: f
                },
                success: function(a) {
                    wx.setStorageSync("needRefreshUserInfo", "true");
                }
            });
        } else e.showErrorToast("用户名不能为空");
    },
    _QNUpload: function(t) {
        var e = this;
        if (a.isEmptyObject(t)) e.publishReport(); else t[0];
    },
    _getImageKey: function(a) {
        var t = a.split(".").pop().toLowerCase();
        Date.prototype.format = function(a) {
            var t = {
                "M+": this.getMonth() + 1,
                "d+": this.getDate(),
                "h+": this.getHours(),
                "m+": this.getMinutes(),
                "s+": this.getSeconds(),
                "q+": Math.floor((this.getMonth() + 3) / 3),
                S: this.getMilliseconds()
            };
            /(y+)/.test(a) && (a = a.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length)));
            for (var e in t) new RegExp("(" + e + ")").test(a) && (a = a.replace(RegExp.$1, 1 == RegExp.$1.length ? t[e] : ("00" + t[e]).substr(("" + t[e]).length)));
            return a;
        };
        var e = new Date();
        return "member/" + e.format("yyyy") + "/" + e.format("MM") + e.format("dd") + "/" + e.format("hh") + e.format("mm") + e.format("ss") + "_" + Math.ceil(1e5 * Math.random()) + "." + t;
    },
    onDismiss: function() {
        this.setData({
            isClick: !this.data.isClick
        });
    },
    onClickAge: function() {
        console.log("改变点击事件：" + this.data.isClick), this.setData({
            isClick: !this.data.isClick,
            isAge: !0
        });
    },
    onClickSkin: function() {
        console.log("改变点击事件：" + this.data.isClick), this.setData({
            isClick: !this.data.isClick,
            isAge: !1
        });
    },
    bindItemClick: function(t) {
        var e = this, s = t.currentTarget.dataset.clicktype, i = t.currentTarget.dataset.selected;
        if ("age" == s) {
            var n = e.data.ageInfo;
            a.each(n.options, function(a, t) {
                if (a.val == i) {
                    a.select = !0;
                    var s = e.data.user;
                    s.addtional_info || (s.addtional_info = {}), s.addtional_info.age_range = i, e.setData({
                        user: s
                    }), e.data.additionalInfoParam.age_range = i;
                } else a.select = !1;
            }), e.setData({
                ageInfo: n
            });
        } else if ("skin" == s) {
            var o = e.data.skinInfo;
            a.each(o.options, function(a, t) {
                if (a.val == i) {
                    a.select = !0;
                    var s = e.data.user;
                    s.addtional_info || (s.addtional_info = {}), s.addtional_info.skin_type = i, e.setData({
                        user: s
                    }), e.data.additionalInfoParam.skin_type = i;
                } else a.select = !1;
            }), e.setData({
                skinInfo: o
            });
        }
        e.setData({
            isClick: !e.data.isClick
        });
    }
});
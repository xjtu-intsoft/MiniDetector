require("../../utils/kissy.js");

var e, s = require("../../utils/io.js"), n = getApp();

Page({
    data: {
        isLogin: !1,
        user: {},
        unreadNum: 0
    },
    onLoad: function(e) {
        var s = this, t = !1;
        if (n.isLogin()) {
            t = !0;
            var r = n.getUser();
            s.setData({
                user: r
            }), s.requestUserInfo();
        } else t = !1;
        s.setData({
            isLogin: t
        });
    },
    onShow: function() {
        var e = this, s = wx.getStorageSync("needRefreshUserInfo");
        console.log("needRefreshUser = ", s);
        var t = !1;
        if (n.isLogin()) {
            if (t = !0, e.startTimer(), "true" == s) {
                var r = n.getUser();
                e.setData({
                    user: r
                }), e.requestUserInfo();
            }
        } else t = !1;
        console.log("isLogin = ", t), e.setData({
            isLogin: t
        }), console.log("登录状态 ", t);
    },
    onHide: function() {
        clearInterval(e), wx.setStorageSync("needRefreshUserInfo", "false");
    },
    bindLogout: function(e) {
        var s = this;
        wx.showModal({
            content: "确定要退出吗？",
            showCancel: !0,
            cancelColor: "#000000",
            confirmColor: "#3CC51F",
            success: function(e) {
                e.confirm && (n.logout(), s.setData({
                    isLogin: n.isLogin()
                }));
            }
        });
    },
    requestUserInfo: function() {
        var e = this;
        s.get({
            data: {
                rd: 10011
            },
            success: function(s) {
                var n = s.data, t = JSON.stringify(n);
                e.setData({
                    user: n,
                    userStr: t
                }), console.log("userStr = ", t);
            },
            fail: function(e) {}
        });
    },
    requestUnreadMessageNum: function() {
        var e = this;
        s.get({
            data: {
                rd: 10054
            },
            success: function(s) {
                var n = Number(s.data.unread_num);
                e.setData({
                    unreadNum: n
                }), console.log("unreadNum=", n);
            },
            fail: function(e) {
                console.log("request unreadNum fail", e.errmsg);
            }
        });
    },
    startTimer: function() {
        console.log("startTimer");
        var s = this;
        s.requestUnreadMessageNum(), e = setInterval(function() {
            s.requestUnreadMessageNum();
        }, 3e4);
    },
    bindShowMessage: function() {
        var e = this;
        wx.navigateTo({
            url: "/pages/message/index",
            success: function() {
                e.setData({
                    unreadNum: 0
                });
            }
        });
    }
});
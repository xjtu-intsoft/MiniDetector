var t, e = require("../../utils/kissy.js"), a = require("../../utils/io.js"), n = require("../../utils/util.js"), i = require("../../config.js"), o = getApp(), r = i.MEMBER_PASSPORT_KEY;

Page({
    data: {
        underway_list_page: 1,
        underway_list: [],
        underway_loadDone: !1,
        tryNum: 0,
        banner: [],
        unreadNum: 0,
        showShop: 0
    },
    onShow: function() {
        var t = this;
        getApp().isLogin() && t.startTimer();
    },
    debugwxio: function() {
        wx.cloud.callFunction({
            name: "debugwxio",
            data: {
                url: "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=wx9b06e9ccad36c060&secret=f654d54da2ae39841d48713c1abd5826"
            },
            complete: function(t) {
                console.log("xxxxx debugwx res = ", t);
            }
        });
    },
    onHide: function() {
        clearInterval(t);
    },
    onLoad: function(t) {
        var e = this, a = decodeURIComponent(t.scene);
        a && "undefined" != a && a.length > 0 && (console.log("scene in 首页 = ", a), wx.navigateTo({
            url: "/" + a
        })), wx.showLoading({
            title: "加载中..."
        }), e.loadUnderwayListData(), e.requestTryingNum(), wx.cloud.callFunction({
            name: "getShowShopState",
            complete: function(t) {
                var a = t.result;
                e.setData({
                    showShop: a
                }), console.log("xxx showShop = ", a);
            }
        });
    },
    requestLogin: function() {
        wx.login({
            success: function(t) {
                if (t.code) {
                    var e = t.code;
                    wx.getUserInfo({
                        success: function(t) {
                            a.post({
                                data: {
                                    rd: 10001,
                                    code: e,
                                    encryptedData: t.encryptedData,
                                    iv: t.iv
                                },
                                success: function(t) {
                                    var e = t.data;
                                    wx.setStorageSync(r, e), console.log("首页授权成功");
                                },
                                fail: function(t) {}
                            });
                        },
                        fail: function(t) {}
                    });
                }
            },
            fail: function(t) {}
        });
    },
    showErrorAlert: function(t) {
        console.log("授权异常:", t);
        var e = "授权异常:" + t;
        n.showErrorToast(e);
    },
    requestTryingNum: function() {
        var t = this;
        a.get({
            data: {
                rd: 10021
            },
            success: function(e) {
                var a = e.data;
                t.setData({
                    tryNum: a.tryNum
                });
            }
        });
    },
    onDetailClick: function(t) {
        var a = this, n = t.currentTarget.dataset.tryid, i = a.data.underway_list, o = {};
        e.each(i, function(t) {
            t.tryid == n && (o = t);
        });
        o = {
            tryid: n,
            subject: o.subject,
            type: o.type,
            size: o.size,
            amount: o.amount,
            status: o.status,
            coverimg: o.coverimg,
            start_time: o.start_time,
            end_time: o.end_time,
            view_num: o.view_num
        };
        o = encodeURIComponent(JSON.stringify(o));
        var r = "/pages/try/detail?tryid=" + n + "&tryInfo=" + o;
        console.log("url = ", r), wx.navigateTo({
            url: r
        });
    },
    formSubmit: function(t) {
        var e = t.detail.formId;
        n.postFormId(e), console.log("the formId = ", e);
    },
    onPullDownRefresh: function() {
        this.loadUnderwayListData(1);
    },
    onReachBottom: function() {
        var t = this;
        0 == t.data.underway_loadDone && t.loadUnderwayListData();
    },
    getVipInfo: function() {
        var t = this, e = o.getUser(), a = !1;
        e && e.vip_info && e.vip_info.uid && (a = !0), t.setData({
            isVip: a
        });
    },
    loadUnderwayListData: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, i = this;
        i.getVipInfo(), e.isNull(t) && (t = i.data.underway_list_page), a.get({
            data: {
                rd: 10063,
                page: t
            },
            success: function(e) {
                var a = i.canvertData(e.data);
                0 == a.list.length && i.setData({
                    underway_loadDone: !0
                });
                var n = a.list;
                1 != t ? n = i.data.underway_list.concat(n) : i.setData({
                    underway_loadDone: !1
                }), i.setData({
                    underway_list: n,
                    banner: e.data.banner,
                    underway_list_page: ++t
                }), wx.hideLoading();
            },
            fail: function(t) {
                n.showErrorToast(t);
            },
            complete: function() {
                wx.stopPullDownRefresh();
            }
        });
    },
    canvertData: function(t) {
        return e.each(t.list, function(a, n) {
            if (!e.isUndefined(a.second)) {
                var i = Math.floor(a.second / 86400), o = Math.floor((a.second - 60 * i * 60 * 24) / 3600), r = Math.round((a.second - 60 * i * 60 * 24 - 60 * o * 60) / 60);
                t.list[n].remain_day = i, t.list[n].remain_hour = o, t.list[n].remain_min = r;
            }
            if (!e.isUndefined(a.wait_time)) {
                var i = Math.floor(a.wait_time / 86400), o = Math.floor((a.wait_time - 60 * i * 60 * 24) / 3600), r = Math.round((a.wait_time - 60 * i * 60 * 24 - 60 * o * 60) / 60);
                t.list[n].remain_day = i, t.list[n].remain_hour = o, t.list[n].remain_min = r;
            }
        }), t;
    },
    requestUnreadMessageNum: function() {
        var t = this;
        a.get({
            data: {
                rd: 10054
            },
            success: function(e) {
                var a = Number(e.data.unread_num);
                t.setData({
                    unreadNum: a
                }), console.log("unreadNum=", a);
            },
            fail: function(t) {
                console.log("request unreadNum fail", t);
            }
        });
    },
    startTimer: function() {
        console.log("startTimer");
        var e = this;
        e.requestUnreadMessageNum(), t = setInterval(function() {
            e.requestUnreadMessageNum();
        }, 3e4);
    },
    bindShowMessage: function() {
        var t = this;
        wx.navigateTo({
            url: "/pages/message/index",
            success: function() {
                t.setData({
                    unreadNum: 0
                });
            }
        });
    },
    goToIfShop: function() {
        wx.navigateToMiniProgram({
            appId: "wx9882cde4aa06d0f7",
            path: "pages/personal/vip/vipExplain",
            extraData: {
                source: "ifTry"
            }
        });
    },
    onShareAppMessage: function() {
        return {
            title: "【if 试用】 - 好的试用产品都在这里~",
            desc: "有" + this.data.tryNum + "款试用正在进行",
            path: "/pages/index/index"
        };
    }
});
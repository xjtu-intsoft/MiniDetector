var t, e = require("../../utils/kissy.js"), a = require("../../utils/io.js"), i = require("../../utils/util.js");

Page({
    data: {
        list_page: 1,
        list: [],
        loadDone: !1,
        users: {},
        unreadNum: 0
    },
    onLoad: function(t) {
        this.loadListData();
    },
    onPullDownRefresh: function() {
        this.loadListData(1);
    },
    onReachBottom: function() {
        this.loadListData();
    },
    loadListData: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, i = this;
        1 != i.data.loadDone && (e.isNull(t) && (t = i.data.list_page), 1 == t && i.setData({
            loadDone: !1
        }), a.get({
            data: {
                rd: 10053,
                page: t
            },
            success: function(a) {
                var s = i.canvertData(a.data);
                0 == s.list.length && i.setData({
                    loadDone: !0
                });
                var n = s.list;
                1 != t && (n = i.data.list.concat(n)), i.setData({
                    list: n,
                    users: e.merge(i.data.users, s.users),
                    list_page: ++t
                });
            },
            complete: function() {
                wx.stopPullDownRefresh();
            }
        }));
    },
    canvertData: function(t) {
        return e.each(t.list, function(a, i) {
            var s = Math.floor(a.time_left / 86400), n = Math.floor((a.time_left - 60 * s * 60 * 24) / 3600), o = Math.round((a.time_left - 60 * s * 60 * 24 - 60 * n * 60) / 60);
            t.list[i].remain_day = s, t.list[i].remain_hour = n, t.list[i].remain_min = o;
            var r = e.system.windowWidth - 30, u = a.width, l = .58 * u;
            t.list[i].width = r, t.list[i].height = r / u * l;
            var d = t.list[i].uids;
            if (d && d.length > 5) {
                var c = d.slice(0, 5);
                t.list[i].uids = c;
            }
        }), t;
    },
    bindItemClick: function(t) {
        console.log("bindItemClick");
        var a = this, i = t.currentTarget.dataset.tryid, s = {};
        e.each(a.data.list, function(t) {
            t.tryid == i && (s = t);
        });
        s = {
            tryid: i,
            subject: s.subject,
            type: s.type,
            size: s.size,
            amount: s.amount,
            status: s.status,
            coverimg: s.coverimg,
            start_time: s.start_time,
            end_time: s.end_time,
            view_num: s.view_num
        };
        s = encodeURIComponent(JSON.stringify(s)), wx.navigateTo({
            url: "/pages/try/detail?tryid=" + i + "&tryInfo=" + s + "&isFromWelfare=1"
        });
    },
    formSubmit: function(t) {
        var e = t.detail.formId;
        i.postFormId(e), console.log("the formId = ", e);
    },
    requestUnreadMessageNum: function() {
        var t = this;
        a.get({
            data: {
                rd: 10054
            },
            success: function(e) {
                var a = Number(e.data.unread_num);
                t.setData({
                    unreadNum: a
                }), console.log("unreadNum=", a);
            },
            fail: function(t) {
                console.log("request unreadNum fail", t.mrrmsg);
            }
        });
    },
    startTimer: function() {
        console.log("startTimer");
        var e = this;
        e.requestUnreadMessageNum(), t = setInterval(function() {
            e.requestUnreadMessageNum();
        }, 3e4);
    },
    bindShowMessage: function() {
        var t = this;
        wx.navigateTo({
            url: "/pages/message/index",
            success: function() {
                t.setData({
                    unreadNum: 0
                });
            }
        });
    },
    onShareAppMessage: function() {
        return {
            title: "【if 福利】 - if 姐发福利，快来看看吧~",
            path: "/pages/welfare/index"
        };
    },
    onReady: function() {},
    onShow: function() {
        getApp().isLogin() && this.startTimer();
    },
    onHide: function() {
        clearInterval(t);
    },
    onUnload: function() {}
});
var t = require("../../utils/kissy.js"), a = require("../../utils/io.js"), e = getApp();

Page({
    data: {
        isLogin: !1,
        list: [],
        trys: {},
        activityItems: {},
        pagetime: 0,
        loadDone: !1,
        first_load_done: !1,
        have_read_msg_id: 0
    },
    onLoad: function(t) {},
    onReachBottom: function() {
        var t = this;
        t.data.loadDone || t.loadData();
    },
    loadData: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], i = this;
        if (e || 1 != i.data.loadDone) {
            var o = i.data.pagetime;
            e && (o = 0), a.get({
                data: {
                    rd: 10019,
                    pagetime: o
                },
                success: function(a) {
                    var o = a.data;
                    i.setData({
                        have_read_msg_id: Number(o.have_read_msg_id)
                    }), 0 == o.list.length ? i.setData({
                        loadDone: !0,
                        first_load_done: !0
                    }) : i.setData({
                        loadDone: !1
                    }), e ? i.setData({
                        list: i.convertData(o.list),
                        trys: o.trys,
                        activityItems: o.activityItems,
                        pagetime: o.pagetime,
                        first_load_done: !0
                    }) : i.setData({
                        list: i.data.list.concat(i.convertData(o.list)),
                        trys: t.merge(i.data.trys, o.trys),
                        activityItems: t.merge(i.data.activityItems, o.activityItems),
                        pagetime: o.pagetime,
                        first_load_done: !0
                    });
                },
                fail: function() {}
            });
        }
    },
    convertData: function(a) {
        return t.each(a, function(e, i) {
            a[i].time = t.simpleTime(e.time), a[i].msg_id = Number(e.msg_id);
        }), a;
    },
    onReady: function() {},
    onShow: function() {
        t.log("onShow message page");
        var a = this, i = !1;
        e.isLogin() ? (i = !0, a.loadData(!0)) : (i = !1, a.setData({
            list: [],
            trys: {},
            pagetime: 0,
            first_load_done: !0,
            loadDone: !1
        })), a.setData({
            isLogin: i
        });
    },
    onHide: function() {},
    onUnload: function() {}
});
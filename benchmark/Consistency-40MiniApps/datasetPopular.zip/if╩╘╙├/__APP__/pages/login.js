require("../utils/kissy.js");

var t = require("../utils/io.js"), o = require("../utils/util.js"), e = require("../config.js"), n = getApp(), s = e.MEMBER_PASSPORT_KEY;

Page({
    data: {
        loadingStatus: !1,
        hasAuth: !0
    },
    onLoad: function(t) {
        var o = this;
        o.setData({
            loadingStatus: !1
        }), wx.getSetting({
            success: function(t) {
                var e = t.authSetting["scope.userInfo"];
                o.data.hasAuth = e;
            }
        });
    },
    onShow: function() {
        this.updateWXLoginCode();
    },
    bindAuthLogin: function(t) {
        this.requestLogin();
    },
    requestLogin: function() {
        var e = this;
        e.setData({
            loadingStatus: !0
        }), wx.login({
            success: function(n) {
                if (n.code) {
                    var a = n.code;
                    wx.getUserInfo({
                        success: function(n) {
                            t.post({
                                data: {
                                    rd: 10001,
                                    code: a,
                                    encryptedData: n.encryptedData,
                                    iv: n.iv
                                },
                                success: function(t) {
                                    var o = t.data;
                                    wx.setStorageSync(s, o), wx.setStorageSync("needRefreshUserInfo", "true"), wx.navigateBack({
                                        delta: 1
                                    });
                                },
                                fail: function(t) {
                                    console.log("10001登录失败！" + t), o.showErrorToast(t);
                                },
                                complete: function() {
                                    e.setData({
                                        loadingStatus: !1
                                    });
                                }
                            });
                        },
                        fail: function(t) {
                            console.log("获取用户信息失败！" + t.errMsg), e.setData({
                                loadingStatus: !1
                            });
                            var n = t.errMsg;
                            wx.getSetting({
                                success: function(t) {
                                    var s = t.authSetting["scope.userInfo"];
                                    1 != s ? wx.openSetting({
                                        fail: function(t) {
                                            console.log(t.errMsg);
                                        }
                                    }) : o.showErrorToast(n), e.data.hasAuth = s;
                                },
                                fail: function(t) {
                                    o.showErrorToast(n);
                                }
                            });
                        }
                    });
                } else console.log("获取用户登录态失败！" + n.errMsg), e.setData({
                    loadingStatus: !1
                }), o.showErrorToast(n.errMsg);
            },
            fail: function(t) {
                e.setData({
                    loadingStatus: !1
                }), console.log("授权异常" + t.errMsg), o.showErrorToast(t.errMsg);
            }
        });
    },
    getUserInfo: function(t) {
        var o = this, e = t.detail.encryptedData, s = t.detail.iv;
        if (!e || !s) return o.updateWXLoginCode(), void console.log("用户拒绝授权");
        n.registerAccount(o.data.loginCode, e, s, function() {
            wx.setStorageSync("needRefreshUserInfo", "true"), wx.navigateBack({
                delta: 1
            }), console.log("getUserInfo for get gift success call back");
        }, function() {
            o.updateWXLoginCode();
        }, "gfd");
    },
    updateWXLoginCode: function() {
        var t = this;
        wx.login({
            success: function(o) {
                o.code && (t.data.loginCode = o.code, console.log("updateWXLoginCode ok ", t.data.loginCode));
            },
            fail: function(t) {
                console.log("updateWXLoginCode fail ", t.errMsg);
            }
        });
    }
});
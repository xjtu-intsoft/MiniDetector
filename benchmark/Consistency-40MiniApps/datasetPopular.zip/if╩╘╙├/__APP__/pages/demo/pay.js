Page({
    data: {},
    onLoad: function(n) {
        this.startPay();
    },
    startPay: function(n) {
        console.log("startPay click"), wx.requestPayment({
            timeStamp: "1489571760",
            nonceStr: "a2186aa7c086b46ad4e8bf81e2a3a19b",
            package: "prepay_id=wx20170315175114861e64e4010779508325",
            signType: "MD5",
            paySign: "6D517F45E4A15D159D08240ABB9D5F5B",
            success: function(n) {
                console.log(n), wx.showToast({
                    title: n.errMsg,
                    icon: "success",
                    duration: 1e3
                });
            },
            fail: function(n) {
                console.log(n), wx.showToast({
                    title: n.errMsg,
                    icon: "loading",
                    duration: 2e3
                });
            }
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {}
});
var o = require("../../utils/kissy.js"), t = require("../../utils/io.js");

Page({
    data: {
        content: {},
        movies: [ {
            url: "http://img04.tooopen.com/images/20130712/tooopen_17270713.jpg"
        }, {
            url: "http://img04.tooopen.com/images/20130617/tooopen_21241404.jpg"
        }, {
            url: "http://img04.tooopen.com/images/20130701/tooopen_20083555.jpg"
        }, {
            url: "http://img02.tooopen.com/images/20141231/sy_78327074576.jpg"
        } ]
    },
    onLoad: function(e) {
        var s = this;
        t.get({
            data: {
                rd: 10099,
                aid: 127
            },
            success: function(t) {
                o.log("请求成功了  " + t.data);
                var e = s.canvertData(t.data);
                s.setData({
                    content: e
                });
            },
            fail: function(t) {
                o.log("请求失败" + t);
            }
        }), wx.getSystemInfo({
            success: function(o) {
                console.log(o.platform), console.log(o.model), console.log(o.system), console.log(o.version);
            }
        });
    },
    canvertData: function(t) {
        return o.each(t, function(e, s) {
            if ("img" == e.type) {
                var n = o.system.windowWidth - 30, a = e.spans.width, i = e.spans.height;
                t[s].spans.width = n, t[s].spans.height = n / a * i;
            }
        }), t;
    }
});
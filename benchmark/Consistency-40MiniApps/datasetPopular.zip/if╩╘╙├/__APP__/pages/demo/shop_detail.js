getApp();

Page({
    data: {
        movies: [ {
            url: "http://img01.iffashion.cn/backstage/2017/0302/155320_55912.jpg"
        }, {
            url: "http://img01.iffashion.cn/backstage/2017/0302/155321_11984.jpg"
        }, {
            url: "http://img01.iffashion.cn/backstage/2017/0302/155321_42881.jpg"
        } ]
    },
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {}
});
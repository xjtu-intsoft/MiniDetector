var t = require("../../utils/kissy.js"), a = require("../../utils/io.js");

Page({
    data: {
        tabs: [ "全部申请", "成功申请" ],
        activeIndex: 0,
        sliderOffset: .07 * t.system.windowWidth,
        sliderList: 0,
        underway_list_page: 1,
        underway_list: [],
        underway_loadDone: !1,
        end_list_page: 1,
        end_list: [],
        end_loadDone: !1
    },
    onLoad: function() {
        var a = this;
        a.setData({
            sliderLeft: (.86 * t.system.windowWidth / a.data.tabs.length - 40) / 2
        }), a.loadUnderwayListData(), a.loadEndListData();
    },
    tabClick: function(t) {
        this.setData({
            sliderOffset: t.currentTarget.offsetLeft,
            activeIndex: t.currentTarget.id
        });
    },
    onDetailClick: function(t) {
        var a = t.currentTarget.id;
        wx.navigateTo({
            url: "/pages/try/detail/detail?tryid=" + a
        });
    },
    onReachBottom: function() {
        0 == this.data.activeIndex && 0 == this.data.underway_loadDone && (this.loadUnderwayListData(), 
        t.log("0 onReachBottom")), 1 == this.data.activeIndex && 0 == this.data.end_loadDone && (this.loadEndListData(), 
        t.log("1 onReachBottom"));
    },
    loadListData: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, a = this;
        0 == a.data.activeIndex ? a.loadUnderwayListData(t) : a.loadEndListData(t);
    },
    loadUnderwayListData: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, n = this;
        t.isNull(e) && (e = n.data.underway_list_page), a.get({
            data: {
                rd: 10002,
                size: 7,
                page: e
            },
            success: function(t) {
                var a = n.canvertData(t.data);
                0 == a.list.length && n.setData({
                    underway_loadDone: !0
                });
                var i = a.list;
                1 != e && (i = n.data.underway_list.concat(i)), n.setData({
                    underway_list: i,
                    underway_list_page: ++e
                });
            },
            complete: function() {}
        });
    },
    loadEndListData: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, n = this;
        t.isNull(e) && (e = n.data.end_list_page), a.get({
            data: {
                rd: 10002,
                size: 3,
                page: e
            },
            success: function(t) {
                var a = n.canvertData(t.data);
                0 == a.list.length && n.setData({
                    end_loadDone: !0
                });
                var i = a.list;
                1 != e && (i = n.data.end_list.concat(i)), n.setData({
                    end_list: i,
                    end_list_page: ++e
                });
            },
            complete: function() {}
        });
    },
    canvertData: function(a) {
        return t.each(a.list, function(t, e) {
            var n = Math.floor(t.second / 86400), i = Math.floor((t.second - 60 * n * 60 * 24) / 3600), d = Math.round((t.second - 60 * n * 60 * 24 - 60 * i * 60) / 60);
            a.list[e].remain_day = n, a.list[e].remain_hour = i, a.list[e].remain_min = d;
        }), a;
    }
});
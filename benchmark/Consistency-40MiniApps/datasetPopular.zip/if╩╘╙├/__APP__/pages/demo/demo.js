var i = require("../../utils/kissy.js"), s = require("../../utils/io.js");

Page({
    data: {},
    onLoad: function(t) {
        s.get({
            data: {
                rd: 10099
            },
            success: function(s) {
                i.log(s.data);
            },
            fail: function(s) {
                i.log(s);
            }
        });
    }
});
Page({
    data: {
        types: [ "全部订单", "待付款", "待成团", "待收货" ]
    },
    onLoad: function(o) {},
    swiperChange: function(o) {
        var e = o.detail.current, a = o.detail.source;
        console.log("滚动到了第" + e + "个,原因" + a);
    },
    loadMoreWaitPayType: function() {
        console.log("loadMoreWaitPayType");
    },
    loadMoreAllType: function() {
        console.log("loadMoreAllType");
    }
});
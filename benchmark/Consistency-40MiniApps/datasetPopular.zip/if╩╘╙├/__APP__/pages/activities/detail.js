var t = require("../../utils/kissy.js"), e = require("../../utils/io.js"), a = getApp();

Page({
    data: {
        collectid: 0,
        collectInfo: {},
        collectInfoJson: "",
        collectInfoLoadDone: !1,
        posts_load_done: !1,
        loadEndDataLock: !1,
        fromShare: !1,
        posts: [],
        users: {},
        report_page: 1,
        loginUser: {},
        isExistDefAddress: !1
    },
    onLoad: function(e) {
        var a = this;
        a.setData({
            collectid: e.collectid
        }), t.isUndefined(e.fromShare) || a.setData({
            fromShare: !0
        });
    },
    onReachBottom: function() {
        this.loadEndData();
    },
    loadEndData: function() {
        var a = this;
        1 != a.data.posts_load_done && (a.data.loadEndDataLock || (a.setData({
            loadEndDataLock: !0
        }), e.get({
            data: {
                rd: 10033,
                collectid: a.data.collectid,
                page: a.data.report_page
            },
            success: function(e) {
                var s = e.data;
                0 != s.posts.length ? a.setData({
                    posts: a.data.posts.concat(a.canvertPostsData(s.posts)),
                    users: t.merge(a.data.users, s.users),
                    report_page: ++a.data.report_page
                }) : a.setData({
                    posts_load_done: !0
                });
            },
            complete: function() {
                a.setData({
                    loadEndDataLock: !1
                });
            }
        })));
    },
    canvertData: function(e) {
        return t.each(e.rich_text, function(a, s) {
            if ("img" == a.type) {
                var o = t.system.windowWidth - .12 * t.system.windowWidth, i = a.spans.width, n = a.spans.height;
                e.rich_text[s].spans.width = o, e.rich_text[s].spans.height = o / i * n;
            }
        }), t.each(e.rules, function(a, s) {
            if ("image" == e.rules[s].type) {
                var o = t.system.windowWidth - .12 * t.system.windowWidth, i = a.width, n = a.height;
                e.rules[s].width = o, e.rules[s].height = o / i * n;
            }
        }), e;
    },
    canvertPostsData: function(e) {
        return t.each(e, function(a, s) {
            e[s].pubtime = t.simpleTime(a.time);
        }), e;
    },
    bindPreviewImage: function(e) {
        var a = this, s = e.currentTarget.dataset.postkey, o = e.currentTarget.dataset.imgkey, i = a.data.posts[s].imagesBig;
        t.log(i[o]), t.log(i), wx.previewImage({
            current: i[o],
            urls: i,
            success: function(t) {},
            fail: function() {},
            complete: function() {}
        });
    },
    bindWriteReportBtn: function() {
        var t = this;
        if (a.isLogin()) {
            var e = "";
            e = t.data.isExistDefAddress ? "/pages/try/submitReport?collectid=" + t.data.collectid : "/pages/home/address/add?collectid=" + t.data.collectid, 
            wx.navigateTo({
                url: e
            });
        } else wx.navigateTo({
            url: "/pages/login"
        });
    },
    bindLikesBtn: function(t) {
        var s = this, o = t.currentTarget.dataset.postkey, i = t.currentTarget.dataset.pid, n = t.currentTarget.dataset.status;
        a.isLogin() ? (1 == n && (s.data.posts[o].isLike = 1, s.data.posts[o].likes = Number(s.data.posts[o].likes) + 1), 
        2 == n && (s.data.posts[o].isLike = 0, s.data.posts[o].likes = Number(s.data.posts[o].likes) - 1), 
        s.setData({
            posts: s.data.posts
        }), e.get({
            data: {
                rd: 10034,
                pid: i,
                status: n
            },
            success: function(t) {},
            complete: function() {}
        })) : wx.navigateTo({
            url: "/pages/login"
        });
    },
    bindShowMoreBtn: function(e) {
        var a = this, s = e.currentTarget.dataset.pid;
        t.each(a.data.posts, function(t) {
            t.pid == s && (t.showMore = !0);
        }), a.setData({
            posts: a.data.posts
        });
    },
    bindOperateReport: function(e) {
        var a = this, s = e.currentTarget.dataset.pid;
        wx.showActionSheet({
            itemList: [ "编辑" ],
            itemColor: "#000000",
            success: function(e) {
                if (0 == e.tapIndex) {
                    var o = {};
                    t.each(a.data.posts, function(t) {
                        t.pid == s && (o = t);
                    }), o = encodeURIComponent(JSON.stringify(o)), wx.navigateTo({
                        url: "/pages/try/submitReport?collectid=" + a.data.collectid + "&post=" + o
                    });
                }
            },
            fail: function(e) {
                t.log(e.errMsg);
            }
        });
    },
    onShareAppMessage: function() {
        var t = this;
        return {
            title: t.data.collectInfo.subject,
            desc: "if 试用",
            path: "/pages/activities/detail?collectid=" + t.data.collectid + "&fromShare=1"
        };
    },
    onReady: function() {},
    onShow: function() {
        var t = this, s = a.getUser();
        t.setData({
            loginUser: s
        }), e.get({
            data: {
                rd: 10052
            },
            success: function(e) {
                0 != e.data.is_exist && t.setData({
                    isExistDefAddress: !0
                });
            }
        }), wx.getStorageSync("apply_report") && (t.setData({
            posts_load_done: !1,
            posts: [],
            users: {},
            report_page: 1
        }), wx.removeStorage({
            key: "apply_report"
        }), t.loadEndData()), e.get({
            data: {
                rd: 10032,
                collectid: t.data.collectid
            },
            success: function(e) {
                var a = t.canvertData(e.data);
                t.setData({
                    collectInfo: a,
                    collectInfoJson: encodeURIComponent(JSON.stringify(a)),
                    collectInfoLoadDone: !0
                });
            },
            complete: function() {}
        });
    },
    onHide: function() {},
    onUnload: function() {}
});
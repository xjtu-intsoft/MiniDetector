var t = require("../../utils/kissy.js"), a = require("../../utils/io.js");

Page({
    data: {
        list_page: 1,
        list: [],
        loadDone: !1,
        users: {}
    },
    onLoad: function(t) {
        this.loadListData();
    },
    onPullDownRefresh: function() {
        this.loadListData(1);
    },
    onReachBottom: function() {
        this.loadListData();
    },
    loadListData: function() {
        var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null, e = this;
        1 != e.data.loadDone && (t.isNull(i) && (i = e.data.list_page), 1 == i && e.setData({
            loadDone: !1
        }), a.get({
            data: {
                rd: 10031,
                page: i
            },
            success: function(a) {
                var n = e.canvertData(a.data);
                0 == n.list.length && e.setData({
                    loadDone: !0
                });
                var s = n.list;
                1 != i && (s = e.data.list.concat(s)), e.setData({
                    list: s,
                    users: t.merge(e.data.users, n.users),
                    list_page: ++i
                });
            },
            complete: function() {
                wx.stopPullDownRefresh();
            }
        }));
    },
    canvertData: function(a) {
        return t.each(a.list, function(i, e) {
            var n = Math.floor(i.time_left / 86400), s = Math.floor((i.time_left - 60 * n * 60 * 24) / 3600), o = Math.round((i.time_left - 60 * n * 60 * 24 - 60 * s * 60) / 60);
            a.list[e].remain_day = n, a.list[e].remain_hour = s, a.list[e].remain_min = o;
            var l = t.system.windowWidth - 30, r = i.width, u = .58 * r;
            a.list[e].width = l, a.list[e].height = l / r * u;
        }), a;
    },
    onShareAppMessage: function() {
        return {
            title: "【活动】分享体验，集赞拿奖",
            desc: "if 试用",
            path: "/pages/activities/index"
        };
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {}
});
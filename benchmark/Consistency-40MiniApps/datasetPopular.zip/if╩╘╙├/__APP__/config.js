module.exports = {
    version: "2.1.11",
    API_URL: "https://mapi.iffashion.cn/wxapp",
    MEMBER_PASSPORT_KEY: "MEMBER_PASSPORT_KEY_V1.0",
    MAPI_SIGN_KEY: "-G3WBSD4hsWMI",
    QN_UPLOAD_URL: "https://upload.qiniup.com"
};
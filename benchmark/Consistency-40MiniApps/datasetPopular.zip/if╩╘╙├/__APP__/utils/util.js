function t(t) {
    return (t = t.toString())[1] ? t : "0" + t;
}

var e = require("io.js");

module.exports = {
    formatTime: function(e) {
        var i = e.getFullYear(), o = e.getMonth() + 1, n = e.getDate(), s = e.getHours(), a = e.getMinutes(), g = e.getSeconds();
        return [ i, o, n ].map(t).join("/") + " " + [ s, a, g ].map(t).join(":");
    },
    showErrorToast: function(t, e) {
        wx.hideLoading && wx.hideLoading(), new getApp().WeToast().toast({
            title: t,
            img: e ? "../../../image/icon_tips.png" : "../../image/icon_tips.png"
        });
    },
    showSuccessToast: function(t, e) {
        wx.hideLoading && wx.hideLoading(), new getApp().WeToast().toast({
            title: t,
            img: e ? "../../../image/icon_success.png" : "../../image/icon_success.png"
        });
    },
    postFormId: function(t) {
        if (t) {
            var i = t.split(" ");
            console.log("formIdArr = ", i), i.length > 1 || e.post({
                data: {
                    rd: 11038,
                    devid: "wechat_app_devid",
                    form_id: t
                },
                success: function(t) {}
            });
        }
    }
};
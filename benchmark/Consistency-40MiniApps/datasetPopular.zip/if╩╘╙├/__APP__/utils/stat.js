var t = require("kissy.js"), a = require("../config.js");

!function() {
    function i(t, a, i) {
        if (t[a]) {
            var n = t[a];
            t[a] = function(t) {
                i.call(this, t, a), n.call(this, t);
            };
        } else t[a] = function(t) {
            i.call(this, t, a);
        };
    }
    var n = function(t) {
        wx.request({
            url: a.API_URL + "/w.gif",
            data: t,
            method: "GET",
            success: function(t) {},
            fail: function() {},
            complete: function() {}
        });
    }, e = function() {
        getApp();
        var i = this, e = wx.getStorageSync("aldstat_uuid");
        e || (e = "" + Date.now() + Math.floor(1e7 * Math.random()), wx.setStorageSync("aldstat_uuid", e));
        var o = a.MEMBER_PASSPORT_KEY, u = "", r = wx.getStorageSync(o) || {};
        !t.isUndefined(r.uid) && r.uid > 0 && (u = r.uid);
        var c = Date.now() + Math.floor(1e7 * Math.random()), s = {
            path: i.__route__,
            os: "wxapp",
            uuid: e,
            uid: u,
            r: c
        };
        n(s);
    }, o = Page;
    Page = function(t) {
        i(t, "onShow", e), o(t);
    };
}();
function e(e) {
    void 0 == e.data && (e.data = {});
    var n = [];
    for (var s in e.data) n.push(e.data[s]);
    var a = n.sort().join("");
    e.data.ifsign = i.md5(a + o.MAPI_SIGN_KEY), "POST" == e.method.toUpperCase() && (e.data = i.param(e.data)), 
    "function" != typeof e.success && (e.success = function(e) {}), "function" != typeof e.fail && (e.fail = function() {}), 
    "function" != typeof e.complete && (e.complete = function() {});
    var d = o.MEMBER_PASSPORT_KEY, c = "", r = wx.getStorageSync(d) || {};
    !i.isUndefined(r.uid) && r.uid > 0 && (c = r.uid);
    var u = {
        timezone: 8,
        resolution: i.system.windowWidth + "*" + i.system.windowHeight,
        channel: "wxapp",
        os: "wxapp",
        device_model: i.system.model,
        app_version: i.system.version,
        device_id: "",
        uidentity: c,
        platform: i.system.platform,
        os_version: i.system.os_version
    }, f = {
        "content-type": "application/x-www-form-urlencoded",
        IFENV: JSON.stringify(u)
    };
    t({
        url: o.API_URL,
        data: e.data,
        method: e.method,
        header: f,
        success: function(t) {
            0 == t.data.errcode ? e.success(t.data) : e.fail(t.data.errmsg);
        },
        fail: function() {
            e.fail("网络请求错误");
        },
        complete: function() {
            e.complete();
        }
    });
}

function t(e) {
    wx.request(e);
}

var o = require("../config.js"), i = require("kissy.js");

module.exports = {
    get: function(t) {
        t.method = "GET", e(t);
    },
    post: function(t) {
        t.method = "POST", e(t);
    },
    request: t
};
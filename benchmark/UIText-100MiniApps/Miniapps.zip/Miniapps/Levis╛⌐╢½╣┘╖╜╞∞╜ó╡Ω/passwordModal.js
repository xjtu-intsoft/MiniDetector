var a = {
    passwordListClick: function() {
        this.data.isPasswordModalData.passwordFocus ? this.setData({
            "isPasswordModalData.passwordFocus": !1
        }) : this.setData({
            "isPasswordModalData.passwordFocus": !0
        });
    },
    setPasswordValue: function(a) {
        this.setData({
            "isPasswordModalData.passWordValue": a.detail.value,
            "isPasswordModalData.mondalHint": ""
        });
    },
    passwordConfirm: function(a) {
        var s = this, t = this.data.isPasswordModalData.passWordValue;
        (this.data.isPasswordModalData.passwordShort ? /^\d{6}$/ : /^\S{6,20}$/).test(t) ? s.submitOrder(a) : 0 == t.length ? this.setData({
            "isPasswordModalData.mondalHint": "请输入支付密码"
        }) : this.setData({
            "isPasswordModalData.mondalHint": "密码格式错误"
        });
        var i = this.getPayType();
        this.pingClick("WOrder_FillSafeDialog", "", this.skuIdsListStr + i + "_1", "", a);
    },
    passWordModalClose: function(a) {
        this.setData({
            "isPasswordModalData.passwordFocus": !0,
            "isPasswordModalData.modalDisplay": !1,
            "isPasswordModalData.passWordValue": "",
            "isPasswordModalData.mondalHint": ""
        }), this.data && this.data.isCashOnDelivery && this.cancelCashOnDelivery();
        var s = this.getPayType();
        this.pingClick("WOrder_FillSafeDialog", "", this.skuIdsListStr + s + "_2", "", a);
    },
    forgetPassword: function(a) {
        var s = this;
        s.setData({
            "isPasswordModalData.passwordFocus": !1,
            "isPasswordModalData.modalDisplay": !1
        });
        var t = s.getPayType();
        this.pingClick("WOrder_FillForgetPassword", "", this.skuIdsListStr + t, "", a), 
        wx.navigateTo({
            url: "../payWebview/payWebview?fromtype=1"
        });
    },
    setShortPassWord: function() {
        this.setData({
            "isPasswordModalData.passwordFocus": !1
        });
    },
    shortpwdfocus: function(a) {
        var s = this.getPayType();
        this.pingClick("WOrder_FillSafeShortInput", "", this.skuIdsListStr + s, "", a);
    },
    longpwdfocus: function(a) {
        var s = this.getPayType();
        this.pingClick("WOrder_FillSafeLongInput", "", this.skuIdsListStr + s, "", a);
    },
    getPayType: function() {
        return this.data.jdBeanObj && this.data.jdBeanObj.isSwitchChecked && !this.data.isUseRedPacket ? "_2" : this.data.jdBeanObj && !this.data.jdBeanObj.isSwitchChecked && this.data.isUseRedPacket ? "_1" : this.data.jdBeanObj && this.data.jdBeanObj.isSwitchChecked && this.data.isUseRedPacket ? "_1&2" : "_";
    }
};

module.exports = {
    passwordModalObject: a
};
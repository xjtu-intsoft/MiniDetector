var t = require("../../api/api");

Component({
    properties: {
        articleDesc: {
            type: Object
        },
        control: {
            type: Boolean
        }
    },
    data: {
        stateFlag: !0,
        nickName: "",
        phone: "",
        code: ""
    },
    methods: {
        closeModule: function() {
            this.setData({
                stateFlag: !0
            }), wx.switchTab({
                url: "/pages/xunchong/xunchong"
            });
        },
        getCode: function() {
            /\S/.test(this.data.phone) ? t.sendMessage({
                phone: this.data.phone,
                type: 1
            }).then(function(t) {
                0 == t.err_code ? wx.showToast({
                    title: t.msg,
                    icon: "success"
                }) : wx.showModal({
                    title: "提示",
                    content: t.msg,
                    showCancel: !1
                });
            }) : wx.showModal({
                title: "提示",
                content: "请输入手机号",
                showCancel: !1
            });
        },
        toRegister: function() {
            var e = this, a = /\S/;
            a.test(this.data.nickName) && a.test(this.data.phone) && a.test(this.data.code) ? t.bingdingPhone({
                code: this.data.code,
                nickName: this.data.nickName,
                phone: this.data.phone
            }).then(function(t) {
                console.log(t), 0 == t.err_code && wx.showModal({
                    title: "温馨提示",
                    content: t.msg,
                    showCancel: !1
                }), e.setData({
                    stateFlag: !0
                });
            }) : wx.showModal({
                title: "提示",
                content: "请把信息补充完整哦",
                showCancel: !1
            });
        },
        changeNickName: function(t) {
            this.setData({
                nickName: t.detail.value
            });
        },
        getPhone: function(t) {
            this.setData({
                phone: t.detail.value.toString()
            });
        },
        inpCode: function(t) {
            this.setData({
                code: t.detail.value.toString()
            });
        }
    },
    lifetimes: {
        attached: function() {
            this.setData({
                stateFlag: this.properties.control
            });
        }
    }
});
require("./../../../webpack-require")("FsW4", Object.assign({}, require("./../../../vendors.js").modules, require("./../../../commons.js").modules, {
    "1j1R": function(t, o, e) {
        var n = e("Fcif"), i = e("3gK6"), a = getApp(), c = function(t) {
            return void 0 === t && (t = {}), t = Object(n.a)({
                config: {
                    skipKdtId: !0,
                    skipShopInfo: !0,
                    noQuery: !0
                },
                method: "POST",
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                origin: "uic",
                data: {},
                success: function() {},
                fail: function() {}
            }, t), a.request(t);
        };
        o.a = {
            fetchCode: function(t, o, e, n) {
                return c({
                    origin: "uic",
                    pathname: "/passport/login/sms.json",
                    path: "/passport/login/sms.json",
                    data: {
                        mobile: t,
                        countryCode: "+86",
                        sessionId: a.getSessionId()
                    },
                    success: function(t) {
                        e(t);
                    },
                    fail: n
                });
            },
            codeLogin: function(t, o, e, n) {
                wx.request({
                    url: Object(i.a)({
                        origin: "uic",
                        pathname: "/sso/wx/codeLogin"
                    }),
                    method: "POST",
                    config: {
                        skipKdtId: !0,
                        skipShopInfo: !0
                    },
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    data: {
                        mobile: t,
                        countryCode: "+86",
                        verifyCode: o,
                        sessionId: a.getSessionId()
                    },
                    success: function(t) {
                        t.data && 0 === t.data.code ? e && e(t) : n(t.data);
                    },
                    fail: n
                });
            },
            setPassword: function(t, o, e) {
                wx.request({
                    url: Object(i.a)({
                        origin: "uic",
                        pathname: "/sso/wx/updatePasswd"
                    }),
                    method: "POST",
                    config: {
                        skipKdtId: !0,
                        skipShopInfo: !0
                    },
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    data: {
                        password: t,
                        sessionId: a.getSessionId()
                    },
                    success: function(t) {
                        var n = t.data;
                        0 === n.code || 200 === n.code ? o(n) : e(n);
                    },
                    fail: e
                });
            },
            loginBySms: function(t, o, e) {
                return a.logger.appError({
                    name: "loginBySms",
                    message: "loginBySms",
                    detail: t
                }), c({
                    origin: "uic",
                    pathname: "/passport/login.json",
                    path: "/passport/login.json",
                    data: t,
                    success: function(t) {
                        o(t);
                    },
                    fail: e
                });
            },
            loginByWx: function(t, o, e) {
                return a.logger.appError({
                    name: "loginByWx",
                    message: "loginByWx",
                    detail: t
                }), c({
                    origin: "uic",
                    pathname: "/passport/login/wx.json",
                    path: "/passport/login/wx.json",
                    data: t,
                    success: function(t) {
                        return o(t);
                    },
                    fail: e
                });
            }
        };
    },
    FsW4: function(t, o, e) {
        e.r(o);
        var n = e("Fcif"), i = e("qJXH"), a = e("LotS");
        Object(i.b)(Object(n.a)({
            data: {
                pageText: {
                    tips: "为了你的资产安全请绑定手机号"
                },
                formData: {
                    countryCode: "+86",
                    mobile: "",
                    wxMobile: "",
                    captcha: "",
                    captchaTime: null
                },
                captcha: {
                    text: "获取验证码",
                    code: "",
                    times: 1,
                    countdown: 60,
                    textStyle: "acc-code__btn--enabled",
                    btnStyle: "",
                    timer: null
                },
                loginBtn: {
                    text: "同意协议并登录",
                    disabled: !0,
                    wxDisabled: !1,
                    wxText: "微信快速登录"
                },
                redirect: {
                    logined: "/packages/account/settings/index",
                    navigateType: "redirectTo"
                },
                agreeUrl: "https://bbs.youzan.com/forum.php?mod=viewthread&tid=672890&page=1&extra=#pid3837866"
            },
            onLoad: function(t) {
                t.redirectUrl && this.setYZData({
                    "redirect.logined": t.redirectUrl
                }), t.navigateType && this.setYZData({
                    "redirect.navigateType": t.navigateType
                }), wx.setNavigationBarTitle({
                    title: "验证码登录"
                });
            },
            loginRedirect: function() {
                var t = this.data.redirect, o = t.logined, e = t.navigateType, i = {};
                return "navigateBack" !== e ? i.url = o : i.delta = 1, wx[e](Object(n.a)(Object(n.a)({}, i), {}, {
                    success: function() {},
                    fail: function() {
                        wx.showToast({
                            icon: "none",
                            title: "登录跳转失败，请关闭小程序重新登录。"
                        });
                    }
                }));
            }
        }, a.a));
    },
    LotS: function(t, o, e) {
        var n = e("hHpg"), i = e("NERQ"), a = e("1j1R"), c = getApp();
        o.a = {
            confirmLogin: function(t) {
                void 0 === t && (t = {});
                var o = t.mobile || this.data.formData.mobile, e = t.countryCode || this.data.formData.countryCode, n = this.data.redirect.logined, i = "/packages/account/to-bind/index?mobile=" + o + "&countryCode=" + encodeURIComponent(e) + "&redirectUrl=" + encodeURIComponent(n);
                return wx.redirectTo({
                    url: i
                });
            },
            configDialog: function(t, o) {
                var e, n = this;
                if (void 0 === t && (t = !1), void 0 === o && (o = {}), t) {
                    if (!o.mobile) return wx.showToast({
                        icon: "none",
                        title: "授权获取手机号码失败，请重启小程序重新授权"
                    });
                    e = o.mobile;
                } else {
                    if (!this.data.formData.mobile) return wx.showToast({
                        icon: "none",
                        title: "请正确填写手机号码"
                    });
                    e = this.data.formData.mobile;
                }
                var a = [];
                a.push(e.substring(0, 3)), a.push("****"), a.push(e.substring(7));
                var c = "手机号" + a.join("") + "已与其他微信帐号绑定";
                i.a.confirm({
                    message: c,
                    confirmButtonText: "继续登录",
                    cancelButtonText: "换个手机号"
                }).then(function() {
                    n.confirmLogin(o);
                }).catch(function() {});
            },
            login: function() {
                var t = this, o = this.data.loginBtn.disabled, e = this.data.formData, n = e.mobile, i = e.captcha, s = e.countryCode;
                if (!o) {
                    if (!this._checkMobile(n)) return wx.showToast({
                        icon: "none",
                        title: "请输入正确的手机号"
                    });
                    if (!this._checkCaptcha(i)) return wx.showToast({
                        icon: "none",
                        title: "请正确输入收到的六位验证码"
                    });
                    var r = {
                        countryCode: s,
                        mobile: n,
                        captcha: i
                    };
                    this._beforeLogin(), a.a.loginBySms(r, function() {
                        return t._loginSuccess(), c.login(function() {
                            return t.loginRedirect();
                        });
                    }, function(o) {
                        if (t._loginFail(), 135200018 === o.code || 135200019 === o.code) return t.configDialog();
                        wx.showToast({
                            icon: "none",
                            title: o.msg || "服务请求出错，请稍后再试"
                        });
                    });
                }
            },
            wxLogin: function(t) {
                var o = this;
                if (!this.data.loginBtn.wxDisabled) {
                    if (this.beginWxLogin(), !t.detail.iv || !t.detail.encryptedData) return wx.showToast({
                        icon: "none",
                        title: "微信授权失败"
                    }), void this.resetWxLogin();
                    var e = {
                        encryptedData: t.detail.encryptedData,
                        iv: t.detail.iv,
                        appId: c.getAppId(),
                        sessionId: c.getSessionId()
                    };
                    this.loginLoading(), a.a.loginByWx(e, function() {
                        return o._loginSuccess("wxLogin"), c.login(function() {
                            return o.loginRedirect();
                        });
                    }, function(t) {
                        if (o._loginFail(t, "wxLogin"), -9999 === t.code) {
                            var e = t.res;
                            if (e && e.data && (135200018 === e.data.code || 135200019 === e.data.code) && e.data.mobile) return o.configDialog(!0, {
                                mobile: e.data.mobile,
                                countryCode: e.data.countryCode
                            });
                        }
                        var n = t.msg || "服务请求出错，请稍后再试";
                        return n = 135000049 === t.code ? "微信授权失败，请重启小程序重新授权" : n, wx.showToast({
                            icon: "none",
                            title: n
                        });
                    });
                }
            },
            wxLoginError: function() {},
            beginWxLogin: function() {
                this.setYZData({
                    "loginBtn.wxDisabled": !0
                });
            },
            resetWxLogin: function() {
                this.setYZData({
                    "loginBtn.wxDisabled": !1
                });
            },
            fetchCaptcha: function() {
                var t = this, o = this.data, e = o.captcha, n = o.formData;
                if (60 === e.countdown) if (this._checkMobile(n.mobile)) {
                    var i = e.times;
                    a.a.fetchCode(n.mobile, i, function() {
                        t._countDownForCaptchaCode(), t.setYZData({
                            "captcha.btnStyle": "countdown",
                            "captcha.textStyle": "acc-code__btn--disabled",
                            "captcha.times": i
                        });
                    }, function(t) {
                        var o = t.msg || "服务请求失败，请稍后再试";
                        wx.showToast({
                            icon: "none",
                            title: o
                        });
                    });
                } else wx.showToast({
                    icon: "none",
                    title: "请输入正确的手机号"
                });
            },
            bindMobileInput: function(t) {
                this.setYZData({
                    "formData.mobile": t.detail,
                    "loginBtn.disabled": !(t.detail && this.data.formData.captcha)
                });
            },
            bindCaptchaInput: function(t) {
                this.setYZData({
                    "formData.captcha": t.detail,
                    "loginBtn.disabled": !(t.detail && this.data.formData.mobile)
                });
            },
            _checkMobile: function(t) {
                return !(!t || 11 != t.length);
            },
            _checkCaptcha: function(t) {
                return !(!t || 6 != t.length);
            },
            _countDownForCaptchaCode: function() {
                var t = this, o = this.data.captcha.countdown;
                0 !== o ? (o--, this.setYZData({
                    "captcha.countdown": o,
                    "captcha.text": "已发送(" + o + "s)"
                }), this.data.captcha.timer = setTimeout(function() {
                    t._countDownForCaptchaCode();
                }, 1e3)) : this.setYZData({
                    "captcha.countdown": 60,
                    "captcha.text": "重新发送",
                    "captcha.btnStyle": "",
                    "captcha.textStyle": "acc-code__btn--enabled"
                });
            },
            _beforeLogin: function() {
                this.loginLoading(), this.setYZData({
                    "loginBtn.disabled": !0
                });
            },
            _afterLogin: function() {},
            _loginSuccess: function(t) {
                void 0 === t && (t = null), n.a.clear(), wx.showToast({
                    title: "登录成功",
                    icon: "success",
                    mask: !1
                }), "wxLogin" === t && this.resetWxLogin();
            },
            _loginFail: function(t, o) {
                void 0 === o && (o = null), n.a.clear();
                var e = this.data.formData, i = e.mobile, a = e.captcha, c = !(i && a), s = e.countryCode, r = e.wxMobile;
                if (t) {
                    var d = t.res;
                    d && d.data && d.data.countryCode && (s = d.data.countryCode, r = d.data.mobile);
                }
                this.setYZData({
                    "loginBtn.disabled": c,
                    "formData.countryCode": s,
                    "formData.wxMobile": r
                }), "wxLogin" === o && this.resetWxLogin();
            },
            readAgreement: function() {
                var t = encodeURIComponent(this.data.agreeUrl);
                wx.navigateTo({
                    url: "/pages/common/webview-page/index?src=" + t,
                    success: function() {},
                    error: function() {
                        wx.showToast({
                            icon: "none",
                            title: "打开《用户使用协议》失败\b"
                        });
                    }
                });
            },
            loginLoading: function(t) {
                return void 0 === t && (t = "正在登录..."), n.a.clear(), n.a.loading({
                    mask: !1,
                    selector: "#login-page-van-toast",
                    message: t
                });
            }
        };
    }
}));
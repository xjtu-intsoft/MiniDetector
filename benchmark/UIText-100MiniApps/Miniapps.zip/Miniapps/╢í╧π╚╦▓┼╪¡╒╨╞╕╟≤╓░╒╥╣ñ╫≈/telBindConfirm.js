!function() {
    "use strict";
    var e = a(require("./../vendor.js")(0)), t = a(require("./../vendor.js")(1)), n = a(require("./../config/api.js"));
    function a(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function r(e, t, n, a, r, s, o) {
        try {
            var i = e[s](o), l = i.value;
        } catch (e) {
            return void n(e);
        }
        i.done ? t(l) : Promise.resolve(l).then(a, r);
    }
    t.default.component({
        options: {
            styleIsolation: "apply-shared"
        },
        props: {
            visible: {
                type: Boolean,
                default: !1
            }
        },
        methods: {
            handleCancel: function() {
                console.log("取消绑定"), this.close(), this.$emit("onTelBindClose", 1);
            },
            close: function() {
                this.visible = !1, this.$emit("close");
            },
            getPhoneNumber: function(t) {
                var a, s = this;
                return (a = e.default.mark(function a() {
                    var r, o;
                    return e.default.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (t.$wx.detail.encryptedData) {
                                e.next = 2;
                                break;
                            }
                            return e.abrupt("return");

                          case 2:
                            return e.next = 4, s.$app.request(n.default.bindDxyUserByPhone, {
                                sessionId: s.$app.$options.globalData.unValidatedSession,
                                encryptedData: t.$wx.detail.encryptedData,
                                iv: t.$wx.detail.iv
                            });

                          case 4:
                            if (!(r = e.sent).dxyUserBind) {
                                e.next = 11;
                                break;
                            }
                            try {
                                wx.setStorageSync("sessionId", r.sessionId), wx.setStorageSync("sessionIdValidity", Date.now() + 144e5), 
                                wx.setStorageSync("simuid", r.simuid), wx.setStorageSync("dxyUserName", r.dxyUserName);
                            } catch (e) {
                                console.log(e);
                            }
                            s.close(), s.$emit("popupConfirm"), e.next = 21;
                            break;

                          case 11:
                            o = "", console.log(r, "resres"), e.t0 = r.message, e.next = "ERR_USERNAME_ALREADY_BIND" === e.t0 ? 16 : 18;
                            break;

                          case 16:
                            return o = "当前手机号已绑定,请更换", e.abrupt("break", 20);

                          case 18:
                            return o = "创建用户失败", e.abrupt("break", 20);

                          case 20:
                            wx.showToast({
                                title: o,
                                icon: "none",
                                mask: "true",
                                duration: 1e3
                            });

                          case 21:
                          case "end":
                            return e.stop();
                        }
                    }, a);
                }), function() {
                    var e = this, t = arguments;
                    return new Promise(function(n, s) {
                        var o = a.apply(e, t);
                        function i(e) {
                            r(o, n, s, i, l, "next", e);
                        }
                        function l(e) {
                            r(o, n, s, i, l, "throw", e);
                        }
                        i(void 0);
                    });
                })();
            }
        }
    }, {
        info: {
            components: {},
            on: {}
        },
        handlers: {
            "444-0": {
                tap: function() {
                    var e, t = (e = arguments[arguments.length - 1].$wx).detail && e.detail.arguments ? e.detail.arguments[0] : arguments[arguments.length - 1], n = e.detail && e.detail.arguments;
                    (e = this).handleCancel.apply(e, n || [ t ]);
                }
            },
            "444-1": {
                getphonenumber: function() {
                    var e, t = (e = arguments[arguments.length - 1].$wx).detail && e.detail.arguments ? e.detail.arguments[0] : arguments[arguments.length - 1], n = e.detail && e.detail.arguments;
                    (e = this).getPhoneNumber.apply(e, n || [ t ]);
                }
            }
        },
        models: {},
        refs: void 0
    });
}();
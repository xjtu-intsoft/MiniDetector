!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = function() {
        function e(e, t) {
            for (var r = 0; r < t.length; r++) {
                var i = t[r];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
                Object.defineProperty(e, i.key, i);
            }
        }
        return function(t, r, i) {
            return r && e(t.prototype, r), i && e(t, i), t;
        };
    }(), t = p(require("./../npm/wepy/lib/wepy.js")), r = require("./../config.js"), i = require("./../utils/request.js"), o = require("./../utils/phone.js"), a = (require("./../utils/util.js"), 
    require("./../utils/loginUtil.js")), n = require("./../error.js"), s = p(require("./../components/openappfail.js")), c = p(require("./../components/errormsg.js"));
    function p(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function u(e) {
        return function() {
            var t = e.apply(this, arguments);
            return new Promise(function(e, r) {
                return function i(o, a) {
                    try {
                        var n = t[o](a), s = n.value;
                    } catch (e) {
                        return void r(e);
                    }
                    if (!n.done) return Promise.resolve(s).then(function(e) {
                        i("next", e);
                    }, function(e) {
                        i("throw", e);
                    });
                    e(s);
                }("next");
            });
        };
    }
    function l(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
    }
    function d(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    var h = function(t) {
        function p() {
            var e, t, r;
            l(this, p);
            for (var i = arguments.length, a = Array(i), n = 0; n < i; n++) a[n] = arguments[n];
            return t = r = d(this, (e = p.__proto__ || Object.getPrototypeOf(p)).call.apply(e, [ this ].concat(a))), 
            r.$repeat = {}, r.$props = {
                openappfail: {
                    "v-bind:openFailed.sync": "openFailed"
                },
                error: {
                    "v-bind:error.sync": "errorObj"
                }
            }, r.$events = {}, r.components = {
                openappfail: s.default,
                error: c.default
            }, r.config = {
                disableScroll: !0
            }, r.computed = {
                isCourse: function() {
                    return 66 === Number(this.details.product_type);
                }
            }, r.data = {
                status: "0",
                index: 0,
                phonelist: o.phonelist,
                phoneNum: "",
                codeNum: "",
                details: !1,
                gift_receive_map: !1,
                pageQuery: !1,
                appShare: !1,
                wxuserinfo: !1,
                openId: wx.getStorageSync("openid") || "",
                timers: 0,
                platform: wx.getSystemInfoSync().platform,
                toAppUrl: "",
                getmsg: !0,
                issubmit: !1,
                detailUrl: "",
                openFailed: !1,
                errorObj: {
                    iserror: !1,
                    errorText: ""
                },
                isReceive: !1,
                giveType: "课程"
            }, r.methods = {
                courseDetail: function() {
                    if ([ 2, 81, 41, 53, 54, 55, 56, 57, 310 ].includes(Number(this.details.product_type))) return !1;
                    wx.navigateTo({
                        url: this.detailUrl
                    });
                }
            }, d(r, t);
        }
        var h, g, f;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(p, t), e(p, [ {
            key: "onLoad",
            value: (f = u(regeneratorRuntime.mark(function e(t) {
                var r;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return wx.login(), e.prev = 1, (r = this).pageQuery = t, r.appShare = r.$parent.globalData.appShare, 
                        wx.showLoading({
                            title: "正在打开"
                        }), e.next = 8, r.pageQuery;

                      case 8:
                        if (!e.sent) {
                            e.next = 10;
                            break;
                        }
                        r.getdetails();

                      case 10:
                        e.next = 15;
                        break;

                      case 12:
                        e.prev = 12, e.t0 = e.catch(1), wx.showModal({
                            title: "",
                            content: "内容获取失败，请关闭小程序重试",
                            showCancel: !1,
                            confirmText: "去首页",
                            confirmColor: "#FF6B00",
                            success: function(e) {
                                wx.reLaunch({
                                    url: "index"
                                });
                            }
                        });

                      case 15:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 1, 12 ] ]);
            })), function(e) {
                return f.apply(this, arguments);
            })
        }, {
            key: "getdetails",
            value: (g = u(regeneratorRuntime.mark(function e() {
                var t, r, o, a, s;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = this, e.prev = 1, e.next = 4, (0, i.ajax)({
                            type: "giveApi",
                            url: "getpresent",
                            method: "post",
                            params: {
                                secret_key: this.pageQuery.secret_key,
                                mark: this.pageQuery.mark
                            }
                        });

                      case 4:
                        r = e.sent, 0 === (o = r.data).h.c ? 1e7 === o.c.code ? (2 === (a = Number(o.c.gift_detail.product_type)) ? (this.giveType = "电子书", 
                        this.toAppUrl = "igetapp://ebook/detail?ebookId=" + o.c.gift_detail.product_id) : 81 === a ? (this.giveType = "讲座", 
                        this.toAppUrl = "igetapp://lecture.rn/detail?lectureId=" + o.c.gift_detail.product_id) : 41 === a ? (this.giveType = "评测", 
                        this.toAppUrl = "igetapp://evaluation/detail?eid=" + o.c.gift_detail.product_id) : a > 52 && a < 58 ? (this.giveType = "听书权益", 
                        this.toAppUrl = "igetapp://odob/vip") : 310 === a ? (this.giveType = "训练营", this.toAppUrl = "igetapp://learning/course/detail?classId=" + o.c.gift_detail.product_id + "&type=310") : (this.giveType = "课程", 
                        this.toAppUrl = "course/course_detail?course_pid=" + o.c.gift_detail.product_id + "&course_ptype=" + o.c.gift_detail.product_type + "&course_paid_status=0"), 
                        this.gift_receive_map = !1, this.details = !1, this.details = o.c.gift_detail, wx.setNavigationBarTitle({
                            title: this.details.name + "送你得到" + this.giveType
                        }), this.detailUrl = "/pages/detail?productType=" + this.details.product_type + "&productId=" + this.details.product_id + "&shareTitle=" + this.details.share_title + "&shareImg=" + this.details.share_img, 
                        this.details.is_expire && (this.status = "2"), this.details.is_expire || (this.status = this.details.total_count === this.details.received_counts ? "3" : "1", 
                        this.details.total_count !== this.details.received_counts && wx.loadFontFace({
                            family: "my-family",
                            source: 'url("https://piccdn.luojilab.com/fe-oss/default/FZYanSJW_Zhun.ttf")'
                        })), o.c.gift_receive_map && null !== o.c.gift_receive_map && o.c.gift_receive_map.length > 0 && (this.gift_receive_map = o.c.gift_receive_map), 
                        s = wx.getStorageSync("ReceiveRecord") ? JSON.parse(decodeURIComponent(wx.getStorageSync("ReceiveRecord"))) : {}, 
                        Object.keys(s).includes("" + this.pageQuery.secret_key + this.pageQuery.mark) && (this.phoneNum = s["" + this.pageQuery.secret_key + this.pageQuery.mark], 
                        this.status = "4"), this.$apply()) : t.reloadModel(n.giveError[o.c.code] + "，请退出或“点击重试”" || o.c.msg + "，请退出或“点击重试”" || "服务器错误，请退出重试或者“点击重试”") : (wx.reportMonitor("receiveDetail", 1), 
                        t.reloadModel(n.giveError[o.h.c] + "，请退出或“点击重试”" || o.h.e + "，请退出或“点击重试”" || "服务器错误，请退出重试或者“点击重试”")), 
                        e.next = 13;
                        break;

                      case 9:
                        e.prev = 9, e.t0 = e.catch(1), wx.reportMonitor("receiveDetail", 1), t.reloadModel("网络情况异常，请在网好时重试");

                      case 13:
                        wx.hideLoading();

                      case 14:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 1, 9 ] ]);
            })), function() {
                return g.apply(this, arguments);
            })
        }, {
            key: "onGetPhoneNumber",
            value: function(e) {
                var t = this;
                wx.login({
                    success: function(r) {
                        r && r.code && e && e.detail && "getPhoneNumber:ok" === e.detail.errMsg && t.getPhone(e, r.code);
                    }
                });
            }
        }, {
            key: "getPhone",
            value: function(e, t) {
                var i = this;
                wx.showLoading();
                var o = e.detail, n = o.encryptedData, s = o.iv;
                (0, a.$login)("loginByNumber", {
                    sys_code: 4,
                    app_code: r.config.appId,
                    js_code: t,
                    iv: s,
                    encrypted_data: n
                }).then(function(e) {
                    0 == e.code ? i.receive(e.data.token) : (wx.hideLoading(), wx.reportMonitor("getUserToken", 1), 
                    wx.showModal({
                        title: "提示",
                        content: e.msg,
                        showCancel: !1,
                        confirmText: "重新授权"
                    }));
                }).catch(function(e) {
                    wx.reportMonitor("getUserToken", 1), wx.hideLoading(), wx.showModal({
                        title: "提示",
                        content: "授权失败，请重试",
                        showCancel: !1,
                        confirmText: "重新登录"
                    });
                });
            }
        }, {
            key: "reloadModel",
            value: function(e) {
                var t = this;
                wx.showModal({
                    title: "",
                    content: e,
                    showCancel: !1,
                    confirmText: "点击重试",
                    confirmColor: "#FF6B00",
                    success: function(e) {
                        e.confirm && t.getdetails();
                    }
                });
            }
        }, {
            key: "showErrorMsg",
            value: function(e) {
                this.errorObj.iserror = !0, this.errorObj.errorText = e, this.$apply();
            }
        }, {
            key: "receivedy",
            value: function() {
                wx.showModal({
                    title: "",
                    content: "打开订阅消息，接受领取成功通知",
                    success: function(e) {
                        e.confirm ? wx.requestSubscribeMessage({
                            tmplIds: [ "DjbS-1FW-aLlWM-Hhz_JrRPNGkZBAsteuT1mRE6DUC8" ],
                            complete: function() {}
                        }) : e.cancel && console.log("用户点击取消");
                    }
                });
            }
        }, {
            key: "receive",
            value: (h = u(regeneratorRuntime.mark(function e(t) {
                var r, o, a, s, c;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return wx.showLoading(), r = {
                            product_id: this.details.product_id,
                            product_type: this.details.product_type,
                            secret_key: this.pageQuery.secret_key,
                            mark: this.pageQuery.mark,
                            device: this.platform,
                            token: t
                        }, o = this, e.prev = 3, e.next = 6, (0, i.ajax)({
                            type: "giveApi",
                            url: "receive",
                            method: "post",
                            params: r
                        });

                      case 6:
                        a = e.sent, (s = a.data) && 0 === s.h.c ? (wx.hideLoading(), 1e7 === s.c.code ? (this.gift_receive_map = !1, 
                        this.details = !1, this.details = s.c.gift_detail, this.phoneNum = s.c.gift_detail.receive_phone, 
                        s.c.gift_receive_map && null !== s.c.gift_receive_map && s.c.gift_receive_map.length > 0 && (o.gift_receive_map = s.c.gift_receive_map), 
                        this.status = "4", this.isReceive = !0, c = wx.getStorageSync("ReceiveRecord") ? JSON.parse(decodeURIComponent(wx.getStorageSync("ReceiveRecord"))) : {}, 
                        Object.keys(c).includes("" + o.pageQuery.secret_key + o.pageQuery.mark) || (c["" + o.pageQuery.secret_key + o.pageQuery.mark] = s.c.gift_detail.receive_phone, 
                        wx.setStorageSync("ReceiveRecord", encodeURIComponent(JSON.stringify(c)))), this.$apply()) : 100000102 === s.c.code ? this.showErrorMsg(s.c.msg || "服务器错误") : this.showErrorMsg(n.giveError[s.c.code] || s.c.msg || "服务器错误")) : (wx.hideLoading(), 
                        wx.reportMonitor("receiveFail", 1), this.showErrorMsg(s.h.e || "服务器错误")), this.$apply(), 
                        e.next = 18;
                        break;

                      case 12:
                        e.prev = 12, e.t0 = e.catch(3), wx.hideLoading(), wx.reportMonitor("receiveFail", 1), 
                        this.showErrorMsg("领取失败"), this.$apply();

                      case 18:
                      case "end":
                        return e.stop();
                    }
                }, e, this, [ [ 3, 12 ] ]);
            })), function(e) {
                return h.apply(this, arguments);
            })
        }, {
            key: "countdown",
            value: function() {
                var e = this, t = this;
                setTimeout(function() {
                    t.timers--, t.timers > 0 ? t.countdown() : t.getmsg = !0, e.$apply();
                }, 1e3);
            }
        }, {
            key: "launchAppError",
            value: function(e) {
                e.detail.errMsg && (this.openFailed = !0, this.$apply());
            }
        } ]), p;
    }(t.default.page);
    Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(h, "pages/give"));
}();
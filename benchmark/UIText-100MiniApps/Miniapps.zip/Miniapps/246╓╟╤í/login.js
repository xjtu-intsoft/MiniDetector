(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/login/login" ], {
    "16d8": function(n, t, e) {
        e.d(t, "b", function() {
            return o;
        }), e.d(t, "c", function() {
            return a;
        }), e.d(t, "a", function() {});
        var o = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, a = [];
    },
    1845: function(n, t, e) {},
    4908: function(n, t, e) {
        e.r(t);
        var o = e("16d8"), a = e("a599");
        for (var c in a) "default" !== c && function(n) {
            e.d(t, n, function() {
                return a[n];
            });
        }(c);
        e("e39b");
        var i = e("f0c5"), u = Object(i.a)(a.default, o.b, o.c, !1, null, "7161a752", null, !1, o.a, void 0);
        t.default = u.exports;
    },
    8015: function(n, t, e) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            e("d3dc"), t(e("66fd")), n(t(e("4908")).default);
        }).call(this, e("543d").createPage);
    },
    a599: function(n, t, e) {
        e.r(t);
        var o = e("ab78"), a = e.n(o);
        for (var c in o) "default" !== c && function(n) {
            e.d(t, n, function() {
                return o[n];
            });
        }(c);
        t.default = a.a;
    },
    ab78: function(n, t, e) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var o = e("d2e2"), a = {
                data: function() {
                    return {
                        checkState: 0
                    };
                },
                methods: {
                    getPhoneNumber: function(t) {
                        wx.login({
                            success: function(e) {
                                (0, o.loginApi)({
                                    encryptedData: t.detail.encryptedData,
                                    iv: t.detail.iv,
                                    code: e.code
                                }).then(function(t) {
                                    for (var e in console.log(t), t.data) n.setStorageSync(e, t.data[e]);
                                    if ((0, o.chayu)({
                                        id: t.data.user_id
                                    }).then(function(n) {
                                        console.log(n);
                                    }), 9999 == t.status) return n.showToast({
                                        title: "登录失败",
                                        icon: "none"
                                    }), !1;
                                    n.showToast({
                                        title: "登录成功",
                                        icon: "none"
                                    }), setTimeout(function() {
                                        n.reLaunch({
                                            url: "../index/index"
                                        });
                                    }, 1e3);
                                }).catch(function(t) {
                                    n.showToast({
                                        title: "失败，请重试",
                                        icon: "none"
                                    });
                                });
                            }
                        });
                    },
                    server: function() {
                        n.navigateTo({
                            url: "../helpDetail/helpDetail?id=2"
                        });
                    },
                    checkChange: function() {
                        this.checkState = !this.checkState;
                    }
                },
                onLoad: function() {
                    (0, o.getAboutUs)({
                        id: 2
                    }).then(function(n) {
                        console.log(n);
                    });
                }
            };
            t.default = a;
        }).call(this, e("543d").default);
    },
    e39b: function(n, t, e) {
        var o = e("1845");
        e.n(o).a;
    }
}, [ [ "8015", "common/runtime", "common/vendor" ] ] ]);
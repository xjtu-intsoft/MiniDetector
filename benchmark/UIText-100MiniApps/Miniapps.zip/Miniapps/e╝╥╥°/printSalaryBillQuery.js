var t = require("../../CCD63213EAC014CFAAB05A14095A0515.js"), a = getApp();

a.globalData.requestUrl;

Page({
    data: {
        orderList: [],
        lastCount: 0,
        lastPage: 1,
        inventoryFlag: "工资清单"
    },
    onLoad: function(t) {
        this.setData({
            requestUrl: a.globalData.requestUrl
        });
    },
    calltap: function() {
        wx.makePhoneCall({
            phoneNumber: "95527"
        });
    },
    deletetap: function(a) {
        wx.showModal({
            title: "温馨提示",
            content: "是否确认取消邮寄申请？",
            confirmText: "确认",
            confirmColor: "#FF7A45",
            success: function(r) {
                if (r.confirm) {
                    t.request({
                        number: a.currentTarget.dataset.alphabeta
                    }, "alterPrePrint", function(t) {
                        0 == t.data.status && wx.redirectTo({
                            url: "../printSalaryBillDelOk/printSalaryBillDelOk"
                        });
                    }, function(a) {
                        t.showError(a.data.msg);
                    });
                }
            }
        });
    },
    onShow: function() {
        var a = this;
        t.request({
            state: "0",
            pageNo: "1"
        }, "queryPrePrint", function(r) {
            if (0 == r.data.count) return t.showError("暂无预约记录"), !1;
            a.data.lastCount = r.data.count, a.setData({
                orderList: r.data.dataList
            });
        }, function(a) {
            t.showError(a.data.msg);
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {
        var a = this;
        if (20 != a.data.lastCount) return t.showError("暂无更多记录"), !1;
        t.request({
            state: "0",
            pageNo: a.data.lastPage + 1 + ""
        }, "queryPrePrint", function(t) {
            a.data.lastCount = t.data.count, a.data.lastPage += 1, a.setData({
                orderList: a.data.orderList.concat(t.data.dataList)
            });
        }, function(a) {
            t.showError(a.data.msg);
        });
    },
    onShareAppMessage: function() {
        return a.appShare();
    }
});
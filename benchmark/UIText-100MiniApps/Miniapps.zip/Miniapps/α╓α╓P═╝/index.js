var e = require("../../function/base64/base64"), t = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../../util/dataBury")), a = getApp();

Component({
    properties: {
        isShowPayInput: {
            type: Boolean,
            value: !1,
            observer: function(e, t) {}
        },
        focus: {
            type: Boolean,
            value: !1,
            observer: function(e, t) {}
        },
        remark: {
            type: String,
            value: "",
            observer: function(e, t) {}
        },
        totalFee: {
            type: String,
            value: "",
            observer: function(e, t) {}
        },
        showReturnIndexBtn: {
            type: Boolean,
            value: !1
        }
    },
    data: {
        isLoaded: !0,
        translateY: 0
    },
    methods: {
        getBoardHeight: function(e) {
            var t = this;
            this.setData({
                password: ""
            }, function() {
                t.setData({
                    translateY: e.detail.height ? wx.getSystemInfoSync().windowHeight - e.detail.height : 450
                });
            });
        },
        emptyBoardHeight: function() {
            this.setData({
                translateY: wx.getSystemInfoSync().windowHeight
            }), this.closeDialog();
        },
        setPayPass: function(e) {
            var t = this;
            e.detail.value.length > 6 ? this.setData({
                focus: !1
            }) : this.setData({
                password: e.detail.value.slice(0, 6)
            }, function() {
                6 != t.data.password.length || t.data.disabled || t.sendPayPassSubmit();
            });
        },
        sendPayPassSubmit: function() {
            var o = this, s = this;
            this.setData({
                disabled: !0
            }), a.ajaxSubmit({
                url: a.globalData.host + "pay/memberCardPay",
                method: "post",
                header: {
                    sessionId: wx.getStorageSync("memberCardInfo") && wx.getStorageSync("memberCardInfo").sessionId
                },
                data: {
                    memberId: wx.getStorageSync("memberCardInfo") && wx.getStorageSync("memberCardInfo").id,
                    payPassword: (0, e.Base64Encode)(this.data.password + "member"),
                    remark: this.data.remark,
                    totalFee: 100 * this.data.totalFee,
                    xcxId: a.globalData.xcxId
                },
                isHideLoading: !0
            }).then(function(e) {
                console.log(e), o.setData({
                    password: "",
                    focus: !1,
                    disabled: !1
                });
                try {
                    (0, t.default)({
                        act: "/pay",
                        pay_type: "arrive_pay",
                        pay_method: 2,
                        pay_sum: 100 * o.data.totalFee,
                        order_id: "",
                        pay_status: "000000" === e.data.code ? 1 : 2,
                        refer_type: s.data.showReturnIndexBtn ? "qrcode" : "xcx"
                    });
                } catch (e) {
                    console.log(e);
                }
                if ("900001" != e.data.code) if ("900002" != e.data.code) {
                    if ("000000" !== e.data.code) return wx.showToast({
                        title: e.data.msg || "支付失败",
                        icon: "none"
                    }), void o.closeDialog();
                    wx.navigateTo({
                        url: "/subPackage/business/pages/pay_page/pay_complete?inputValue=" + o.data.totalFee + "&remark=" + o.data.remark + "&payWay=会员卡支付"
                    }), o.closeDialog();
                } else wx.showModal({
                    title: "",
                    content: e.data.msg,
                    cancelText: "确定",
                    confirmColor: "#00b300",
                    confirmText: "忘记密码",
                    success: function(e) {
                        e.confirm && o.forgetPass();
                    }
                }); else wx.showModal({
                    title: "",
                    content: e.data.msg,
                    cancelText: "重新输入",
                    confirmColor: "#00b300",
                    confirmText: "忘记密码",
                    success: function(e) {
                        e.confirm ? o.forgetPass() : o.setData({
                            focus: !1
                        }, function() {
                            o.setData({
                                focus: !0
                            });
                        });
                    }
                });
            });
        },
        forgetPass: function() {
            wx.navigateTo({
                url: "/subPackage/my/pages/vip_security_center/vip_security_center?forget=1"
            });
        },
        closeDialog: function() {
            this.triggerEvent("closeDialog");
        },
        setFocus: function() {
            this.setData({
                focus: !0
            });
        }
    }
});
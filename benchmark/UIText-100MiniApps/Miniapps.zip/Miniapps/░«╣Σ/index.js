var webpackRequire = require("./../../../webpack-require");

webpackRequire("wex6", Object.assign({}, require("././../../../vendors.js").modules, {
    wex6: function(e, t, a) {
        "use strict";
        var n = a("63Ad"), i = n(a("NthX")), r = n(a("fFdx")), s = n(a("++tL")), c = a("fZnw"), o = a("WUiH"), l = a("dWkE"), u = a("g0o/"), d = a("p5k1");
        (0, s.default)({
            data: {
                popupVisible: !1,
                confirmButtonDisabled: !1
            },
            lifetimes: {
                attached: function() {
                    this.$on(u.constants.EVENT_PHONE_NUMBER_POPUP_SHOW, this.showPopup);
                }
            },
            methods: {
                showPopup: function(e) {
                    var t = this;
                    return (0, r.default)(i.default.mark(function a() {
                        var n, r, s;
                        return i.default.wrap(function(a) {
                            for (;;) switch (a.prev = a.next) {
                              case 0:
                                return n = e.detail.callback, t.callbackList = t.callbackList || [], t.callbackList.push(n), 
                                t.setData({
                                    popupVisible: !0
                                }), a.next = 6, (0, c.promisifyCall)("wx.login");

                              case 6:
                                r = a.sent, s = r.code, t.code = t.code || s;

                              case 9:
                              case "end":
                                return a.stop();
                            }
                        }, a);
                    }))();
                },
                hidePopup: function() {
                    this.data.popupVisible && (this.data.confirmButtonDisabled || (this.setData({
                        popupVisible: !1
                    }), this.handleCallback(new Error(u.constants.ERROR_MESSAGE_CANCEL))));
                },
                handleCallback: function(e) {
                    this.callbackList && this.callbackList.forEach(function(t) {
                        return t(e);
                    }), delete this.callbackList;
                },
                handleConfirmButtonClick: function() {
                    this.setData({
                        confirmButtonDisabled: !0
                    });
                },
                handleGetPhoneNumber: function(e) {
                    var t = this;
                    return (0, r.default)(i.default.mark(function a() {
                        var n, r;
                        return i.default.wrap(function(a) {
                            for (;;) switch (a.prev = a.next) {
                              case 0:
                                if (n = e.detail, a.prev = 1, n.encryptedData && n.iv) {
                                    a.next = 6;
                                    break;
                                }
                                return console.log(n.errMsg), t.setData({
                                    confirmButtonDisabled: !1
                                }), a.abrupt("return");

                              case 6:
                                return r = t.code, delete t.code, o.Toast.loading("绑定中..."), a.next = 11, (0, d.bindPhoneNumber)(n, r);

                              case 11:
                                o.Toast.clear(), (0, o.Toast)("绑定成功"), t.setData({
                                    popupVisible: !1
                                }), t.handleCallback(), a.next = 21;
                                break;

                              case 17:
                                a.prev = 17, a.t0 = a.catch(1), (0, o.ToastError)(a.t0), t.setData({
                                    confirmButtonDisabled: !1
                                });

                              case 21:
                              case "end":
                                return a.stop();
                            }
                        }, a, null, [ [ 1, 17 ] ]);
                    }))();
                },
                openWebView: function(e) {
                    var t = e.currentTarget.dataset.url;
                    (0, l.openWebView)(t);
                }
            }
        });
    }
}));
var e, t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/defineProperty")), a = getApp(), n = require("../../8D1B1FC27192379CEB7D77C508F07896.js"), i = n.toast, o = n.trim, s = n.checkPhone, r = n.checkSmsCode, l = n.isRepeatClick, u = n.encode, c = n.localData, d = require("../../726A44257192379C140C2C223B707896.js"), h = d.SmsCode, m = d.Set, f = null;

Page({
    data: {
        userConfig: null,
        phone: "",
        smscode: "",
        timeDown: -1
    },
    onLoad: function() {
        e = this;
    },
    onShow: function() {
        this.setData({
            userConfig: a.globalData.userConfig
        });
    },
    submit: function() {
        var n = this;
        s(this.data.phone) ? r(this.data.smscode) ? m({
            data: {
                bigtype: "bindmobile",
                mobile: this.data.phone,
                sms_code: this.data.smscode
            }
        }).then(function(o) {
            console.log(o), n.setData((0, t.default)({}, "userConfig.user.mobile", n.data.phone), function() {
                var t = e.data.userConfig;
                t.user.mobile = this.data.phone, c.set("userConfig", u(JSON.stringify(t))), a.globalData.userConfig = t, 
                f && clearInterval(f), i("更新成功", 2e3, function() {
                    wx.navigateBack({
                        delta: 1
                    });
                });
            });
        }) : i("请输入正确的验证码") : i("请输入正确的手机号啊");
    },
    phoneChange: function(e) {
        this.setData({
            phone: o(e.detail.value)
        });
    },
    smscodeChange: function(e) {
        this.setData({
            smscode: o(e.detail.value)
        });
    },
    getSMSCode: function() {
        var e = this;
        this.data.timeDown > 0 || l() || (s(this.data.phone) ? h({
            data: {
                bigtype: "getnumbercode",
                mobile: this.data.phone,
                sms_type: 3
            }
        }).then(function() {
            i("发送成功"), e.setData({
                timeDown: 59
            }), e.starTimeDown();
        }) : i("请输入正确的手机号啊"));
    },
    starTimeDown: function() {
        var t = this;
        f && clearInterval(f), f = setInterval(function() {
            e.data.timeDown--, e.setData({
                timeDown: t.data.timeDown
            }, function() {
                e.data.timeDown < 0 && clearInterval(f);
            });
        }, 1e3);
    },
    onUnload: function() {
        f && clearInterval(f);
    }
});
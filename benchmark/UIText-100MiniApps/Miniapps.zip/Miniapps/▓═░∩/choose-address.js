// dist/public/components/goods-cell/choose-address.js
var app = getApp();

Component({
    /**
   * 组件的属性列表
   */
    properties: {
        renderInfo: {
            type: Object,
            value: null
        }
    },
    /**
   * 组件的初始数据
   */
    data: {
        addInfo: null
    },
    lifetimes: {
        attached: function attached() {}
    },
    pageLifetimes: {
        // 组件所在页面的生命周期函数
        show: function show() {
            var _this = this;
            app.api.prequest({
                url: app.url.myAddress,
                method: "POST"
            }).then(function(res) {
                var mrad = res.data.find(function(item) {
                    return item.isDefault == 1;
                });
                _this.setData({
                    addInfo: mrad || null
                });
                _this.triggerEvent("getaddress", _this.data.addInfo);
                //console.log(res, mrad)
                        });
            console.log("parentOnShow");
        },
        hide: function hide() {},
        resize: function resize() {}
    },
    /**
   * 组件的方法列表
   */
    methods: {
        tzdzlb: function tzdzlb() {
            wx.navigateTo({
                url: "/pages/personal/address/dzlb"
            });
        }
    }
});
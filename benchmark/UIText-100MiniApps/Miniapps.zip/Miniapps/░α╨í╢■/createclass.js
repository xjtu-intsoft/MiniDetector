var e = getApp(), t = require("../../../utils/common"), s = require("../../../utils/config"), a = require("../../../utils/stat.js"), i = require("../../../utils/data.js");

Page({
    data: {
        userType: 1,
        periodName: [],
        periodCode: [],
        index: -1,
        relations: [ "爸爸", "妈妈", "爷爷", "奶奶", "外公", "外婆", "哥哥", "姐姐", "叔叔", "婶婶", "舅舅", "舅母", "姑父", "姑姑", "其他家长" ],
        relation: "",
        relationIndex: -1,
        applying: !1
    },
    onLoad: function() {
        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, s = t.userType, o = void 0 === s ? 1 : s;
        this.setData({
            userType: o
        }), i.queryRelations({
            success: function(t) {
                var s = [];
                t.forEach(function(e) {
                    s.push(e.relation);
                }), e.setData({
                    relations: s
                });
            }
        }), a.reportUB("ENADDCLASS");
    },
    onShow: function() {
        this.queryPeriod();
    },
    onShareAppMessage: function() {
        return t.getShareInfo({
            sharepage: "createclass"
        });
    },
    queryPeriod: function() {
        var e = this;
        i.queryPeriods({
            success: function(t) {
                for (var s = [], a = [], i = 0; i < t.length; i++) s.push(t[i].periodName), a.push(t[i].periodCode);
                e.setData({
                    periodName: s,
                    periodCode: a
                });
            },
            fail: function(e) {
                t.tips(e.resultMsg);
            }
        });
    },
    bindPickerChange: function(e) {
        this.setData({
            index: e.detail.value
        });
    },
    bindRelationChange: function(e) {
        this.setData({
            relation: this.data.relations[e.detail.value]
        });
    },
    formSubmit: function(a) {
        var i = this;
        if (!this.data.applying) {
            var o = a.detail.value, n = this.trim(o.className), r = o.periodName, l = this.data.periodCode[r], c = this.data.periodName[r], d = this.trim(o.userName), u = this.trim(o.stuName), f = this.data.relation, h = this.data.userType;
            if (n) if (n.length >= 15) t.showModal({
                title: "提示",
                content: "班级名称不能超过15个字",
                showCancel: !1,
                success: function(e) {
                    if (e.confirm) return !1;
                }
            }); else if (c) if (console.log(d), 1 != h || /^.{1,10}$/.test(d)) if (2 != h || /^.{1,10}$/.test(u)) if (2 != h || f) {
                var p = {
                    targetUserType: h,
                    className: n,
                    periodCode: l,
                    periodName: c,
                    userName: 1 == h ? d : "",
                    stuName: 2 == h ? u : "",
                    relation: 2 == h ? f : ""
                };
                e.globalData.qd && (p.psCode = e.globalData.qd), e.globalData.qdClassCode && (p.qdClassCode = e.globalData.qdClassCode), 
                e.globalData.qdInviteUserId && (p.inviteUserId = e.globalData.qdInviteUserId), this.setData({
                    applying: !0
                }), wx.showLoading({
                    title: "提交中",
                    mask: !0
                }), t.postSign({
                    url: s.SERVICE + "/base/applet/linkman/addClass",
                    params: p,
                    version: "1.0.0",
                    success: function(e) {
                        wx.hideLoading(), "001" == e.resultCode ? (t.setClassCode(e.data.classCode), t.setRoles(e.data.roles), 
                        t.switchRole(e.data.classCode, function() {
                            wx.setStorageSync("myclass_invitetips_show", "1"), wx.switchTab({
                                url: "/pages/main/myclass/myclass"
                            });
                        })) : t.tips(e.resultMsg);
                    },
                    fail: function(e) {
                        wx.hideLoading(), t.tips("/base/applet/linkman/addClass服务异常，请稍后重试" + e.statusCode);
                    },
                    complete: function() {
                        i.setData({
                            applying: !1
                        });
                    }
                });
            } else t.showModal({
                title: "提示",
                content: "请选择亲属关系",
                showCancel: !1,
                success: function(e) {
                    if (e.confirm) return !1;
                }
            }); else t.showModal({
                title: "提示",
                content: u ? "姓名不能超过10个字" : "姓名不能为空",
                showCancel: !1,
                success: function(e) {
                    if (e.confirm) return !1;
                }
            }); else t.showModal({
                title: "提示",
                content: d ? "姓名不能超过10个字" : "姓名不能为空",
                showCancel: !1,
                success: function(e) {
                    if (e.confirm) return !1;
                }
            }); else t.showModal({
                title: "提示",
                content: "请选择学段名称",
                showCancel: !1,
                success: function(e) {
                    if (e.confirm) return !1;
                }
            }); else t.showModal({
                title: "提示",
                content: "班级名称不能为空",
                showCancel: !1,
                success: function(e) {
                    if (e.confirm) return !1;
                }
            });
        }
    },
    trim: function(e) {
        return e ? e.replace(/\s+/g, "") : "";
    }
});
var a = getApp(), e = require("../../../6FA7039152E9388C09C16B9667134E53.js"), t = require("../../../7AD5FCE752E9388C1CB394E039434E53.js"), s = require("../../../DA50223052E9388CBC364A3761234E53.js"), n = require("../../../559B6DC352E9388C33FD05C480334E53.js");

Page({
    data: {
        resSn: 0,
        jwAvatar: "",
        jwName: "",
        needUpdateName: !1,
        sexIndex: 0,
        sexArray: [ {
            name: "请选择",
            code: 0
        } ],
        workExprIndex: 0,
        workExprArray: n.workExprArray,
        birthday: "",
        mobile: "",
        phone: "",
        email: "",
        address: "",
        startTime: "",
        endTime: ""
    },
    onLoad: function(a) {
        var e = this.data.sexArray.concat(n.sexArray), t = new Date(), s = t.getFullYear() - 50 + "-01-01", r = t.getFullYear() - 16 + "-12-31";
        this.setData({
            sexArray: e,
            startTime: s,
            endTime: r
        }), this.bindData();
    },
    bindData: function() {
        var a = this, s = {
            url: e.apiPath.RESUME_MINI,
            showLoading: !0,
            data: {
                Action: "get"
            },
            callback: {
                success: function(e) {
                    if (0 == e.Code && null != e.Data) {
                        var t = e.Data;
                        a.setData({
                            resSn: t.ResSn,
                            jwName: t.Name,
                            needUpdateName: "求职者" == t.Name.substr(0, 3),
                            jwAvatar: null == t.JwAvatar || "" == t.JwAvatar ? "/Images/avatar-default.png" : t.JwAvatar,
                            sexIndex: null == t.Sex || "" == t.Sex ? 0 : t.Sex,
                            workExprIndex: null == t.ExprYear ? 0 : t.ExprYear,
                            birthday: null == t.Birthday ? "2000-1-1" : t.Birthday,
                            mobile: null == t.Mobile ? "" : t.Mobile,
                            phone: null == t.ContactPhone ? "" : t.ContactPhone,
                            email: null == t.ContactEmail ? "" : t.ContactEmail,
                            address: null == t.ContactAddress ? "" : t.ContactAddress
                        });
                    }
                }
            }
        };
        t.requestApi(s);
    },
    changeAvatar: function() {
        var n = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "compressed" ],
            success: function(r) {
                var i = r.tempFilePaths[0];
                wx.showLoading({
                    title: "正在上传图片",
                    mask: !0
                }), wx.uploadFile({
                    url: t.serverPath + e.apiPath.UP_LOGO,
                    filePath: i,
                    name: "LogoFile",
                    formData: {
                        Action: "UpPic",
                        token: wx.getStorageSync("LoginToken")
                    },
                    success: function(e) {
                        var t = JSON.parse(e.data);
                        console.log(e), 0 == t.Code && null != t.Data ? (n.setData({
                            jwAvatar: t.Data
                        }), a.globalData.jwAvatar = t.Data) : s.showMessage("出现错误, 请稍候再试.", "none");
                    },
                    fail: function(a) {
                        s.showMessage("出现错误, 请稍候再试.", "none");
                    },
                    complete: function() {
                        wx.hideLoading();
                    }
                });
            }
        });
    },
    inputEvent: function(a) {
        var e = a.detail.value;
        switch (console.log(e, a.currentTarget.dataset.type), a.currentTarget.dataset.type) {
          case "mobile":
            this.setData({
                mobile: e
            });
            break;

          case "phone":
            this.setData({
                phone: e
            });
            break;

          case "address":
            this.setData({
                address: e
            });
            break;

          case "sex":
            this.setData({
                sexIndex: a.detail.value
            });
            break;

          case "workExpr":
            this.setData({
                workExprIndex: a.detail.value
            });
            break;

          case "birthday":
            this.setData({
                birthday: a.detail.value
            });
        }
    },
    tapSave: function() {
        var n = this;
        if (n.data.sexIndex && 0 != n.data.sexIndex) if (n.data.birthday && 0 != n.data.birthday.length) if (n.data.mobile && 0 != n.data.mobile.length) if (11 == n.data.mobile.length) if (n.data.email && 0 != n.data.email.length) if (n.data.address && 0 != n.data.address.length) {
            var r = {
                url: e.apiPath.RESUME_MINI,
                data: {
                    ResSn: n.data.resSn,
                    Action: "editInfo",
                    Name: n.data.jwName,
                    Avatar: n.data.jwAvatar,
                    Sex: n.data.sexIndex,
                    WorkExpr: n.data.workExprIndex,
                    Birthday: n.data.birthday,
                    Mobile: n.data.mobile,
                    Phone: n.data.phone,
                    Email: n.data.email,
                    Address: n.data.address,
                    SiteCode: a.globalData.siteCode,
                    OpenId: a.globalData.wechatOpenId
                },
                callback: {
                    success: function(e) {
                        0 == e.Code && s.showMessage(e.Message, "success", 1e3, {
                            successCallback: function() {
                                a.globalData.jwName = n.data.jwName, wx.navigateBack({
                                    delta: -1
                                });
                            }
                        });
                    }
                }
            };
            t.requestApi(r);
        } else s.showMessage("请填写联系地址", "none"); else s.showMessage("请填写联系邮箱", "none"); else s.showMessage("手机号码为11位号码", "none"); else s.showMessage("请填写手机号码", "none"); else s.showMessage("请选择出生日期", "none"); else s.showMessage("请选择性别", "none");
    },
    imgError: function() {
        this.setData({
            jwAvatar: "/Images/avatar-default.png"
        });
    }
});
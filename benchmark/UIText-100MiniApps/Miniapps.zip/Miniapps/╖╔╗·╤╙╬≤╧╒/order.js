var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/defineProperty")), t = getApp(), a = require("../../services/index"), r = a.initOrder, i = (a.orderForm, 
a.plan), s = a.initPrivate, d = require("../../utils/index"), n = d.dateAdd, o = d.dateSubtract, l = d.formatDate, u = d.getIdCardToInfo, h = (d.getFullAge, 
d.getFullAgeByEffectTime), c = d.birthdayToStartAndEnd, y = d.isBetween, D = d.trim, g = d.getPrice, T = require("../../utils/checkValue"), p = T.identityCardValidate, f = T.userNameValidate, m = T.phoneValidate, C = (T.emailValidate, 
T.flightValidate), A = 0;

Page({
    data: {
        ifDiscount: !1,
        toError: "",
        isScroll: !0,
        showToast: !1,
        toastText: "",
        showModal: !1,
        modalText: "",
        periodObj: {
            D: "天",
            M: "月",
            Y: "年",
            O: ""
        },
        limitValueUnit: {
            Y: "years",
            A: "years",
            D: "days",
            M: "months"
        },
        detailData: null,
        initDATA: {
            holders: {
                holderName: "",
                holderCardType: "",
                holderCardIndex: 0,
                holderCardTypeDesc: "",
                holderCardNo: "",
                holderBirthday: "",
                holderStartBirthday: "",
                holderEndBirthday: "",
                holderDefaultBirthday: "",
                holderGender: "M",
                holderMobile: "",
                holderEmail: "baoxian@ly.com",
                isShow: !0,
                cellsClass: "cells-show-desc"
            },
            insureds: {
                insuredRelation: "",
                insuredRelationIndex: 0,
                insuredRelationDesc: "",
                insuredName: "",
                insuredCardType: "",
                insuredCardIndex: 0,
                insuredCardTypeDesc: "",
                insuredCardNo: "",
                insuredBirthday: "",
                insuredStartBirthday: "",
                insuredEndBirthday: "",
                insuredDefaultBirthday: "",
                insuredGender: "M",
                qty: 1,
                isShow: !0,
                cellsClass: "cells-show-desc",
                linkman: !0,
                insuredsShow: !1
            }
        },
        totalFee: 0,
        actualPayFee: 0,
        productCode: "",
        planCode: "",
        safegyardStartTime: "",
        safegyardStartTimeStr: "",
        safegyardEndTimeStr: "",
        startTimeStart: "",
        startTimeEnd: "",
        flightCode: "",
        DATA: {},
        isAgreement: !1,
        isClick: !0,
        submitDATA: {},
        showBottomPopup: !1,
        items: [],
        holdersShow: !1,
        linkman: !0,
        positions: -1,
        orderAgain: "",
        orderAgainData: {}
    },
    showToast: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 3e3, t = this;
        this.setData({
            showToast: !0
        }), setTimeout(function() {
            t.setData({
                showToast: !1
            });
        }, e);
    },
    initPage: function() {
        var e = this.data.initDATA, a = t.globalData.orderData;
        if (!a) return !1;
        var r = a.priceFactors, i = a.safegyardStartTime, s = a.orderAgainData;
        r.map(function(t, a) {
            "insuredBirthday" === t.factorCode ? Object.assign(e, {
                safeguardAge: t.enumName
            }) : "applyPeriod" === t.factorCode && Object.assign(e, {
                safeguardPeriod: t.enumName
            });
        }), this.setData({
            totalFee: a.totalFee,
            actualPayFee: a.actualPayFee,
            productCode: a.productCode,
            planCode: a.safeguardPlanCode,
            safegyardStartTime: i,
            detailData: a,
            orderAgainData: s,
            initDATA: e
        }), this.getPlansData();
    },
    initData: function() {
        var e = this, a = this, i = t.globalData, d = i.platform, n = i.token, o = this.data, l = o.productCode, u = o.planCode, h = o.initDATA;
        r({
            params: {
                productCode: l,
                planCode: u,
                platform: d
            }
        }, function(e) {
            var t = e.data;
            if (!t) return null;
            wx.setNavigationBarTitle({
                title: t.title
            }), Object.assign(h, t), a.setData({
                initDATA: h
            }), a.initStartTime(), a.initShowDataAndBirthday(), a.initOrderAgain();
        }), s({
            token: n
        }, function(t) {
            var a = t.data, r = [];
            a.length && a.map(function(t, a) {
                var i = e.getHolderCredType(t.certType);
                r[a] = t, "" != i.desc ? r[a].CredObj = i.desc : r[a].CredObj = i.newDesc;
            }), e.setData({
                items: r
            });
        });
    },
    initOrderAgain: function() {
        var e = this.data, t = e.orderAgain, a = e.orderAgainData;
        t && this.setPageOrderInfo(a);
    },
    setPageOrderInfo: function(e) {
        var t = this, a = t.data, r = a.DATA, i = (a.orderAgain, a.detailData), s = a.initDATA, d = (s.restricNum, 
        s.restricPersonNum), n = t.data, o = n.totalFee, l = n.actualPayFee, u = r.holders, h = r.insureds, c = e.holder, y = e.insuredList;
        0 == d && (d = 1);
        var D = t.getHolderCredType(c.holderCredType);
        Object.assign(u, {
            holderName: c.holderName,
            holderCardNo: c.holderCredNo,
            holderMobile: c.holderPhone,
            holderCardType: D.type,
            holderCardIndex: D.index,
            holderCardTypeDesc: D.desc,
            holderBirthday: c.holderBirthday,
            holderDefaultBirthday: c.holderBirthday,
            holderGender: c.holderGender
        });
        for (var T = d < y.length ? d : y.length, p = 1; p < T; p++) {
            var f = Object.assign({}, h[0]);
            h.push(f), o = g(o + i.totalFee), l = g(l + i.actualPayFee);
        }
        h.map(function(e, a) {
            var r = y[a], i = t.getInsureRelation(r.relation), s = t.getInsureCredType(r.credType);
            e.insuredName = r.name, e.insuredCardNo = r.credNo, e.insuredRelation = i.type, 
            e.insuredRelationIndex = i.index, e.insuredRelationDesc = i.desc, e.insuredCardType = s.type, 
            e.insuredCardIndex = s.index, e.insuredCardTypeDesc = s.desc, e.insuredBirthday = r.birthday, 
            e.insuredDefaultBirthday = r.birthday, e.insuredGender = r.gender;
        }), Object.assign(r, {
            holders: u,
            insureds: h,
            flightCode: u.flightCode
        }), this.setData({
            DATA: r,
            totalFee: o,
            actualPayFee: l
        });
    },
    getHolderCredType: function(e) {
        var t = this.data.initDATA.holderCredList, a = -1, r = "";
        t.map(function(t, i) {
            t.paramCode == e && (a = i, r = t.paramDesc);
        });
        var i = "";
        switch (e) {
          case 1:
            i = "身份证";
            break;

          case 2:
            i = "护照";
            break;

          case 3:
            i = "港澳通行证";
            break;

          case 4:
            i = "台胞证";
            break;

          case 5:
            i = "军官证";
            break;

          case 6:
            i = "驾驶证";
            break;

          case 7:
            i = "出生证";
            break;

          case 8:
            i = "回乡证";
            break;

          case 9:
            i = "户口本";
            break;

          case 99:
            i = "其他";
        }
        return -1 == a && (e = "", a = 0), {
            type: e,
            index: a,
            desc: r,
            newDesc: i
        };
    },
    getInsureRelation: function(e) {
        var t = this.data.initDATA.insurantRelList, a = -1, r = "";
        return t.map(function(t, i) {
            t.paramCode == e && (a = i, r = t.paramDesc);
        }), -1 == a && (e = "", a = 0), {
            type: e,
            index: a,
            desc: r
        };
    },
    getInsureCredType: function(e) {
        var t = this.data.initDATA.insurantCredList, a = -1, r = "";
        return t.map(function(t, i) {
            t.paramCode == e && (a = i, r = t.paramDesc);
        }), -1 == a && (e = "", a = 0), {
            type: e,
            index: a,
            desc: r
        };
    },
    getPlansData: function() {
        var e = t.globalData;
        if (e.planDetail) return !1;
        var a = this.data.detailData, r = a.productCode, s = a.safeguardPlanCode;
        i({
            params: {
                productCode: r,
                safeguardPlanCode: s
            }
        }, function(t) {
            var a = t.data;
            if (!a) return null;
            Object.assign(e, {
                planDetail: a
            });
        });
    },
    initShowDataAndBirthday: function() {
        var e = this.data, a = e.initDATA, r = (e.limitValueUnit, e.DATA), i = e.safegyardStartTime, s = a.holderSexList, d = a.holderCredList, n = a.sexList, u = a.insurantCredList, h = a.insurantRelList, y = a.holders, D = a.insureds, g = !1, T = !1, p = !1, f = !1, m = !1, C = {};
        s && s.length > 0 && (T = !0), d && d.length > 0 && (g = !0), n && n.length > 0 && (f = !0), 
        u && u.length > 0 && (p = !0), h && h.length > 0 && (m = !0), Object.assign(C, {
            isSingleHolderGender: T,
            isSingleHolderCard: g,
            isSingleInsurantGender: f,
            isSingleInsurantCard: p,
            isSingleInsurantRelation: m
        });
        var A = y.holderEndBirthday, b = y.holderDefaultBirthday, v = y.holderCardType, x = y.holderCardIndex, w = y.holderCardTypeDesc;
        b = A = l(o("years", 18, new Date(i)), "yyyy-MM-dd"), g && (d.map(function(e, t) {
            1 == e.paramCode && (v = e.paramCode, w = e.paramDesc, x = t, Object.assign(y, {
                holderCardType: v,
                holderCardTypeDesc: w,
                holderCardIndex: x
            }));
        }), 1 === d.length && (v = d[0].paramCode, w = d[0].paramDesc, x = 0, Object.assign(y, {
            holderCardType: v,
            holderCardTypeDesc: w,
            holderCardIndex: x
        }))), Object.assign(y, {
            holderEndBirthday: A,
            holderDefaultBirthday: b
        });
        var B = D.insuredStartBirthday, S = D.insuredEndBirthday, O = D.insuredDefaultBirthday, j = D.insuredRelation, N = D.insuredRelationDesc, I = D.insuredCardType, P = D.insuredRelationIndex, M = D.insuredCardTypeDesc, k = t.globalData.orderData.priceFactors;
        (void 0 === k ? [] : k).map(function(e, t) {
            if ("insuredBirthday" === e.factorCode) {
                var a = e.lowerLimitValue, r = e.lowerLimitValueUnit, s = e.upperLimitValue, d = e.upperLimitValueUnit, n = c(r, a, d, s, i), o = n.startBirthdayDate, l = n.endBirthdayDate;
                B = o, S = l, O = l;
            }
        }), m && 1 === h.length && (j = h[0].paramCode, N = h[0].paramDesc, Object.assign(D, {
            insuredRelation: j,
            insuredRelationDesc: N
        })), p && (u.map(function(e, t) {
            1 == e.paramCode && (I = u[0].paramCode, M = u[0].paramDesc, P = t, Object.assign(D, {
                insuredCardType: I,
                insuredCardTypeDesc: M,
                insuredRelationIndex: P
            }));
        }), 1 === u.length && (I = u[0].paramCode, M = u[0].paramDesc, P = 0, Object.assign(D, {
            insuredCardType: I,
            insuredCardTypeDesc: M,
            insuredRelationIndex: P
        }))), Object.assign(D, {
            insuredStartBirthday: B,
            insuredEndBirthday: S,
            insuredDefaultBirthday: O
        }), Object.assign(a, C), this.setData({
            initDATA: a
        });
        var E = Object.assign({}, D);
        (h = h || []).map(function(e, t) {
            "本人" === e.paramDesc && Object.assign(E, {
                insuredRelation: e.paramCode,
                insuredRelationIndex: t,
                insuredRelationDesc: e.paramDesc
            });
        });
        var R = [];
        R.push(E), Object.assign(r, {
            holders: y,
            insureds: R
        }), this.setData({
            DATA: r
        });
    },
    initStartTime: function() {
        var e, t, a = this.data.initDATA, r = a.needDelay, i = a.delayDays, s = void 0 === i ? 0 : i, d = a.endInsuranceTime, o = void 0 === d ? 0 : d;
        if (o = parseInt(o), 1 == r) {
            var u = new Date(), h = new Date();
            h.setHours(23, 45, 0), u.getTime() < h.getTime() ? 0 == u.getHours() && 0 == u.getMinutes() ? (e = l(n("days", s + 1, new Date()), "yyyy-MM-dd"), 
            t = l(n("days", o + 1, new Date()), "yyyy-MM-dd")) : (e = l(n("days", s, new Date()), "yyyy-MM-dd"), 
            t = l(n("days", o, new Date()), "yyyy-MM-dd")) : (e = l(n("days", s + 1, new Date()), "yyyy-MM-dd"), 
            t = l(n("days", o + 1, new Date()), "yyyy-MM-dd"));
        } else e = l(n("days", s, new Date()), "yyyy-MM-dd"), t = l(n("days", o, new Date()), "yyyy-MM-dd");
        this.setData({
            startTimeStart: e,
            startTimeEnd: t
        }), this.startTimeChange();
    },
    changeShow: function(e) {
        var t = e.currentTarget.dataset.index, a = this.data.DATA, r = a.holders, i = a.insureds;
        if (-1 == t) {
            var s = r.isShow, d = r.cellsClass;
            return d = (s = !s) ? "cells-show-desc" : "cells-hide-desc", Object.assign(r, {
                isShow: s,
                cellsClass: d
            }), Object.assign(a, {
                holders: r
            }), this.setData({
                DATA: a
            }), !1;
        }
        var n = i[t], o = n.isShow, l = n.cellsClass;
        l = (o = !o) ? "cells-show-desc" : "cells-hide-desc", i[t].isShow = o, i[t].cellsClass = l, 
        Object.assign(i[t], {
            isShow: o,
            cellsClass: l
        }), Object.assign(a, {
            insureds: i
        }), this.setData({
            DATA: a
        });
    },
    startTimeChange: function(e) {
        var t, a;
        if (e) {
            t = e.detail.value, a = e.currentTarget.dataset.index;
        } else {
            var r = this.data, i = r.safegyardStartTime, s = r.detailData, d = r.periodObj, o = (s.maxPeriod, 
            s.maxPeriodUnit), u = void 0 === o ? "D" : o;
            s.maxPeriodUnitText;
            t = i, Object.assign(s, {
                maxPeriodUnitText: d[u]
            }), this.setData({
                detailData: s
            }), a = -2;
        }
        if (-2 == a) {
            var h, c, y = this.data.limitValueUnit, D = this.data.detailData, g = D.maxPeriod, T = D.maxPeriodUnit;
            D.maxPeriodUnitText;
            if (h = l(new Date(t.replace(/-/g, "/")), "yyyy年MM月dd日"), "O" == T) c = "终身保障"; else {
                var p = n(y[T.toUpperCase()], g, new Date(t.replace(/-/g, "/")));
                c = l(n("days", -1, p), "yyyy年MM月dd日");
            }
            return this.setData({
                safegyardStartTime: t,
                safegyardStartTimeStr: h,
                safegyardEndTimeStr: c
            }), !1;
        }
        var f = this.data.DATA, m = f.holders, C = f.insureds;
        if (-1 == a) {
            m.holderDefaultBirthday, m.holderBirthday;
            return Object.assign(m, {
                holderDefaultBirthday: t,
                holderBirthday: t
            }), Object.assign(f, {
                holders: m
            }), this.setData({
                DATA: f
            }), !1;
        }
        var A = C[a];
        A.insuredDefaultBirthday, A.insuredBirthday;
        Object.assign(C[a], {
            insuredDefaultBirthday: t,
            insuredBirthday: t
        }), Object.assign(f, {
            insureds: C
        }), this.setData({
            DATA: f
        });
    },
    clickTimeChange: function(e) {
        var a;
        a = e.detail.value;
        var r, i, s = this.data.limitValueUnit, d = this.data.detailData, u = d.maxPeriod, h = d.maxPeriodUnit;
        d.maxPeriodUnitText;
        if (r = l(new Date(a.replace(/-/g, "/")), "yyyy年MM月dd日"), "O" == h) i = "终身保障"; else {
            var y = n(s[h.toUpperCase()], u, new Date(a.replace(/-/g, "/")));
            i = l(n("days", -1, y), "yyyy年MM月dd日");
        }
        this.setData({
            safegyardStartTime: a,
            safegyardStartTimeStr: r,
            safegyardEndTimeStr: i
        });
        var D, g = this.data.DATA, T = g.insureds, p = g.holders, f = t.globalData.orderData.priceFactors, m = "";
        (void 0 === f ? [] : f).map(function(e) {
            if ("insuredBirthday" === e.factorCode) {
                var t = e.lowerLimitValue, r = e.lowerLimitValueUnit, i = e.upperLimitValue, s = e.upperLimitValueUnit, d = c(r, t, s, i, a);
                D = d.startBirthdayDate, m = d.endBirthdayDate;
            }
        }), p.holderEndBirthday = l(o("years", 18, new Date(a)), "yyyy-MM-dd"), p.holderDefaultBirthday = p.holderEndBirthday, 
        T.map(function(e) {
            e.insuredStartBirthday = D, e.insuredEndBirthday = m, e.insuredDefaultBirthday = m;
        }), Object.assign(g, {
            insureds: T,
            holders: p
        }), this.setData({
            DATA: g
        });
    },
    getInputVal: function(t) {
        var a = t.detail.value, r = t.currentTarget.dataset, i = r.index, s = r.type, d = this.data.DATA, n = d.holders, o = d.insureds;
        if (a = D(a) || "", "flightCode" == s) return this.setData((0, e.default)({}, s, a)), 
        !1;
        if (-1 == i) {
            if (1 == n.holderCardType && p(a)) {
                var l = u(a), h = l.birthday, c = l.gender;
                Object.assign(n, {
                    holderBirthday: h,
                    holderGender: c
                });
            }
            return Object.assign(n, (0, e.default)({}, s, a)), Object.assign(d, {
                holders: n
            }), this.setData({
                DATA: d
            }), !1;
        }
        if (1 == o[i].insuredCardType && p(a)) {
            var y = u(a), g = y.birthday, T = y.gender;
            Object.assign(o[i], {
                insuredBirthday: g,
                insuredGender: T
            });
        }
        Object.assign(o[i], (0, e.default)({}, s, a)), Object.assign(d, {
            insureds: o
        }), this.setData({
            DATA: d
        });
    },
    changeRelation: function(e) {
        var t = e.detail.value, a = e.currentTarget.dataset, r = a.index, i = a.type, s = this.data, d = s.DATA, n = s.initDATA, o = n.holderCredList, l = n.insurantRelList, u = n.insurantCredList, h = d.holders, c = d.insureds;
        if (-1 == r) return "card" === i && Object.assign(h, {
            holderCardIndex: t,
            holderCardType: o[t].paramCode,
            holderCardTypeDesc: o[t].paramDesc
        }), Object.assign(d, {
            holders: h
        }), this.setData({
            DATA: d
        }), !1;
        "card" === i ? Object.assign(c[r], {
            insuredCardIndex: t,
            insuredCardType: u[t].paramCode,
            insuredCardTypeDesc: u[t].paramDesc
        }) : "relation" === i && Object.assign(c[r], {
            insuredRelationIndex: t,
            insuredRelation: l[t].paramCode,
            insuredRelationDesc: l[t].paramDesc
        }), Object.assign(d, {
            insureds: c
        }), this.setData({
            DATA: d
        });
    },
    changeGender: function(e) {
        var t = e.currentTarget.dataset, a = t.index, r = t.gender, i = this.data.DATA, s = i.holders, d = i.insureds;
        if (-1 == a) return Object.assign(s, {
            holderGender: r
        }), Object.assign(i, {
            holders: s
        }), this.setData({
            DATA: i
        }), !1;
        Object.assign(d[a], {
            insuredGender: r
        }), Object.assign(i, {
            insureds: d
        }), this.setData({
            DATA: i
        });
    },
    bingAdd: function(e) {
        var t = this.data, a = t.initDATA, r = t.DATA, i = t.totalFee, s = t.actualPayFee, d = t.detailData, n = a.restricPersonNum, o = r.insureds, l = o.length;
        if (!this.getInsurantValidate(l - 1)) return this.showToast(), !1;
        l < n ? (o.map(function(e, t) {
            e.isShow, e.cellsClass;
            return e.isShow = !1, e.cellsClass = "cells-hide-desc", e;
        }), o.push(Object.assign({}, a.insureds)), Object.assign(r, {
            insureds: o
        }), i = g(i + d.totalFee), s = g(s + d.actualPayFee), this.setData({
            DATA: r,
            totalFee: i,
            actualPayFee: s
        })) : (this.setData({
            toastText: "被保人只能添加".concat(l, "个")
        }), this.showToast());
    },
    bindDelete: function(e) {
        var t = e.currentTarget.dataset.index;
        A = t, this.setData({
            showModal: !0,
            modalText: "确定删除第".concat(t + 1, "位被保人的信息吗？")
        });
    },
    hideTip: function() {
        this.setData({
            showModal: !1
        });
    },
    onConfirm: function() {
        var e = A, t = this.data, a = t.DATA, r = t.totalFee, i = t.actualPayFee, s = t.detailData, d = a.insureds;
        d.splice(e, 1), Object.assign(a, {
            insureds: d
        }), r = g(r - s.totalFee), i = g(i - s.actualPayFee), this.setData({
            DATA: a,
            totalFee: r,
            actualPayFee: i,
            showModal: !1
        });
    },
    changeAgreement: function(e) {
        var t = this.data.isAgreement;
        this.setData({
            isAgreement: !t
        });
    },
    seeTBXZ: function() {
        wx.navigateTo({
            url: "../point/point"
        });
    },
    seeBXTK: function() {
        var e = t.globalData.planDetail.product.insuranceClause;
        if (1 == e.length) {
            var a = e[0].clauseFileAddress;
            return wx.showLoading({
                title: "加载中",
                mask: !0
            }), wx.downloadFile({
                url: a,
                success: function(e) {
                    wx.hideLoading(), wx.openDocument({
                        filePath: e.tempFilePath
                    });
                }
            }), !1;
        }
        wx.navigateTo({
            url: "../provision/provision"
        });
    },
    goCustomer: function() {
        wx.navigateTo({
            url: "../InfoPage/Info"
        });
    },
    checkIDNumber: function(e, t) {
        var a = !1;
        switch (e = Number(e)) {
          case 1:
            a = p(t);
            break;

          case 2:
            a = /^[a-zA-Z0-9]*$/.test(t);
            break;

          default:
            t && (a = !0);
        }
        return a;
    },
    getValidate: function() {
        var e = this.data, t = e.DATA, a = e.initDATA, r = (e.isAgreement, e.flightCode), i = a.isSingleHolderCard, s = a.isSingleInsurantRelation, d = a.isSingleInsurantCard, o = a.insureds, c = (o.insuredStartBirthday, 
        o.insuredEndBirthday, t.holders), D = t.insureds, g = this.data.safegyardStartTime, T = a.needDelay, A = a.delayDays, b = a.endInsuranceTime, v = void 0 === b ? 0 : b, x = new Date(g.replace(/-/g, "/")).getTime(), w = l(n("days", A, new Date()), "yyyy/MM/dd"), B = l(n("days", v, new Date()), "yyyy/MM/dd"), S = Date.parse(w), O = Date.parse(B);
        if (1 === T) {
            var j = new Date(), N = j.getTime(), I = new Date();
            if (I.setHours(23, 45, 0), N < I.getTime()) {
                if (0 == j.getHours() && 0 == j.getMinutes() && !this.checkNightTime()) return !1;
            } else if (!this.checkNightTime()) return !1;
        }
        if (x > O || x < S) return this.setData({
            toastText: "起保时间已过请重新下单",
            toError: "safegyardStartTime"
        }), !1;
        if (a.flightCode && !C(r)) return this.setData({
            toastText: "请填写正确的航班号",
            toError: "flightCode"
        }), !1;
        var P = c.holderName, M = c.holderCardType, k = c.holderCardNo, E = c.holderBirthday, R = c.holderMobile;
        if (!f(P)) return this.setData({
            toastText: "请填写正确的投保人姓名",
            toError: "holderName"
        }), !1;
        if (!M) return this.setData({
            toastText: "请选择投保人证件类型",
            toError: "holderCardType"
        }), !1;
        if (i && !this.checkIDNumber(M, k)) return this.setData({
            toastText: "请填写正确的投保人证件号码",
            toError: "holderCardNo"
        }), !1;
        if (!E) return this.setData({
            toastText: "请填写正确的投保人出生日期",
            toError: "holderBirthday"
        }), !1;
        if (h(E, this.data.safegyardStartTime) < 18) return this.setData({
            toastText: "投保人年龄不满18周岁不符合投保要求",
            toError: "holderBirthday"
        }), !1;
        if (!m(R)) return this.setData({
            toastText: "请填写正确的投保人手机号",
            toError: "holderMobile"
        }), !1;
        var F = 0;
        if (D.map(function(e, t) {
            "本人" == e.insuredRelationDesc && F++;
        }), F > 1) return this.setData({
            toastText: "投被保人关系为本人的只能有一个",
            toError: "insureds"
        }), !1;
        for (var L = 0; L < D.length; L++) {
            var G = D[L], V = G.insuredRelation, U = G.insuredRelationDesc, H = G.insuredName, q = G.insuredCardType, Y = G.insuredCardNo, J = G.insuredBirthday, X = 1 === D.length ? "" : L + 1;
            if (Object.assign(D[L], {
                isShow: !0,
                cellsClass: "cells-show-desc"
            }), Object.assign(t, {
                insureds: D
            }), "本人" == U) {
                if (1 == c.holderCardType) {
                    if (p(c.holderCardNo)) {
                        var Z = u(c.holderCardNo).birthday;
                        if (!y(D[L].insuredStartBirthday, D[L].insuredEndBirthday, Z)) return this.setData({
                            DATA: t,
                            toastText: "被保人".concat(X, "的年龄不符合投保要求"),
                            toError: "insured".concat(L)
                        }), !1;
                    }
                } else if (!y(D[L].insuredStartBirthday, D[L].insuredEndBirthday, c.holderBirthday)) return this.setData({
                    DATA: t,
                    toastText: "被保人".concat(X, "的年龄不符合投保要求"),
                    toError: "insured".concat(L)
                }), !1;
            } else {
                if (!q) return this.setData({
                    DATA: t,
                    toastText: "请选择被保人".concat(X, "的证件类型"),
                    toError: "insuredCardType".concat(L)
                }), !1;
                if (s && (!V || "-1" == V)) return this.setData({
                    DATA: t,
                    toastText: "请输入与被保人".concat(X, "的关系"),
                    toError: "insuredRelation".concat(L)
                }), !1;
                if (!f(H)) return this.setData({
                    DATA: t,
                    toastText: "请填写正确的被保人".concat(X, "的姓名"),
                    toError: "insuredName".concat(L)
                }), !1;
                if (d) {
                    if (!this.checkIDNumber(q, Y)) return this.setData({
                        DATA: t,
                        toastText: "请填写正确的被保人".concat(X, "的证件号码"),
                        toError: "insuredCardNo".concat(L)
                    }), !1;
                    if (1 == q && Y === c.holderCardNo) return this.setData({
                        DATA: t,
                        toastText: "被保人".concat(X, "的证件号码与投保人相同，关系应为本人"),
                        toError: "insuredCardNo".concat(L)
                    }), !1;
                    if (1 == q) {
                        if (p(Y)) {
                            var z = u(Y).birthday;
                            if (!y(D[L].insuredStartBirthday, D[L].insuredEndBirthday, z)) return this.setData({
                                DATA: t,
                                toastText: "被保人".concat(X, "的年龄不符合投保要求"),
                                toError: "insuredBirthday".concat(L)
                            }), !1;
                        }
                    } else if (!y(D[L].insuredStartBirthday, D[L].insuredEndBirthday, J)) return this.setData({
                        DATA: t,
                        toastText: "被保人".concat(X, "的年龄不符合投保要求"),
                        toError: "insuredBirthday".concat(L)
                    }), !1;
                }
                if (!J) return this.setData({
                    toastText: "请填写正确的被保人".concat(X, "出生日期"),
                    toError: "insuredCardNo".concat(L)
                }), !1;
            }
        }
        return !0;
    },
    getInsurantValidate: function(e) {
        var t = this.data, a = t.DATA, r = t.initDATA, i = r.isSingleInsurantRelation, s = r.isSingleInsurantCard, d = r.insureds, n = d.insuredStartBirthday, o = d.insuredEndBirthday, l = a.holders, h = a.insureds, c = 0, D = e + 1;
        if (h.map(function(e, t) {
            "本人" == e.insuredRelationDesc && c++;
        }), c > 1) return this.setData({
            toastText: "投被保人关系为本人的只能有一个"
        }), !1;
        var g = h[e], T = g.insuredRelation, m = g.insuredRelationDesc, C = g.insuredName, A = g.insuredCardType, b = g.insuredCardNo, v = g.insuredBirthday;
        if ("本人" == m) {
            if (1 == l.holderCardType && p(l.holderCardNo)) {
                var x = u(l.holderCardNo).birthday;
                if (!y(n, o, x)) return this.setData({
                    toastText: "被保人".concat(D, "的年龄不符合投保要求")
                }), !1;
            }
            return !0;
        }
        if (i && !T) return this.setData({
            toastText: "请输入与被保人".concat(D, "的关系")
        }), !1;
        if (!f(C)) return this.setData({
            toastText: "请填写正确的被保人".concat(D, "的姓名")
        }), !1;
        if (s) {
            if (!this.checkIDNumber(A, b)) return this.setData({
                toastText: "请填写正确的被保人".concat(D, "的证件号码")
            }), !1;
            if (1 == A && b === l.holderCardNo) return this.setData({
                toastText: "被保人".concat(D, "的证件号码与投保人相同，关系应为本人")
            }), !1;
            if (1 == A && p(b)) {
                var w = u(b).birthday;
                if (!y(n, o, w)) return this.setData({
                    toastText: "投保人".concat(D, "的年龄不符合投保要求")
                }), !1;
            }
        }
        return !!v || (this.setData({
            toastText: "请填写正确的被保人".concat(D, "出生日期")
        }), !1);
    },
    checkNightTime: function() {
        var e = this.data, t = e.safegyardStartTime, a = e.initDATA, r = a.delayDays, i = a.endInsuranceTime, s = void 0 === i ? 0 : i, d = new Date(t.replace(/-/g, "/")), o = d.getTime(), l = n("days", r + 1, new Date()), u = n("days", s + 1, new Date()), h = l.getTime();
        if (o > u.getTime() || o < h) {
            var c = d.getFullYear(), y = d.getMonth() + 1, D = d.getDate(), g = l.getFullYear(), T = l.getMonth() + 1, p = l.getDate();
            return g == c && T == y && p == D || (this.setData({
                toastText: "对不起，您的起保时间需要重新选择",
                toError: "safegyardStartTime"
            }), !1);
        }
        return !0;
    },
    getSubmitData: function() {
        var e = this.data, a = e.initDATA, r = e.DATA, i = e.detailData, s = e.safegyardStartTime, d = e.totalFee, n = e.productCode, o = e.flightCode, l = e.planCode, u = e.linkman, h = a.isSingleHolderCard, c = a.isSingleHolderGender, y = a.isSingleInsurantRelation, D = a.isSingleInsurantCard, g = a.isSingleInsurantGender, T = i.priceFactors, p = r.holders, f = r.insureds, m = t.globalData, C = {
            channelId: m.channelId,
            refId: m.refid,
            platid: m.platid,
            platform: m.platform,
            effectTime: "".concat(s, " 00:00:00"),
            totalFee: d,
            activityCode: a.maCode,
            activityType: a.maType,
            activityPercent: a.ratio,
            productCode: n,
            safeguardPlanCode: l,
            holderName: p.holderName,
            holderMobile: p.holderMobile,
            holderEmail: p.holderEmail,
            holderBirthday: p.holderBirthday,
            priceFactors: T,
            linkman: u
        };
        a.flightCode && Object.assign(C, {
            ticketNo: o
        }), h && Object.assign(C, {
            holderCardType: p.holderCardType,
            holderCardNo: p.holderCardNo
        }), c && Object.assign(C, {
            holderGender: p.holderGender
        });
        var A, b = [], v = 0, x = a.insurantRelList;
        D && x.map(function(e, t) {
            "本人" === e.paramDesc && (A = e.paramCode);
        }), f.map(function(e, t) {
            var a = {
                insuredName: e.insuredName,
                insuredBirthday: e.insuredBirthday,
                qty: e.qty,
                linkman: e.linkman
            };
            v += e.qty, y && Object.assign(a, {
                insuredRelation: e.insuredRelation
            }), D && Object.assign(a, {
                insuredCardType: e.insuredCardType,
                insuredCardNo: e.insuredCardNo
            }), g && Object.assign(a, {
                insuredGender: e.insuredGender
            }), A == e.insuredRelation && (Object.assign(a, {
                insuredName: p.holderName,
                insuredCardType: p.holderCardType,
                insuredCardNo: p.holderCardNo,
                insuredBirthday: p.holderBirthday
            }), g && p.holderGender && Object.assign(a, {
                insuredGender: p.holderGender
            })), b.push(a);
        }), Object.assign(C, {
            qty: v,
            addInsurantForms: b
        }), this.setData({
            submitDATA: C
        });
    },
    insureBtnClick: function() {
        var e = this;
        if (!this.getValidate()) return this.showToast(), !1;
        this.getSubmitData(), wx.showLoading({
            title: "加载中",
            mask: !0
        }), this.setData({
            isClick: !1
        });
        var a = t.globalData;
        if (a.userInfo && a.token) {
            var r = a.token;
            a.userInfo;
            return e.submitData({
                token: r
            }), !0;
        }
        t.getlogin(function(r, i) {
            if (r) wx.openSetting({
                success: function() {
                    t.getlogin(function(t, r) {
                        if (t) return !1;
                        var i = r.vToken, s = r.vUserInfo;
                        Object.assign(a, {
                            token: i,
                            userInfo: s
                        }), e.submitData({
                            token: i
                        });
                    });
                }
            }); else {
                var s = i.vToken, d = i.vUserInfo;
                Object.assign(a, {
                    token: s,
                    userInfo: d
                }), e.submitData({
                    token: s
                });
            }
        });
    },
    submitData: function(e) {
        var a = e.token, r = this.data.submitDATA, i = {
            token: a
        }, s = t.globalData, d = s.recommendId, n = s.ifDiscount;
        d && "" != d && "undefined" != d && (r.recommendOpenId = d), r.allowDiscount = n ? 0 : 1;
        var o = r;
        wx.hideLoading(), wx.navigateTo({
            url: "../ReadFirst/ReadFirst?params=".concat(JSON.stringify(o), "&header=").concat(JSON.stringify(i))
        });
    },
    clPreservation: function(e) {
        if (-1 == e.currentTarget.dataset.index) this.setData({
            linkman: !this.data.linkman
        }); else if (e.currentTarget.dataset.index >= 0) {
            var t = this.data.DATA, a = t.insureds, r = e.currentTarget.dataset.index, i = {
                linkman: !a[r].linkman
            };
            Object.assign(a[r], i), this.setData({
                DATA: t
            });
        }
    },
    toggleBottomPopup: function(e) {
        var t = {
            insuredsShow: !0
        }, a = {
            insuredsShow: !1
        }, r = this.data.DATA, i = r.insureds;
        i.map(function(r, s) {
            s == e.currentTarget.dataset.type ? Object.assign(i[s], t) : Object.assign(i[s], a);
        }), -1 == e.currentTarget.dataset.type ? this.setData({
            showBottomPopup: !this.data.showBottomPopup,
            isScroll: !this.data.isScroll,
            positions: e.currentTarget.dataset.type,
            holdersShow: !0,
            DATA: r
        }) : e.currentTarget.dataset.type >= 0 ? this.setData({
            showBottomPopup: !this.data.showBottomPopup,
            isScroll: !this.data.isScroll,
            positions: e.currentTarget.dataset.type,
            holdersShow: !1,
            DATA: r
        }) : this.setData({
            showBottomPopup: !this.data.showBottomPopup,
            isScroll: !this.data.isScroll
        });
    },
    radioChange: function(e) {
        var t = this.data, a = t.items, r = t.positions, i = a[e.detail.value];
        if (r && -1 == r) {
            var s = this.getHolderCredType(i.certType), d = {
                holderName: i.linkerName,
                holderCardType: s.type,
                holderCardTypeDesc: s.desc,
                holderCardNo: i.certNo ? i.certNo : "",
                holderBirthday: i.birthday ? i.birthday : "",
                holderGender: i.sex ? i.sex : "M",
                holderMobile: i.mobile ? i.mobile : "",
                holderEmail: i.email ? i.email : "baoxian@ly.com",
                holderCardIndex: s.index
            }, n = this.data.DATA, o = n.holders;
            Object.assign(o, d), this.setData({
                showBottomPopup: !this.data.showBottomPopup,
                isScroll: !this.data.isScroll,
                DATA: n
            });
        } else {
            var l = this.getInsureCredType(i.certType), u = {
                insuredName: i.linkerName,
                insuredCardType: l.type,
                insuredCardTypeDesc: l.desc,
                insuredCardNo: i.certNo ? i.certNo : "",
                insuredBirthday: i.birthday ? i.birthday : "",
                insuredGender: i.sex ? i.sex : "M",
                insuredCardIndex: l.index
            }, h = this.data.DATA, c = h.insureds;
            Object.assign(c[r], u), this.setData({
                showBottomPopup: !this.data.showBottomPopup,
                isScroll: !this.data.isScroll,
                DATA: h
            });
        }
    },
    onLoad: function(e) {
        var t = e.orderAgain, a = void 0 === t ? "" : t;
        this.setData({
            orderAgain: a
        }), this.initPage(), this.initData();
    },
    onShow: function() {
        var e = t.globalData.ifDiscount;
        this.setData({
            ifDiscount: e
        });
    },
    onHide: function() {},
    onUnload: function() {}
});
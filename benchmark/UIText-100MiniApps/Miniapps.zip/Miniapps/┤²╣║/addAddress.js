(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "pages/addAddress/addAddress" ], {
    "11ce": function(e, t, i) {
        "use strict";
        i.r(t);
        var d = i("cb1b"), n = i("f15c");
        for (var a in n) "default" !== a && function(e) {
            i.d(t, e, function() {
                return n[e];
            });
        }(a);
        i("3799");
        var s, o = i("f0c5"), r = Object(o["a"])(n["default"], d["b"], d["c"], !1, null, null, null, !1, d["a"], s);
        t["default"] = r.exports;
    },
    "2fbf": function(e, t, i) {
        "use strict";
        (function(e) {
            i("0f39"), i("921b");
            d(i("66fd"));
            var t = d(i("11ce"));
            function d(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            e(t.default);
        }).call(this, i("543d")["createPage"]);
    },
    "334c": function(e, t, i) {},
    3799: function(e, t, i) {
        "use strict";
        var d = i("334c"), n = i.n(d);
        n.a;
    },
    "951f": function(e, t, i) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var d = n(i("0a61"));
            function n(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }
            var a = function() {
                i.e("components/uni-popup").then(function() {
                    return resolve(i("72e5"));
                }.bind(null, i)).catch(i.oe);
            }, s = function() {
                i.e("components/level-four-address/level-four-address").then(function() {
                    return resolve(i("fcde"));
                }.bind(null, i)).catch(i.oe);
            }, o = {
                components: {
                    uniPopup: a,
                    levelFourAddress: s
                },
                data: function() {
                    return {
                        sysinfo: {},
                        src: d.default.src,
                        checked: !1,
                        phone: "",
                        name: "",
                        location: "",
                        add_id: "",
                        isPopup: !1,
                        upaddress: !1,
                        back: !0,
                        ifW: !1,
                        chooseAddReady: !0,
                        adds: "",
                        province_id: "",
                        city_id: "",
                        area_id: "",
                        street_id: "",
                        selectedAddr: "",
                        isNewAddress: "",
                        onSubmitReady: !0
                    };
                },
                onLoad: function(t) {
                    var i = this;
                    this.sysinfo = e.getSystemInfoSync(), e.setNavigationBarTitle({
                        title: "新增地址"
                    }), t.name && (e.setNavigationBarTitle({
                        title: "修改地址"
                    }), i.name = t.name), t.phone && (i.phone = t.phone), t.location && (i.location = t.location), 
                    t.add_id && (i.add_id = t.add_id), t.adds && (i.adds = t.adds), t.default && (i.checked = 1 == t.default), 
                    t.province_id && (i.province_id = t.province_id), t.city_id && (i.city_id = t.city_id), 
                    t.area_id && (i.area_id = t.area_id), t.street_id && (i.street_id = t.street_id), 
                    "1" == t.ifW ? i.ifW = !0 : i.ifW = !1, t.isNewAddress && (i.isNewAddress = !0), 
                    t.selectedAddr && (this.selectedAddr = JSON.parse(t.selectedAddr));
                },
                onBackPress: function() {
                    if (e.hideLoading(), !this.ifW && (this.isPopup = !0, this.back)) return !0;
                },
                methods: {
                    hideKey: function() {},
                    onClose: function() {
                        this.isPopup = !1;
                    },
                    onBack_: function() {
                        this.back = !1, e.navigateBack({
                            delta: 1
                        });
                    },
                    columnChange: function(e) {
                        var t = this;
                        if (0 == e.detail.column) {
                            var i = t.address[0][e.detail.value].id;
                            t.getCity(i, !0);
                        }
                        if (1 == e.detail.column) {
                            i = t.address[1][e.detail.value].id;
                            t.getArea(i, !0);
                        }
                    },
                    onChange: function(e) {
                        this.province_id = this.address[0][e.target.value[0]].id, this.city_id = this.address[1][e.target.value[1]].id, 
                        this.adds = this.address[0][e.target.value[0]].region_name + "省" + this.address[1][e.target.value[1]].region_name + "市", 
                        this.address[2].length > 0 && (this.adds += this.address[2][e.target.value[2]].region_name, 
                        this.area_id = this.address[2][e.target.value[2]].id);
                    },
                    cancel: function() {},
                    switch1Change: function() {
                        this.checked = !this.checked;
                    },
                    onPopup: function() {
                        var t = this;
                        if (!(t.name && t.phone && t.adds && t.location)) return !1;
                        e.hideKeyboard();
                        var i = /^[\u4E00-\u9FA5A-Za-z]+$/;
                        if ("" == this.name) return e.showToast({
                            title: "您还未填写收货人",
                            duration: 2e3,
                            icon: "none"
                        }), !1;
                        if (!i.test(this.name)) return e.showToast({
                            title: "收货人姓名格式有误 再检查一下？",
                            duration: 2e3,
                            icon: "none"
                        }), !1;
                        if ("" == this.phone) return e.showToast({
                            title: "您忘记输入手机号码了",
                            duration: 2e3,
                            icon: "none"
                        }), !1;
                        var d = /^((\+|00)86)?1((3[\d])|(4[5,6,7,9])|(5[0-3,5-9])|(6[5-7])|(7[0-8])|(8[\d])|(9[1,8,9]))\d{8}$/;
                        return d.test(this.phone) ? "" == this.adds ? (e.showToast({
                            title: "您忘了选择所在地区",
                            duration: 2e3,
                            icon: "none"
                        }), !1) : "" == this.location ? (e.showToast({
                            title: "填写详细地址，让宝贝飞奔向您！",
                            duration: 2e3,
                            icon: "none"
                        }), !1) : void (this.onSubmitReady && (this.onSubmitReady = !1, this.onSubmit())) : (e.showToast({
                            title: "手机号码格式有误 再检查一下？",
                            duration: 2e3,
                            icon: "none"
                        }), !1);
                    },
                    onSubmit: function() {
                        var t = this;
                        t.location = t.location.replace(/^\s+|\s+$/g, ""), e.showLoading({
                            title: "正在添加",
                            mask: !0
                        });
                        this.$request({
                            url: d.default.apiUrl + "api/Member/postAddressApi",
                            data: {
                                token: d.default.newToken,
                                add_consignee: t.name,
                                add_province: t.province_id,
                                add_city: t.city_id,
                                add_distric: t.area_id,
                                add_town: t.street_id,
                                add_address: t.location,
                                add_mobile: t.phone,
                                add_default: t.checked ? 1 : 0,
                                add_id: t.add_id,
                                validate: d.default.data
                            },
                            success: function(i) {
                                return t.onSubmitReady = !0, 200 != i.statusCode ? (e.showToast({
                                    title: "服务器链接失败",
                                    icon: "none"
                                }), !1) : 9998 != i.data.status && void (200 == i.data.status ? (e.showToast({
                                    title: "地址添加成功",
                                    duration: 2e3,
                                    mask: !0,
                                    icon: "success"
                                }), t.add_id ? e.setStorageSync("isNewAddress", t.add_id) : e.setStorageSync("isNewAddress", !0), 
                                t.back = !1, setTimeout(function() {
                                    e.navigateBack({
                                        delta: 1
                                    });
                                }, 1500)) : e.showToast({
                                    title: i.data.message,
                                    duration: 2e3,
                                    icon: "none"
                                }));
                            },
                            fail: function(i) {
                                t.onSubmitReady = !0, e.hideLoading(), e.showToast({
                                    icon: "none",
                                    title: "网络连接错误"
                                });
                            }
                        });
                    },
                    hidePopup: function() {
                        this.isPopup = !1;
                    },
                    onBack: function() {
                        this.isPopup = !1;
                    },
                    getPicker: function() {
                        e.hideKeyboard(), this.$refs.addrPicker.togglePicker();
                    },
                    addressPickerHandle: function(e) {
                        e.picker ? this.upaddress = !0 : (this.upaddress = !1, this.province_id = e.province_id, 
                        this.city_id = e.city_id, this.area_id = e.area_id, this.street_id = e.street_id, 
                        this.adds = e.adds);
                    }
                }
            };
            t.default = o;
        }).call(this, i("543d")["default"]);
    },
    cb1b: function(e, t, i) {
        "use strict";
        i.d(t, "b", function() {
            return n;
        }), i.d(t, "c", function() {
            return a;
        }), i.d(t, "a", function() {
            return d;
        });
        var d = {
            auth: function() {
                return i.e("components/auth/auth").then(i.bind(null, "09ed"));
            },
            levelFourAddress: function() {
                return i.e("components/level-four-address/level-four-address").then(i.bind(null, "fcde"));
            }
        }, n = function() {
            var e = this, t = e.$createElement;
            e._self._c;
        }, a = [];
    },
    f15c: function(e, t, i) {
        "use strict";
        i.r(t);
        var d = i("951f"), n = i.n(d);
        for (var a in d) "default" !== a && function(e) {
            i.d(t, e, function() {
                return d[e];
            });
        }(a);
        t["default"] = n.a;
    }
}, [ [ "2fbf", "common/runtime", "common/vendor" ] ] ]);
var e = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
    return typeof e;
} : function(e) {
    return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
};

require("../../../runtime"), require("../../../common"), require("../../../vendors"), 
(wx.webpackJsonp_mps_esfCommon = wx.webpackJsonp_mps_esfCommon || []).push([ [ 4, 29, 30, 32, 33, 34, 35 ], {
    159: function(e, t, n) {
        n.r(t);
        n(160);
        var o = n(51);
        for (var r in o) "default" !== r && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(r);
    },
    160: function(e, t, n) {
        n(84);
    },
    161: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        }), t.fetchPrivacyPhone = t.fetchVercode = void 0;
        var o = function(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }(n(4)), r = "landlord";
        t.fetchVercode = function(e) {
            return o.default.get(r, "VERCODE", e);
        }, t.fetchPrivacyPhone = function(e) {
            return o.default.get(r, "PRIVACY_PHONE", e);
        };
    },
    162: function(e, t, n) {},
    20: function(t, n, o) {
        function r(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        function i(e) {
            return function() {
                var t = e.apply(this, arguments);
                return new Promise(function(e, n) {
                    function o(r, i) {
                        try {
                            var u = t[r](i), c = u.value;
                        } catch (e) {
                            return void n(e);
                        }
                        if (!u.done) return Promise.resolve(c).then(function(e) {
                            o("next", e);
                        }, function(e) {
                            o("throw", e);
                        });
                        e(c);
                    }
                    return o("next");
                });
            };
        }
        function u(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function c(t, n) {
            if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !n || "object" !== (void 0 === n ? "undefined" : e(n)) && "function" != typeof n ? t : n;
        }
        function a(t, n) {
            if ("function" != typeof n && null !== n) throw new TypeError("Super expression must either be null or a function, not " + (void 0 === n ? "undefined" : e(n)));
            t.prototype = Object.create(n && n.prototype, {
                constructor: {
                    value: t,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), n && (Object.setPrototypeOf ? Object.setPrototypeOf(t, n) : t.__proto__ = n);
        }
        Object.defineProperty(n, "__esModule", {
            value: !0
        });
        var s, f, p = r(o(65)), l = Object.assign || function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                for (var o in n) Object.prototype.hasOwnProperty.call(n, o) && (e[o] = n[o]);
            }
            return e;
        }, h = function() {
            function e(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var o = t[n];
                    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                    Object.defineProperty(e, o.key, o);
                }
            }
            return function(t, n, o) {
                return n && e(t.prototype, n), o && e(t, o), t;
            };
        }(), d = function e(t, n, o) {
            null === t && (t = Function.prototype);
            var r = Object.getOwnPropertyDescriptor(t, n);
            if (void 0 === r) {
                var i = Object.getPrototypeOf(t);
                return null === i ? void 0 : e(i, n, o);
            }
            if ("value" in r) return r.value;
            var u = r.get;
            if (void 0 !== u) return u.call(o);
        }, v = r(o(0)), m = r(o(109)), y = o(3), C = o(161);
        o(162);
        var b = /^[1][3,4,5,7,8,9][0-9]{9}$/, _ = (f = s = function(e) {
            function t() {
                var e, n, o, r;
                u(this, t);
                for (var i = arguments.length, a = Array(i), s = 0; s < i; s++) a[s] = arguments[s];
                return n = o = c(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(a))), 
                o.$usedState = [ "phoneNumber", "canClick", "verifyCode", "canConfirm", "title", "text", "hintOne", "hintTwo", "isCorrectPhoneNumber", "isCorrectVerifyCode", "clickTimes", "countDown", "isCountDownRunning", "infoId", "brokerId", "sourceType", "pageName", "lastPhoneNumber", "__fn_onClick" ], 
                o.onPhoneNumberInput = function(e) {
                    var t = e.detail.value || "";
                    return t.length >= 11 && (t = t.slice(0, 11)), o.setState({
                        phoneNumber: t,
                        isCorrectPhoneNumber: P(t),
                        hintOne: ""
                    }), t;
                }, o.onVerifyCodeInput = function(e) {
                    var t = e.detail.value || "";
                    return t.length >= 6 && (t = t.slice(0, 6)), o.setState({
                        verifyCode: t,
                        isCorrectVerifyCode: g(t, o.responseId),
                        hintTwo: ""
                    }), t;
                }, o.clearPhoneNumberInput = function() {
                    o.setState({
                        phoneNumber: "",
                        hintOne: ""
                    });
                }, o.clearVerfiyInput = function() {
                    o.setState({
                        verifyCode: "",
                        hintTwo: ""
                    });
                }, o.clickGetVercode = function(e) {
                    if (e) {
                        var t = o.state.phoneNumber;
                        o.props.lastPhoneNumber !== t ? P(t) ? o.getVercode() : o.setState({
                            hintOne: "电话号码格式不正确，请修改"
                        }) : o.setState({
                            hintOne: "当前号码无需再次验证"
                        });
                    }
                }, o.getVercode = function() {
                    var e = o.state, t = e.phoneNumber, n = e.clickTimes;
                    return o.setState({
                        clickTimes: n + 1
                    }), o.startTimer(), (0, C.fetchVercode)({
                        phone: t
                    }).then(function(e) {
                        var t = e.data.response_id;
                        o.responseId = t;
                    });
                }, o.startTimer = function() {
                    o.setState({
                        isCountDownRunning: !0
                    }), o.timer = setInterval(function() {
                        var e = o.state.countDown - 1;
                        -1 === e ? (o.setState({
                            isCountDownRunning: !1,
                            countDown: 60
                        }), clearTimeout(o.timer)) : o.setState({
                            countDown: e
                        });
                    }, 1e3);
                }, o.onVerifyConfirm = function(e) {
                    if (e) {
                        var t = o.state, n = t.verifyCode, r = t.phoneNumber;
                        return o.onCallToBrokerByChangePhone({
                            phone: r,
                            verCode: n,
                            responseId: o.responseId
                        });
                    }
                }, o.getPrivatePhone = function(e) {
                    return (0, C.fetchPrivacyPhone)(l({}, e)).then(function(e) {
                        var t = e.data.phone;
                        if (t) {
                            var n = o.props, r = n.onConfirm, i = n.pageName;
                            return r && o.props.onConfirm(), (0, y.makeCallPhone)(i, t, {});
                        }
                        return Promise.reject({
                            data: {
                                msg: "暂时无可用号码，请稍后再试。"
                            }
                        });
                    });
                }, o.onTouchMove = function(e) {
                    e.stopPropagation();
                }, o.onCoverClick = function() {
                    console.log(o.phoneInputRef);
                }, o.customComponents = [], r = n, c(o, r);
            }
            return a(t, m.default), h(t, [ {
                key: "_constructor",
                value: function(e) {
                    d(t.prototype.__proto__ || Object.getPrototypeOf(t.prototype), "_constructor", this).call(this, e), 
                    this.state = {
                        phoneNumber: "",
                        verifyCode: "",
                        isCorrectPhoneNumber: !1,
                        isCorrectVerifyCode: !1,
                        clickTimes: 0,
                        hintOne: "",
                        hintTwo: "",
                        countDown: 60,
                        isCountDownRunning: !1
                    }, this.responseId = "", this.phoneInputRef = v.default.createRef(), this.timer = null, 
                    this.$$refs = new v.default.RefsArray();
                }
            }, {
                key: "componentDidMount",
                value: function() {
                    var e = this.props, t = e.infoId, n = e.brokerId, o = e.sourceType, r = e.pageName;
                    this.SDK().AJKMPS.Soj.sendExpSoj(r, "xcx_esf_prop_personcall_correctmobile_exposure", {
                        info_id: t || "",
                        source_type: o || "",
                        broker_id: n || ""
                    });
                }
            }, {
                key: "onCallToBrokerByChangePhone",
                value: function() {
                    var e = i(p.default.mark(function e(t) {
                        var n, o, r, i = this, u = t.phone, c = t.verCode, a = t.responseId;
                        return p.default.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return n = this.props.infoId, e.next = 3, this.SDK().AJKMPS.getUserInfo();

                              case 3:
                                return o = e.sent, r = o.user_id, e.abrupt("return", this.getPrivatePhone({
                                    info_id: n || "",
                                    ppu: encodeURIComponent(o || ""),
                                    user_id: r || "",
                                    phone: u,
                                    ver_code: c,
                                    response_id: a
                                }).catch(function(e) {
                                    var t = e.data.msg;
                                    i.setState({
                                        hintTwo: t
                                    });
                                }));

                              case 6:
                              case "end":
                                return e.stop();
                            }
                        }, e, this);
                    }));
                    return function(t) {
                        return e.apply(this, arguments);
                    };
                }()
            }, {
                key: "_createData",
                value: function() {
                    this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
                    arguments[2], this.$prefix;
                    var e = this.__state, t = e.clickTimes, n = e.phoneNumber, o = e.verifyCode, r = (e.hintOne, 
                    e.hintTwo, e.countDown), i = e.isCountDownRunning, u = this.__props, c = u.title, a = (u.onCancel, 
                    w(n, i, t, r)), s = a.text, f = a.canClick, p = t > 0 && o.length >= 6;
                    return this.$$refs.pushRefs([ {
                        type: "dom",
                        id: "fczzz",
                        refName: "",
                        fn: this.phoneInputRef
                    } ]), Object.assign(this.__state, {
                        canClick: f,
                        canConfirm: p,
                        title: c,
                        text: s
                    }), this.__state;
                }
            }, {
                key: "funPrivatefdzzz",
                value: function() {
                    return this.props.onCancel.apply(void 0, Array.prototype.slice.call(arguments, 1));
                }
            } ]), t;
        }(), s.$$events = [ "onTouchMove", "onCoverClick", "onPhoneNumberInput", "clearPhoneNumberInput", "clickGetVercode", "onVerifyCodeInput", "clearVerfiyInput", "funPrivatefdzzz", "onVerifyConfirm" ], 
        s.defaultProps = {
            title: "更改手机号码",
            infoId: "",
            sourceType: "",
            brokerId: "",
            pageName: "",
            lastPhoneNumber: "",
            onConfirm: function() {},
            onCancel: function() {}
        }, s.$$componentPath = "component/components/changePhoneModal/index", f), P = function(e) {
            return !!b.test(e);
        }, g = function() {
            return (arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "") === (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "");
        }, w = function(e, t, n, o) {
            return 0 === n && 11 !== e.length ? {
                text: "获取验证码",
                canClick: !1
            } : 0 === n && 11 === e.length ? {
                text: "获取验证码",
                canClick: !0
            } : t && n > 0 ? {
                text: "重新获取" + o,
                canClick: !1
            } : !t && n > 0 && 11 === e.length ? {
                text: "重新获取",
                canClick: !0
            } : !t && n > 0 && 11 !== e.length ? {
                text: "重新获取",
                canClick: !1
            } : void 0;
        };
        n.default = _, Component(o(0).default.createComponent(_));
    },
    51: function(e, t, n) {
        n.r(t);
        var o = n(20), r = n.n(o);
        for (var i in o) "default" !== i && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(i);
        t.default = r.a;
    },
    84: function(e, t, n) {
        e.exports = n.p + "component/components/changePhoneModal/index.wxml";
    }
}, [ [ 159, 1, 2, 0 ] ] ]);
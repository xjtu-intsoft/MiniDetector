Page({
    data: {
        showTopTips: !1,
        radioItems: [ {
            name: "cell standard",
            value: "0"
        }, {
            name: "cell standard",
            value: "1",
            checked: !0
        } ],
        checkboxItems: [ {
            name: "standard is dealt for u.",
            value: "0",
            checked: !0
        }, {
            name: "standard is dealicient for u.",
            value: "1"
        } ],
        date: "2016-09-01",
        time: "12:01",
        countryCodes: [ "+86", "+80", "+84", "+87" ],
        countryCodeIndex: 0,
        countries: [ "中国", "美国", "英国" ],
        countryIndex: 0,
        accounts: [ "微信号", "QQ", "Email" ],
        accountIndex: 0,
        isAgree: !1
    },
    showTopTips: function() {
        var e = this;
        this.setData({
            showTopTips: !0
        }), setTimeout(function() {
            e.setData({
                showTopTips: !1
            });
        }, 3e3);
    },
    radioChange: function(e) {
        console.log("radio发生change事件，携带value值为：", e.detail.value);
        for (var a = this.data.radioItems, t = 0, n = a.length; t < n; ++t) a[t].checked = a[t].value == e.detail.value;
        this.setData({
            radioItems: a
        });
    },
    checkboxChange: function(e) {
        console.log("checkbox发生change事件，携带value值为：", e.detail.value);
        for (var a = this.data.checkboxItems, t = e.detail.value, n = 0, o = a.length; n < o; ++n) {
            a[n].checked = !1;
            for (var i = 0, c = t.length; i < c; ++i) if (a[n].value == t[i]) {
                a[n].checked = !0;
                break;
            }
        }
        this.setData({
            checkboxItems: a
        });
    },
    bindDateChange: function(e) {
        this.setData({
            date: e.detail.value
        });
    },
    bindTimeChange: function(e) {
        this.setData({
            time: e.detail.value
        });
    },
    bindCountryCodeChange: function(e) {
        console.log("picker country code 发生选择改变，携带值为", e.detail.value), this.setData({
            countryCodeIndex: e.detail.value
        });
    },
    bindCountryChange: function(e) {
        console.log("picker country 发生选择改变，携带值为", e.detail.value), this.setData({
            countryIndex: e.detail.value
        });
    },
    bindAccountChange: function(e) {
        console.log("picker account 发生选择改变，携带值为", e.detail.value), this.setData({
            accountIndex: e.detail.value
        });
    },
    bindAgreeChange: function(e) {
        this.setData({
            isAgree: !!e.detail.value.length
        });
    }
});
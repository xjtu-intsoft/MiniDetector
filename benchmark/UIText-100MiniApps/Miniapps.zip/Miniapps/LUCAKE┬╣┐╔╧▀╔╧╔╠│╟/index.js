require("./../../../webpack-require")("nVkq", Object.assign({}, require("././../../../vendors.js").modules, require("././../../../commons.js").modules, {
    NG5q: function(t, o, n) {
        var e = n("Fcif"), a = n("8B9M"), i = Object(a.a)(), c = function(t) {
            return void 0 === t && (t = {}), t = Object(e.a)({
                config: {
                    skipKdtId: !0,
                    skipShopInfo: !0,
                    noQuery: !0
                },
                method: "POST",
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                origin: "uic",
                data: {},
                success: function() {},
                fail: function() {}
            }, t), i.request(t);
        };
        o.a = {
            fetchCode: function(t, o, n) {
                return c({
                    origin: "uic",
                    pathname: "/passport/weapp/login/sms.json",
                    path: "/passport/weapp/login/sms.json",
                    data: Object(e.a)({
                        countryCode: "+86"
                    }, t, {
                        sessionId: i.getSessionId()
                    }),
                    success: function(t) {
                        o(t);
                    },
                    fail: n
                });
            },
            loginBySms: function(t, o, n) {
                return c({
                    origin: "uic",
                    pathname: "/passport/login.json",
                    path: "/passport/login.json",
                    data: t,
                    success: function(t) {
                        o(t);
                    },
                    fail: n
                });
            }
        };
    },
    nVkq: function(t, o, n) {
        n.r(o);
        var e = n("NERQ"), a = n("hHpg"), i = n("8B9M"), c = n("NG5q"), s = n("FjcP"), r = n.n(s), u = Object(i.a)();
        Component({
            properties: {
                show: {
                    type: Boolean,
                    value: !1
                },
                title: {
                    type: String,
                    value: "验证码登录"
                },
                redirectUrl: {
                    type: String,
                    value: "/packages/account/settings/index"
                }
            },
            data: {
                formData: {
                    countryCode: "+86",
                    mobile: "",
                    wxMobile: "",
                    captcha: "",
                    captchaTime: null,
                    agreement: "《用户使用协议》"
                },
                captcha: {
                    text: "获取验证码",
                    code: "",
                    countdown: 60,
                    textStyle: "acc-code__btn--enabled",
                    btnStyle: "",
                    timer: null
                },
                loginBtn: {
                    text: "登录",
                    disabled: !0,
                    wxDisabled: !1
                },
                agreement: {
                    text: "《用户使用协议》",
                    url: "https://bbs.youzan.com/forum.php?mod=viewthread&tid=672890&page=1&extra=#pid3837866"
                }
            },
            methods: {
                changeLoginType: function() {
                    this.triggerEvent("changeLoginType", {
                        type: "password"
                    });
                },
                fetchCaptcha: function() {
                    var t = this, o = this.data, n = o.captcha, e = o.formData;
                    60 === n.countdown && (this._checkMobile(e.mobile) ? r()({
                        bizType: 11,
                        onSuccess: function(o) {
                            c.a.fetchCode({
                                mobile: e.mobile,
                                ticket: o
                            }, function() {
                                t._countDownForCaptchaCode(), t.setData({
                                    "captcha.btnStyle": "countdown",
                                    "captcha.textStyle": "acc-code__btn--disabled"
                                });
                            }, function(t) {
                                var o = t.msg || "服务请求失败，请稍后再试";
                                wx.showToast({
                                    icon: "none",
                                    title: o
                                });
                            });
                        }
                    }) : wx.showToast({
                        icon: "none",
                        title: "请输入正确的手机号"
                    }));
                },
                _checkMobile: function(t) {
                    return /^\d{11}$/.test(t);
                },
                _checkCaptcha: function(t) {
                    return /^\d{6}$/.test(t);
                },
                login: function() {
                    var t = this, o = this.data.loginBtn.disabled, n = this.data.formData, e = n.mobile, i = n.captcha, s = n.countryCode;
                    if (!o) {
                        if (!this._checkMobile(e)) return wx.showToast({
                            icon: "none",
                            title: "请输入正确的手机号"
                        });
                        if (!this._checkCaptcha(i)) return wx.showToast({
                            icon: "none",
                            title: "请正确输入收到的6位验证码"
                        });
                        var r = {
                            countryCode: s,
                            mobile: e,
                            captcha: i
                        };
                        this._beforeLogin(), c.a.loginBySms(r, function() {
                            return u.login().then(function() {
                                return t._loginSuccess();
                            });
                        }, function(o) {
                            if (135200018 === o.code || 135200019 === o.code) return t.configDialog();
                            t.setData({
                                "loginBtn.disabled": !1
                            }), a.a.clear(), wx.showToast({
                                icon: "none",
                                title: o.msg || "服务请求出错，请稍后再试"
                            });
                        });
                    }
                },
                _loginSuccess: function() {
                    return a.a.clear(), this.triggerEvent("loginSuccess", {}, {}), this.setData({
                        show: !1
                    }), wx.showToast({
                        title: "登录成功",
                        icon: "success",
                        mask: !1
                    });
                },
                bindMobileInput: function(t) {
                    this.setData({
                        "formData.mobile": t.detail,
                        "loginBtn.disabled": !(t.detail && this.data.formData.captcha)
                    });
                },
                bindCaptchaInput: function(t) {
                    this.setData({
                        "formData.captcha": t.detail,
                        "loginBtn.disabled": !(t.detail && this.data.formData.mobile)
                    });
                },
                _beforeLogin: function() {
                    this.loginLoading(), this.setData({
                        "loginBtn.disabled": !0
                    });
                },
                configDialog: function(t, o) {
                    var n, a = this;
                    if (void 0 === t && (t = !1), void 0 === o && (o = {}), t) {
                        if (!o.mobile) return wx.showToast({
                            icon: "none",
                            title: "授权获取手机号码失败，请重启小程序重新授权"
                        });
                        n = o.mobile;
                    } else {
                        if (!this.data.formData.mobile) return wx.showToast({
                            icon: "none",
                            title: "请正确填写手机号码"
                        });
                        n = this.data.formData.mobile;
                    }
                    var i = [];
                    i.push(n.substring(0, 3)), i.push("****"), i.push(n.substring(7));
                    var c = "手机号" + i.join("") + "已与其他微信帐号绑定";
                    e.a.confirm({
                        message: c,
                        confirmButtonText: "继续登录",
                        cancelButtonText: "换个帐号",
                        context: this,
                        zIndex: 1e4
                    }).then(function() {
                        a.confirmLogin(o);
                    }).catch(function() {});
                },
                confirmLogin: function(t) {
                    void 0 === t && (t = {});
                    var o = t.mobile || this.data.formData.mobile, n = t.countryCode || this.data.formData.countryCode, e = this.data.redirectUrl, a = "/packages/account/to-bind/index?mobile=" + o + "&countryCode=" + encodeURIComponent(n) + "&redirectUrl=" + encodeURIComponent(e);
                    return wx.redirectTo({
                        url: a,
                        error: function() {
                            wx.showToast({
                                icon: "none",
                                title: "页面跳转失败，请重启小程序重新进入"
                            });
                        }
                    });
                },
                _countDownForCaptchaCode: function() {
                    var t = this, o = this.data.captcha.countdown;
                    0 !== o ? (o--, this.setData({
                        "captcha.countdown": o,
                        "captcha.text": "已发送(" + o + "s)"
                    }), this.data.captcha.timer = setTimeout(function() {
                        t._countDownForCaptchaCode();
                    }, 1e3)) : this.setData({
                        "captcha.countdown": 60,
                        "captcha.text": "重新发送",
                        "captcha.btnStyle": "",
                        "captcha.textStyle": "acc-code__btn--enabled"
                    });
                },
                loginLoading: function(t) {
                    return void 0 === t && (t = "正在登录..."), a.a.clear(), a.a.loading({
                        mask: !1,
                        context: this,
                        selector: "#login-loading-van-toast",
                        message: t
                    });
                }
            }
        });
    }
}));
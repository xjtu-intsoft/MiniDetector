var t = getApp(), e = require("../../utils/util"), i = e.promiseRequest, s = e.phoneValidate, a = e.galog;

e.navigatorTo;

Page({
    data: {
        mobile: "",
        isShow: !1,
        toastText: "",
        iconType: "",
        description: "",
        status: !1,
        desStatue: !1,
        userPolicyChecked: !1,
        isPolicyChecked: !1
    },
    onLoad: function(t) {
        this.checkSign(), a("留下联系方式");
    },
    onShareAppMessage: function(t) {
        return {
            title: "八戒财税公司注册代理记账办资质",
            path: this.route
        };
    },
    mobileInput: function(t) {
        this.setData({
            mobile: t.detail.value
        });
    },
    goAsk: function(e) {
        var a = this, o = this.data;
        if (o.mobile) if (s(o.mobile)) if (!o.mobile || o.description) if (o.description.length < 10 || o.description.length > 200) this.toastShow("描述文字长度不正确 正确长度10~200个汉字", "warn"); else if (o.userPolicyChecked || o.isPolicyChecked) {
            var n = {
                chanceTypeId: 117,
                remark: o.description,
                userPhone: o.mobile,
                uniqid: wx.getStorageSync("uniqid") || ""
            };
            i(t.chanceUrl + "/api/chance/submitChanceNew", n).then(function(t) {
                t.success ? (a.toastShow("提交成功", "success"), a.setData({
                    mobile: "",
                    description: ""
                })) : a.toastShow(t.data.description, "warn");
            }).catch(function(t) {
                a.toastShow("网络出现了点小问题，请稍后再试", "warn");
            });
        } else this.toastShow("请阅读并勾选猪八戒网《隐私保护政策》", "warn"); else this.toastShow("描述不能为空", "warn"); else this.toastShow("手机格式不正确", "warn"); else this.toastShow("手机号码不能为空", "warn");
    },
    desInput: function(t) {
        this.setData({
            description: t.detail.value
        });
    },
    focus: function(t) {
        this.setData({
            status: !0
        });
    },
    blur: function(t) {
        this.setData({
            status: !1
        });
    },
    desFocus: function(t) {
        this.setData({
            desStatue: !0
        });
    },
    desBlur: function(t) {
        this.setData({
            desStatue: !1
        });
    },
    toastShow: function(t, e) {
        var i = this;
        i.setData({
            isShow: !0,
            toastText: t,
            iconType: e
        }), setTimeout(function() {
            i.setData({
                isShow: !1
            });
        }, 2e3);
    },
    goCall: function() {
        wx.makePhoneCall({
            phoneNumber: "4000233766"
        });
    },
    checkSign: function() {
        var e = this;
        i(t.apiUrl + "/api/cxcms/findUserSigningAgreement").then(function(t) {
            t.success && e.setData({
                userPolicyChecked: 3 === t.data
            });
        }).catch(function(t) {
            e.toastShow("网络出现了点小问题，请稍后再试", "warn");
        });
    },
    addSign: function() {
        var e = this;
        i(t.apiUrl + "/api/cxcms/addSigningAgreement").then(function(t) {
            t.success && e.setData({
                userPolicyChecked: !0
            });
        }).catch(function(t) {
            e.toastShow("网络出现了点小问题，请稍后再试", "warn");
        });
    },
    checkboxFocus: function() {
        this.setData({
            isPolicyChecked: !this.data.isPolicyChecked
        });
    }
});
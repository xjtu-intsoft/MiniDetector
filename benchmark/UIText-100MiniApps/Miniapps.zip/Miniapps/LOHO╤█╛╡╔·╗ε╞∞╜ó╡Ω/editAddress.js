function i(i, t, e) {
    return t in i ? Object.defineProperty(i, t, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : i[t] = e, i;
}

var t = require("../../../utils/util.js"), e = require("../../../utils/config.js");

Page({
    data: {
        addressId: null,
        cityTip: "",
        provinceTip: "选择省/市/区",
        districtTip: "",
        cityShow: !1,
        districtShow: !1,
        provinceList: [],
        cityList: [],
        districtList: [],
        is_default: !1,
        consignee: "",
        province: null,
        city: null,
        district: null,
        address: "",
        mobile: ""
    },
    pickerRegion: function(i) {
        var t = this, e = i.detail.value[0], a = i.detail.value[1], n = i.detail.value[2], r = {
            regionName: e
        }, s = {
            regionName: a
        }, o = {
            regionName: n
        };
        t.setData({
            provinceTip: e,
            cityTip: a,
            districtTip: n,
            province: r,
            city: s,
            district: o
        });
    },
    getProvince: function() {
        var i = this;
        (0, t.$ajax)({
            url: e.Host.ROOT + "/regionController/getProvince"
        }).then(function(t) {
            console.log(t), i.setData({
                provinceList: t.data
            });
        });
    },
    getCity: function(i) {
        var a = this, n = i;
        (0, t.$ajax)({
            url: e.Host.ROOT + "/regionController/getCity/" + n
        }).then(function(i) {
            a.setData({
                cityList: i.data
            });
        });
    },
    getItemList: function(a, n) {
        var r = this, s = a, o = "", d = "";
        2 == n ? (o = "/regionController/getCounty/" + s, d = "districtList") : 1 == n && (o = "/regionController/getCity/" + s, 
        d = "cityList"), (0, t.showLoading)(), (0, t.$ajax)({
            url: e.Host.ROOT + o
        }).then(function(e) {
            r.setData(i({}, d, e.data)), (0, t.hideLoading)();
        });
    },
    chooseItem: function(i) {
        var t = this, e = i.currentTarget.dataset.type - 0, a = i.detail.value, n = [];
        switch (e) {
          case 0:
            var r = (n = t.data.provinceList)[a];
            t.setData({
                province: r,
                provinceTip: r.regionName,
                cityShow: !0,
                city: null,
                cityTip: "选择城市",
                district: null,
                districtShow: !1
            }), t.getItemList(r.regionId, 1);
            break;

          case 1:
            var s = (n = t.data.cityList)[a];
            t.setData({
                city: s,
                cityTip: s.regionName,
                district: null,
                districtTip: "选择区域",
                districtShow: !0
            }), t.getItemList(s.regionId, 2);
            break;

          case 2:
            var o = (n = t.data.districtList)[a];
            t.setData({
                district: o,
                districtTip: o.regionName
            });
        }
    },
    setDefaultAddress: function() {
        this.setData({
            is_default: !this.data.is_default
        });
    },
    setFormData: t.setFormData,
    addAddress: function() {
        var i = this, a = this.data, n = a.consignee, r = a.mobile, s = a.address, o = a.province, d = a.city, c = a.district, u = a.is_default;
        if ("" == n) return (0, t.showTips)("请输入收货人姓名"), !1;
        if (/\D/g.test(r)) return (0, t.showTips)("请输入正确的电话"), !1;
        if ("" == s) return (0, t.showTips)("请输入详细地址"), !1;
        if (null == o || null == d || null == c) return (0, t.showTips)("请选择完整地址"), !1;
        (0, t.showLoading)();
        var l = "";
        l = null != i.data.addressId ? "/user/updAddress" : "/user/addAddress", (0, t.$ajax)({
            url: e.Host.ROOT + l,
            method: "POST",
            header: {
                Cookie: "userId=" + wx.getStorageSync("userId").openId
            },
            data: {
                addressId: i.data.addressId,
                customerId: wx.getStorageSync("userId").openId,
                userId: wx.getStorageSync("userId").openId,
                consignee: n,
                mobile: r,
                address: s,
                provinceName: o.regionName,
                cityName: d.regionName,
                districtName: c.regionName,
                isDefault: u - 0,
                loho_id: wx.getStorageSync("userId").userId,
                zipcode: "000000",
                email: "",
                tel: "",
                sign_building: "",
                best_time: "",
                country: 1
            }
        }).then(function(i) {
            (0, t.hideLoading)(), wx.navigateBack({
                delta: 1
            });
        });
    },
    onLoad: function(i) {
        var t = this;
        if ("undefined" != i.addressInfo) {
            var e = JSON.parse(i.addressInfo);
            console.log(e), t.setData({
                addressId: e.addressId,
                consignee: e.consignee,
                mobile: e.mobile,
                address: e.address,
                province: {
                    regionId: e.province,
                    regionName: e.provinceName
                },
                city: {
                    regionId: e.city,
                    regionName: e.cityName
                },
                district: {
                    regionId: e.district,
                    regionName: e.districtName
                },
                is_default: e.isDefault,
                cityTip: e.cityName,
                provinceTip: e.provinceName,
                districtTip: e.districtName,
                cityShow: !0,
                districtShow: !0
            });
        }
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});
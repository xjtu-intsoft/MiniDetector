function a(a) {
    if (Array.isArray(a)) {
        for (var t = 0, e = Array(a.length); t < a.length; t++) e[t] = a[t];
        return e;
    }
    return Array.from(a);
}

var t = function(a) {
    return a && a.__esModule ? a : {
        default: a
    };
}(require("../../../vant-weapp/toast/toast")), e = require("../../../utils/util.js"), o = getApp(), n = o.httpRequest, s = o.upLoadFile;

Page({
    data: {
        IsUpLoadWorksBtnShow: !0,
        EndDate: e.formatTimeTwo(new Date().getTime() / 1e3, "Y-M-D"),
        StartDate: e.formatTimeTwo(new Date(new Date().getFullYear() - 70, new Date().getMonth(), new Date().getDate()).getTime() / 1e3, "Y-M-D"),
        ShowData: {
            birthDayDate: "请选择日期",
            workAgeData: "请选择时间",
            CategoryColumns: "请选择行业",
            PositionNameData: "请点我定位",
            SelectCityData: "请选择城市",
            addImgText: "拍照/相册",
            worksImgsUrlList: [],
            worksImgsNameList: [],
            idCardImgsUrlList: [],
            idCardImgsList: [],
            certificateTypeData: "请选择证件"
        },
        SexColumns: [],
        CategoryColumns: [],
        WorkAgeColumns: [],
        AreaList: [],
        ApplyInfo: {
            name: "",
            sex: "",
            birth_day: "选择日期",
            wechat_number: "",
            server_category: "",
            school: "",
            work_age: 0,
            areaData: [],
            latitude: 0,
            longitude: 0,
            address: "",
            certificate_type: "请选择证件类型",
            certificate_number: "",
            phone: ""
        }
    },
    onLoad: function(a) {
        var t = this;
        wx.showLoading({
            title: "加载中",
            mask: !0
        }), n("/api/common/get/xml/constant", "get", {}, function(a) {
            if (0 === a.data.status) {
                console.log(a), o.globalData.xmlConstant !== a.data.data && (o.globalData.xmlConstant = a.data.data), 
                o.globalData.xmlConstant.school.push({
                    name: "无"
                });
                var e = JSON.parse(JSON.stringify(o.globalData.xmlConstant.school));
                e.map(function(a) {
                    "无" === a.name ? a.name += "（三公里）" : a.name += "（五公里）";
                }), t.setData({
                    WorkAgeColumns: o.globalData.xmlConstant.work_age,
                    CategoryColumns: o.globalData.xmlConstant.service_industry,
                    SchoolColumns: e
                }), wx.hideLoading();
            }
        }), wx.getStorage({
            key: "ApplyInfo",
            success: function(a) {
                null != a.data ? (t.setData({
                    ApplyInfo: a.data
                }), wx.getStorage({
                    key: "ShowData",
                    success: function(a) {
                        null == a.data ? wx.setStorage({
                            key: "ShowData",
                            data: t.data.ShowData
                        }) : a.data.worksImgsNameList && a.data.worksImgsNameList.length >= 5 ? t.setData({
                            IsUpLoadWorksBtnShow: !1,
                            ShowData: a.data
                        }) : t.setData({
                            ShowData: a.data
                        });
                    },
                    fail: function() {
                        wx.setStorage({
                            key: "ShowData",
                            data: t.data.ShowData
                        });
                    }
                })) : wx.setStorage({
                    key: "ApplyInfo",
                    data: t.data.ApplyInfo
                });
            },
            fail: function() {
                wx.setStorage({
                    key: "ApplyInfo",
                    data: t.data.ApplyInfo
                });
            }
        }), wx.getStorage({
            key: "areaList",
            success: function(a) {
                t.setData({
                    AreaList: a.data
                });
            },
            fail: function() {
                n("/api/common/get-provinces", "get", {}, function(a) {
                    for (var e = 0; e < a.data.data.length; e++) a.data.data[e].isLeaf = !1;
                    t.setData({
                        AreaList: a.data.data
                    }), wx.setStorage({
                        key: "areaList",
                        data: a.data.data
                    });
                });
            }
        });
    },
    onShow: function() {
        o.loginSuccess();
    },
    onSetStorageApply: function() {
        wx.setStorage({
            key: "ApplyInfo",
            data: this.data.ApplyInfo
        }), wx.setStorage({
            key: "ShowData",
            data: this.data.ShowData
        });
    },
    onNameInputBlur: function(a) {
        this.setData({
            "ApplyInfo.name": a.detail.value
        }), this.onSetStorageApply();
    },
    onSexChange: function(a) {
        this.setData({
            "ApplyInfo.sex": parseInt(a.detail)
        }), this.onSetStorageApply();
    },
    onChangeBirthDay: function(a) {
        this.setData({
            "ApplyInfo.birth_day": a.detail.value
        }), this.onSetStorageApply();
    },
    onWechatNumberBlur: function(a) {
        this.setData({
            "ApplyInfo.wechat_number": a.detail.value
        }), this.onSetStorageApply();
    },
    onCategoryColumnsChange: function(a) {
        this.setData({
            "ApplyInfo.server_category": parseInt(this.data.CategoryColumns[a.detail.value].value),
            "ShowData.CategoryColumns": this.data.CategoryColumns[a.detail.value].name
        }), this.onSetStorageApply();
    },
    onSchoolBlur: function(a) {
        this.setData({
            "ApplyInfo.school": a.detail.value
        }), this.onSetStorageApply();
    },
    onSchoolChange: function(a) {
        console.log(o.globalData.xmlConstant.school), this.setData({
            "ApplyInfo.school": o.globalData.xmlConstant.school[a.detail.value].name
        }), this.onSetStorageApply();
    },
    onWorkAgeChange: function(a) {
        this.setData({
            "ApplyInfo.work_age": parseInt(this.data.WorkAgeColumns[a.detail.value].value),
            "ShowData.workAgeData": this.data.WorkAgeColumns[a.detail.value].name
        }), this.onSetStorageApply();
    },
    onClickShowAreaListPicker: function() {
        this.setData({
            IsAreaListShow: !0
        });
    },
    onChangeAreaListPicker: function(a) {
        this.setData({
            "ApplyInfo.areaData": a.detail.value,
            "ShowData.SelectCityData": a.detail.done && a.detail.options.map(function(a) {
                return a.label;
            }).join("/")
        });
    },
    onChangeAreaListLoad: function(t) {
        var e = this, o = t.detail.value, s = [].concat(a(this.data.AreaList));
        wx.showLoading({
            mask: !0
        }), n("/api/common/get-provinces", "get", {
            parent_code: o[o.length - 1]
        }, function(a) {
            if (1 == o.length) try {
                s.forEach(function(t, n) {
                    if (t.value == o[0]) {
                        for (var i = 0; i < a.data.data.length; i++) a.data.data[i].isLeaf = !1;
                        throw s[n].children = a.data.data, e.setData({
                            "ApplyInfo.areaData": o,
                            AreaList: s
                        }), wx.setStorage({
                            key: "areaList",
                            data: s
                        }), "城市数据更新成功，跳出forEach";
                    }
                });
            } catch (a) {
                console.log(a);
            } else if (2 == o.length) try {
                s.forEach(function(t, n) {
                    t.value == o[0] && s[n].children.forEach(function(t, i) {
                        if (t.value == o[1]) throw s[n].children[i].children = a.data.data, e.setData({
                            "ApplyInfo.areaData": o,
                            AreaList: s
                        }), wx.setStorage({
                            key: "areaList",
                            data: s
                        }), "城区数据更新成功，跳出forEach";
                    });
                });
            } catch (a) {
                console.log(a);
            }
            wx.hideLoading();
        });
    },
    onCloseAreaListPicker: function() {
        this.setData({
            IsAreaListShow: !1
        });
    },
    onClickShowPositionPicker: function() {
        var a = this;
        wx.chooseLocation({
            success: function(t) {
                "" !== t.name || "" !== t.address ? a.setData({
                    "ApplyInfo.latitude": t.latitude,
                    "ApplyInfo.longitude": t.longitude,
                    "ApplyInfo.address": t.address,
                    "ApplyInfo.position_name": t.name,
                    "ShowData.PositionNameData": t.name
                }) : 0 === a.data.ApplyInfo.latitude && 0 === a.data.ApplyInfo.longitude && a.setData({
                    "ShowData.PositionNameData": "定位失败，请重新点击定位"
                });
            },
            fail: function() {
                0 === a.data.ApplyInfo.latitude && 0 === a.data.ApplyInfo.longitude && a.setData({
                    "ShowData.PositionNameData": "定位失败，请重新点击定位"
                });
            },
            complete: function() {
                a.onSetStorageApply();
            }
        });
    },
    onAddressBlur: function(a) {
        this.setData({
            "ApplyInfo.address": a.detail.value
        }), this.onSetStorageApply();
    },
    onClickAddImg: function(a) {
        var t = this, e = this.data.ShowData.worksImgsUrlList, o = this.data.ShowData.worksImgsNameList;
        e && e.length >= 5 ? wx.showModal({
            title: "提示",
            content: "图片只能上传5张",
            showCancel: !1,
            confirmText: "我知道啦"
        }) : wx.chooseImage({
            count: 5 - o.length,
            success: function(a) {
                var n = 1;
                wx.showLoading({
                    title: "上传中...",
                    mask: !0
                });
                for (var i = a.tempFiles, l = i.length, r = 0; r < i.length; r++) if (i[r].size <= 2e6) {
                    var d = i[r];
                    s("/api/dresser/upload/image", d.path, "image", {}, {
                        type: 2
                    }, function(a) {
                        var s = JSON.parse(a.data);
                        e.push(s.data.url), o.push(s.data.filename), t.setData({
                            "ShowData.worksImgsUrlList": e,
                            "ShowData.worksImgsNameList": o
                        }), wx.setStorage({
                            key: "ShowData",
                            data: t.data.ShowData
                        }), o && o.length >= 5 && t.setData({
                            IsUpLoadWorksBtnShow: !1
                        }), n++ === l && wx.hideLoading();
                    });
                } else wx.showToast({
                    title: "上传的图片不能大于2M!",
                    icon: "none",
                    success: function() {
                        n++ < l && setTimeout(function() {
                            console.log(n, l), wx.showLoading({
                                title: "上传中...",
                                mask: !0
                            });
                        }, 1e3);
                    }
                });
            }
        });
    },
    onClickImgsPreview: function(a) {
        var t = a.target.dataset.index, e = this.data.ShowData.worksImgsUrlList;
        wx.previewImage({
            current: e[t],
            urls: e
        });
    },
    onClickImgDel: function(a) {
        var t = this, e = a.target.dataset.index, o = this.data.ShowData.worksImgsUrlList, s = this.data.ShowData.worksImgsNameList;
        null == s[e] && s.splice(e, 1), null != o[e] ? wx.showModal({
            content: "确定删除？",
            success: function(a) {
                if (a.confirm) {
                    var i = {
                        filename: s[e],
                        type: 2
                    };
                    n("/api/dresser/delete/image", "post", i, function(a) {
                        0 == a.data.status ? (s.splice(e, 1), o.splice(e, 1), t.setData({
                            "ShowData.worksImgsUrlList": o,
                            "ShowData.worksImgsNameList": s
                        }), wx.setStorage({
                            key: "ShowData",
                            data: t.data.ShowData
                        }), s && s.length < 5 && t.setData({
                            IsUpLoadWorksBtnShow: !0
                        }), wx.showToast({
                            title: "删除成功",
                            icon: "success",
                            duration: 1e3
                        })) : 40104 == a.data.status && wx.showToast({
                            title: "删除失败",
                            icon: "fail",
                            duration: 1e3
                        });
                    });
                }
            }
        }) : o.splice(e, 1);
    },
    onClickGoToNext: function() {
        "" == this.data.ApplyInfo.name ? (0, t.default)({
            message: "姓名不能为空",
            duration: 1e3
        }) : "" == this.data.ApplyInfo.sex ? (0, t.default)({
            message: "性别不能为空",
            duration: 1e3
        }) : "" == this.data.ApplyInfo.birth_day ? (0, t.default)({
            message: "生日不能为空",
            duration: 1e3
        }) : "" == this.data.ApplyInfo.wechat_number ? (0, t.default)({
            message: "微信号不能为空",
            duration: 1e3
        }) : "请选择行业" == this.data.ApplyInfo.server_category ? (0, t.default)({
            message: "服务行业不能为空",
            duration: 1e3
        }) : "" == this.data.ApplyInfo.work_age ? (0, t.default)({
            message: "工作经验不能为空",
            duration: 1e3
        }) : 0 == this.data.ApplyInfo.latitude || 0 == this.data.ApplyInfo.latitude ? (0, 
        t.default)({
            message: "入驻定位必须选择",
            duration: 1e3
        }) : "" == this.data.ApplyInfo.address ? (0, t.default)({
            message: "详细地址不能为空",
            duration: 1e3
        }) : wx.navigateTo({
            url: "./verification"
        });
    }
});
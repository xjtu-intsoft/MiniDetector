function e(t) {
    var a = t.data.second;
    if (0 != a) setTimeout(function() {
        t.setData({
            second: a - 1
        }), e(t);
    }, 1e3); else t.setData({
        selected: !1,
        second: 60
    });
}

require("../../../vendor/qcloud-weapp-client-sdk/index.js");

var t = require("../../../utils/api.js"), a = require("../../../utils/commin.js");

getApp();

Page({
    data: {
        second: 60,
        selected: !1,
        verification: null,
        phone: "",
        code: "",
        isPhone: !0,
        toastHidden: !0,
        promptNew: "注册失败",
        userInfo: {},
        skipPage: "",
        isLoading: !0
    },
    onShow: function() {
        var e = {
            page: "pages/personalCenter/personalPage/personalPage",
            des: "手机注册"
        };
        a.pageMonitoring(t, e);
    },
    onLoad: function(e) {
        this.setData({
            userInfo: wx.getStorageSync("userInfo"),
            skipPage: e.skipPage
        });
    },
    getphone: function(e) {
        this.setData({
            phone: e.detail.value
        });
    },
    getCode: function(a) {
        var n = this, o = n.data.phone;
        if (/^1[34578]\d{9}$/.test(o)) {
            this.setData({
                selected: !0
            }), e(n);
            var s = {
                phone: o
            };
            t.getList("POST", "notification/sms/sendCode", s).then(function(e) {
                console.log(e);
            });
        } else wx.showModal({
            title: "提示",
            content: "您输入的手机号有误，请输入正确的手机号。",
            showCancel: !1,
            success: function(e) {
                e.confirm && console.log("用户点击确定");
            }
        });
    },
    getNumber: function(e) {
        this.setData({
            code: e.detail.value
        });
    },
    navigateTo: function() {
        wx.navigateBack();
    },
    register: function() {
        var e = this, a = this, n = {
            url: "/pages/personalCenter/rechargePage/rechargePage?skipPage=" + a.data.skipPage
        }, o = a.data.code, s = a.data.phone;
        if ("" == o) wx.showModal({
            title: "提示",
            content: "验证码不能为空，请输入验证码！",
            showCancel: !1,
            success: function(e) {
                e.confirm && console.log("用户点击确定");
            }
        }); else {
            a.setData({
                isLoading: !1
            });
            var i = {
                phone: s,
                code: o
            };
            t.getList("POST", "user/bindPhone", i).then(function(o) {
                a.setData({
                    isLoading: !0
                }), "000000" == o.data.code ? (wx.redirectTo(n), t.getList("GET", "user/isBindPhone", formData).then(function(e) {
                    wx.setStorage({
                        key: "isBindPhone",
                        data: e.data.data.bindStatus
                    });
                })) : "300100" == o.data.code ? e.setData({
                    toastHidden: !1,
                    promptNew: "验证码错误"
                }) : "300101" == o.data.code && e.setData({
                    toastHidden: !1,
                    promptNew: "手机号重复"
                });
            });
        }
    },
    serviceTerms: function() {
        wx.navigateTo({
            url: "/pages/personalCenter/serviceAgreement/serviceAgreement"
        });
    },
    toastChange: function() {
        this.setData({
            toastHidden: !0
        });
    }
});
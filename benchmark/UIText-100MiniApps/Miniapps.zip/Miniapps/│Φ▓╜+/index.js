var t, a, e, i, r = require("../../@babel/runtime/helpers/interopRequireDefault"), n = r(require("../../@babel/runtime/regenerator")), s = r(require("../../@babel/runtime/helpers/asyncToGenerator"));

Page({
    data: {
        image: "",
        petName: "",
        varietyTitle: "品种",
        varietyValue: {
            id: null,
            value: ""
        },
        varietyList: "",
        typeList: [ {
            title: "性别",
            list: [],
            mode: "selector",
            value: "gender",
            dataIndex: 0
        }, {
            title: "身高",
            list: [],
            mode: "selector",
            value: "shoulder",
            dataIndex: 0
        }, {
            title: "体重",
            list: [],
            mode: "selector",
            value: "weight",
            dataIndex: 0
        }, {
            title: "出生日期",
            mode: "date",
            value: "",
            dataIndex: 0
        } ],
        petIndex: null,
        paramInfo: null,
        character: [],
        characterActive: [],
        dis: !1
    },
    onLoad: function(t) {
        this.setData({
            petIndex: t.index,
            paramInfo: t.info
        }), this.getPet();
    },
    setInfo: (i = (0, s.default)(n.default.mark(function t() {
        var a, e, i, r, s, d, c, o;
        return n.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                a = wx.getStorageSync("petInfo")[this.data.petIndex], e = a.pet, i = e.image, r = e.nickname, 
                s = e.variety, d = e.birthday, c = e.character, this.data.id = a.pet_id, this.data.image = i, 
                this.data.petName = r, this.data.varietyValue.value = s && s.title ? s.title : "", 
                this.data.varietyValue.id = s && s.id ? s.id : 0, this.data.characterActive = c || [], 
                o = this.data.typeList.map(function(t, e) {
                    return "date" == t.mode && (t.dataIndex = d), e <= 2 && (t.dataIndex = a.pet[t.value]), 
                    t;
                }), console.log(o), this.setData({
                    image: i,
                    petName: r,
                    varietyValue: this.data.varietyValue,
                    typeList: o
                });

              case 11:
              case "end":
                return t.stop();
            }
        }, t, this);
    })), function() {
        return i.apply(this, arguments);
    }),
    gotoTicket: function() {
        wx.navigateTo({
            url: "../variety/index?variety=" + JSON.stringify(this.data.varietyList) + "&hots=" + JSON.stringify(this.data.variety_hots)
        });
    },
    bindPicker: function(t) {
        var a = t.detail.value, e = t.currentTarget.dataset.picker;
        this.data.typeList[e].dataIndex = a, this.setData({
            typeList: this.data.typeList
        });
    },
    handleUploadImg: (e = (0, s.default)(n.default.mark(function t() {
        var a;
        return n.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return t.next = 2, getApp().http.uploadImage(1);

              case 2:
                a = t.sent, console.log(a), a.length >= 1 && this.setData({
                    image: a[0]
                });

              case 5:
              case "end":
                return t.stop();
            }
        }, t, this);
    })), function() {
        return e.apply(this, arguments);
    }),
    getPet: (a = (0, s.default)(n.default.mark(function t() {
        var a, e, i, r;
        return n.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                return a = wx.getStorageSync("petInfo")[this.data.petIndex], e = a ? a.pet.character : [], 
                t.next = 4, getApp().http.getPet();

              case 4:
                i = t.sent, console.log(i), 1e3 == i.data.code ? (this.data.typeList.map(function(t) {
                    if ("date" == t.mode) {
                        var e = new Date(), r = e.getMonth() + 1, n = e.getDate();
                        r >= 1 && r <= 9 && (r = "0" + r), n >= 0 && n <= 9 && (n = "0" + n), t.dataIndex = a ? a.birthday : e.getFullYear() + "-" + r + "-" + n;
                    }
                    return t.list = i.data.data[t.value], t;
                }), this.data.varietyList = i.data.data.variety, this.data.variety_hots = i.data.data.variety_hot, 
                this.data.character = i.data.data.character.map(function(t) {
                    return console.log(e), console.log(e.some(function(a) {
                        return a == t;
                    })), {
                        name: t,
                        select: e.some(function(a) {
                            return a == t;
                        })
                    };
                }), console.log(this.data.character), this.setData({
                    typeList: this.data.typeList,
                    varietyList: this.data.varietyList,
                    character: this.data.character
                }), "editPetInfo" == this.data.paramInfo && this.setInfo()) : (wx.showToast({
                    icon: "none",
                    title: "网络不佳"
                }), r = setTimeout(function() {
                    wx.navigateBack({
                        delta: 1
                    }), clearTimeout(r);
                }, 1e3));

              case 7:
              case "end":
                return t.stop();
            }
        }, t, this);
    })), function() {
        return a.apply(this, arguments);
    }),
    handleInputName: function(t) {
        var a = t.detail.value;
        this.setData({
            petName: a
        });
    },
    selectTap: function(t) {
        var a = this, e = t.currentTarget.dataset.index;
        this.data.characterActive.find(function(t) {
            return t == a.data.character[e].name;
        }) ? this.data.characterActive.forEach(function(t, i) {
            t == a.data.character[e].name && (a.data.character[e].select = !1, a.data.characterActive.splice(i, 1));
        }) : (this.data.characterActive.push(this.data.character[e].name), this.data.character[e].select = !0), 
        this.setData({
            characterActive: this.data.characterActive,
            character: this.data.character
        }), console.log(this.data.characterActive);
    },
    save: (t = (0, s.default)(n.default.mark(function t() {
        var a, e;
        return n.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                if (!this.data.dis) {
                    t.next = 2;
                    break;
                }
                return t.abrupt("return", !1);

              case 2:
                return this.setData({
                    dis: !0
                }), a = {
                    image: this.data.image,
                    nickname: this.data.petName,
                    variety: this.data.varietyValue.id,
                    gender: null,
                    shoulder: null,
                    weight: null,
                    birthday: null,
                    character: this.data.characterActive
                }, this.data.typeList.forEach(function(t) {
                    "date" == t.mode ? a.birthday = t.dataIndex : a[t.value] = t.dataIndex;
                }), "editPetInfo" == this.data.paramInfo && (a.id = wx.getStorageSync("petInfo")[this.data.petIndex].pet_id), 
                wx.showLoading({
                    title: "保存中..."
                }), setTimeout(function() {
                    return wx.hideLoading();
                }, 1e3), t.next = 10, getApp().http.editPetInfo(a, this.data.paramInfo);

              case 10:
                e = t.sent, wx.setStorageSync("petSelect", ""), 1e3 === e.data.code ? (wx.showToast({
                    title: "保存成功"
                }), this.setData({
                    dis: !1
                }), wx.navigateBack({
                    delta: 1
                })) : (console.log(e.data.message), this.setData({
                    dis: !1
                }), wx.showToast({
                    icon: "none",
                    title: e.data.message
                })), setTimeout(function() {
                    return wx.hideLoading();
                }, 1500);

              case 14:
              case "end":
                return t.stop();
            }
        }, t, this);
    })), function() {
        return t.apply(this, arguments);
    }),
    onReady: function() {},
    onShow: function() {
        wx.hideShareMenu();
    },
    onHide: function() {},
    onUnload: function() {}
});
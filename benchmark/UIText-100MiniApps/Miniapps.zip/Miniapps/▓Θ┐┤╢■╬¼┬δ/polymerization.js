var e = require("../../../@babel/runtime/helpers/interopRequireDefault");

require("../../../@babel/runtime/helpers/Arrayincludes"), require("../../../@babel/runtime/helpers/Arrayincludes"), 
require("../../../@babel/runtime/helpers/Arrayincludes"), require("../../../@babel/runtime/helpers/Arrayincludes"), 
require("../../../@babel/runtime/helpers/Arrayincludes"), require("../../../@babel/runtime/helpers/Arrayincludes"), 
require("../../../@babel/runtime/helpers/Arrayincludes"), require("../../../@babel/runtime/helpers/Arrayincludes");

var t = e(require("../../../@babel/runtime/helpers/toConsumableArray")), a = e(require("../../../@babel/runtime/regenerator")), o = e(require("../../../@babel/runtime/helpers/asyncToGenerator")), r = e(require("../../../@babel/runtime/helpers/defineProperty")), i = e(require("../../../@babel/runtime/helpers/typeof")), n = require("../../../utils/index"), s = require("../../../utils/CONST"), c = require("../../../appconfig/config"), d = e(require("../../../utils/i18n/index")), u = require("../../../fe-common/dist/utils/index"), l = e(require("../../../fe-common/dist/processor/RecordTag/index")), m = require("../../../fe-common/dist/processor/Gradient/helpers"), g = e(require("../FocusIdWatcher/index")), p = e(require("../Form/Elements/config")), f = e(require("../../../utils/wxRequest"));

function h(e, t) {
    var a = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        t && (o = o.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), a.push.apply(a, o);
    }
    return a;
}

var _, v = getApp(), y = require("../../../utils/util.js").request, b = require("../../../utils/qqmap-wx-jssdk.js"), S = require("../../../utils/util.js"), D = 0, k = {
    "4g": 1,
    wifi: 2,
    "5g": 3,
    "2g": 4,
    "3g": 5,
    none: 6,
    unknown: 7
};

function N() {
    return Math.random().toString(14).substring(2);
}

var w, I = {
    time: {
        el: "",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    },
    date: {
        el: ".date",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    },
    text: {
        el: ".input-wrap",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    },
    textarea: {
        el: ".textarea",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    },
    number: {
        el: ".number-wrap",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    },
    identity: {
        el: ".input-wrap",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    },
    owner_address: {
        el: ".input-wrap",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    },
    carnumber: {
        el: ".input-wrap",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    },
    name: {
        el: ".input-wrap",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    },
    customer_number: {
        el: ".input-wrap",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    },
    job_number: {
        el: ".input-wrap",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    },
    recorder: {
        el: "",
        msg: d.default.config.common.pleaseAuthWechat
    },
    tel: {
        el: "",
        msg: d.default.config.common.pleaseAuthPhone
    },
    address: {
        el: "",
        msg: d.default.config.common.pleaseAuthLocation
    },
    radio: {
        el: ".radio-wrap label",
        msg: d.default.config.common.mustCheck
    },
    sex: {
        el: ".radio-wrap label",
        msg: d.default.config.common.mustCheck
    },
    checkbox: {
        el: ".checkbox-wrap label",
        msg: d.default.config.common.mustCheck
    },
    checklist: {
        el: ".right",
        msg: d.default.config.common.mustCheckAll
    },
    image: {
        el: ".add",
        msg: "".concat(d.default.config.common.please).concat(d.default.config.common.addPicture)
    },
    audio: {
        el: ".add",
        msg: "".concat(d.default.config.common.please).concat(d.default.config.common.clickToRecord)
    },
    video: {
        el: ".add",
        msg: "".concat(d.default.config.common.please).concat(d.default.config.common.addVideo)
    },
    matrix: {
        el: ".table",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    },
    chained_selects: {
        el: ".chained-selects-wrap",
        msg: "".concat(d.default.config.common.content).concat(d.default.config.common.mustBeFilled)
    }
}, T = {
    alpha: "字母",
    number: "数字",
    alphaNum: "字母数字组合"
}, x = {
    identity: {
        el: ".input-wrap",
        msg: d.default.config.common.inputError
    },
    number: {
        el: ".number-wrap",
        msg: d.default.config.common.inputError
    },
    carnumber: {
        el: ".input-wrap",
        msg: d.default.config.common.inputError
    },
    job_number: {
        el: ".input-wrap",
        msg: d.default.config.common.inputError
    },
    customer_number: {
        el: ".input-wrap",
        msg: d.default.config.common.inputError
    },
    checkbox: {
        el: ".checkbox-wrap label",
        msg: d.default.config.common.inputError
    }
};

(0, n.Component)({
    options: {
        addGlobalClass: !0
    },
    properties: {
        capacityInfo: {
            type: Object
        },
        tasksList: {
            type: Object
        },
        options: {
            type: Object,
            default: {}
        },
        memaryRecord: {
            type: Object,
            default: {},
            observer: function() {
                var e = this.data.options.expandLog;
                this.setNickName && 1 === e && this.setNickName();
            }
        },
        memaryUser: {
            type: Object,
            default: {}
        },
        setOnShow: {
            type: Function,
            default: function() {}
        },
        setOnPageScroll: {
            type: Function,
            default: function() {}
        },
        backLen: {
            type: Number
        },
        isAuth: {
            type: Boolean
        },
        isCustom: {
            type: Boolean,
            value: !1
        },
        doAuth: {
            type: Function
        },
        calcHeight: {
            type: Number
        },
        setPaddingBottom: {
            type: Function,
            value: function() {}
        },
        setHeaderCoverify: {
            type: Function,
            value: function() {}
        },
        noShadow: {
            type: Boolean,
            value: !1
        },
        emptyTips: {
            type: Object,
            value: {}
        },
        canAddRecordTime: {
            type: Number,
            value: 1
        },
        isBeforeRecordTime: {
            type: Number,
            value: 0
        },
        canAddRecord: {
            type: Boolean,
            value: !0
        },
        ownerCanAddRecord: {
            type: Boolean,
            value: !0
        },
        customLimitText: {
            type: String,
            value: ""
        },
        ownerCustomLimitText: {
            type: String,
            value: ""
        },
        limitType: {
            type: Number,
            value: 0
        },
        limitTimeStart: {
            type: String,
            value: ""
        },
        timeLimitType: {
            type: Number,
            value: 0
        },
        limitTimeMsg: {
            type: Array,
            value: []
        },
        limitTimeEnd: {
            type: String,
            value: ""
        },
        formAuth: {
            type: Number,
            value: 8
        },
        caseId: {
            type: String,
            value: ""
        },
        tplId: {
            type: String,
            value: ""
        },
        from: {
            type: String,
            value: ""
        },
        expandLog: {
            type: Number
        },
        isTplCreate: {
            type: Boolean,
            value: !1
        },
        formData: {
            type: Object
        },
        isEditTpl: {
            type: Boolean,
            value: !1
        },
        needUa: {
            type: Boolean,
            value: !1
        },
        orgid: {
            type: Number,
            value: 0
        },
        codeFrom: {
            type: String,
            value: ""
        }
    },
    lifetimes: {
        attached: function() {
            var e = this;
            try {
                if (this.setData({
                    minaType: c.minaType
                }), this.data.needUa) {
                    var t = wx.getSystemInfoSync(), a = t.version, o = t.system, r = t.SDKVersion, i = t.platform, u = t.model;
                    wx.getNetworkType({
                        success: function(t) {
                            e.asData.uaMag = {
                                app_id: v.globalData.appid,
                                weixin_version: a,
                                system_type: o,
                                sdk_version: r,
                                inter_type: k[t.networkType],
                                device_brand: i,
                                device_model: u,
                                create_from: 1
                            };
                        }
                    });
                }
            } catch (e) {
                console.warn(e);
            }
            d.default.register(this), v.setAuthInfo(this);
            try {
                this.setData({
                    baseFontSize: 16
                }), this.data.setHeaderCoverify(!1);
            } catch (e) {
                console.error("获取字号失败或修改header的coverify失败");
            }
            var l = this.data.options;
            "string" == typeof this.data.options && (l = JSON.parse(this.data.options));
            var m = {}, g = {}, p = {};
            try {
                m = "string" == typeof l.commonConfig ? JSON.parse(decodeURIComponent(l.commonConfig || "{}")) : l.commonConfig || {}, 
                p = "string" == typeof l.recordTplToken ? JSON.parse(decodeURIComponent(l.recordTplToken || "{}")) : l.recordTplToken || {}, 
                v.globalData.codePages && (g = v.globalData.codePages[v.globalData.codePages.length - 1] || {});
            } catch (e) {
                console.error(e);
            }
            this.asData.recordTplToken = p;
            var f = this.data, h = f.codeFrom, _ = f.canAddRecord, y = f.canAddRecordTime, b = f.ownerCanAddRecord, S = (0, 
            n.getValue)(m, "add_record_mode", 0), D = !1, N = (0, n.getValue)(g, "asData.openCodeOrigin", 0), w = (0, 
            n.getValue)(g, "asData.isManager", 0), I = (0, n.getValue)(g, "asData.subManagerRoleId", 0), T = "", x = "";
            T = 1012 === N ? "使用长按二维码" : 1013 === N ? "从相册选取二维码" : 1007 === N || 1008 === N ? "从聊天框中" : h === s.WORKBENCH_FROM ? "从工作台" : "使用链接跳转", 
            _ && y && b && (1 === S ? (v.clicklogNew(104, 146065), 1011 !== N && (w ? x = "表单设置了仅限微信“扫一扫”填写，他人需扫码填写，但你是".concat(1 === I ? "子管理员" : "管理员", "，不受此限制") : D = !0)) : 2 === S && (v.clicklogNew(104, 146066), 
            1011 !== N && h !== s.WORKBENCH_FROM && (w ? x = "表单设置了仅限微信“扫一扫”和从“工作台”打开填写，他人需扫码或从工作台进入，但你是".concat(1 === I ? "子管理员" : "管理员", "，不受此限制") : D = !0)));
            var C = "editRecordDetail" !== (0, n.getValue)(this.data.options, "type"), V = "editRecordDetail" !== (0, 
            n.getValue)(this.data.options, "type") ? "" : "保存修改";
            this.asData.openCodeOrigin = N, this.setData({
                options: l,
                isLimitAdd: D,
                openCodeText: T,
                managerText: x,
                isNotFromEdit: C,
                editSaveText: V
            }), this.initIsAuth = this.data.isAuth, this.asData.org_id = this.data.options.orgid, 
            this.asData.gUserInfo = v.globalData.userInfoV1, this.asData.tipMsg = l.tipMsg ? decodeURIComponent(l.tipMsg) : "{}", 
            this.asData.isSecretForm = l.isSecretForm, this.asData.secretUrl = l.secretUrl;
            var R = (v.globalData.currentCodeInfoList.get(this.data.options.currentURL) || {}).data || {}, O = {
                code_id: (0, n.getValue)(R, "qrcode_record.id", 0),
                org_id: (0, n.getValue)(R, "qrcode_record.org_id", 0)
            }, A = this.data.options.formAuth || this.data.formAuth;
            this.setData({
                compData: O,
                expand_log: (0, n.getValue)(R, "expand_log"),
                tpl_id: this.data.options.tpl_id,
                data_id: this.data.options.data_id,
                formAuth: A,
                orgCode: this.data.options.org_code,
                currentURL: this.data.options.currentURL,
                password: this.data.options.password,
                updateField: this.updateField.bind(this),
                updateFieldStatic: this.updateFieldStatic.bind(this),
                updateEmptyTips: this.updateEmptyTips.bind(this),
                updataAutoMemory: this.updataAutoMemory.bind(this),
                updateEmptyTipsValue: this.updateEmptyTipsValue.bind(this),
                onInputFieldFocus: this.onInputFieldFocus.bind(this),
                setFocusId: this.setFocusId.bind(this),
                authLocation: this.getPosition.bind(this),
                authUserInfo: this.getEditUserInfo.bind(this),
                isAuth: this.data.isAuth,
                recordSumStatus: this.data.options.recordSumStatus,
                isUltimate: (0, n.includes)([ 4, 15, 44 ], (0, n.getValue)(this.data.options, "editionMsg.from_edition_id"))
            }, function() {
                e.initDesc();
            }), this.adding = !1, v.clicklogNew(104, 153001);
            var L = wx.getStorageSync("userInfoV1");
            L.mobile && this.setData({
                hasMobileAlready: !0
            });
            var M = L.auth_id, E = 0;
            if (M) {
                var F = "".concat(M).substr(-1, 1);
                "1" !== F && "3" !== F && "5" !== F && "7" !== F && "9" !== F || (E = 1);
            }
            this.setData({
                lastAuthIdOne: E
            });
        },
        detached: function() {
            var e = v.globalData, t = (0, n.getValue)(e.currentCodeInfoList.get(this.data.currentURL), "data", {});
            if (this.stopRender(), !this.asData.added && !this.data.isTplCreate) {
                var a = JSON.parse(JSON.stringify(this.asData.groups));
                a.push({
                    saveTime: new Date().getTime()
                }), "editRecordDetail" === (0, n.getValue)(this.data.options, "type") ? wx.removeStorageSync("editRecordDetail") : wx.setStorageSync("".concat(this.data.tpl_id, "_").concat(t.qrcode_record.id, "_").concat(t.qrcode_record.id, "_").concat(t.qrcode_record.web_url), a);
            }
        }
    },
    pageLifetimes: {
        show: function() {
            var e = wx.getStorageSync("signData");
            e && (this.updateField(e.data, e.pid), wx.removeStorageSync("signData"));
            var t = wx.getStorageSync("backFromAuthSuccess");
            if (t) {
                try {
                    var a = JSON.parse(JSON.stringify(this.data.recorderInfo));
                    a.tel && (a.tel.item.value = t, this.updateField(a.tel.item, a.tel.pid));
                    var o = JSON.parse(JSON.stringify(this.data.userInfo));
                    o.mobile = t, this.setData({
                        recorderInfo: a,
                        userInfo: o,
                        isAuth: !0
                    });
                } catch (e) {
                    console.error(e);
                }
                this.doAdd("fake form Id"), wx.removeStorageSync("backFromAuthSuccess");
            }
        }
    },
    data: {
        form: {},
        fieldsArray: [],
        formSourceData: {},
        updateField: function() {},
        updateFieldStatic: function() {},
        adding: !1,
        isMember: !0,
        colorInfo: {},
        recorderInfo: {},
        baseFontSize: 16,
        formMinHeight: 0,
        confirmPaddingBottom: 0,
        orgCode: "",
        haveNickName: !1,
        haveMemberName: !1,
        emptyRed: 0,
        onInputFieldFocus: function() {},
        rderFocus: !1,
        focusId: "",
        setFocusId: function() {},
        imgMarkAddress: "",
        imgMarkNickName: "",
        colorReady: !1,
        isAuthLocate: !0,
        isAuth: !0,
        needMemary: 0,
        needMemaryTip: !1,
        showAutoSetTip: !1,
        loading: !0,
        chunkSize: 0,
        currentChunkIndex: -1,
        tags: {},
        lastAuthIdOne: 0,
        hasMobileAlready: !1,
        changeStatusMsg: [],
        ignoreLocation: !1,
        goToAuthing: !1,
        authModalVisible: !1,
        isNotFromEdit: !0,
        editSaveText: ""
    },
    asData: {
        gUserInfo: {},
        globalNickName: "",
        coveredForm: !1,
        la: "",
        lo: "",
        added: !1,
        backupGroups: [],
        groups: [],
        chunks: [],
        memoryArr: [],
        doRecording: !1,
        statusRuleMsg: [],
        currentStatusMsg: [],
        initChangeStatusMsg: [],
        authIdErrorReqNum: 0
    },
    methods: {
        initDesc: function() {
            var e = this, t = v.globalData;
            this.getDesc(function() {
                var a = !1, o = e;
                e.setNickName = function() {
                    var t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0], r = JSON.parse(JSON.stringify(e.asData.groups)), s = (0, 
                    n.getValue)(o.data, "options.tpl_memary_add_time"), c = {}, d = {}, l = o.data.options, m = l.memaryRecord, g = l.memaryUser;
                    if ("InlineRecord" === e.data.from) c = e.data.memaryRecord || {}, d = e.data.memaryUser || {}; else try {
                        c = m ? JSON.parse(decodeURIComponent(m)) : {}, d = g ? JSON.parse(decodeURIComponent(g)) : {};
                    } catch (e) {
                        console.error(e);
                    }
                    var p = c.tpl_memory_maps || {}, f = !1;
                    if (d && "{}" !== JSON.stringify(d)) for (var h in p = p || {}, d) p[h] = d[h];
                    c.tpl_memory_maps = p;
                    var y = +o.data.options.isMemary, D = {}, k = !1, w = [];
                    r.forEach(function(t) {
                        t.components.forEach(function(r) {
                            r.options.tpl_memory && (1 == +r.options.tpl_memory[0].value && (k = !0, f = !0));
                            if (c && "{}" !== JSON.stringify(c)) {
                                var d = function() {
                                    var t = c.user_memory_maps, a = p || t, o = function(t) {
                                        if (+t === r.id) {
                                            if ("name" === r.tpl_component || "recorder" === r.tpl_component || "job_number" === r.tpl_component || "tel" === r.tpl_component || "identity" === r.tpl_component || "carnumber" === r.tpl_component || "sex" === r.tpl_component ? r.memoryTime = e.formatTime(parseInt((0, 
                                            n.getValue)(c, "tpl_memory_maps.update_time"), 10)) : r.memoryTime = e.formatTime(parseInt(s, 10)), 
                                            "checklist" === r.tpl_component) {
                                                a[t] && (r.isAutoMemory = !0, w.push(r.id));
                                                var o = function(e) {
                                                    (r.options.checklist || []).forEach(function(o) {
                                                        o.id === +e && (o.data = a[t][e].toString());
                                                    });
                                                };
                                                for (var i in a[t]) o(i);
                                                return {
                                                    v: {
                                                        v: void 0
                                                    }
                                                };
                                            }
                                            if ("radio" === r.tpl_component || "sex" === r.tpl_component) {
                                                "sex" === r.tpl_component && "number" != typeof a[t] && (r.options.radio || []).forEach(function(e) {
                                                    e.value === a[t] && (a[t] = e.id);
                                                });
                                                var d = a[t];
                                                d && (r.isAutoMemory = !0, w.push(r.id));
                                                var l = (0, u.isObject)(d);
                                                return (r.options.radio || []).forEach(function(e) {
                                                    l ? (e.selected = d.hasOwnProperty(e.id), e.selected && e.custom && (e.customValue = d[e.id] || "")) : e.selected = e.id === a[t], 
                                                    e.focusId = N();
                                                }), {
                                                    v: {
                                                        v: void 0
                                                    }
                                                };
                                            }
                                            if ("checkbox" === r.tpl_component) {
                                                var m = a[t], g = (0, n.isArray)(m);
                                                return m.length && (r.isAutoMemory = !0, w.push(r.id)), (r.options.checkbox || []).forEach(function(e) {
                                                    g ? e.selected = m.indexOf(e.id) > -1 : (e.selected = m.hasOwnProperty(e.id), e.custom && e.selected && (e.customValue = m[e.id] || "")), 
                                                    e.focusId = N();
                                                }), {
                                                    v: {
                                                        v: void 0
                                                    }
                                                };
                                            }
                                            if ("carnumber" === r.tpl_component) {
                                                if (a[t]) {
                                                    r.isAutoMemory = !0, w.push(r.id);
                                                    for (var p = JSON.parse(JSON.stringify(a[t])), f = [], h = 0; h < 8; h++) f.push(p.slice(h, h + 1));
                                                    r.value = f, r.focusId = N();
                                                }
                                                return {
                                                    v: {
                                                        v: void 0
                                                    }
                                                };
                                            }
                                            if ("matrix" === r.tpl_component) {
                                                if (a[t]) {
                                                    var _ = JSON.parse(JSON.stringify(a[t]));
                                                    0 !== _.length && (r.isAutoMemory = !0, w.push(r.id)), (r.options.item || []).forEach(function(e) {
                                                        e.colValue = _[e.id], e.focusId = N();
                                                    });
                                                }
                                                return {
                                                    v: {
                                                        v: void 0
                                                    }
                                                };
                                            }
                                            a[t] && (r.isAutoMemory = !0, w.push(r.id)), r.value = a[t];
                                        }
                                    };
                                    for (var d in a) {
                                        var l = o(d);
                                        if ("object" === (0, i.default)(l)) return l.v;
                                    }
                                }();
                                if ("object" === (0, i.default)(d)) return d.v;
                            }
                            r.focusId = N(), "radio" !== r.tpl_component && "sex" !== r.tpl_component || (r.options.radio || []).forEach(function(e) {
                                e.focusId = N();
                            }), "checkbox" === r.tpl_component && (r.options.checkbox || []).forEach(function(e) {
                                e.focusId = N();
                            }), "checklist" === r.tpl_component && (r.options.checklist || []).forEach(function(e) {
                                e.focusId = N();
                            }), e.data.userInfo.has_auth_member && e.data.haveMemberName && "name" === r.tpl_component && (r.value = o.data.userInfo.nick_name), 
                            "tel" === r.tpl_component && (r.value = o.data.userInfo.mobile, D.tel = {
                                item: r,
                                pid: t.id
                            }, o.data.userInfo.mobile && !o.data.isAuth && e.setData({
                                hasMobileAlready: !0
                            })), "recorder" === r.tpl_component && (r.value = o.data.userInfo.nick_name, D.recorder = {
                                item: r,
                                pid: t.id
                            }), "address" === r.tpl_component && (a = !0, D.address = {
                                item: r,
                                pid: t.id
                            }), "matrix" === r.tpl_component && (r.options.item || []).forEach(function(e) {
                                e.focusId = N();
                            });
                        });
                    });
                    var I = 0;
                    2 === y ? k = !0 : 1 === y ? (k = !1, I = 1) : 0 === y && k && (I = 1);
                    var T = v.getDeviceInfo(), x = T.screenWidth, C = (x - 52) / 3;
                    e.asData.groups = r, e.asData.memoryArr = w, e.setData({
                        recorderInfo: D,
                        firstRecordCanAdd: (0, n.getValue)(r, "0.can_add_record", !0) && (0, n.getValue)(r, "0.owner_can_add_record", !0),
                        needMemary: I,
                        needMemaryTip: k,
                        showAutoSetTip: f,
                        picWidth: C,
                        isIPhoneX: S.isIphoneX()
                    }), _ = new b({
                        key: "Z4OBZ-5ZYWW-QP4RP-RLNNW-NTBNE-USBLB"
                    }), e.setLocateAuthStatus(), a && e.data.canAddRecord && e.data.ownerCanAddRecord && e.data.canAddRecordTime && t && !e.data.isTplCreate && "editRecordDetail" !== (0, 
                    n.getValue)(e.data.options, "type") && wx.getSetting({
                        success: function(e) {
                            e.authSetting && e.authSetting["scope.userLocation"] && o.getPosition(void 0, void 0, void 0, "polymerization", !1);
                        }
                    }), e.getRuleMsg(function() {
                        v.globalData.refreshUnfoldRecordForm = e.checkNeedRecoverForm.bind(e), t && o.checkNeedRecoverForm(!0), 
                        e.scrollHeight = 0;
                        var a = e.asData.statusRuleMsg;
                        (0, n.getValue)(a, "length") && e.handleChangeStatus();
                    }), e.setData({
                        isMember: !!e.data.userInfo.has_auth_member
                    });
                }, e.checkUserInfo(), e.calcContentHeight();
                var r = (0, n.getValue)(t.currentCodeInfoList.get(e.data.currentURL), "data", {}), s = (0, 
                n.getValue)(r, "log_msg.data_list", []);
                if (s.length > 0) {
                    var c = (0, u.findIndex)(s, function(t) {
                        return t.id === Number(e.data.tpl_id);
                    });
                    try {
                        if (c > -1) {
                            var d = s[c].tpl_label;
                            if (d && "[]" !== JSON.stringify(d)) {
                                var m = (0, l.default)(d);
                                e.setData({
                                    tags: m
                                });
                            }
                        }
                    } catch (e) {
                        console.error(e);
                    }
                }
                e.data.setOnPageScroll && e.data.setOnPageScroll(e.onPageScroll.bind(e));
            });
        },
        showDisabledTip: function() {
            var e = this.data.openCodeText;
            wx.showModal({
                title: "只允许使用扫一扫方式填写",
                content: "你当前".concat(e, "打开，无权填写，请用微信扫一扫打开"),
                showCancel: !1,
                confirmText: "我知道了",
                success: function(e) {
                    e.confirm;
                }
            });
        },
        clearAddress: function(e) {
            var t = e.currentTarget.dataset, a = t.data, o = void 0 === a ? {} : a, r = t.pid, i = this.data.isTplCreate ? this.getField({
                pid: r,
                cid: o.id
            }) : o;
            this.updateAddress({
                field: i,
                pid: r,
                address: "",
                latitude: 0,
                longitude: 0
            });
        },
        openAddress: function(e) {
            var t = e.currentTarget.dataset, a = t.name, o = t.la, r = t.lo, i = t.pid, n = t.cid, s = this.asData, c = s.la, d = s.lo, u = this.data.isTplCreate ? this.getField({
                pid: i,
                cid: n
            }).addressName : a;
            wx.openLocation({
                name: u,
                longitude: Number(r || d),
                latitude: Number(o || c),
                scale: 16
            });
        },
        setLocateAuthStatus: function() {
            var e = this;
            wx.getSetting({
                success: function(t) {
                    var a = !1;
                    t.authSetting && t.authSetting["scope.userLocation"] && (a = !0), e.setData({
                        isAuthLocate: a
                    });
                }
            });
        },
        setFocusId: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", t = arguments.length > 1 ? arguments[1] : void 0;
            g.default.setFocusId(e), t || this.setData({
                focusId: e
            });
        },
        onInputFieldFocus: function(e, t, a) {
            var o = this;
            if (p.default.paddingAdjust) {
                var r = t.elType, i = void 0 === r ? "" : r;
                if (a) this.data.setPaddingBottom(t.detail && t.detail.height || 300), setTimeout(function() {
                    wx.pageScrollTo({
                        scrollTop: o.scrollHeight + a - ("textarea" === i ? 100 : 170),
                        duration: 200
                    });
                }, 120); else {
                    var s = this.createSelectorQuery();
                    s.select("#".concat(e)).boundingClientRect(), s.selectViewport().scrollOffset(), 
                    s.exec(function(e) {
                        var a = (0, n.getValue)(e, "0.top", 0), r = (0, n.getValue)(e, "1.scrollTop", 0);
                        o.data.setPaddingBottom(t.detail && t.detail.height || 300), setTimeout(function() {
                            wx.pageScrollTo({
                                scrollTop: r + a - ("textarea" === i ? 100 : 170),
                                duration: 200
                            });
                        }, 120);
                    });
                }
            }
        },
        onPageScroll: function(e) {
            this.scrollHeight = e.scrollTop;
        },
        checkUserInfo: function() {
            var e = this, t = this.asData.gUserInfo;
            v.getUserInfo(this.asData.org_id, function(a) {
                a.mobile || (a.mobile = t.mobile || "");
                var o = !!a.nick_name;
                !a.nick_name && t && t.wx && t.wx.nickName && (a.nick_name = t.wx.nickName), e.asData.globalNickName = a.nick_name, 
                e.setData({
                    userInfo: a,
                    haveNickName: !!a.nick_name,
                    imgMarkNickName: a.nick_name,
                    haveMemberName: o
                }), setTimeout(function() {
                    e.setNickName();
                }, 0);
            });
        },
        calcContentHeight: function() {
            var e = this;
            if (this.data.calcHeight || this.setData({
                getHeight: !0
            }), this.data.calcHeight && this.data.colorReady) {
                var t = this.data, a = t.isLimitAdd, o = t.managerText, r = t.options, i = this.createSelectorQuery();
                i.select("#confirm").boundingClientRect(), i.exec(function(t) {
                    var i = (0, n.getValue)(t, "0.height", 120), s = v.getDeviceInfo(), c = s.screenHeight, d = s.statusBarHeight, u = (a || o) && 1 !== r.expandLog ? 108 : 46;
                    e.setData({
                        formMinHeight: c - i - d - u,
                        getHeight: !0
                    });
                });
            }
        },
        getCurCodeInfo: function() {
            var e = v.globalData;
            return (0, n.getValue)(e.currentCodeInfoList.get(this.data.currentURL), "data", {});
        },
        getColorInfo: function() {
            var e = this.getCurCodeInfo(), t = (0, n.getValue)(e, "recordColorInfo", {});
            return (0, n.includes)([ "#000", "#000000" ], t.foreColor) && t.lowThemeColor ? console.warn("跳过eslint") : t.lowThemeColor = t.themeColor, 
            (0, n.includes)([ "#fff", "#ffffff" ], t.themeColor) && (t.lowThemeColor = "#07c160", 
            t.lowCrtColor = "#06ae56"), t.lowThemeColor && (t.lowThemeColorBorderColor = (0, 
            m.hsbHandler)(t.lowThemeColor, .13), t.activeThemeColor = (0, m.hsbHandler)(t.lowThemeColor, .2), 
            t.chosenThemeColor = (0, m.hsbHandler)(t.lowThemeColor, .1)), t.themeColor && (t.themeColorBorderColor = (0, 
            m.hsbHandler)(t.themeColor, .13)), e.recordColorInfo;
        },
        startRender: function() {
            var e = this;
            this.stopRender();
            var t = this.asData, a = t.chunks;
            if (a && a.length) {
                var o = this.data, i = o.currentChunkIndex, n = o.chunkSize, s = i + 1, c = function() {
                    for (;s < n; s++) if (JSON.stringify(e.data["chunk".concat(s)]) !== JSON.stringify(a[s])) {
                        e.setData((0, r.default)({
                            currentChunkIndex: s
                        }, "chunk".concat(s), a[s])), s++;
                        break;
                    }
                    if (s >= n) return e.setData({
                        currentChunkIndex: n - 1
                    }), e.data.isTplCreate && e.triggerEvent("completeRender", !0), e.stopRender(), 
                    !0;
                };
                c() || (t.renderTimer = setInterval(c, 100));
            }
        },
        stopRender: function() {
            var e = this.asData, t = e.renderTimer;
            t && (clearInterval(t), delete e.renderTimer);
        },
        renderGroups: function(e) {
            var t = this, a = e.isInit, o = e.groups;
            o = o || this.asData.groups;
            var r = (0, n.chunk)(o, 5);
            (0, n.assign)(this.asData, {
                groups: o,
                chunks: r
            });
            var i = r.length;
            if (a) this.setData({
                chunkSize: i,
                currentChunkIndex: -1
            }, function() {
                setTimeout(function() {
                    t.startRender();
                }, 100);
            }); else {
                var s = {};
                (0, n.forEach)(r, function(e, a) {
                    var o = t.data["chunk".concat(a)];
                    o && JSON.stringify(e) !== JSON.stringify(o) && (s["chunk".concat(a)] = e);
                }), this.setData(s);
            }
        },
        checkNeedRecoverForm: function(e) {
            var t = this, a = v.globalData, o = (0, n.getValue)(a.currentCodeInfoList.get(this.data.currentURL), "data", {});
            if (this.setData({
                colorInfo: this.getColorInfo()
            }), setTimeout(function() {
                t.setData({
                    colorReady: !0
                }), t.calcContentHeight();
            }, 200), this.asData.coveredForm) e && this.renderGroups({
                isInit: e
            }); else {
                var r = wx.getStorageSync("".concat(this.data.tpl_id, "_").concat((0, n.getValue)(o, "qrcode_record.id", 0), "_").concat((0, 
                n.getValue)(o, "qrcode_record.id", 0), "_").concat((0, n.getValue)(o, "qrcode_record.web_url", "")), this.asData.groups);
                if ("editRecordDetail" === (0, n.getValue)(this.data.options, "type")) {
                    r = wx.getStorageSync("editRecordDetail");
                    var i = {}, s = !1;
                    (0, n.forEach)(this.asData.groups, function(e, a) {
                        (0, n.forEach)(e.components, function(e, o) {
                            if ("checklist" === e.tpl_component) e.options.checklist.forEach(function(e) {
                                e.data = r[a].components[o].raw_value[e.id];
                            }); else if ("sex" === e.tpl_component) e.options.radio.forEach(function(e) {
                                e.selected = e.id === r[a].components[o].raw_value;
                            }); else if ("radio" === e.tpl_component) e.options.radio.forEach(function(e) {
                                var t = (0, n.getValue)(e, "id"), i = r[a].components[o].raw_value;
                                "number" != typeof i || isNaN(i) ? (0, n.forEach)(i, function(a, o) {
                                    t !== +a && t !== +o || (e.selected = !0), t === +o && a && (e.customValue = a);
                                }) : e.selected = t === r[a].components[o].raw_value;
                            }); else if ("checkbox" === e.tpl_component) e.options.checkbox.forEach(function(e) {
                                var t = (0, n.getValue)(e, "id"), i = r[a].components[o].raw_value;
                                (0, n.forEach)(i, function(a, o) {
                                    t !== +a && t !== +o || (e.selected = !0), t === +o && a && (e.customValue = a);
                                });
                            }); else if ("matrix" === e.tpl_component) {
                                var c = r[a].components[o].raw_value;
                                e.options.item.forEach(function(e) {
                                    e.colValue = c[e.id];
                                });
                            } else if ("owner_address" === e.tpl_component) r[a].components[o].raw_value && (e.value = JSON.stringify(r[a].components[o].raw_value)); else if ("signature" === e.tpl_component) e.value = r[a].components[o].raw_value; else if ("carnumber" === e.tpl_component) {
                                for (var d = r[a].components[o].raw_value, u = [], l = 0; l < 8; l++) u.push(d.slice(l, l + 1));
                                e.value = u;
                            } else if ("tel" === e.tpl_component) e.value = r[a].components[o].raw_value, i.tel = {
                                item: e,
                                pid: e.group_id
                            }; else if ("recorder" === e.tpl_component) e.value = r[a].components[o].raw_value, 
                            s = !!r[a].components[o].raw_value, i.recorder = {
                                item: e,
                                pid: e.group_id
                            }; else if ("address" === e.tpl_component) {
                                e.value = r[a].components[o].raw_value.address, t.asData.la = r[a].components[o].raw_value.lat, 
                                t.asData.lo = r[a].components[o].raw_value.log;
                                var m = (0, n.cloneDeep)(e);
                                (0, n.getValue)(m, "value") && (m.lat = r[a].components[o].raw_value.lat, m.log = r[a].components[o].raw_value.log), 
                                i.address = {
                                    item: m,
                                    pid: m.group_id
                                };
                            } else e.value = r[a].components[o].raw_value;
                        });
                    }), r = JSON.parse(JSON.stringify(this.asData.groups)), this.asData.editInitData = (0, 
                    n.cloneDeep)(r), this.setData({
                        recorderInfo: i,
                        haveNickName: s
                    });
                }
                if (r) {
                    var c = r.pop().saveTime, d = this.data.userInfo, u = new Date().getTime() - c > 1728e5, l = JSON.parse(JSON.stringify(this.asData.groups)), m = !!(0, 
                    n.getValue)(d, "has_auth_member");
                    try {
                        r.forEach(function(e) {
                            e.components = e.components ? e.components : [], e.components.forEach(function(e) {
                                l.forEach(function(t) {
                                    t.components.forEach(function(t) {
                                        if (t.id == e.id) if ("radio" === t.tpl_component || "sex" === t.tpl_component) {
                                            var a = t.options.radio.map(function(e) {
                                                return e.id;
                                            }), o = e.options.radio.filter(function(e) {
                                                return (0, n.includes)(a, e.id);
                                            });
                                            t.options.radio.forEach(function(e) {
                                                o.forEach(function(t) {
                                                    e.id === t.id && (e.selected = t.selected, e.custom && (e.customValue = t.customValue || ""));
                                                });
                                            });
                                        } else if ("checkbox" === t.tpl_component) {
                                            var r = t.options.checkbox.map(function(e) {
                                                return e.id;
                                            }), i = e.options.checkbox.filter(function(e) {
                                                return (0, n.includes)(r, e.id);
                                            });
                                            t.options.checkbox.forEach(function(e) {
                                                i.forEach(function(t) {
                                                    e.id === t.id && (e.selected = t.selected, e.custom && (e.customValue = t.customValue || ""));
                                                });
                                            });
                                        } else if ("checklist" === t.tpl_component) {
                                            var s = t.options.checklist.map(function(e) {
                                                return e.id;
                                            }), c = e.options.checklist.filter(function(e) {
                                                return (0, n.includes)(s, e.id);
                                            });
                                            t.options.checklist.forEach(function(e) {
                                                c.forEach(function(t) {
                                                    e.id === t.id && (e.data = t.data);
                                                });
                                            });
                                        } else if ("matrix" === t.tpl_component) {
                                            var d = e.options.item;
                                            t.options.item.forEach(function(e) {
                                                d.forEach(function(t) {
                                                    e.id === t.id && (e.colValue = t.colValue);
                                                });
                                            });
                                        } else {
                                            if ("date" === t.tpl_component) return;
                                            if ("name" === t.tpl_component && m) return;
                                            if ("recorder" === t.tpl_component && (m || (0, n.includes)([ 1, "1" ], (0, n.getValue)(t, "options.readonly[0].value")))) return;
                                            t.value = e.value, "image" === t.tpl_component && u && (t.value = []);
                                        }
                                    });
                                });
                            });
                        });
                    } catch (e) {
                        console.error(e);
                    }
                    this.asData.coveredForm = !0;
                    var g = this.asData.statusRuleMsg;
                    (0, n.getValue)(g, "length") && this.handleChangeStatus(l), this.renderGroups({
                        isInit: e,
                        groups: l
                    });
                } else e && this.renderGroups({
                    isInit: e
                });
            }
        },
        getPositionTarget: function() {
            var e = this.asData.groups, t = {}, a = null;
            return e.forEach(function(e) {
                e.components.forEach(function(o) {
                    "address" === o.tpl_component && (t = o, a = e.id);
                });
            }), {
                currentTarget: {
                    dataset: {
                        data: t,
                        pid: a
                    }
                },
                target: {
                    dataset: {
                        data: t,
                        pid: a
                    }
                }
            };
        },
        openAuthModal: (0, n.debounceLeading)(function() {
            "third" === c.minaType ? this.goToAuth() : this.setData({
                confirm: this.goToAuth.bind(this),
                authModalVisible: !0
            });
        }),
        goToAuth: (0, n.debounceLeading)(function() {
            var e = this;
            this.setData({
                goToAuthing: !0
            });
            var t = this.data, a = t.orgCode, o = t.currentURL, r = t.password, i = "?orgCode=".concat(a, "&currentURL=").concat(o, "&password=").concat(r, "&authForWhich=addRecord");
            (0, n.navigateTo)({
                url: "/subPackages/codeRecord/pages/authRecord/authRecord".concat(i),
                cb: function() {
                    e.setData({
                        goToAuthing: !1
                    });
                }
            });
        }),
        add: function(e) {
            var t = this;
            if (!this.adding) if (this.asData.doRecording) wx.showModal({
                title: "提示",
                content: "正在录音中，是否保存录音并提交记录？",
                success: function(e) {
                    e.confirm && t.selectComponent("#".concat(t.asData.doRecording)).stopRecord();
                }
            }); else {
                if (this.adding = !0, this.asData.isSecretForm && v.clicklogNew(123, 11, this.data.currentURL), 
                this.data.caseId || this.data.tplId) {
                    var a = "custom" === this.data.from;
                    return wx.showToast({
                        title: "当前为示例模板".concat(a ? "" : "，请点击下方按钮\n使用模板生成二维码"),
                        icon: "none",
                        complete: function() {
                            if (a) {
                                var e = v.globalData.__toastTimer;
                                e && clearTimeout(e), v.globalData.__toastTimer = setTimeout(function() {
                                    wx.navigateBack();
                                }, 1500);
                            }
                        }
                    }), void (this.adding = !1);
                }
                setTimeout(function() {
                    var a = (0, n.getValue)(e, "detail.formId", ""), o = v.globalData.userInfoV1;
                    o.userData ? "third" !== c.minaType ? v.getCheckUserTipInfo(function(e) {
                        e ? t.doAdd(a) : (t.adding = !1, t.setData({
                            confirm: t.doAdd.bind(t, a),
                            authModalVisible: !0
                        }));
                    }) : t.doAdd(a) : v.getUserByOpenId(o.openId, function() {
                        "third" !== c.minaType ? v.getCheckUserTipInfo(function(e) {
                            e ? t.doAdd(a) : (t.adding = !1, t.setData({
                                confirm: t.doAdd.bind(t, a),
                                authModalVisible: !0
                            }));
                        }) : t.doAdd(a);
                    });
                }, wx.blurDelay);
            }
        },
        getServerTime: function() {
            var e = v.globalData;
            return new Promise(function(t, a) {
                y({
                    url: "".concat(e.ncUrl, "/commonapi/time"),
                    doSuccess: function(e) {
                        1 === e.code ? t(e.data.unix_timestamp) : a();
                    },
                    doFail: a
                });
            });
        },
        doAdd: (w = (0, o.default)(a.default.mark(function e(t) {
            var o, i, s = this;
            return a.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, this.getServerTime();

                  case 3:
                    o = e.sent, e.next = 11;
                    break;

                  case 6:
                    return e.prev = 6, e.t0 = e.catch(0), wx.showToast({
                        title: "网络错误"
                    }), this.adding = !1, e.abrupt("return");

                  case 11:
                    if (o) {
                        e.next = 14;
                        break;
                    }
                    return this.adding = !1, e.abrupt("return");

                  case 14:
                    if ("editRecordDetail" !== (0, n.getValue)(this.data.options, "type") || JSON.stringify(this.asData.groups) !== JSON.stringify(this.asData.editInitData)) {
                        e.next = 18;
                        break;
                    }
                    return wx.showToast({
                        title: "请修改内容后再保存",
                        icon: "none"
                    }), this.adding = !1, e.abrupt("return");

                  case 18:
                    i = "验证表单数据", this.data.isTplCreate && (i = "正在保存"), wx.showLoading({
                        title: i,
                        mask: !0,
                        success: function() {
                            var e = v.globalData, a = (0, n.getValue)(e.currentCodeInfoList.get(s.data.currentURL), "data", {}), i = e.userInfoV1, c = {
                                org_id: (0, n.getValue)(a, "qrcode_record.org_id", 0),
                                code_id: (0, n.getValue)(a, "qrcode_record.id", 0),
                                tpl_id: s.data.tpl_id,
                                data_id: s.data.data_id,
                                user_org_id: 0,
                                user_id: (0, n.getValue)(i, "userData.user_id", ""),
                                list_name: (0, n.getValue)(a, "qrcode_record.list_name", ""),
                                web_url: (0, n.getValue)(a, "qrcode_record.web_url", ""),
                                fields_value: {},
                                wx_msg: {
                                    app_id: e.appid,
                                    union_id: i.unionId || "",
                                    open_id: i.openId
                                },
                                watermark_recorder: s.data.imgMarkNickName || "",
                                watermark_address: s.data.imgMarkAddress || ""
                            }, d = {}, l = "", m = "", g = JSON.parse(JSON.stringify(s.asData.groups));
                            g.forEach(function(e) {
                                e.components.forEach(function(e) {
                                    var t = function(e) {
                                        return e.options.log_result && 1 === Number((0, n.getValue)(e, "options.log_result.0.value", 0));
                                    }(e);
                                    d[e.id] = function() {
                                        var a = e.tpl_component;
                                        if ("recorder" === a && (m = e.value || "", c.watermark_recorder = e.value || s.data.imgMarkNickName || ""), 
                                        (0, n.includes)([ "date", "time", "text", "textarea", "number", "recorder", "tel", "identity", "name", "customer_number", "job_number", "chained_selects" ], a)) {
                                            var o = e.value || "";
                                            return t && (l = o, "number" === a && (l += e.options.unit[0].value), "chained_selects" === a && (l = e.valueStr || "")), 
                                            {
                                                type: a,
                                                data: o
                                            };
                                        }
                                        if ("owner_address" === a) {
                                            var i = e.value || "";
                                            return t && (l = i), {
                                                type: a,
                                                data: i
                                            };
                                        }
                                        if ("carnumber" === a) {
                                            var d = e.value, u = "";
                                            d && d.forEach(function(e) {
                                                "" !== e && (u += e);
                                            });
                                            var g = u || "";
                                            return t && (l = g), {
                                                type: a,
                                                data: g
                                            };
                                        }
                                        if ("address" === a) {
                                            var p = "";
                                            return e.addressName ? p = {
                                                address: e.addressName,
                                                lat: e.lat,
                                                log: e.log
                                            } : e.value && (p = {
                                                address: e.value,
                                                lat: s.asData.la,
                                                log: s.asData.lo
                                            }), t && (l = p), {
                                                type: a,
                                                data: p
                                            };
                                        }
                                        if ("radio" === a || "sex" === a) {
                                            var f = e.options.radio.find(function(e) {
                                                return e.selected;
                                            }), h = f && f.id || "";
                                            return f && f.custom && (h = (0, r.default)({}, f.id, f.customValue || "")), f && t && (l = f.value), 
                                            {
                                                type: a,
                                                data: h
                                            };
                                        }
                                        if ("checkbox" === a) {
                                            var _ = e.options.checkbox.filter(function(e) {
                                                return e.selected;
                                            }), v = [], y = !1, b = {};
                                            return _.forEach(function(e) {
                                                v.push(e.id), b[e.id] = e.customValue || "", e.custom && !y && (y = !0);
                                            }), y && (v = b), t && (l = v), {
                                                type: a,
                                                data: v
                                            };
                                        }
                                        if ("checklist" === a) {
                                            var S = {};
                                            return e.options.checklist.forEach(function(e) {
                                                S[e.id] = e.data || 0;
                                            }), {
                                                type: a,
                                                data: S
                                            };
                                        }
                                        if ("image" === a) {
                                            var D = (e.value || []).map(function(e) {
                                                return "editRecordDetail" === (0, n.getValue)(s.data.options, "type") && e.url && e.url.indexOf("/free/") > -1 && (e.is_change = !0), 
                                                e;
                                            });
                                            return t && (l = D), {
                                                type: a,
                                                data: D
                                            };
                                        }
                                        if ("signature" === a) return {
                                            type: a,
                                            data: (e.value || []).map(function(e) {
                                                return "editRecordDetail" === (0, n.getValue)(s.data.options, "type") && e.url && e.url.indexOf("/free/") > -1 && (e.is_change = !0), 
                                                e;
                                            })
                                        };
                                        if ("audio" === a || "video" === a) {
                                            var k = (e.value || []).map(function(e) {
                                                return "editRecordDetail" === (0, n.getValue)(s.data.options, "type") && e.url && e.url.indexOf("/free/") > -1 && (e.is_change = !0), 
                                                e;
                                            });
                                            return t && (l = k), {
                                                type: a,
                                                data: k
                                            };
                                        }
                                        if ("matrix" === a) {
                                            var N = {};
                                            return e.options.item.forEach(function(e) {
                                                N[e.id] = e.colValue;
                                            }), {
                                                type: a,
                                                data: N
                                            };
                                        }
                                    }();
                                });
                            });
                            var p = (0, u.validateRecordForm)({
                                recordDescGroups: g,
                                formData: d,
                                options: {
                                    serverTime: o,
                                    cb: {
                                        findExpiredImgCB: function(e) {
                                            var t = e.comp, a = e.finalImages;
                                            t.value = a;
                                        },
                                        findExpiredSignCB: function(e) {
                                            var t = e.comp, a = e.expirationType;
                                            t.value = [], "aliyun" === a && (0, n.postClickLog)({
                                                fir: 104,
                                                sec: 118007,
                                                datas: {
                                                    returnPath: t.value[0].url
                                                }
                                            });
                                        },
                                        formatOrLengthLimitErrorCB: function() {
                                            v.clicklogNew(104, 180005, s.data.currentURL);
                                        },
                                        lengthLimitErrorCB: function() {
                                            v.clicklogNew(104, 180004, s.data.currentURL);
                                        },
                                        formatErrorCB: function() {
                                            v.clicklogNew(104, 180003, s.data.currentURL);
                                        }
                                    },
                                    constants: {
                                        EMPTY_INFO: I,
                                        TEXT_TYPE: T,
                                        ERROR_INFO: x
                                    }
                                }
                            });
                            d = (0, n.getValue)(p, "newFormData", d);
                            var f = p.haveEmpty, h = p.haveError, _ = p.ErrorName, b = p.emptyName, S = p.emptyId, k = p.emptyTips, N = p.hasExpiredImages, w = p.hasExpiredSign, C = p.isOnlyCameralUploadExpired;
                            if (p.checkRangeTips, w) return wx.hideLoading(), wx.showModal({
                                content: "有签名组件上传过久已失效，请重新签字。",
                                showCancel: !1,
                                confirmText: "我知道了"
                            }), s.renderGroups({
                                groups: g
                            }), void (s.adding = !1);
                            if (N.length) return wx.hideLoading(), wx.showModal({
                                content: "有 ".concat(N.length, " 张图片").concat(C ? "拍摄" : "上传", "过久已失效，请重新上传"),
                                showCancel: !1,
                                confirmText: "我知道了"
                            }), s.renderGroups({
                                groups: g
                            }), void (s.adding = !1);
                            if (f) return s.adding = !1, wx.hideLoading(), wx.showToast({
                                title: b + s.data.lang.common.mustBeFilled,
                                icon: "none",
                                duration: 1500,
                                mask: !1
                            }), s.setData({
                                emptyRed: s.data.emptyRed + 1,
                                emptyCompId: S,
                                emptyTips: k
                            }), s.renderGroups({
                                groups: g
                            }), void s.gotoEmptyComp();
                            if (h) return wx.hideLoading(), s.adding = !1, wx.showToast({
                                title: k[S].msg || "".concat(_, "输入错误"),
                                icon: "none",
                                duration: 1500,
                                mask: !1
                            }), s.setData({
                                emptyRed: s.data.emptyRed + 1,
                                emptyCompId: S,
                                emptyTips: k
                            }), s.renderGroups({
                                groups: g
                            }), void s.gotoEmptyComp();
                            if (s.data.isTplCreate) s.triggerEvent("returnTplData", d); else {
                                c.fields_value = d, wx.showLoading({
                                    title: "正在提交...",
                                    mask: !0
                                }), s.setData({
                                    adding: !0
                                });
                                var V = wx.getStorageSync("userInfoV1");
                                2 === s.data.needMemary && v.clicklog(104, 108001), s.asData.isSecretForm && v.clicklogNew(123, 17, s.data.currentURL), 
                                1 === D && (0, n.postClickLog)({
                                    fir: 104,
                                    sec: 139
                                });
                                var R = {
                                    record: JSON.stringify(c),
                                    union_id: i.unionId,
                                    app_id: e.appid,
                                    user_id: (0, n.getValue)(V, "userData.user_id", "") || "",
                                    time: V.userData.time,
                                    publickey: V.userData.publickey,
                                    auth_id: V.auth_id,
                                    auth_id_publickey: V.auth_id_publickey,
                                    auth_id_time: V.openidData.time,
                                    qrcode_route: s.data.currentURL,
                                    need_memary: s.data.needMemary
                                };
                                v.globalData.cardAuthInfo && (R.real_auth_id = V.auth_id, R.real_auth_publickey = V.auth_id_publickey, 
                                R.real_auth_time = V.openidData.time, R.auth_id = v.globalData.cardAuthInfo.auth_id, 
                                R.auth_id_publickey = v.globalData.cardAuthInfo.auth_id_publickey, R.auth_id_time = v.globalData.cardAuthInfo.auth_id_time);
                                try {
                                    s.asData.uaMag && (s.asData.uaMag.user_id = (0, n.getValue)(V, "userData.user_id", 0), 
                                    s.asData.uaMag.open_id = (0, n.getValue)(V, "openId", ""), s.asData.uaMag.mobile = (0, 
                                    n.getValue)(V, "userData.mobile", 0), s.asData.uaMag.union_id = (0, n.getValue)(V, "unionId", ""), 
                                    s.asData.uaMag.auth_id = (0, n.getValue)(V, "auth_id", ""), s.asData.uaMag.org_id = s.data.orgid, 
                                    R.ua_mag = JSON.stringify(s.asData.uaMag));
                                } catch (e) {
                                    console.warn(e);
                                }
                                var O = s.data.codeFrom, A = s.asData, L = A.openCodeOrigin, M = A.authIdErrorReqNum;
                                if (R.entry_form_mode = L ? 1 : 2, R.entry_form_mode_value = L ? "".concat(L) : O, 
                                R.authid_refresh = M > 0 ? 1 : 0, "editRecordDetail" !== (0, n.getValue)(s.data.options, "type")) y({
                                    url: "".concat(e.ncUrl, "/record/addRecord"),
                                    data: R,
                                    doSuccess: function(o) {
                                        s.data.ignoreLocation && (0, n.postClickLog)({
                                            fir: 104,
                                            sec: 118139
                                        }), v.globalData.errorLocation && c.watermark_address && (v.setGlobalData({
                                            errorLocation: !1
                                        }), (0, n.postClickLog)({
                                            fir: 104,
                                            sec: 118098,
                                            datas: {
                                                timeStamp: new Date().getTime()
                                            }
                                        }));
                                        try {
                                            if (wx.__cur_form_upload_image_list && wx.__cur_form_upload_image_list.length) {
                                                var r = JSON.parse(JSON.stringify(o.data));
                                                delete r.record_data, (0, n.postClickLog)({
                                                    fir: 187,
                                                    sec: 3,
                                                    datas: {
                                                        response: r,
                                                        images: wx.__cur_form_upload_image_list
                                                    }
                                                });
                                            }
                                        } catch (e) {
                                            console.error(e);
                                        }
                                        if (s.adding = !1, 1 === o.code) {
                                            if (s.data.userInfo && s.data.userInfo.nick_name && !s.data.isMember && s.data.userInfo.nick_name !== m) {
                                                var d = s.data.userInfo;
                                                d.nick_name = m, wx.setStorageSync("userInfoDetails", d);
                                            }
                                            if (wx.hideLoading(), wx.setStorageSync("recordBack", 1), wx.setStorageSync("backFromPhone", !0), 
                                            v.globalData.codePages && ((v.globalData.codePages[v.globalData.codePages.length - 1] || {
                                                backFromPhone: !0
                                            }).backFromPhone = !0), c.recordName = s.data.formSourceData.name, c.logResult = l, 
                                            c.is_del = 1 === Number(o.data.is_need_audit) ? 2 : 0, c.globalNickName = s.asData.globalNickName, 
                                            c.auth_maps = (0, n.getValue)(V, "auth_maps"), c.auth_maps_publickey = (0, n.getValue)(V, "auth_maps_publickey"), 
                                            c.auth_maps_time = (0, n.getValue)(V, "auth_maps_time"), wx.setStorageSync("_addedRecordData", c), 
                                            s.asData.added = !0, s.asData.card = null, (0, n.getValue)(o, "data.card.card_id", "") && (s.asData.card = o.data.card), 
                                            s.data.isUltimate || s.initIsAuth || 4 !== Number(s.data.formAuth) || 0 != s.data.recordSumStatus || s.openAuthFormDone({
                                                tpl_id: s.data.tpl_id,
                                                code_id: c.code_id
                                            }), (0, n.getValue)(o, "data.jump_msg.jump_url") && 3 !== (0, n.getValue)(o, "data.audit_status")) {
                                                var u = JSON.parse(s.asData.tipMsg);
                                                1 === Number(u.has_jump) && (0, n.postClickLog)({
                                                    fir: 104,
                                                    sec: 118120
                                                }), 2 === Number(u.has_jump) && (0, n.postClickLog)({
                                                    fir: 104,
                                                    sec: 118121
                                                });
                                                var g = (0, n.getValue)(o, "data.jump_msg.jump_text_custom", "提交成功");
                                                s.setData({
                                                    jumpText: g
                                                });
                                                var p = 1500;
                                                g.length > 5 && g.length <= 10 ? p = 2e3 : g.length > 10 && (p = 2500), s.setData({
                                                    showNavModal: !0
                                                }), setTimeout(function() {
                                                    s.setData({
                                                        showNavModal: !1
                                                    }), (0, n.reLaunch)({
                                                        url: "/pages/code/code?q=".concat((0, n.getValue)(o, "data.jump_msg.jump_url")),
                                                        path: "/pages/code/code?q=".concat(s.data.currentURL)
                                                    });
                                                }, p);
                                            } else s.goToSuccessPage(c, o, a);
                                            return s.setNickName(!1), void wx.removeStorageSync("".concat(s.data.tpl_id, "_").concat(a.qrcode_record.id, "_").concat(a.qrcode_record.id, "_").concat(a.qrcode_record.web_url), void 0);
                                        }
                                        if (wx.hideLoading(), "authId_paramsError" === (0, n.getValue)(o, "msg.text") && s.asData.authIdErrorReqNum < 1) {
                                            s.asData.authIdErrorReqNum += 1;
                                            var f = s.data.orgCode;
                                            v.onlyCheckAuthed(f, function() {
                                                s.doAdd(t);
                                            }, "", "", 0, {
                                                onlyCheckParams: {
                                                    direct_return: 0
                                                }
                                            });
                                        } else 4 === o.data.audit_status ? wx.showModal({
                                            content: "管理员拒绝接收你提交的数据，如果存在误操作，请及时联系管理员处理",
                                            showCancel: !1,
                                            confirmText: "关闭",
                                            confirmColor: "#4caf50"
                                        }) : wx.showModal({
                                            content: o.msg.text || "添加失败",
                                            showCancel: !1,
                                            confirmText: "关闭",
                                            confirmColor: "#4caf50"
                                        });
                                        getApp().mtj.trackEvent("add_record_faild", {
                                            content: JSON.stringify({
                                                data: {
                                                    ecord: JSON.stringify(c),
                                                    union_id: i.unionId,
                                                    app_id: e.appid
                                                },
                                                res: JSON.stringify(o)
                                            })
                                        });
                                    },
                                    doFail: function() {
                                        s.setData({
                                            adding: !0
                                        }), s.adding = !1;
                                    },
                                    doComplete: function() {
                                        s.setData({
                                            adding: !1
                                        }), s.adding = !1;
                                    }
                                }); else {
                                    var E = {
                                        org_id: s.asData.org_id,
                                        record_id: (0, n.getValue)(s.data.options, "record_id"),
                                        fields_value: JSON.stringify(d),
                                        user_id: R.user_id,
                                        auth_id: R.auth_id,
                                        publickey: R.publickey,
                                        time: R.time,
                                        remake: "",
                                        watermark_recorder: s.data.imgMarkNickName || "",
                                        watermark_address: s.data.imgMarkAddress || "",
                                        auth_maps: V.auth_maps,
                                        auth_maps_publickey: V.auth_maps_publickey,
                                        auth_maps_time: V.auth_maps_time
                                    };
                                    y({
                                        url: "".concat(e.ncUrl, "/record/operateRecodeMsgForWx"),
                                        data: E,
                                        doSuccess: function(e) {
                                            1 === e.code && (wx.hideLoading(), s.adding = !1, setTimeout(function() {
                                                wx.setStorageSync("updateDetail", e), wx.navigateBack({
                                                    delta: 1
                                                });
                                            }));
                                        },
                                        doFail: function() {
                                            s.setData({
                                                adding: !0
                                            }), s.adding = !1;
                                        },
                                        doComplete: function() {
                                            s.setData({
                                                adding: !1
                                            }), s.adding = !1;
                                        }
                                    });
                                }
                            }
                        },
                        fail: function() {
                            s.adding = !1;
                        }
                    });

                  case 21:
                  case "end":
                    return e.stop();
                }
            }, e, this, [ [ 0, 6 ] ]);
        })), function(e) {
            return w.apply(this, arguments);
        }),
        mobileCreateAccount: function(e) {
            var t = this, a = this.data.orgCode;
            v.createUserAccountNew(a, e || this.data.userInfo.mobile, 6, function(e, a) {
                if (-1 === e) try {
                    (0, n.postClickLog)({
                        fir: 17,
                        sec: 124012,
                        datas: {
                            errorInfo: JSON.stringify(a),
                            mobile: t.data.userInfo.mobile
                        }
                    });
                } catch (e) {
                    console.error(e);
                }
                var o = (0, n.getValue)(a, "member_record.name");
                o && (t.setData({
                    haveNickName: !0,
                    isMember: !0
                }), t.nameChange({
                    detail: {
                        value: o
                    }
                })), (0, n.postClickLog)({
                    fir: 17,
                    sec: 124013,
                    datas: {
                        mobile: t.data.userInfo.mobile
                    }
                });
            }, !1, {
                fromAddRecordCreate: !0
            });
        },
        goToSuccessPage: function(e, t, a) {
            var o = this, r = e.watermark_recorder, i = e.list_name, s = e.recordName, c = e.tpl_id, d = e.auth_maps, u = e.auth_maps_publickey, l = e.auth_maps_time, m = this.data, g = m.backLen, p = m.currentURL, f = m.options, h = m.tplId, _ = m.changeStatusMsg, y = this.asData, b = y.org_id, D = y.tipMsg, k = y.isSecretForm, N = y.secretUrl, w = y.card, I = y.openCodeOrigin, T = t.data, x = T.is_need_audit, C = T.target_id, V = T.record_number_data, R = T.create_time, O = T.audit_status, A = T.publickey, L = T.jump_msg, M = T.record_token, E = L.jump_url, F = L.jump_text_custom, J = S.getNewCurrentDate(1e3 * R), U = (0, 
            n.getValue)(a, "log_msg.data_list", []), P = 0;
            (0, n.forEach)(U, function(e, t) {
                if (parseInt(e.tpl_id, 10) === parseInt(c, 10)) {
                    var a = U[t];
                    if (a) {
                        var o = a.notary_config;
                        o && 1 === o.status && 1 === o.card_status && (P = 1);
                    }
                }
            });
            var q = [ [ "backLength", g || 1 ], [ "orgId", b ], [ "codeId", a.qrcode_record.id ], [ "needCheck", 1 === Number(x) ? 2 : 0 ], [ "tipMsg", encodeURIComponent(D) ], [ "changeStatusMsg", encodeURIComponent(JSON.stringify(_)) ], [ "tasksList", encodeURIComponent(JSON.stringify(this.data.tasksList || [])) ], [ "tplNumber", encodeURIComponent(JSON.stringify(V || "{}")) ], [ "tpl_name", s ], [ "list_name", i ], [ "recorder", r ], [ "currentURL", p ], [ "recordId", C ], [ "addRecordTime", J ], [ "isSecretForm", k ], [ "secretUrl", N ], [ "openStatus", f.openStatus ], [ "autoStatus", f.autoStatus ], [ "modalStatus", f.modalStatus ], [ "enableWXCard", f.enableWXCard ], [ "showDateStatus", f.showDateStatus ], [ "showSavebuttonStatus", f.showSavebuttonStatus ], [ "card", JSON.stringify(w) ], [ "tplId", h || c ], [ "targetId", C ], [ "IsOpenNotary", P ], [ "notaryPublickey", A ], [ "openCodeOrigin", I ], [ "auth_maps", d ], [ "auth_maps_publickey", u ], [ "auth_maps_time", l ], [ "recordToken", encodeURIComponent(JSON.stringify(M || {})) ] ].map(function(e) {
                return e.join("=");
            }).join("&");
            try {
                var B = this.data.tags;
                B.IsOpenNotary = P, wx.setStorageSync("__current-form-tag", JSON.stringify(B));
            } catch (e) {
                console.error(e);
            }
            if (3 !== O) {
                if (k) return v.clicklogNew(123, 17, p), void wx.redirectTo({
                    url: "/subPackages/codeRecord/pages/AddRecordSuccess/AddRecordSuccess?".concat(q)
                });
                1 == (0, n.getValue)(this.data.options, "expandLog", null) ? (0, n.navigateTo)({
                    url: "/subPackages/codeRecord/pages/AddRecordSuccess/AddRecordSuccess?".concat(q),
                    events: {
                        loadPage: function() {
                            o.renderGroups({
                                groups: o.asData.backupGroups
                            });
                        }
                    }
                }) : wx.redirectTo({
                    url: "/subPackages/codeRecord/pages/AddRecordSuccess/AddRecordSuccess?".concat(q)
                });
            } else {
                var j = wx.getStorageSync("userInfoV1"), H = [ [ "backLength", g || 1 ], [ "orgId", b ], [ "codeId", a.qrcode_record.id ], [ "recordId", C ], [ "authId", j.auth_id ], [ "card", JSON.stringify(w) ], [ "jumpUrl", E ], [ "jumpTextCustom", F ], [ "tplId", h || c ], [ "list_name", i ], [ "currentURL", p ], [ "tipMsg", encodeURIComponent(D) ], [ "tpl_name", s ], [ "openStatus", f.openStatus ], [ "autoStatus", f.autoStatus ], [ "addRecordTime", J ], [ "tplNumber", encodeURIComponent(JSON.stringify(V || "{}")) ], [ "changeStatusMsg", encodeURIComponent(JSON.stringify(_)) ], [ "tasksList", encodeURIComponent(JSON.stringify(this.data.tasksList || [])) ], [ "auth_maps", d ], [ "auth_maps_publickey", u ], [ "auth_maps_time", l ], [ "recordToken", encodeURIComponent(JSON.stringify(M || {})) ] ].map(function(e) {
                    return e.join("=");
                }).join("&");
                1 != (0, n.getValue)(this.data.options, "expandLog", null) ? wx.redirectTo({
                    url: "/subPackages/codeRecord/pages/RecordNeedAudit/index?".concat(H)
                }) : (0, n.navigateTo)({
                    url: "/subPackages/codeRecord/pages/RecordNeedAudit/index?".concat(H),
                    events: {
                        loadPage: function() {
                            o.renderGroups({
                                groups: o.asData.backupGroups
                            });
                        }
                    }
                });
            }
        },
        updateFieldStatic: function(e, t) {
            var a = JSON.parse(JSON.stringify(this.asData.groups)), o = a.find(function(e) {
                return e.id === t;
            }), r = (0, n.getValue)(o, "components", []);
            (0, n.forEach)(r, function(t, a) {
                t.id === e.id && r.splice(a, 1, e);
            }), this.asData.groups = a;
            var i = this.asData.statusRuleMsg;
            (0, n.getValue)(i, "length") && "radio" === e.tpl_component && this.handleChangeStatus();
        },
        handleChangeStatus: function(e) {
            var t = JSON.parse(JSON.stringify(e || this.asData.groups)), a = v.globalData, o = (0, 
            n.getValue)(a.currentCodeInfoList.get(this.data.currentURL), "data", {}), r = (0, 
            n.getValue)(o, "qrcode_record.tpl_qrcode_status");
            if (2 !== r && 1 !== r) {
                var i = this.asData.statusRuleMsg;
                if ((0, n.getValue)(i, "length")) {
                    var s = [];
                    t.forEach(function(e) {
                        return [ e.components.forEach(function(e) {
                            "radio" === e.tpl_component && s.push(e);
                        }) ];
                    });
                    var c = [], d = this.asData.currentStatusMsg;
                    s.forEach(function(e) {
                        if ((0, n.getValue)(e, "options.radio.length")) {
                            var t = (0, n.getValue)(e, "options.radio", []).filter(function(e) {
                                return e.selected;
                            });
                            if (!(0, n.getValue)(t, "length")) return;
                            var a = (0, n.getValue)(t, "0.id"), r = (0, n.getValue)(o, "qrcode_record.id");
                            i.forEach(function(t) {
                                if ((0, n.getValue)(e, "id") === (0, n.getValue)(t, "result.tpl_field_id") && a === (0, 
                                n.getValue)(t, "result.tpl_field_option_id")) {
                                    var o = (0, n.getValue)(d, "".concat(r), []), i = +(0, n.getValue)(t, "result.state_id"), s = (0, 
                                    n.getValue)(t, "result.state_option_id"), u = (0, n.getValue)(t, "result.state_option_record.text"), l = (0, 
                                    n.getValue)(t, "result.state_option_record.color"), m = (0, n.getValue)(t, "result.state_record.name"), g = o.find(function(e) {
                                        return +e.state_id === i;
                                    });
                                    if (g) {
                                        if (g.id === s) return;
                                        var p = {
                                            state_id: i,
                                            current_status: (0, n.getValue)(g, "text"),
                                            current_color: (0, n.getValue)(g, "color"),
                                            change_status: u,
                                            change_color: l,
                                            state_name: m
                                        };
                                        c.push(p);
                                    } else {
                                        var f = {
                                            state_id: i,
                                            current_status: "未设置",
                                            current_color: "#999",
                                            change_status: u,
                                            change_color: l,
                                            state_name: m
                                        };
                                        c.push(f);
                                    }
                                }
                            });
                        }
                    });
                    var l = this.asData.initChangeStatusMsg, m = (0, n.cloneDeep)(l);
                    (0, n.getValue)(m, "length") && (m.forEach(function(e, t) {
                        var a = +(0, n.getValue)(e, "state_id");
                        -1 !== (0, u.findIndex)(c, function(e) {
                            return +e.state_id === a;
                        }) && m.splice(t, 1);
                    }), c = m.concat(c)), this.setData({
                        changeStatusMsg: c
                    });
                }
            }
        },
        updateField: function(e, t) {
            var a = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], o = JSON.parse(JSON.stringify(this.asData.groups)), r = o.find(function(e) {
                return e.id === t;
            }), i = (0, n.getValue)(r, "components", []);
            (0, n.forEach)(i, function(t, a) {
                t.id === e.id && i.splice(a, 1, e);
            }), this.renderGroups({
                groups: o
            }), a && (this.asData.doRecording = !1, this.add());
        },
        updateEmptyTips: function(e) {
            var t = (0, n.cloneDeep)(this.data.emptyTips);
            delete t[e], this.setData({
                emptyTips: t
            });
        },
        doRecording: function(e) {
            this.asData.doRecording = e.detail;
        },
        updateEmptyTipsValue: function(e, t) {
            var a = JSON.parse(JSON.stringify(this.asData.groups));
            if (e) {
                var o = e.split("-"), r = (0, n.getValue)(a, "".concat(o[1], ".components.").concat(o[2])), i = {}, s = r.title, c = (0, 
                n.cloneDeep)(x[r.tpl_component]);
                c.msg = t || s + c.msg, i[e] = c, this.setData({
                    emptyCompId: e,
                    emptyTips: i
                });
            }
        },
        getDesc: function(e) {
            var t, a = this, o = v.globalData, i = o.ncUrl, s = this.data, c = s.isTplCreate, d = s.tpl_id;
            if (c) {
                var u = this.data.formData, l = (0, n.chunk)(u.groups, 5).length;
                return (0, n.assign)(this.asData, {
                    backupGroups: JSON.parse(JSON.stringify(u.groups)),
                    groups: JSON.parse(JSON.stringify(u.groups))
                }), this.setData({
                    formSourceData: u,
                    recordName: (0, n.getValue)(u, "name", ""),
                    loading: !1,
                    colorInfo: this.getColorInfo(),
                    chunkSize: l,
                    currentChunkIndex: -1
                }), void (e && e());
            }
            o && (t = (0, n.getValue)(o.currentCodeInfoList.get(this.data.currentURL), "data.qrcode_record.org_id", 0));
            var m = this.asData.recordTplToken, g = void 0 === m ? {} : m, p = "".concat(i, "/record/getDesc"), f = function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var a = null != arguments[t] ? arguments[t] : {};
                    t % 2 ? h(Object(a), !0).forEach(function(t) {
                        (0, r.default)(e, t, a[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(a)) : h(Object(a)).forEach(function(t) {
                        Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(a, t));
                    });
                }
                return e;
            }({
                tpl_id: d,
                org_id: t
            }, g);
            v.addTimeLog("before_api_request", {
                apiurl: p
            }, "getdesc"), y({
                url: p,
                data: f,
                doSuccess: function(t) {
                    v.addTimeLog("after_api_request", {
                        apiurl: p,
                        success: !0
                    }, "getdesc"), v.saveTimeLog("getdesc");
                    var o = (0, n.getValue)(t, "data.groups", []);
                    (0, n.assign)(a.asData, {
                        backupGroups: JSON.parse(JSON.stringify(o)),
                        groups: JSON.parse(JSON.stringify(o))
                    });
                    var r = (0, n.chunk)(o, 5).length, i = t.data, s = (0, n.getValue)(i, "notary_config") || {}, c = 1 === s.status && 1 === s.card_status, d = (0, 
                    n.filter)(i.rule_msg, function(e) {
                        return "state_event" === e.type;
                    }), u = (0, n.getValue)(d, "length") > 0;
                    a.setData({
                        formSourceData: i,
                        IsOpenNotary: c,
                        hasStatusRule: u,
                        recordName: (0, n.getValue)(t, "data.name", ""),
                        colorInfo: a.getColorInfo(),
                        loading: !1,
                        chunkSize: r,
                        currentChunkIndex: -1,
                        showFormProtocol: 1 === Number((0, n.getValue)(t, "data.privacy_status", 0)),
                        showSubmitBtn: 1 === t.code
                    }), e && e(t);
                }
            });
        },
        getRuleMsg: function(e) {
            var t, r = this, i = v.globalData, s = i.ncUrl, c = (0, n.getValue)(i.currentCodeInfoList.get(this.data.currentURL), "data", {}), d = "".concat(s, "/statusRule/getList"), u = {
                code_id: (0, n.getValue)(c, "qrcode_record.id"),
                tpl_id: this.data.tpl_id,
                qrcode_route: this.data.currentURL
            };
            u.code_id ? y({
                url: d,
                data: u,
                doSuccess: (t = (0, o.default)(a.default.mark(function t(o) {
                    var i, s;
                    return a.default.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                          case 0:
                            if (1 !== (0, n.getValue)(o, "code")) {
                                t.next = 8;
                                break;
                            }
                            return i = (0, n.getValue)(o, "data", []), s = i.filter(function(e) {
                                return "state_event" === (0, n.getValue)(e, "type") && (0, n.getValue)(e, "result.state_option_record") && (0, 
                                n.getValue)(e, "result.state_record");
                            }), r.asData.statusRuleMsg = s, t.next = 6, r.getTargetStateMsg();

                          case 6:
                            return e && e(o), t.abrupt("return");

                          case 8:
                            e && e(o);

                          case 9:
                          case "end":
                            return t.stop();
                        }
                    }, t);
                })), function(e) {
                    return t.apply(this, arguments);
                })
            }) : e && e();
        },
        getTargetStateMsg: function() {
            var e = this, t = this.asData.statusRuleMsg;
            if ((0, n.getValue)(t, "length")) {
                var a = v.globalData, o = (0, n.getValue)(a.currentCodeInfoList.get(this.data.currentURL), "data", {}), r = (0, 
                n.getValue)(o, "qrcode_record.tpl_qrcode_status");
                if (2 !== r && 1 !== r) {
                    var i = a.ncUrl, s = {
                        qrcode_route: this.data.currentURL
                    }, c = "".concat(i, "/state/getTargetStateMsg");
                    return new Promise(function(a) {
                        y({
                            url: c,
                            data: s,
                            doSuccess: function(r) {
                                if (1 === (0, n.getValue)(r, "code")) {
                                    var i = (0, n.getValue)(r, "data"), s = (0, n.getValue)(o, "qrcode_record.id"), c = [];
                                    t.forEach(function(e) {
                                        var t = (0, n.getValue)(i, "".concat(s), []);
                                        if (!(0, n.getValue)(e, "result.tpl_field_id")) {
                                            var a = +(0, n.getValue)(e, "result.state_id"), o = (0, n.getValue)(e, "result.state_option_id"), r = (0, 
                                            n.getValue)(e, "result.state_option_record.text"), d = (0, n.getValue)(e, "result.state_option_record.color"), u = (0, 
                                            n.getValue)(e, "result.state_record.name"), l = t.find(function(e) {
                                                return +e.state_id === a;
                                            });
                                            if (l) {
                                                if (l.id === o) return;
                                                var m = {
                                                    state_id: a,
                                                    current_status: (0, n.getValue)(l, "text"),
                                                    current_color: (0, n.getValue)(l, "color"),
                                                    change_status: r,
                                                    change_color: d,
                                                    state_name: u
                                                };
                                                c.push(m);
                                            } else {
                                                var g = {
                                                    state_id: a,
                                                    current_status: "未设置",
                                                    current_color: "#999",
                                                    change_status: r,
                                                    change_color: d,
                                                    state_name: u
                                                };
                                                c.push(g);
                                            }
                                        }
                                    }), e.asData.currentStatusMsg = i, e.asData.initChangeStatusMsg = c, e.setData({
                                        changeStatusMsg: c
                                    }), a(r);
                                }
                            }
                        });
                    });
                }
            }
        },
        getField: function(e) {
            var t = e.pid, a = e.cid, o = JSON.parse(JSON.stringify(this.asData.groups)).find(function(e) {
                return e.id === t;
            });
            return (0, n.getValue)(o, "components", []).find(function(e) {
                return e.id === a;
            }) || {};
        },
        getPosition: function(e, t) {
            var a = this, o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : function() {}, r = arguments.length > 3 ? arguments[3] : void 0, i = !(arguments.length > 4 && void 0 !== arguments[4]) || arguments[4];
            e || (e = this.getPositionTarget());
            var n = e.currentTarget.dataset, s = n.data, c = void 0 === s ? {} : s, d = n.pid, u = n.cid;
            this.data.emptyTips[u] && this.updateEmptyTips(u);
            var l = this.data.isTplCreate, m = l ? this.getField({
                pid: d,
                cid: c.id
            }) : c;
            if (this.data.ignoreLocation) return this.updateAddress({
                field: m,
                pid: d,
                address: "位置信息获取失败（多次尝试失败，可能是手机信号波动导致）",
                latitude: "0",
                longitude: "0"
            }), t && this.doAdd(t), void setTimeout(function() {
                o();
            }, 1e3);
            v.getUserLocation(this, {
                cb: function(e) {
                    if (0 === e.code) return D = 1, a.setData({
                        ignoreLocation: !0
                    }), a.updateAddress({
                        field: m,
                        pid: d,
                        address: "位置信息获取失败（多次尝试失败，可能是手机信号波动导致）",
                        latitude: "0",
                        longitude: "0"
                    }), t && a.doAdd(t), void setTimeout(function() {
                        o();
                    }, 1e3);
                    -1 !== e ? v.wx.request({
                        url: "".concat(v.globalData.ncUrl, "/commonapi/getLocateMsg"),
                        data: {
                            longitude: e.longitude,
                            latitudes: e.latitude
                        },
                        header: {
                            "content-type": "application/json"
                        },
                        method: "GET",
                        success: function(r) {
                            if (1 === r.data.code) {
                                var i = "";
                                (r.data.data.formatted_address || r.data.data.sematic_description) && (i = "".concat(r.data.data.formatted_address, "(").concat(r.data.data.sematic_description, ")"));
                                var n = e.latitude, s = e.longitude;
                                l && !m.addressName && (m.addressName = i), a.updateAddress({
                                    field: m,
                                    pid: d,
                                    address: i,
                                    latitude: n,
                                    longitude: s
                                }), t && a.doAdd(t), o();
                            } else a.locationFailClicklog(2), a.useTencentLocate(e, m, d);
                        },
                        fail: function() {
                            a.locationFailClicklog(3), a.useTencentLocate(e, m, d);
                        }
                    }) : a.locationFailClicklog(1);
                },
                authReason: r,
                toAuthPage: i
            });
        },
        locationFailClicklog: function(e) {
            (0, n.postClickLog)({
                fir: 104,
                sec: 118155,
                datas: {
                    type: e
                }
            });
        },
        updateAddress: function(e) {
            var t = e.field, a = e.pid, o = e.address, r = e.latitude, i = e.longitude;
            t.value = o, this.data.isTplCreate && (t.lat = r, t.log = i);
            var n = JSON.parse(JSON.stringify(this.data.recorderInfo));
            a && (this.updateField(t, a), n.address = {
                item: t,
                pid: a
            }), this.asData.la = r, this.asData.lo = i, this.setData({
                recorderInfo: n,
                imgMarkAddress: o
            });
        },
        history: function() {
            var e = v.globalData, t = (0, n.getValue)(e.currentCodeInfoList.get(this.data.currentURL), "data", {}), a = {
                org_id: t.qrcode_record.org_id,
                code_id: t.qrcode_record.id
            };
            (0, n.navigateTo)({
                url: "/subPackages/codeRecord/pages/recordHistory/recordHistory?orgId=".concat(a.org_id, "&codeId=").concat(a.code_id, "&noPower=false&checkMyRecord=1&noShowHide=1")
            });
        },
        back: function() {
            wx.navigateBack({
                delta: 0
            });
        },
        openBack: function(e) {
            var t = e.currentTarget.dataset.cid;
            this.data.emptyTips[t] && this.updateEmptyTips(t), v.resetAuthInfo(e.detail, this);
        },
        useTencentLocate: function(e, t, a) {
            var o = this, r = function() {
                wx.showModal({
                    title: "提示",
                    content: "获取定位失败，请重新获取。",
                    showCancel: !1
                });
            };
            _.reverseGeocoder({
                location: {
                    latitude: e.latitude,
                    longitude: e.longitude
                },
                success: function(i) {
                    0 == i.status ? (t.value = i.result.address, o.updateField(t, a), o.asData.la = e.latitude, 
                    o.asData.lo = e.longitude) : (o.locationFailClicklog(4), r());
                },
                fail: function() {
                    this.locationFailClicklog(5), r();
                },
                complete: function() {
                    wx.hideLoading();
                }
            });
        },
        clearRecorder: function() {
            this.setData({
                haveNickName: !1
            }), this.nameChange({
                detail: {
                    value: ""
                }
            });
        },
        nameChange: function(e) {
            var t = e.detail, a = JSON.parse(JSON.stringify(this.data.recorderInfo));
            (0, n.getValue)(a, "recorder.item") && (a.recorder.item.value = t.value, this.updateField(a.recorder.item, a.recorder.pid), 
            this.setData({
                recorderInfo: a
            }));
        },
        handleGetEditUserInfo: (0, n.debounceLeading)(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0], t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : function() {};
            this.getEditUserInfo({
                fromMark: e,
                cb: t
            });
        }),
        getEditUserInfo: function() {
            var e = this, a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = a.fromMark, r = void 0 !== o && o, i = a.cb, c = void 0 === i ? function() {} : i, d = a.authReason, u = a.otherAuth, l = void 0 === u ? [] : u, m = a.authBack, g = void 0 !== m && m;
            if ((0, n.getValue)(v, "globalData.userInfoV1.wx.nickName", "") && g) {
                var p = (0, n.getValue)(v, "globalData.userInfoV1.wx.nickName", "");
                this.setData({
                    haveNickName: !0
                });
                var f = JSON.parse(JSON.stringify(this.data.recorderInfo));
                f.recorder && (f.recorder.item.value = p, this.updateField(f.recorder.item, f.recorder.pid));
                var h = JSON.parse(JSON.stringify(this.data.userInfo));
                return h.nick_name = p, this.authInfo((0, n.getValue)(v, "globalData.userInfoV1.wx", {})), 
                this.asData.globalNickName = p, this.setData({
                    recorderInfo: f,
                    userInfo: h,
                    imgMarkNickName: p
                }), void c();
            }
            (0, n.getValue)(v, "globalData.userInfoV1.wx.nickName", "") ? v.getUserProfile("表单信息中的头像、昵称展示", function(t) {
                if (-1 !== t) if (t.nickName) {
                    e.setData({
                        haveNickName: !0
                    });
                    var a = JSON.parse(JSON.stringify(e.data.recorderInfo));
                    a.recorder && (a.recorder.item.value = t.nickName, e.updateField(a.recorder.item, a.recorder.pid));
                    var o = JSON.parse(JSON.stringify(e.data.userInfo));
                    o.nick_name = t.nickName, e.authInfo(t), e.asData.globalNickName = t.nickName, e.setData({
                        recorderInfo: a,
                        userInfo: o,
                        imgMarkNickName: t.nickName
                    }), c();
                } else wx.showToast({
                    title: "授权微信名失败"
                });
            }) : l ? wx.getSetting({
                success: function(a) {
                    var o = !1, i = (0, n.filter)(l, function(e) {
                        var t = (0, n.getValue)(s.AUTHSCOPE_MAP, e);
                        return "positioning" === e && (o = !0 === a.authSetting[t]), !(t && a.authSetting[t]);
                    });
                    new Promise(function(e) {
                        o ? v.wx.getLocation({
                            type: "gcj02",
                            fail: function() {
                                i = (0, t.default)(new Set([].concat((0, t.default)(i), [ "positioning" ])));
                            },
                            complete: function() {
                                e();
                            }
                        }) : e();
                    }).then(function() {
                        v.toAuthPage({
                            authTypeArr: [ "wechat" ].concat(i),
                            authReason: d,
                            orgCode: e.data.orgCode,
                            success: function() {
                                e.getEditUserInfo({
                                    fromMark: r,
                                    cb: c,
                                    authReason: d,
                                    toAuthPage: !1,
                                    authBack: !0
                                });
                            }
                        }), wx.hideLoading();
                    });
                },
                fail: function() {
                    v.toAuthPage({
                        authTypeArr: [ "wechat" ],
                        authReason: d,
                        orgCode: e.data.orgCode,
                        success: function() {
                            e.getEditUserInfo({
                                fromMark: r,
                                cb: c,
                                authReason: d,
                                toAuthPage: !1,
                                authBack: !0
                            });
                        }
                    }), wx.hideLoading();
                }
            }) : v.toAuthPage({
                authTypeArr: [ "wechat" ],
                authReason: d,
                orgCode: this.data.orgCode,
                success: function() {
                    e.getEditUserInfo({
                        fromMark: r,
                        cb: c,
                        authReason: d,
                        toAuthPage: !1,
                        authBack: !0
                    });
                }
            });
        },
        clearTel: function() {
            this.updateTel("");
        },
        getPhoneNumber: (0, n.debounceLeading)(function() {
            var e = this;
            wx.showLoading({
                title: "正在获取手机号",
                mask: !0
            }), v.getUserPhoneNumber({
                orgCode: this.data.orgCode,
                cb: function(t) {
                    wx.hideLoading(), -1 !== t && e.updateTel(t);
                }
            });
        }),
        updateTel: function(e) {
            try {
                var t = JSON.parse(JSON.stringify(this.data.recorderInfo));
                t.tel && (t.tel.item.value = e, this.updateField(t.tel.item, t.tel.pid));
                var a = JSON.parse(JSON.stringify(this.data.userInfo));
                a.mobile = e, a.mobile && !this.data.isAuth && (this.setData({
                    hasMobileAlready: !0
                }), this.mobileCreateAccount(a.mobile)), this.setData({
                    recorderInfo: t,
                    userInfo: a
                });
            } catch (e) {
                console.error(e);
            }
        },
        getauthPhoneNumber: function() {
            var e = this;
            this.getPhoneNumber(function() {
                e.doAdd("fake form Id");
            });
        },
        getauthUserInfo: function() {
            var e = this;
            this.getEditUserInfo({
                fromMark: !1,
                cb: function() {
                    e.data.isAuth ? e.doAdd("fake form Id") : wx.showToast({
                        title: "请继续点击手机号授权",
                        icon: "none"
                    });
                }
            });
        },
        openAuthFormDone: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.code_id, a = e.tpl_id;
            wx.setStorageSync("backFromPhone", 1);
            var o = wx.getStorageSync("userInfoV1"), r = {
                code_id: t,
                tpl_id: a,
                user_id: (0, n.getValue)(o, "userData.user_id", ""),
                nick_name: (0, n.getValue)(o, "wx.nickName", ""),
                city: (0, n.getValue)(o, "city", ""),
                time: (0, n.getValue)(o, "userData.time", "")
            };
            v.clicklog(108, 2, JSON.stringify(r));
        },
        showTelToast: function() {
            wx.showToast({
                title: "手机号不能编辑",
                icon: "none"
            });
        },
        authInfo: function(e) {
            var t = this, a = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", o = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "", r = wx.getStorageSync("userInfoV1");
            e || (e = r.wx || {});
            var i = {
                app_id: v.globalData.appid,
                mobile: r.mobile || "",
                user_id: (0, n.getValue)(r, "userData.user_id", ""),
                time: r.userData.time,
                publickey: r.userData.publickey,
                union_id: r.unionId || ""
            };
            a && (i.user_id = a), i.org_id = o || this.asData.org_id, r.unionId && f.default.postRequest("".concat(v.globalData.decodeUrl, "/mobileDataAuth/saveBasicAuthInfo"), i).then(function(e) {
                if (1 === (e = e.data).code) {
                    var a = (0, n.getValue)(e, "data.member_record.name");
                    a && t.nameChange({
                        detail: {
                            value: a
                        }
                    });
                }
            });
        },
        gotoEmptyComp: function() {
            var e = this, t = this.data.emptyCompId, a = this.createSelectorQuery();
            a.select("#".concat(t)).boundingClientRect(), a.exec(function(t) {
                var a = (0, n.getValue)(t, "0.top", 0) - 24;
                a > 0 ? a = 0 : a -= 100, wx.pageScrollTo({
                    scrollTop: e.scrollHeight + a,
                    duration: 300
                });
            });
        },
        onKeyboardHeightChange: function() {},
        isLicenseNo: function(e) {
            return /^(([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z](([0-9]{5}[DF])|([DF]([A-HJ-NP-Z0-9])[0-9]{4})))|([京津沪渝冀豫云辽黑湘皖鲁新苏浙赣鄂桂甘晋蒙陕吉闽贵粤青藏川宁琼使领][A-Z][A-HJ-NP-Z0-9]{4}[A-HJ-NP-Z0-9挂学警港澳使领]))$/.test(e);
        },
        editChangeName: function() {
            this.setData({
                rderFocus: !0
            });
        },
        recorderFocus: function() {
            this.setData({
                rderFocus: !0
            });
        },
        recorderBlur: function(e) {
            this.nameChange(e), this.setData({
                rderFocus: !1
            });
        },
        checkboxChange: function(e) {
            var t = "needMemary" === e.detail.value[0] ? 1 : 2;
            this.setData({
                needMemary: t
            });
        },
        formatTime: function(e) {
            var t = [], a = new Date(1e3 * e);
            t.push(a.getFullYear()), t.push(this.formatNumber(a.getMonth() + 1)), t.push(this.formatNumber(a.getDate()));
            var o = this.formatNumber(a.getHours()), r = this.formatNumber(a.getMinutes());
            return "".concat(t.join("-"), " ").concat(o, ":").concat(r);
        },
        formatNumber: function(e) {
            return (e = e.toString())[1] ? e : "0".concat(e);
        },
        updataAutoMemory: function(e) {
            var t = JSON.parse(JSON.stringify(this.asData.memoryArr)), a = JSON.parse(JSON.stringify(this.asData.groups));
            if (-1 !== t.indexOf(e)) {
                a.forEach(function(a) {
                    a.components.forEach(function(a) {
                        t.indexOf(e) > -1 && a.id === e && delete a.isAutoMemory;
                    });
                });
                var o = t.filter(function(t) {
                    return t !== e;
                });
                this.asData.memoryArr = o, this.asData.groups = a, this.renderGroups({
                    groups: a
                });
            }
        },
        catchtouchmove: function() {},
        showProtocol: function() {
            this.setData({
                protocolShow: !0
            });
        },
        hideProtocol: function() {
            this.setData({
                protocolShow: !1
            });
        },
        toProtocol: function() {
            (0, n.navigateTo)({
                url: "/webview/pages/webview/webview?q=https://cli.im/help/49902?from=policy"
            }), this.hideProtocol();
        },
        onAddressNameFocus: function(e) {
            var t = e.currentTarget.dataset.cid;
            this.setData({
                addressNameFocusedId: t
            });
        },
        onAddressNameChange: function(e) {
            var t = e.currentTarget.dataset, a = t.data, o = void 0 === a ? {} : a, r = t.pid, i = e.detail.value;
            o.addressName = i, r && this.updateFieldStatic(o, r);
        },
        onAddressNameBlur: function(e) {
            this.setData({
                addressNameFocusedId: 0
            });
        }
    }
});
!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e, t = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var i = t[n];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
                Object.defineProperty(e, i.key, i);
            }
        }
        return function(t, n, i) {
            return n && e(t.prototype, n), i && e(t, i), t;
        };
    }(), n = D(require("./../npm/wepy/lib/wepy.js")), i = require("./../npm/wepy-redux/lib/index.js"), r = D(require("./../components/topBar.js")), s = D(require("./../components/indexFooter.js")), a = D(require("./../components/priviewVideo.js")), o = D(require("./../components/toast.js")), u = D(require("./../components/tinToast.js")), c = D(require("./../components/qcodeToast.js")), h = D(require("./../components/appBannerToast.js")), p = D(require("./../components/signBox.js")), d = D(require("./../components/newGuide.js")), l = D(require("./../components/search.js")), g = D(require("./../components/loading.js")), f = D(require("./../components/publish.js")), y = D(require("./../components/publishDiary.js")), m = D(require("./../components/homeTab.js")), w = D(require("./../components/petDiary.js")), k = D(require("./../components/citys.js")), v = D(require("./../config/constant.js")), x = require("./../config/http.js");
    require("./../npm/wepy-async-function/index.js");
    var b = D(require("./../store/index.js")), S = require("./../config/crypto.js"), I = D(require("./../config/helper.js"));
    D(require("./../config/log.js"));
    function D(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function $(e) {
        return function() {
            var t = e.apply(this, arguments);
            return new Promise(function(e, n) {
                return function i(r, s) {
                    try {
                        var a = t[r](s), o = a.value;
                    } catch (e) {
                        return void n(e);
                    }
                    if (!a.done) return Promise.resolve(o).then(function(e) {
                        i("next", e);
                    }, function(e) {
                        i("throw", e);
                    });
                    e(o);
                }("next");
            });
        };
    }
    function N(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
    }
    function P(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    var R = (0, b.default)();
    (0, i.setStore)(R), n.default.$store = R;
    var L = (0, i.connect)({
        httpImg: function(e) {
            return e.user.httpImg;
        },
        user: function(e) {
            return e.user.user;
        }
    })(e = function(e) {
        function i() {
            var e, t, v, b, S, D, R, L, M, A, T, C, U = this;
            N(this, i);
            for (var q = arguments.length, z = Array(q), O = 0; O < q; O++) z[O] = arguments[O];
            return t = v = P(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(z))), 
            v.config = {
                disableScroll: !1,
                enablePullDownRefresh: !0,
                onReachBottomDistanc: 100
            }, v.$repeat = {}, v.$props = {
                topbar: {
                    title: "宠宠窝",
                    bg: "false",
                    "xmlns:v-bind": "",
                    "v-bind:isIphoneX.once": "isIphoneX"
                },
                indexFooter: {
                    "xmlns:v-bind": "",
                    "v-bind:idx.once": "index"
                },
                search: {
                    "xmlns:v-bind": "",
                    "v-bind:isIphoneX.once": "isIphoneX"
                },
                loading: {
                    "xmlns:v-bind": "",
                    "v-bind:isLoading.sync": "isLoading"
                },
                homeTab: {
                    "xmlns:v-bind": "",
                    "v-bind:currentTab.sync": "currentTab"
                },
                petDiary: {
                    "v-bind:list.sync": "petDiaryList",
                    "v-bind:isAuthorize.sync": "isAuthorize"
                },
                newGuide: {
                    "xmlns:v-bind": "",
                    "v-bind:isIphoneX.sync": "isIphoneX"
                }
            }, v.$events = {}, v.components = {
                topbar: r.default,
                indexFooter: s.default,
                toast: o.default,
                tinToast: u.default,
                qcodeToast: c.default,
                appBannerToast: h.default,
                signBox: p.default,
                search: l.default,
                loading: g.default,
                publish: f.default,
                publishDiary: y.default,
                homeTab: m.default,
                citys: k.default,
                petDiary: w.default,
                newGuide: d.default,
                priviewVideo: a.default
            }, v.data = {
                option: {},
                message: 1,
                currentTab: "1",
                index: "0",
                scrollTop: 0,
                diaryScrollTop: 0,
                isNewMsg: !1,
                keySerach: !1,
                pageNo: 1,
                diaryPageNo: 1,
                pageSize: 20,
                keyWords: {},
                height: "900",
                isLoading: "true",
                clickCount: 0,
                list: [],
                currentindex: 0,
                cards: [],
                showCode: !1,
                nickname: "",
                hasMoreData: !0,
                hasMoreDiary: !0,
                foucus: 0,
                headicon: "",
                canRefesh: !0,
                canRefeshDiary: !0,
                isAuthorize: !1,
                petCardSort: 0,
                isIphoneX: "0",
                cityList: [],
                petDiaryList: [],
                unreadSysMsgList: [],
                isQueryAllDiary: !0,
                canSearchDiary: !0,
                showQcode: !1,
                showUse: !1,
                petCity: {
                    cityName: "点击选择城市",
                    cityId: "",
                    provinceName: "",
                    provinceId: ""
                },
                minelist: [ {
                    title: "我的私信",
                    img: "/main/img/ic_mymessage.png"
                }, {
                    title: "我的设置",
                    img: "/main/img/ic_myinfo.png"
                }, {
                    title: "联系客服",
                    img: "/main/img/ic_service.png"
                }, {
                    title: "使用必读",
                    img: "/main/img/ic_statement.png"
                } ],
                isFirstUse: !1,
                observerObj: {},
                videoIndex: 0,
                isVideoFullScreen: !1,
                isSocketOpen: !1,
                timer: {},
                indicatorDots: !0,
                indicatorColor: "#fff",
                indicatorActiveColor: "#f96966",
                vertical: !1,
                autoplay: !0,
                interval: 2e3,
                duration: 500,
                swiperList: [],
                swiperScrollHeight: !1,
                swiperScroll: !1,
                cannelNum: 0,
                recommendUserId: "",
                showCanningImg: !0,
                signData: null
            }, v.watch = {
                index: function(e, t) {
                    this.getMassage(), "1" == e && this.getOwnerinfo();
                },
                message: function(e, t) {
                    1 == e ? this.$invoke("indexFooter", "clearMsg") : 0 == e && this.$invoke("indexFooter", "showMsg");
                }
            }, v.methods = {
                tabChange: function(e) {
                    this.currentTab = e.detail.current;
                },
                catchTouchMove: function(e) {
                    return !1;
                },
                formSubmit: function(e) {
                    this.events.formSubmitEvent(e.detail.formId);
                },
                showSignBox: function() {
                    if (this.isAuthorize && wx.getStorageSync("userPhone")) {
                        var e = {
                            item: this.signData,
                            cannelInfo: this.signData.cannelInfo
                        };
                        this.$invoke("signBox", "show", e);
                    } else this.$invoke("toast", "show", {
                        type: 3,
                        isAuthorize: !0
                    });
                },
                clickIcon: function(e) {
                    switch (e) {
                      case "0":
                        this.$invoke("homeTab", "hide"), this.$invoke("qcodeToast", "show");
                        break;

                      case "1":
                        if (this.isAuthorize && wx.getStorageSync("userPhone")) {
                            var t = JSON.stringify(this.cards);
                            this.$navigate("../pages/member/member", {
                                cards: encodeURIComponent(t)
                            });
                        } else this.$invoke("toast", "show", {
                            type: 3,
                            isAuthorize: !0
                        });
                        break;

                      case "2":
                        this.$navigate("../pages/info/petEncyclopedia", {
                            type: 2
                        });
                        break;

                      case "3":
                        this.$navigate("../pages/info/petEncyclopedia", {
                            type: 3
                        });
                    }
                },
                newCard: function() {
                    this.$navigate("../pages/person/addPetCard");
                },
                search: function() {
                    this.$invoke("homeTab", "hide"), this.$invoke("search", "show", {
                        isIphoneX: this.isIphoneX
                    });
                },
                tips: (C = $(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (this.isAuthorize && wx.getStorageSync("userPhone")) {
                                e.next = 3;
                                break;
                            }
                            return this.$invoke("toast", "show", {
                                type: 3,
                                isAuthorize: !0
                            }), e.abrupt("return");

                          case 3:
                            this.$navigate("../pages/message/news");

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                })), function() {
                    return C.apply(this, arguments);
                }),
                lookPetInfo: (T = $(regeneratorRuntime.mark(function e(t) {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            this.isAuthorize && wx.getStorageSync("userPhone") ? this.$navigate("../pages/person/petInfoDetail", t) : this.$invoke("toast", "show", {
                                type: 3,
                                isAuthorize: !0
                            });

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                })), function(e) {
                    return T.apply(this, arguments);
                }),
                tin: I.default.throttle((A = $(regeneratorRuntime.mark(function e(t) {
                    var i, r, s, a, o, u, c;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (0 != v.list.length) {
                                e.next = 2;
                                break;
                            }
                            return e.abrupt("return");

                          case 2:
                            if (v.isAuthorize && wx.getStorageSync("userPhone")) {
                                e.next = 5;
                                break;
                            }
                            return v.$invoke("toast", "show", {
                                type: 3,
                                isAuthorize: !0
                            }), e.abrupt("return");

                          case 5:
                            if (n.default.showLoading({
                                title: "请求中..."
                            }), i = v.list[t].petId, !(Object.keys(v.user).length > 0)) {
                                e.next = 24;
                                break;
                            }
                            if (r = v.user.openid, s = v.list[t].ownerId, !v.list[t].isSentTin) {
                                e.next = 18;
                                break;
                            }
                            return a = {
                                petId: i,
                                ownerId: r,
                                toOwnerId: s,
                                status: 1,
                                source: 1
                            }, e.next = 14, (0, x.cannedDeal)(a);

                          case 14:
                            (o = e.sent).data && o.data.flag && (v.list[t].isSentTin = !1, n.default.showToast({
                                title: "取消成功",
                                image: "img/ic_can_cancle.png"
                            }), v.list[t].tinNum--), e.next = 23;
                            break;

                          case 18:
                            return u = {
                                petId: i,
                                ownerId: r,
                                toOwnerId: s,
                                status: 0,
                                source: 1
                            }, e.next = 21, (0, x.cannedDeal)(u);

                          case 21:
                            (c = e.sent).data && c.data.flag && (v.list[t].isSentTin = !0, 0 == c.data.cannelNum ? n.default.showToast({
                                title: "点赞成功",
                                image: "img/ic_can_success.png"
                            }) : (wx.hideLoading(), v.$invoke("toast", "show", {
                                type: 13
                            })), v.list[t].tinNum++);

                          case 23:
                            v.$apply();

                          case 24:
                          case "end":
                            return e.stop();
                        }
                    }, e, U);
                })), function(e) {
                    return A.apply(this, arguments);
                })),
                attention: I.default.throttle((M = $(regeneratorRuntime.mark(function e(t) {
                    var i, r, s, a, o;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (0 != this.list.length) {
                                e.next = 2;
                                break;
                            }
                            return e.abrupt("return");

                          case 2:
                            if (this.isAuthorize && wx.getStorageSync("userPhone")) {
                                e.next = 5;
                                break;
                            }
                            return this.$invoke("toast", "show", {
                                type: 3,
                                isAuthorize: !0
                            }), e.abrupt("return");

                          case 5:
                            if ("1" != this.list[t].isOwner) {
                                e.next = 8;
                                break;
                            }
                            return this.$invoke("tinToast", "show", {
                                type: -2,
                                content: "不能关注您自己哦，请关注别人吧!"
                            }), e.abrupt("return");

                          case 8:
                            if (i = this.list[t].petId, r = this.user.openid, s = this.list[t].ownerId, this.list[t].isAttention) {
                                e.next = 21;
                                break;
                            }
                            if (null == i || null == r) {
                                e.next = 18;
                                break;
                            }
                            return a = {
                                petId: i,
                                ownerId: r,
                                toOwnerId: s
                            }, e.next = 16, (0, x.addFocus)(a);

                          case 16:
                            (o = e.sent).data && o.data.flag && (n.default.hideLoading(), this.methods.updateDiary(), 
                            this.list[t].isAttention = !0, this.foucus++, n.default.showToast({
                                title: "关注成功",
                                image: "img/ic_love_success.png"
                            }), this.$apply());

                          case 18:
                            this.$apply(), e.next = 21;
                            break;

                          case 21:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                })), function(e) {
                    return M.apply(this, arguments);
                })),
                loadMoreData: function() {
                    console.log(131321), 0 == this.currentTab ? this.methods.loadMorePetCard(this) : this.methods.bindLoadMoreDiary();
                },
                loadMorePetCard: function(e) {
                    console.log(e.hasMoreData), e.hasMoreData && (wx.showLoading({
                        title: "加载更多..."
                    }), e.pageNo++, e.getPetList(e.pageNo, e.keyWords), setTimeout(function() {
                        wx.hideLoading();
                    }, 1200));
                },
                updateData: function() {
                    0 == this.currentTab ? this.methods.updatePetCard() : this.methods.updateDiary();
                },
                updatePetCard: function(e) {
                    v.canRefesh && (v.canRefesh = !1, wx.showLoading({
                        title: "刷新中..."
                    }), v.pageNo = 1, v.hasMoreData = !0, v.getPetList(v.pageNo, v.keyWords), setTimeout(function() {
                        v.canRefesh = !0, v.$apply();
                    }, 2e3));
                },
                updateDiary: function(e) {
                    if (v.canRefeshDiary) {
                        if (v.diaryPageNo = 1, "{}" != JSON.stringify(v.keyWords) && v.petDiaryList.length < v.pageSize && v.petDiaryList.length > 0) return void (v.hasMoreDiary = !1);
                        v.canRefeshDiary = !1, wx.showLoading({
                            title: "刷新中..."
                        }), v.hasMoreDiary = !0, setTimeout(function() {
                            v.canRefeshDiary = !0, v.$apply();
                        }, 2e3), "{}" == JSON.stringify(v.keyWords) ? v.isQueryAllDiary ? v.queryAllDiary() : v.queryAttentionDiary() : v.filterDiaryList();
                    }
                },
                bindLoadMoreDiary: function(e) {
                    v.hasMoreDiary && (v.diaryPageNo++, wx.showLoading({
                        title: "加载更多..."
                    }), "{}" == JSON.stringify(v.keyWords) ? v.isQueryAllDiary ? v.queryAllDiary() : v.queryAttentionDiary() : v.filterDiaryList());
                },
                scrollDiary: function(e) {},
                click: function(e) {
                    switch (e) {
                      case "我的私信":
                        this.$navigate("../pages/person/myMsg");
                        break;

                      case "我的设置":
                        this.$navigate("../pages/info/myinfo");
                        break;

                      case "联系客服":
                        this.showCode = !0;
                        break;

                      case "使用必读":
                        this.showUse = !0;
                    }
                },
                next: function() {
                    this.currentindex++, this.currentindex == this.cards.length && (this.currentindex = 0);
                },
                prev: function() {
                    this.currentindex--, -1 == this.currentindex && (this.currentindex = this.cards.length - 1);
                },
                bindchange: function(e) {
                    this.currentindex = e.detail.current;
                },
                hideCode: function() {
                    this.showCode = !1;
                },
                clickQRCode: function() {},
                copyWXCode: function() {
                    wx.setClipboardData({
                        data: "petpethouse_",
                        success: function(e) {
                            console.log(e);
                        }
                    });
                },
                hideUse: function() {
                    this.showUse = !1;
                },
                toDisclaimer: function(e) {
                    this.$navigate("/pages/person/disclaimer", {
                        type: e
                    });
                },
                clickUse: function() {},
                myFabulous: function() {
                    this.$navigate("../pages/person/myFabulous");
                },
                myfocus: function() {
                    this.$navigate("../pages/person/myfoucus");
                },
                toCardList: function() {
                    this.$navigate("../pages/person/petInfo", {
                        index: this.currentindex
                    });
                },
                toNextPage: function(e) {
                    switch (e) {
                      case "1":
                        this.$redirect("/main/index", {
                            currentTab: 0
                        });
                        break;

                      case "2":
                        this.$redirect("/main/index", {
                            currentTab: 1
                        });
                        break;

                      case "3":
                        this.$navigate("/pages/daily/topic");
                        break;

                      case "4":
                        if (this.isAuthorize) {
                            var t = JSON.stringify(this.cards);
                            this.$navigate("/pages/member/member", {
                                cards: encodeURIComponent(t)
                            });
                        } else this.$invoke("toast", "show", {
                            type: 3,
                            isAuthorize: !0
                        });
                        break;

                      case "6":
                        this.$invoke("homeTab", "hide"), this.$invoke("appBannerToast", "show");
                    }
                }
            }, v.events = {
                previewImage: function(e) {
                    "" != e && wx.previewImage({
                        current: e,
                        urls: [ e ]
                    });
                },
                refresh: function() {
                    this.getTaskQuerySign();
                },
                invokeShow: function() {
                    this.$invoke("toast", "show", {
                        type: 3,
                        isAuthorize: !0
                    });
                },
                calculationHeightEvents: function(e) {},
                formSubmitEvent: (L = $(regeneratorRuntime.mark(function e(t) {
                    var n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if ("the formId is no longer available in develop or trial version of this mini program" != t) {
                                e.next = 2;
                                break;
                            }
                            return e.abrupt("return");

                          case 2:
                            return n = {
                                ownerId: this.user.openid,
                                formId: t
                            }, e.next = 5, (0, x.uploadFormId)(n);

                          case 5:
                            e.sent;

                          case 6:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                })), function(e) {
                    return L.apply(this, arguments);
                }),
                clickCardEvent: function(e) {
                    "最新" == e ? (this.petCardSort = 0, this.pageNo = 1, this.hasMoreData = !0) : "热门" == e && (this.petCardSort = 1, 
                    this.pageNo = 1, this.hasMoreData = !0), this.getPetList(this.pageNo, this.keyWords);
                },
                clickDiaryEvent: function(e) {
                    "全部" == e ? (this.diaryPageNo = 1, this.isQueryAllDiary = !0, this.hasMoreDiary = !0, 
                    this.queryAllDiary()) : "已关注" == e && (this.diaryPageNo = 1, this.isQueryAllDiary = !1, 
                    this.hasMoreDiary = !0, this.queryAttentionDiary());
                },
                diaryFocusEvent: function() {
                    this.getPetList(this.pageNo, this.keyWords);
                },
                videoFullScreen: function(e) {
                    this.$invoke("priviewVideo", "show", e);
                },
                lookDiaryDetail: function(e) {
                    console.log("diaryId:" + e), this.isAuthorize && wx.getStorageSync("userPhone") ? this.$navigate("../pages/person/petDiaryDetail", {
                        diaryId: e
                    }) : this.$invoke("toast", "show", {
                        type: 3,
                        isAuthorize: !0
                    });
                },
                add: (R = $(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            this.$invoke("homeTab", "hide"), this.isAuthorize && wx.getStorageSync("userPhone") ? this.$invoke("publish", "show") : this.$invoke("toast", "show", {
                                type: 3,
                                isAuthorize: !0
                            });

                          case 2:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                })), function() {
                    return R.apply(this, arguments);
                }),
                searchEvent: function(e) {
                    this.keyWords = e, "0" == this.currentTab ? (this.pageNo = 1, this.list = [], wx.showLoading({
                        title: "正在搜索..."
                    }), "{}" == JSON.stringify(e) ? this.keySerach = !1 : this.keySerach = !0, this.getPetList(this.pageNo, this.keyWords)) : (this.diaryPageNo = 1, 
                    this.petDiaryList = [], wx.showLoading({
                        title: "正在搜索..."
                    }), this.filterDiaryList());
                },
                resetEvent: function(e) {
                    this.keyWords = e;
                },
                eventOnShow: function() {
                    this.onShow();
                },
                saveUserInfo: (D = $(regeneratorRuntime.mark(function e(t) {
                    var i, r, s, a, o, u, c, h, p, d, l;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return v.isAuthorize = !0, i = {
                                userId: v.user.openid
                            }, e.next = 4, (0, x.queryIfExists)(i);

                          case 4:
                            if (r = e.sent, s = wx.getStorageSync("userPhone"), 1 != r.data.num) {
                                e.next = 18;
                                break;
                            }
                            return a = {
                                userId: v.user.openid,
                                nickName: t.nickName,
                                headPhoto: t.avatarUrl
                            }, e.next = 10, (0, x.updateOwnerinfo)(a);

                          case 10:
                            o = e.sent, wx.getSystemInfo({
                                success: function() {
                                    var e = $(regeneratorRuntime.mark(function e(t) {
                                        var n;
                                        return regeneratorRuntime.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return n = {
                                                    userId: v.user.openid,
                                                    hardwareInfo: JSON.stringify(t)
                                                }, e.next = 3, (0, x.addHardwareInfo)(n);

                                              case 3:
                                                e.sent;

                                              case 4:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e, U);
                                    }));
                                    return function(t) {
                                        return e.apply(this, arguments);
                                    };
                                }(),
                                fail: function(e) {}
                            }), "100030" == o.resultCode && (v.$invoke("toast", "show", {
                                type: 9,
                                isAuthorize: !1
                            }), t.avatarUrl = v.httpImg + "touxiang.png", wx.setStorageSync("wxUserData", t)), 
                            !t.isFirst || s || t.userPhoneMsg || v.$invoke("toast", "show", {
                                type: 3,
                                isAuthorize: !1
                            }), v.initData(!0), v.refrshUserInfo(), e.next = 29;
                            break;

                          case 18:
                            if (0 != r.data.num) {
                                e.next = 29;
                                break;
                            }
                            return u = v.recommendUserId, c = "1" == v.option.formType ? 1 : 0, h = {
                                userId: v.user.openid,
                                nickName: t.nickName,
                                name: "",
                                sex: t.gender,
                                wechatCode: "",
                                mobile: "",
                                idCard: "",
                                headPhoto: t.avatarUrl,
                                remark: "",
                                channel: c
                            }, u && (h.recommendUserId = u), e.next = 25, (0, x.setUserInfo)(h);

                          case 25:
                            (p = e.sent) && (wx.getSystemInfo({
                                success: function() {
                                    var e = $(regeneratorRuntime.mark(function e(t) {
                                        var n;
                                        return regeneratorRuntime.wrap(function(e) {
                                            for (;;) switch (e.prev = e.next) {
                                              case 0:
                                                return n = {
                                                    userId: v.user.openid,
                                                    hardwareInfo: JSON.stringify(t)
                                                }, e.next = 3, (0, x.addHardwareInfo)(n);

                                              case 3:
                                                e.sent;

                                              case 4:
                                              case "end":
                                                return e.stop();
                                            }
                                        }, e, U);
                                    }));
                                    return function(t) {
                                        return e.apply(this, arguments);
                                    };
                                }(),
                                fail: function(e) {}
                            }), "100030" == p.resultCode && (v.$invoke("toast", "show", {
                                type: 9,
                                isAuthorize: !1
                            }), t.avatarUrl = v.httpImg + "touxiang.png", wx.setStorageSync("wxUserData", t)), 
                            !t.isFirst || s || t.userPhoneMsg || v.$invoke("toast", "show", {
                                type: 3,
                                isAuthorize: !1
                            }), v.initData(!0), v.refrshUserInfo()), v.isFirstUse = !0, v.$apply();

                          case 29:
                            if (!t.userPhoneMsg || s) {
                                e.next = 34;
                                break;
                            }
                            return e.next = 32, (0, x.authorization)(t.userPhoneMsg);

                          case 32:
                            e.sent.data.flag && (wx.setStorageSync("userPhone", !0), d = n.default.getLaunchOptionsSync(), 
                            console.log("场景值：" + d.scene), 1069 == d.scene && "1" == v.option.formType && v.$invoke("toast", "show", {
                                type: 16
                            }));

                          case 34:
                            return l = {
                                userId: v.user.openid
                            }, e.next = 37, (0, x.analysisUnionId)(l);

                          case 37:
                            e.sent, v.onShow();

                          case 39:
                          case "end":
                            return e.stop();
                        }
                    }, e, U);
                })), function(e) {
                    return D.apply(this, arguments);
                }),
                guideFinish: function() {
                    this.isFirstUse && this.$invoke("toast", "show", {
                        type: 0,
                        isAuthorize: !1
                    }), this.initData(!1);
                },
                publishCardEvent: function() {
                    this.$navigate("../pages/person/addPetCard");
                },
                publishDiaryEvent: function() {
                    if (this.cards.length > 0) if (1 == this.cards.length) {
                        var e = JSON.stringify(this.cards);
                        this.$navigate("../pages/daily/writedaliy", {
                            index: 0,
                            cards: encodeURIComponent(e)
                        });
                    } else this.$invoke("publishDiary", "show", {
                        cards: this.cards
                    }); else this.$invoke("toast", "show", {
                        type: 6
                    });
                },
                selectPetEvent: function(e) {
                    var t = JSON.stringify(this.cards);
                    this.$navigate("../pages/daily/writedaliy", {
                        index: e,
                        cards: encodeURIComponent(t)
                    });
                },
                selectcityshow: function() {
                    this.$invoke("citys", "show", this.cityList, this.petCity.provinceId, this.petCity.cityId);
                },
                selectCity: function(e) {
                    this.petCity = e, this.$invoke("search", "cityCallback", e);
                },
                leftEvent: (S = $(regeneratorRuntime.mark(function e(t) {
                    var n, i, r;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (wx.getStorageSync("hasGuide") || "1" != this.option.formType || (this.$invoke("newGuide", "show"), 
                            this.currentTab = "0"), !t.isSysMsg) {
                                e.next = 12;
                                break;
                            }
                            return n = this.unreadSysMsgList[0].messageId, this.unreadSysMsgList.splice(0, 1), 
                            (i = []).push(n), r = {
                                messageId: i,
                                skip: "1",
                                ownerId: this.user.openid,
                                type: 1
                            }, e.next = 10, (0, x.messagePushRead)(r);

                          case 10:
                            e.sent.data && this.unreadSysMsgList.length > 0 && (this.$invoke("toast", "show", {
                                type: 8,
                                content: this.unreadSysMsgList[0].content,
                                obj: {
                                    isSysMsg: !0
                                }
                            }), this.$apply());

                          case 12:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                })), function(e) {
                    return S.apply(this, arguments);
                }),
                cancleAuthorize: function() {
                    this.isAuthorize = !1, this.initData(!1);
                },
                rightEvent: (b = $(regeneratorRuntime.mark(function e(t) {
                    var n, i, r;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (!t.isSysMsg) {
                                e.next = 11;
                                break;
                            }
                            return n = this.unreadSysMsgList[0].messageId, (i = []).push(n), r = {
                                messageId: i,
                                ownerId: this.user.openid,
                                type: 1
                            }, e.next = 7, (0, x.messagePushRead)(r);

                          case 7:
                            e.sent.data && this.$navigate("../pages/message/notice", {
                                messageId: n
                            }), e.next = 12;
                            break;

                          case 11:
                            this.$navigate("../pages/person/addPetCard");

                          case 12:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                })), function(e) {
                    return b.apply(this, arguments);
                }),
                toHome: function() {
                    this.keyWords = {}, this.keySerach = !1, this.showCanningImg = !0, n.default.pageScrollTo({
                        scrollTop: 0,
                        duration: 300,
                        success: function() {
                            n.default.startPullDownRefresh();
                        }
                    });
                },
                toMine: function() {
                    this.isAuthorize && wx.getStorageSync("userPhone") ? (this.$invoke("indexFooter", "setPageIndex", "1"), 
                    this.showCanningImg = !1) : this.$invoke("toast", "show", {
                        type: 3,
                        isAuthorize: !0
                    });
                },
                toHomeUnUpdata: function() {
                    this.swiperScroll = !1, this.showCanningImg = !0;
                },
                priviewVideoScreenChange: function(e) {
                    console.log("fullScreen"), console.log(e.detail), e.detail.fullScreen ? this.isVideoFullScreen = !0 : this.isVideoFullScreen = !1;
                },
                toastConfirm: function(e) {
                    10 == e && this.confrimUnReadNoPassMessage();
                }
            }, P(v, t);
        }
        var b, D, R, L, M, A, T, C, U, q, z, O, j, F, W, _, E;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(i, e), t(i, [ {
            key: "onShareAppMessage",
            value: function(e) {
                if ("button" == e.from) {
                    var t = e.target.id, n = this.petDiaryList[t];
                    return {
                        title: "快来看！我分享了" + n.petName + "的宠宠日记！",
                        path: "pages/person/petDiaryDetail?diaryId=" + n.diaryId + "&isShare=1",
                        imageUrl: n.photoList[0],
                        success: function(e) {},
                        fail: function(e) {},
                        complete: function(e) {}
                    };
                }
            }
        }, {
            key: "queryAllDiary",
            value: (E = $(regeneratorRuntime.mark(function e() {
                var t, n, i, r, s, a, o, u = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = {
                            ownerId: this.user.openid,
                            pageNo: this.diaryPageNo,
                            pageSize: this.pageSize,
                            queryFlag: "2"
                        }, e.next = 3, (0, x.queryDiary)(t);

                      case 3:
                        if (n = e.sent, i = n.data, console.log(i, 12), wx.hideLoading(), 0 == i.length && 1 == this.diaryPageNo ? this.canSearchDiary = !1 : this.canSearchDiary = !0, 
                        0 != i.length || 1 == this.diaryPageNo) {
                            e.next = 12;
                            break;
                        }
                        return this.hasMoreDiary = !1, this.$apply(), e.abrupt("return");

                      case 12:
                        for (r in i) for (a in s = i[r].commentInfo.comments) o = s[a].content, i[r].commentInfo.comments[a].content = (0, 
                        S.getDecodeStrData)(o);
                        1 == this.diaryPageNo ? (this.petDiaryList = i, setTimeout(function() {
                            u.diaryScrollTop = 0, u.$apply();
                        }, 1e3)) : this.petDiaryList = this.petDiaryList.concat(i), this.isLoading = "false", 
                        this.$apply();

                      case 16:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return E.apply(this, arguments);
            })
        }, {
            key: "queryAttentionDiary",
            value: (_ = $(regeneratorRuntime.mark(function e() {
                var t, n, i, r, s, a, o, u = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = {
                            ownerId: this.user.openid,
                            pageNo: this.diaryPageNo,
                            pageSize: this.pageSize,
                            queryFlag: "1"
                        }, e.next = 3, (0, x.queryDiary)(t);

                      case 3:
                        if (n = e.sent, i = n.data, wx.hideLoading(), 0 == i.length && 1 == this.diaryPageNo ? this.canSearchDiary = !1 : this.canSearchDiary = !0, 
                        0 != i.length || 1 == this.diaryPageNo) {
                            e.next = 11;
                            break;
                        }
                        return this.hasMoreDiary = !1, this.$apply(), e.abrupt("return");

                      case 11:
                        for (r in i) for (a in s = i[r].commentInfo.comments) o = s[a].content, i[r].commentInfo.comments[a].content = (0, 
                        S.getDecodeStrData)(o);
                        1 == this.diaryPageNo ? (this.petDiaryList = i, setTimeout(function() {
                            u.diaryScrollTop = 0, u.$apply();
                        }, 1e3)) : this.petDiaryList = this.petDiaryList.concat(i), this.$apply();

                      case 14:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return _.apply(this, arguments);
            })
        }, {
            key: "refrshUserInfo",
            value: function() {
                var e = wx.getStorageSync("wxUserData");
                this.nickname = e.nickName, this.headicon = e.avatarUrl, this.$apply();
            }
        }, {
            key: "filterDiaryList",
            value: (W = $(regeneratorRuntime.mark(function e() {
                var t, n, i, r, s, a, o, u, c, h = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        for (i in t = this.isQueryAllDiary ? 0 : 1, n = {
                            pageNo: this.diaryPageNo,
                            pageSize: this.pageSize,
                            ownerId: this.user.openid,
                            diaryQueryType: t
                        }, this.keyWords) n[i] = this.keyWords[i];
                        return e.next = 5, (0, x.filterDiary)(n);

                      case 5:
                        if (r = e.sent, s = r.data, wx.hideLoading(), 0 == s.length && 1 == this.diaryPageNo ? this.canSearchDiary = !1 : this.canSearchDiary = !0, 
                        0 != s.length || 1 == this.diaryPageNo) {
                            e.next = 13;
                            break;
                        }
                        return this.hasMoreDiary = !1, this.$apply(), e.abrupt("return");

                      case 13:
                        for (a in s) for (u in o = s[a].commentInfo.comments) c = o[u].content, s[a].commentInfo.comments[u].content = (0, 
                        S.getDecodeStrData)(c);
                        1 == this.diaryPageNo ? (this.petDiaryList = s, setTimeout(function() {
                            h.diaryScrollTop = 0, h.$apply();
                        }, 1e3)) : this.petDiaryList = this.petDiaryList.concat(s), this.$apply();

                      case 16:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return W.apply(this, arguments);
            })
        }, {
            key: "queryUnreadSysMsgs",
            value: (F = $(regeneratorRuntime.mark(function e() {
                var t, n;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = {
                            ownerId: this.user.openid
                        }, e.next = 3, (0, x.queryUnreadSysMesgList)(t);

                      case 3:
                        n = e.sent, this.unreadSysMsgList = n.data, this.unreadSysMsgList.length > 0 && this.$invoke("toast", "show", {
                            type: 8,
                            content: this.unreadSysMsgList[0].content,
                            obj: {
                                isSysMsg: !0
                            }
                        }), this.$apply();

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return F.apply(this, arguments);
            })
        }, {
            key: "queryUnReadNoPassMessage",
            value: (j = $(regeneratorRuntime.mark(function e() {
                var t, n;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = {
                            ownerId: this.user.openid
                        }, e.next = 3, (0, x.queryUnReadNoPassMessage)(t);

                      case 3:
                        (n = e.sent).data && 1 == n.data.num && this.$invoke("toast", "show", {
                            type: 10,
                            isAuthorize: !1
                        });

                      case 5:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return j.apply(this, arguments);
            })
        }, {
            key: "confrimUnReadNoPassMessage",
            value: (O = $(regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = {
                            ownerId: this.user.openid
                        }, e.next = 3, (0, x.confrimUnReadNoPassMessage)(t);

                      case 3:
                        e.sent;

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return O.apply(this, arguments);
            })
        }, {
            key: "getTaskQuerySign",
            value: (z = $(regeneratorRuntime.mark(function e() {
                var t, n, i;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return n = {
                            ownerId: (t = this).user.openid
                        }, e.next = 4, (0, x.taskQuerySign)(n);

                      case 4:
                        i = e.sent, t.signData = i.data, t.signData.status = t.signData.signStatus, t.signData.cannel = t.signData.signCannel, 
                        t.$apply();

                      case 9:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return z.apply(this, arguments);
            })
        }, {
            key: "onReady",
            value: function() {
                this.height = wx.getSystemInfoSync().windowHeight * (750 / wx.getSystemInfoSync().windowWidth) - 100;
            }
        }, {
            key: "onReachBottom",
            value: function() {
                console.log(131321), 0 == this.currentTab ? this.methods.loadMorePetCard(this) : this.methods.bindLoadMoreDiary();
            }
        }, {
            key: "onPullDownRefresh",
            value: (q = $(regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (0 != (t = this).currentTab) {
                            e.next = 6;
                            break;
                        }
                        return e.next = 4, t.methods.updatePetCard();

                      case 4:
                        e.next = 8;
                        break;

                      case 6:
                        return e.next = 8, t.methods.updateDiary();

                      case 8:
                        return e.next = 10, t.getShufflingPicture();

                      case 10:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return q.apply(this, arguments);
            })
        }, {
            key: "onShow",
            value: (U = $(regeneratorRuntime.mark(function e() {
                var t, n, i, r, s, a, o;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (this.user.openid) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        if (this.getBasicInformation(), wx.hideShareMenu(), !(t = wx.getStorageSync("isAuthorize"))) {
                            e.next = 9;
                            break;
                        }
                        this.isAuthorize = t, e.next = 13;
                        break;

                      case 9:
                        return e.next = 11, this.checkAuth();

                      case 11:
                        n = e.sent, this.isAuthorize = n;

                      case 13:
                        if (!this.isAuthorize || !wx.getStorageSync("userPhone")) {
                            e.next = 20;
                            break;
                        }
                        return i = {
                            ownerId: this.user.openid
                        }, e.next = 17, (0, x.queryConfirmRead)(i);

                      case 17:
                        1 == e.sent.data.num ? this.isNewMsg = !0 : this.isNewMsg = !1, this.$apply();

                      case 20:
                        if (this.getMassage(), this.getTaskQuerySign(), r = getCurrentPages(), (s = r[r.length - 1]).data.isPublishPetCard && (r[r.length - 1].data.isPublishPetCard = !1, 
                        this.currentTab = "0", this.petCardSort = 0, this.pageNo = 1, this.keyWords = {}, 
                        this.hasMoreData = !0, this.$invoke("homeTab", "setCurrentCardContent", "最新")), 
                        console.log(s, s.data.update), !s.data.update) {
                            e.next = 36;
                            break;
                        }
                        if (r[r.length - 1].data.update = !1, this.updatePetCards(), !(Object.keys(this.user).length > 0)) {
                            e.next = 36;
                            break;
                        }
                        return a = {
                            ownerId: this.user.openid
                        }, e.next = 33, (0, x.minepageinfo)(a);

                      case 33:
                        (o = e.sent).data && (this.foucus = o.data.myFocusNum, this.cannelNum = o.data.cannelNum, 
                        this.cards = o.data.cardList), this.$apply();

                      case 36:
                        s.data.isUpdateDiary && (r[r.length - 1].data.isUpdateDiary = !1, this.methods.updateDiary()), 
                        s.data.isPublishDiary && (r[r.length - 1].data.isPublishDiary = !1, this.currentTab = "1", 
                        this.$invoke("homeTab", "setCurrentDiaryContent", "全部"), this.queryAllDiary());

                      case 38:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return U.apply(this, arguments);
            })
        }, {
            key: "getOwnerinfo",
            value: (C = $(regeneratorRuntime.mark(function e() {
                var t, n, i;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (0 !== Object.keys(this.user).length) {
                            e.next = 2;
                            break;
                        }
                        return e.abrupt("return");

                      case 2:
                        return t = {
                            ownerId: this.user.openid
                        }, e.next = 5, (0, x.minepageinfo)(t);

                      case 5:
                        (n = e.sent).data && Object.keys(n.data).length > 0 && (this.foucus = n.data.myFocusNum, 
                        this.cards = n.data.cardList), i = wx.getStorageSync("wxUserData"), this.nickname = i.nickName, 
                        this.cannelNum = n.data.cannelNum, this.headicon = i.avatarUrl, this.$apply();

                      case 12:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return C.apply(this, arguments);
            })
        }, {
            key: "getMassage",
            value: (T = $(regeneratorRuntime.mark(function e() {
                var t, n;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (!(Object.keys(this.user).length > 0)) {
                            e.next = 7;
                            break;
                        }
                        return t = {
                            ownerId: this.user.openid
                        }, e.next = 4, (0, x.directMessages)(t);

                      case 4:
                        (n = e.sent).data && (this.message = n.data.num), this.$apply();

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return T.apply(this, arguments);
            })
        }, {
            key: "getPetList",
            value: (A = $(regeneratorRuntime.mark(function e(t, n) {
                var i, r, s, a, o, u, c, h, p, d, l, g, f;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        for (r in i = {
                            pageNo: t,
                            pageSize: this.pageSize,
                            ownerId: this.user.openid,
                            sort: this.petCardSort
                        }, n) i[r] = n[r];
                        return e.next = 4, (0, x.queryList)(i);

                      case 4:
                        if (s = e.sent, wx.hideLoading(), !s) {
                            e.next = 62;
                            break;
                        }
                        if (null != (s = s.data) || 1 == t) {
                            e.next = 12;
                            break;
                        }
                        return this.hasMoreData = !1, this.$apply(), e.abrupt("return");

                      case 12:
                        if (s) {
                            e.next = 16;
                            break;
                        }
                        return this.list = [], this.$apply(), e.abrupt("return");

                      case 16:
                        if (0 != s.length || 1 == t) {
                            e.next = 20;
                            break;
                        }
                        return this.hasMoreData = !1, this.$apply(), e.abrupt("return");

                      case 20:
                        1 == this.pageNo && (this.list = []), a = 0;

                      case 22:
                        if (!(a < s.length)) {
                            e.next = 58;
                            break;
                        }
                        s[a].petSex = "0" == s[a].petSex ? "公" : "母", s[a].isFocus = "1" == s[a].isFocus, 
                        o = 0, u = "", c = 0;

                      case 28:
                        if (!(c < s[a].petNickName.length)) {
                            e.next = 38;
                            break;
                        }
                        if (h = s[a].petNickName.charAt(c), /^[\u0000-\u00ff]$/.test(h) ? o += 1 : o += 2, 
                        u += h, !(o > 10)) {
                            e.next = 35;
                            break;
                        }
                        return s[a].petNickName = u.substr(0, u.length - 1) + "..", e.abrupt("break", 38);

                      case 35:
                        c++, e.next = 28;
                        break;

                      case 38:
                        if (!s[a].ownerNickName || "null" == s[a].ownerNickName) {
                            e.next = 54;
                            break;
                        }
                        p = 0, d = "", l = s[a].ownerNickName.length, g = 0;

                      case 43:
                        if (!(g < l)) {
                            e.next = 54;
                            break;
                        }
                        if (f = s[a].ownerNickName.charAt(g), /^[\u0000-\u00ff]$/.test(f) ? p += 1 : p += 2, 
                        d += f, 10 == p && (s[a].ownerNickName = d.substr(0, d.length - 1)), !(p > 10)) {
                            e.next = 51;
                            break;
                        }
                        return s[a].ownerNickName = d.substr(0, d.length - 1) + "..", e.abrupt("break", 54);

                      case 51:
                        g++, e.next = 43;
                        break;

                      case 54:
                        this.list.push({
                            pet: {
                                headImg: s[a].photo1,
                                smallImg: s[a].petKindIcon,
                                name: s[a].petNickName,
                                sex: s[a].petSex,
                                addr: s[a].cityName,
                                age: s[a].petAge
                            },
                            person: {
                                headImg: s[a].ownerHeadPhoto,
                                name: s[a].ownerNickName
                            },
                            isAttention: s[a].isFocus,
                            tinNum: s[a].cannedNum,
                            isSentTin: s[a].cannedStatus,
                            tinImg: "img/black_tin.png",
                            petId: s[a].petId,
                            ownerId: s[a].ownerId,
                            isOwner: s[a].isOwner
                        });

                      case 55:
                        a++, e.next = 22;
                        break;

                      case 58:
                        s.length < this.pageSize && (this.hasMoreData = !1), wx.getStorageSync("hasGuide") || "1" == this.option.formType || (this.$invoke("newGuide", "show"), 
                        this.currentTab = "0"), this.$apply();

                      case 62:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function(e, t) {
                return A.apply(this, arguments);
            })
        }, {
            key: "updatePetCards",
            value: function() {
                wx.showLoading({
                    title: "刷新中..."
                }), this.pageNo = 1, this.hasMoreData = !0, this.getPetList(this.pageNo, this.keyWords);
            }
        }, {
            key: "initData",
            value: (M = $(regeneratorRuntime.mark(function e(t) {
                var n;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (this.getPetList(1, this.keyWords), this.queryAllDiary(), Object.keys(this.option).length > 0 && (1 == this.option.type ? this.$navigate("/pages/daily/topic") : 2 != this.option.type && 3 != this.option.type || (n = {
                            type: this.option.type,
                            tab: this.option.tab
                        }, this.option.trickId ? n.trickId = this.option.trickId : this.option.questionId && (n.questionId = this.option.questionId), 
                        this.$navigate("../pages/info/petEncyclopedia", n))), wx.getStorageSync("hasGuide") && (this.queryUnreadSysMsgs(), 
                        this.queryUnReadNoPassMessage()), t) {
                            e.next = 7;
                            break;
                        }
                        return e.abrupt("return");

                      case 7:
                        this.connctWebScoket(), this.sendWebsocketMsg();

                      case 9:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function(e) {
                return M.apply(this, arguments);
            })
        }, {
            key: "connctWebScoket",
            value: function() {
                var e = this;
                0 !== Object.keys(this.user).length && (wx.connectSocket({
                    url: v.default.WEB_SOCKET_URL + this.user.openid,
                    success: function(e) {},
                    fail: function(e) {
                        wx.showToast({
                            title: "网络异常！"
                        });
                    }
                }), wx.onSocketOpen(function() {
                    e.isSocketOpen = !0;
                }), wx.onSocketError(function(t) {
                    console.log("WebSocket连接打开失败，请检查！"), e.isSocketOpen = !1;
                }), wx.onSocketClose(function(t) {
                    console.log("WebSocket断开！"), e.isSocketOpen = !1;
                }), wx.onSocketMessage(function(t) {
                    console.log(t), "0" != t.data && ("1" == t.data ? e.isNewMsg = !0 : "2" == t.data ? e.queryUnreadSysMsgs() : "3" == t.data ? e.$invoke("toast", "show", {
                        type: 10,
                        isAuthorize: !1
                    }) : e.isNewMsg = !1, e.$apply());
                }));
            }
        }, {
            key: "sendWebsocketMsg",
            value: function() {
                var e = this;
                this.timer = setInterval(function() {
                    e.isSocketOpen ? wx.sendSocketMessage({
                        data: "1"
                    }) : e.connctWebScoket();
                }, 3e4);
            }
        }, {
            key: "checkAuth",
            value: (L = $(regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (t = wx.getStorageSync("userPhone"), !wx.getStorageSync("isAuthorize") || !t) {
                            e.next = 5;
                            break;
                        }
                        return e.abrupt("return", !0);

                      case 5:
                        return e.abrupt("return", !1);

                      case 6:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return L.apply(this, arguments);
            })
        }, {
            key: "getShufflingPicture",
            value: (R = $(regeneratorRuntime.mark(function e() {
                var t, i, r;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return t = this, i = {
                            category: 1,
                            channel: 2
                        }, e.next = 4, (0, x.shufflingPictureQuery)(i);

                      case 4:
                        (r = e.sent).data && (console.log(r.data, 4545), t.swiperList = r.data), n.default.stopPullDownRefresh();

                      case 7:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function() {
                return R.apply(this, arguments);
            })
        }, {
            key: "getBasicInformation",
            value: (D = $(regeneratorRuntime.mark(function e(t) {
                var i, r, s, a, o;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, n.default.login();

                      case 2:
                        return i = e.sent, r = {
                            code: i.code
                        }, e.next = 6, (0, x.getOpenId)(r);

                      case 6:
                        if ((s = e.sent).data) {
                            for (o in n.default.$store.dispatch({
                                type: "USER_SIGNIN",
                                payload: {
                                    openid: s.data.openid,
                                    token: s.data.token
                                }
                            }), wx.setStorageSync("userPhone", s.data.flag), a = s.data) "" === a[o] && delete a[o];
                            a.avatarUrl = a.headPhoto, a.gender = a.sex, wx.setStorageSync("newUserInfo", a), 
                            this.nickname = a.nickName, this.headicon = a.avatarUrl, this.$apply(), "relogin" == t && (this.onLoad(this.option), 
                            this.refrshUserInfo());
                        }

                      case 8:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function(e) {
                return D.apply(this, arguments);
            })
        }, {
            key: "onUnload",
            value: function() {
                clearInterval(this.timer);
            }
        }, {
            key: "onLoad",
            value: (b = $(regeneratorRuntime.mark(function e(t) {
                var n, i, r, s, a;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        if (this.option = t, this.currentTab = "0" === t.currentTab ? "0" : "1", this.recommendUserId = t.recommendUserId ? t.recommendUserId : "", 
                        this.$apply(), this.user.openid) {
                            e.next = 9;
                            break;
                        }
                        return this.getBasicInformation("relogin"), e.abrupt("return");

                      case 9:
                        this.getBasicInformation();

                      case 10:
                        return this.getShufflingPicture(), n = {}, e.next = 14, (0, x.queryAllCity)(n);

                      case 14:
                        i = e.sent, this.cityList = i.data, wx.setStorageSync("cityList", this.cityList), 
                        r = {
                            userInfo: {}
                        }, s = wx.getStorageSync("userPhone"), wx.getStorageSync("isAuthorize") && s ? (a = wx.getStorageSync("newUserInfo"), 
                        r.userInfo = Object.assign(r.userInfo, a), wx.setStorageSync("wxUserData", r.userInfo), 
                        console.log(r.userInfo), 1 == t.fromType && (r.userInfo.isFirst = !0), this.getOwnerinfo(), 
                        this.events.saveUserInfo(r.userInfo)) : (this.isLoading = "false", this.isAuthorize = !1, 
                        this.initData(!1), this.$apply(), console.log(t, 46541345), "1" == t.formType && this.$invoke("toast", "show", {
                            type: 3,
                            isAuthorize: !0,
                            isFirst: !0
                        }));

                      case 20:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            })), function(e) {
                return b.apply(this, arguments);
            })
        } ]), i;
    }(n.default.page)) || e;
    Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(L, "main/index"));
}();
Page({
    data: {
        brandInfo: {},
        newsList: [],
        brandList: [],
        currentTab: 0
    },
    clickTab: function(t) {
        var a = this;
        if (this.data.currentTab === t.target.dataset.current) return !1;
        a.setData({
            currentTab: t.target.dataset.current
        });
    },
    showRule: function() {
        this.setData({
            isRuleTrue: !0
        });
    },
    hideRule: function() {
        this.setData({
            isRuleTrue: !1
        });
    },
    onLoad: function(t) {
        var a = this;
        wx.getSystemInfo({
            success: function(t) {
                a.setData({
                    pixelRatio: t.pixelRatio,
                    windowHeight: t.windowHeight,
                    windowWidth: t.windowWidth
                });
            }
        });
        var e = require("../../log.js");
        if (t.q) {
            e.info(t.q);
            var n = decodeURIComponent(t.q);
            console.log(n);
            var i = n.split("=");
            if (i.length >= 2) {
                var o = i[1].split("_");
                t.loginName = o[1], t.industryCode = o[2];
            }
        }
        e.info(t.loginName), e.info(t.industryCode);
        var s = this;
        wx.request({
            url: getApp().globalData.base58Url + "/wx/brandDetail.html",
            method: "GET",
            dataType: "json",
            data: {
                loginName: t.loginName,
                industryCode: t.industryCode
            },
            header: {
                "content-type": "application/json"
            },
            success: function(t) {
                s.setData({
                    brandInfo: t.data.result.wxBrand,
                    newsList: t.data.result.newsList,
                    brandList: t.data.result.brandList
                });
                var a = t.data.result.wxBrand.brandName;
                wx.setNavigationBarTitle({
                    title: a + "_中国餐饮网"
                });
            },
            fail: function(t) {
                wx.showToast({
                    title: "数据异常!",
                    icon: "loading",
                    duration: 1500
                });
            }
        });
    },
    switchNav: function(t) {
        var a = t.currentTarget.dataset.current, e = this.data.windowWidth / 5;
        if (this.setData({
            navScrollLeft: (a - 2) * e
        }), this.data.currentNavTab == a) return !1;
        this.setData({
            currentNavTab: a
        });
    },
    layoutScroll: function(t) {
        -t.detail.scrollTop <= -370 ? this.setData({
            navFixed: !0
        }) : this.setData({
            navFixed: !1
        });
    },
    msgSubmitHandle: function(t) {
        var a = this;
        0 == t.detail.value.phone.length ? (wx.showToast({
            title: "请填写手机号码!",
            icon: "none",
            duration: 1e3
        }), setTimeout(function() {
            wx.hideToast();
        }, 2e3)) : /^1[3456789]\d{9}$/.test(t.detail.value.phone) ? wx.request({
            url: getApp().globalData.base58Url + "/wx/brandMsgSubmit.html",
            method: "POST",
            dataType: "json",
            data: {
                loginName: a.data.brandInfo.loginName,
                phone: t.detail.value.phone,
                userName: t.detail.value.userName,
                content: t.detail.value.content
            },
            header: {
                "content-type": "application/json"
            },
            success: function(t) {
                "留言成功" == t.data.message ? wx.showToast({
                    title: "留言成功",
                    icon: "success",
                    duration: 1500
                }) : wx.showToast({
                    title: t.data.message,
                    icon: "loading",
                    duration: 1500
                });
            },
            fail: function(t) {
                wx.showToast({
                    title: "服务连接失败!",
                    icon: "none",
                    duration: 1500
                });
            },
            complete: function() {
                a.setData({
                    isRuleTrue: !1
                });
            }
        }) : (wx.showToast({
            title: "请填写正确的手机号码!",
            icon: "none",
            duration: 1e3
        }), setTimeout(function() {
            wx.hideToast();
        }, 2e3));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});
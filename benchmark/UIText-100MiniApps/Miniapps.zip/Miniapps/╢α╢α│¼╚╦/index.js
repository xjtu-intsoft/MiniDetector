var e = getApp(), t = !0, a = require("../../utils/mta_analysis.js");

Page({
    data: {
        profit_all: "--",
        profit_today: "--",
        profit_yesterday: "--",
        profit_this_month: "--",
        profit_last_month: "--",
        badge: !1,
        incomeDialog: !1,
        phoneDialog: !1,
        weappDialog: !1,
        weappType: 0,
        setViewInput: "",
        guide: !1,
        opacity: 0,
        top: "45%",
        tapNum: 0,
        finish: !1,
        restart: !1
    },
    onLoad: function(t) {
        a.Page.init();
        var i = e.getAppUserInfo();
        this.setData({
            userInfo: i
        }), this.setData({
            guideFlag: wx.getStorageSync("guide") || !1
        }), this.data.guideFlag || this.setData({
            guide: !0
        }), i.ukey && (this.getBanner(), this.getMyData());
    },
    onShow: function() {
        var a = e.getAppUserInfo();
        this.setData({
            incomeDialog: !1,
            phoneDialog: !1,
            weappDialog: !1
        }), a.ukey && this.data.restart ? (this.setData({
            userInfo: a,
            restart: !1
        }), this.getBanner(), this.getMyData()) : a.ukey && !t && "--" == this.data.profit_all ? (this.setData({
            userInfo: a
        }), this.getBanner(), this.getMyData()) : a.ukey && (this.setData({
            userInfo: a
        }), this.getBanner());
    },
    loginFinish: function() {
        var t = e.getAppUserInfo();
        t.ukey && (this.setData({
            userInfo: t
        }), this.getBanner(), this.getMyData());
    },
    moreTap: function() {
        var e = this.data.tapNum;
        e < 10 && (10 == ++e ? this.setData({
            tapNum: e
        }) : this.data.tapNum = e);
    },
    getBanner: function() {
        var e = void 0, t = void 0;
        (e = (t = wx.getStorageSync("baseInfo")) ? "string" == typeof t ? JSON.parse(t) : t : {}).banner && e.banner.user && this.setData({
            banner: e.banner.user
        });
    },
    getMyData: function() {
        wx.showLoading({
            title: "加载中..."
        });
        var a = this, i = e.getAppUserInfo();
        try {
            if (i.ukey) {
                if (0 == i.grade) wx.hideLoading(), wx.hideNavigationBarLoading(), wx.stopPullDownRefresh(); else if (i.ukey && i.grade > 0) {
                    var o = {
                        ukey: i.ukey
                    };
                    e.request("user_profit/get_profit_data_simple", "POST", o, function(e) {
                        if (e.data && "1" == e.data.success) try {
                            console.log(e.data.data);
                            var t = e.data.data, i = 1 == t.suggestion_tip, o = t.profit_all.toFixed(2), n = t.profit_today.toFixed(2), s = t.profit_yesterday.toFixed(2), r = t.profit_this_month.toFixed(2), g = t.profit_last_month.toFixed(2);
                            a.setData({
                                badge: i,
                                profit_all: o,
                                profit_today: n,
                                profit_yesterday: s,
                                profit_this_month: r,
                                profit_last_month: g
                            }), wx.hideLoading(), wx.hideNavigationBarLoading(), wx.stopPullDownRefresh();
                        } catch (e) {
                            wx.hideLoading(), wx.redirectTo({
                                url: "/pages/notFound/notFound"
                            });
                        }
                    });
                }
            } else t = !1, wx.hideLoading(), wx.hideNavigationBarLoading(), wx.stopPullDownRefresh(), 
            wx.showToast({
                title: "请登录然后进行操作",
                icon: "none",
                duration: 1e3
            }), setTimeout(function() {
                wx.switchTab({
                    url: "/pages/index/index"
                });
            }, 1100);
        } catch (e) {
            wx.hideLoading(), wx.redirectTo({
                url: "/pages/notFound/notFound"
            });
        }
    },
    closeGuide: function() {
        wx.setStorage({
            key: "guide",
            data: "1"
        }), this.setData({
            guide: !1
        });
    },
    copyID: function(e) {
        var t = e.currentTarget.dataset.text, a = String(t);
        wx.setClipboardData({
            data: a,
            success: function(e) {
                wx.showToast({
                    title: "ID已复制",
                    icon: "none",
                    duration: 1e3
                });
            }
        });
    },
    getPhoneNumber: function(t) {
        var a = this, i = t.detail.iv, o = t.detail.encryptedData, n = e.getAppUserInfo();
        if (i && o) try {
            n.ukey ? wx.login({
                success: function(t) {
                    var s = t.code, r = {
                        ukey: n.ukey,
                        code: s,
                        encryptedData: o,
                        iv: i
                    };
                    e.request("weapp/binding_phone", "POST", r, function(e) {
                        if (e.data && "1" == e.data.success) {
                            n.phone = !0;
                            var t = JSON.stringify(n);
                            wx.setStorage({
                                key: "userInfo",
                                data: t
                            });
                            var i = n.wechat ? 2 : 0;
                            a.setData({
                                userInfo: n,
                                weappType: i,
                                weappDialog: !0
                            }), a.setData({
                                opacity: 1,
                                top: "50%"
                            });
                        } else wx.showToast({
                            title: e.data.info,
                            icon: "none",
                            duration: 1e3
                        });
                    });
                }
            }) : wx.redirectTo({
                url: "/pages/notFound/notFound"
            });
        } catch (e) {
            wx.redirectTo({
                url: "/pages/notFound/notFound"
            });
        } else wx.showToast({
            title: "绑定手机失败",
            icon: "none",
            duration: 1e3
        });
    },
    changeIncomeDialog: function() {
        var e = this, t = this.data.incomeDialog, a = t ? 0 : 1, i = t ? "45%" : "50%";
        t ? (this.setData({
            opacity: a,
            top: i
        }), setTimeout(function() {
            e.setData({
                incomeDialog: !1
            });
        }, 400)) : (this.setData({
            incomeDialog: !0
        }), this.setData({
            opacity: a,
            top: i
        }));
    },
    changeWeappDialog: function() {
        var e = this, t = this.data.weappDialog, a = this.data.userInfo, i = t ? 0 : 1, o = t ? "45%" : "50%";
        if (t) this.setData({
            opacity: i,
            top: o
        }), setTimeout(function() {
            e.setData({
                setViewInput: "",
                weappDialog: !1
            });
        }, 400); else {
            var n = a.wechat ? 2 : 1;
            this.setData({
                weappType: n,
                weappDialog: !0
            }), this.setData({
                opacity: i,
                top: o
            });
        }
    },
    checkSet: function(e) {
        var t = e.detail.value;
        return this.data.setViewInput = t, t;
    },
    setWechat: function() {
        var t = this, a = this.data.userInfo, i = this.data.setViewInput;
        if (i) if (a.ukey) {
            var o = {
                ukey: a.ukey,
                wechat: i
            };
            e.request("user_myfans/set_wechat", "POST", o, function(e) {
                if (e.data && "1" == e.data.success) {
                    a.wechat = String(i);
                    var o = JSON.stringify(a);
                    wx.setStorage({
                        key: "userInfo",
                        data: o
                    }), wx.showToast({
                        title: "微信号设置成功",
                        icon: "none",
                        duration: 1500
                    });
                } else wx.showToast({
                    title: "设置失败（" + e.data.info + "）",
                    icon: "none",
                    duration: 1500
                });
                t.setData({
                    opacity: 0,
                    top: "45%"
                }), setTimeout(function() {
                    t.setData({
                        setViewInput: "",
                        weappDialog: !1
                    });
                }, 400);
            });
        } else wx.redirectTo({
            url: "/pages/notFound/notFound"
        }); else wx.showToast({
            title: "请填写微信号",
            icon: "none",
            duration: 1e3
        });
    },
    changePhoneDialog: function() {
        var e = this, t = this.data.phoneDialog, a = t ? 0 : 1, i = t ? "45%" : "50%";
        t ? (this.setData({
            opacity: a,
            top: i
        }), setTimeout(function() {
            e.setData({
                phoneDialog: !1
            });
        }, 400)) : (this.setData({
            phoneDialog: !0
        }), this.setData({
            opacity: a,
            top: i
        }));
    },
    goCash: function() {
        wx.navigateTo({
            url: "/pages/user/cash/index/index"
        });
    },
    goEarning: function() {
        wx.navigateTo({
            url: "/pages/user/earning/index"
        });
    },
    goOrder: function() {
        wx.navigateTo({
            url: "/pages/user/order/index"
        });
    },
    goOrderCP: function(e) {
        var t = e.currentTarget.id;
        wx.navigateTo({
            url: "/pages/user/order/index?filter=" + t
        });
    },
    goMyfans: function() {
        wx.navigateTo({
            url: "/pages/user/myfans/index"
        });
    },
    goInvite: function() {
        wx.navigateTo({
            url: "/pages/user/invite/index"
        });
    },
    goFavorites: function() {
        e.getAppUserInfo().ukey ? wx.navigateTo({
            url: "/pages/user/favorites/index"
        }) : this.goLogin();
    },
    goRanking: function() {
        var e = encodeURIComponent("https://user.duoduocr.com/#/rank");
        wx.navigateTo({
            url: "/pages/webView/webView?webUrl=" + e
        });
    },
    goYunYing: function() {
        wx.showToast({
            title: "即将开放 敬请期待！",
            icon: "none",
            duration: 2e3
        });
    },
    goExchange: function() {
        wx.navigateTo({
            url: "/pages/user/exchange/index"
        });
    },
    goSubsidy: function() {
        wx.navigateTo({
            url: "/pages/user/subsidy/index"
        });
    },
    goQuestion: function() {
        wx.navigateTo({
            url: "/pages/general/question/index"
        });
    },
    goNotice: function() {
        wx.navigateTo({
            url: "/pages/general/notice/index"
        });
    },
    goChudan: function() {
        wx.navigateTo({
            url: "/pages/user/chudan/index"
        });
    },
    goFeedback: function() {
        if (e.getAppUserInfo().ukey) {
            var t = this.data.badge ? 1 : 0;
            this.setData({
                badge: !1
            }), wx.navigateTo({
                url: "/pages/user/feedback/index?badge=" + t
            });
        } else this.goLogin();
    },
    goAbout: function() {
        wx.navigateTo({
            url: "/pages/general/about/index"
        });
    },
    goTo: function(t) {
        if (e.getAppUserInfo().ukey) {
            var a = t.currentTarget.dataset.text, i = void 0, o = void 0, n = void 0, s = void 0, r = void 0, g = void 0, u = void 0;
            a && ("web" === a.type ? (i = encodeURIComponent(a.key), wx.navigateTo({
                url: "/pages/webView/webView?webUrl=" + i
            })) : "goods" === a.type ? (o = a.key, wx.navigateTo({
                url: "/pages/items/detail/index?id=" + o
            })) : "search" === a.type ? (n = a.key, wx.navigateTo({
                url: "/pages/items/list/search/index?key=" + n
            })) : "pdd_theme" === a.type ? (o = a.key, s = a.name, r = a.image_url, wx.navigateTo({
                url: "/pages/items/list/theme/index?id=" + o + "&name=" + s + "&image_url=" + r
            })) : "page" === a.type ? "pages/index/index" === (g = a.key) || "pages/hot/index" === g || "pages/discover/index" === g || "pages/user/index" === g ? wx.switchTab({
                url: "/" + g
            }) : wx.navigateTo({
                url: "/" + g
            }) : "pdd_page" === a.type ? (u = a.key, this.goPddPage(u)) : "activity" === a.type && (o = a.key, 
            wx.navigateTo({
                url: "/pages/general/activity/index?id=" + o
            })));
        } else this.goLogin();
    },
    goPddPage: function(t) {
        var a = e.getAppUserInfo();
        if (a.ukey) {
            wx.showLoading();
            var i = {
                p_id: a.p_id || 0,
                type: t
            };
            e.request("tools/active_url_generate", "POST", i, function(e) {
                if (!e.data || "1" != e.data.success) return wx.hideLoading(), void wx.showToast({
                    title: e.data.info,
                    icon: "none",
                    duration: 2e3
                });
                var t = e.data.data.we_app_info;
                wx.hideLoading(), wx.navigateToMiniProgram({
                    appId: "wx32540bd863b27570",
                    path: t.page_path,
                    extraData: {},
                    envVersion: "release",
                    success: function(e) {
                        console.log("打开成功");
                    },
                    fail: function(e) {
                        console.log("打开失败");
                    }
                });
            });
        } else this.goLogin();
    },
    goLogin: function() {
        wx.navigateTo({
            url: "/pages/authorize/login/index"
        });
    },
    goBeinvite: function() {
        var e = void 0, t = void 0;
        (e = (t = wx.getStorageSync("userInfo")) ? "string" == typeof t ? JSON.parse(t) : t : {}).ukey ? wx.navigateTo({
            url: "/pages/general/beinvited/index?p_id=" + e.p_id + "&from_uid=" + e.from_uid
        }) : this.goLogin();
    },
    goUpdate: function() {
        e.getAppUserInfo().ukey ? wx.navigateTo({
            url: "/pages/user/update/index"
        }) : this.goLogin();
    },
    finishLoad: function() {
        this.setData({
            finish: !0
        });
    },
    onPullDownRefresh: function() {
        if (this.data.incomeDialog || this.data.phoneDialog || this.data.weappDialog) return wx.hideLoading(), 
        wx.hideNavigationBarLoading(), void wx.stopPullDownRefresh();
        wx.showNavigationBarLoading();
        var t = e.getAppUserInfo();
        t.ukey ? (this.setData({
            userInfo: t
        }), this.getBanner(), this.getMyData()) : (wx.hideNavigationBarLoading(), wx.stopPullDownRefresh());
    },
    cantMove: function() {
        return !1;
    }
});
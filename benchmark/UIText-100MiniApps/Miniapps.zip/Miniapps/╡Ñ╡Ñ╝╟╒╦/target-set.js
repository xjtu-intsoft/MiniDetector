function e(e, n, t) {
    return n in e ? Object.defineProperty(e, n, {
        value: t,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[n] = t, e;
}

var n = require("../../util");

Page({
    data: {
        endDate: "",
        money: null,
        startmoney: null,
        name: "",
        minEndDate: (0, n.parseTime)(new Date().getTime() + 1728e5, "{y}-{m}-{d}")
    },
    onLoad: function() {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    bindDateChange: function(e) {
        this.setData({
            endDate: e.detail.value
        });
    },
    onInput: function(n) {
        this.setData(e({}, "" + n.target.dataset.target, n.detail.value));
    },
    checkParams: function() {
        var e = this.data, n = e.name, t = e.startmoney, a = e.money, o = e.endDate, i = "";
        return n ? o ? t ? a ? Number(a) <= Number(t) && (i = "初始金额不能大于目标金额") : i = "要输入目标金额哦" : i = "要输入初始金额哦" : i = "选择目标的结束日吧" : i = "输入目标名", 
        !i || (wx.showToast({
            title: i,
            icon: "none"
        }), !1);
    },
    confirm: function() {
        var e = this.data, n = e.name, t = e.money, a = e.startmoney, o = e.endDate;
        this.checkParams() && wx.cloud.callFunction({
            name: "target",
            data: {
                mode: "add",
                startMoney: Number(String(a).replace(/\b(0+)/gi, "")),
                targetMoney: Number(String(t).replace(/\b(0+)/gi, "")),
                name: n,
                endDate: o
            },
            success: function(e) {
                1 === e.result.code && (wx.showToast({
                    title: "目标创建成功",
                    icon: "none"
                }), setTimeout(function() {
                    wx.navigateTo({
                        url: "/pages/target/target"
                    });
                }, 1500));
            },
            fail: function() {
                wx.showToast({
                    title: "目标创建失败，再试试？",
                    icon: "none"
                });
            },
            complete: function() {}
        });
    },
    onShareAppMessage: function() {}
});
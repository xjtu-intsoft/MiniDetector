var t = require("../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../@babel/runtime/helpers/defineProperty")), a = t(require("../../components/dialog/dialog")), n = require("../../services/bind"), o = t(require("../../utils/performance.js"));

(0, require("../../utils/ald-stat.js").Page)({
    data: {
        loadCaptcha: !1,
        gt: "",
        challenge: "",
        offline: "",
        styleConfig: {
            btnWidth: "686rpx"
        },
        btnStatus: 0,
        btnText: "获取验证码",
        phone: "",
        smsCode: "",
        showConflictModal: !1,
        conflictUserInfos: [],
        selectToken: "",
        backUrl: "",
        backDeptch: ""
    },
    onLoad: function(t) {
        o.default.start("bindPhone");
        var e = t.backUrl || "", a = t.backDeptch || "";
        e && this.setData({
            backUrl: e
        }), a && this.setData({
            backDeptch: a
        }), this.count = 59, this.smsSend = !1;
    },
    onReady: function() {
        o.default.send(1), o.default.send(2);
    },
    inputHandler: function(t) {
        var a = t.detail, n = (a = void 0 === a ? {} : a).value, o = t.target, i = (o = void 0 === o ? {} : o).dataset.type;
        n && this.setData((0, e.default)({}, i, n));
    },
    validatePhone: function(t) {
        return !!/^(0|86|17951)?(13[0-9]|15[012356789]|16[68]|17[0123678]|18[0-9]|19[89]|14[57])[0-9]{8}$/.test(t) || (wx.showToast({
            title: "请输入正确的手机号",
            icon: "none"
        }), !1);
    },
    countDown: function() {
        var t = this, e = this.count;
        this.count -= 1, this.timer = setTimeout(function() {
            if (e <= 0) return clearTimeout(t.timer), t.setData({
                btnText: "重新获取",
                btnStatus: 0
            }), void (t.count = 59);
            t.setData({
                btnText: "".concat(e, "s")
            }), t.countDown();
        }, 1e3);
    },
    sendCodeHandler: function() {
        var t = this, e = this.data, a = e.phone, o = e.btnStatus;
        this.smsSend || (this.smsSend = !0, this.validatePhone(a) && 0 === o && (0, n.sendValidateCode)({
            phone: a,
            bizType: "001",
            appId: "wx-babytree-family"
        }).then(function(e) {
            t.smsSend = !1;
            var a = e.success, n = e.geeCode, o = void 0 === n ? {} : n, i = o.gt, s = void 0 === i ? "" : i, c = o.challenge, l = void 0 === c ? "" : c;
            l ? t.setData({
                loadCaptcha: !0,
                gt: s,
                challenge: l,
                offline: !a
            }) : (wx.showToast({
                title: "发送成功",
                icon: "none"
            }), t.setData({
                btnText: "60s",
                btnStatus: 1
            }, function() {
                t.countDown();
            }));
        }).catch(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = e.message, n = void 0 === a ? "发送验证码失败" : a;
            t.smsSend = !1, wx.showToast({
                title: n,
                icon: "none"
            });
        }));
    },
    geetSuccess: function(t) {
        var e = this, a = t.detail;
        if (a && a.geetest_challenge) {
            var o = this.data.phone, i = a.geetest_challenge, s = a.geetest_validate, c = a.geetest_seccode;
            (0, n.validateGeetest)({
                phone: o,
                appId: "wx-babytree-family",
                bizType: "001",
                challenge: i,
                validate: s,
                seccode: c
            }).then(function(t) {
                e.setData({
                    loadCaptcha: !1
                }, function() {
                    e.sendCodeHandler();
                });
            }).catch(function(t) {
                var e = t.message, a = void 0 === e ? "验证失败" : e;
                wx.showToast({
                    title: a,
                    icon: "none"
                });
            });
        }
    },
    geetClose: function() {
        console.log("GeetClose");
    },
    geetError: function(t) {
        console.log("GeetError:", t);
    },
    formSubmitHandler: function() {
        var t = this, e = this.data, o = e.phone, i = e.smsCode, s = e.loadCaptcha;
        if (this.validatePhone(o)) return s ? wx.showToast({
            title: "请先完成校验",
            icon: "none"
        }) : void (0, n.bindPhone)({
            appId: "wx-babytree-family",
            bizType: "001",
            phone: o,
            smsCode: i
        }).then(function() {
            wx.showToast({
                title: "绑定成功",
                icon: "none"
            }), t.data.backUrl ? setTimeout(function() {
                wx.reLaunch({
                    url: t.data.backUrl
                });
            }, 1500) : t.data.backDeptch ? setTimeout(function() {
                wx.navigateBack({
                    delta: Number(t.data.backDeptch)
                });
            }, 1500) : setTimeout(function() {
                wx.navigateBack({
                    delta: 2
                });
            }, 1500);
        }).catch(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = e.code, o = e.message, i = e.data, s = void 0 === i ? [] : i;
            "00200011" === n ? t.setData({
                conflictUserInfos: s
            }, function() {
                a.default.alert({
                    message: o,
                    confirmButtonText: "更改绑定账号"
                }).then(function() {
                    t.setData({
                        showConflictModal: !0
                    });
                });
            }) : wx.showModal({
                content: o,
                showCancel: !1,
                success: function() {
                    var t = this;
                    /^00200015|00200013$/.test(n) && (this.data.backDeptch ? setTimeout(function() {
                        wx.navigateBack({
                            delta: Number(t.data.backDeptch)
                        });
                    }, 1500) : wx.navigateBack({
                        delta: 2
                    }));
                }
            });
        });
    },
    selectConflictAccount: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, e = t.currentTarget, a = void 0 === e ? {} : e, n = a.dataset, o = void 0 === n ? {} : n, i = o.item;
        this.setData({
            selectToken: i.token
        });
    },
    confirmConflictAccount: function() {
        var t = this, e = this.data.selectToken;
        e ? (0, n.confirmThirdAccount)({
            appId: "wx-babytree-family",
            token: e
        }).then(function() {
            var e = t;
            t.setData({
                showConflictModal: !1
            }), wx.showToast({
                title: "绑定成功",
                icon: "none",
                success: function() {
                    e.data.backUrl ? wx.reLaunch({
                        url: e.data.backUrl
                    }) : e.data.backDeptch ? setTimeout(function() {
                        wx.navigateBack({
                            delta: Number(e.data.backDeptch)
                        });
                    }, 1500) : wx.navigateBack();
                }
            });
        }).catch(function(e) {
            var a = e.message, n = void 0 === a ? "绑定失败" : a;
            t.setData({
                showConflictModal: !1
            }), wx.showModal({
                content: n,
                showCancel: !1
            });
        }) : wx.showToast({
            title: "请选择您想绑定的账号",
            icon: "none"
        });
    }
});
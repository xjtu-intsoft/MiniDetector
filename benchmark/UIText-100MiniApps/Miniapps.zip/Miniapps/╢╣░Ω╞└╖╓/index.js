Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _slicedToArray = function(t, a) {
    if (Array.isArray(t)) return t;
    if (Symbol.iterator in Object(t)) return function(t, a) {
        var e = [], n = !0, s = !1, o = void 0;
        try {
            for (var i, r = t[Symbol.iterator](); !(n = (i = r.next()).done) && (e.push(i.value), 
            !a || e.length !== a); n = !0) ;
        } catch (t) {
            s = !0, o = t;
        } finally {
            try {
                !n && r.return && r.return();
            } finally {
                if (s) throw o;
            }
        }
        return e;
    }(t, a);
    throw new TypeError("Invalid attempt to destructure non-iterable instance");
}, _extends = Object.assign || function(t) {
    for (var a = 1; a < arguments.length; a++) {
        var e = arguments[a];
        for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
    }
    return t;
}, _createClass = function() {
    function n(t, a) {
        for (var e = 0; e < a.length; e++) {
            var n = a[e];
            n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
            Object.defineProperty(t, n.key, n);
        }
    }
    return function(t, a, e) {
        return a && n(t.prototype, a), e && n(t, e), t;
    };
}(), _get = function t(a, e, n) {
    null === a && (a = Function.prototype);
    var s = Object.getOwnPropertyDescriptor(a, e);
    if (void 0 === s) {
        var o = Object.getPrototypeOf(a);
        return null === o ? void 0 : t(o, e, n);
    }
    if ("value" in s) return s.value;
    var i = s.get;
    return void 0 !== i ? i.call(n) : void 0;
}, _index = require("../../../../B3C56234C9B4369CD5A30A33B9E328F4.js"), _index2 = _interopRequireDefault(_index), _basicLogin = require("../../../../C0BBD9D7C9B4369CA6DDB1D0955328F4.js"), _basicLogin2 = _interopRequireDefault(_basicLogin), _refreshCaptcha = require("../../../../DFDDE0A2C9B4369CB9BB88A5121328F4.js"), _refreshCaptcha2 = _interopRequireDefault(_refreshCaptcha), _validate3 = require("../../../../B2DEA187C9B4369CD4B8C980854328F4.js"), _validate4 = _interopRequireDefault(_validate3), _asyncStatus = require("../../../../EF15B521C9B4369C8973DD269A8228F4.js"), _const = require("../../../../04D06682C9B4369C62B60E85CE7228F4.js"), _ma = require("../../../../1F1A8630C9B4369C797CEE373DC228F4.js"), _ma2 = _interopRequireDefault(_ma);

function _interopRequireDefault(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

function _classCallCheck(t, a) {
    if (!(t instanceof a)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(t, a) {
    if (!t) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !a || "object" != typeof a && "function" != typeof a ? t : a;
}

function _inherits(t, a) {
    if ("function" != typeof a && null !== a) throw new TypeError("Super expression must either be null or a function, not " + typeof a);
    t.prototype = Object.create(a && a.prototype, {
        constructor: {
            value: t,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), a && (Object.setPrototypeOf ? Object.setPrototypeOf(t, a) : t.__proto__ = a);
}

var ma = new _ma2.default(), RULES = {
    name: {
        validator: "name",
        message: "请输入正确的手机号或邮箱"
    },
    password: {
        validator: "required",
        message: "请输入密码"
    }
}, BasicLogin = function(t) {
    function o() {
        var t, a, d;
        _classCallCheck(this, o);
        for (var e = arguments.length, n = Array(e), s = 0; s < e; s++) n[s] = arguments[s];
        return (a = d = _possibleConstructorReturn(this, (t = o.__proto__ || Object.getPrototypeOf(o)).call.apply(t, [ this ].concat(n)))).$usedState = [ "$compid__107", "$compid__108", "$compid__109", "name", "password", "captchaModalVisible", "useTCaptcha", "isLoginDisabled", "statusText", "formData", "status", "needCaptcha", "captchaPayload", "captcha_id", "captcha_solution", "captchaModalConfig", "appid", "isInfoEmpty" ], 
        d.handletCaptchaFailed = function(t) {
            var a = t.currentRoute;
            a && 0 <= a.indexOf("basic") && (0, _index.showModal)({
                title: "出错啦",
                content: "验证码校验出错",
                showCancel: !1
            });
        }, d.handletCaptchaSuccess = function(t) {
            var a = t.ticket, e = t.randstr, n = t.currentRoute;
            return n && 0 <= n.indexOf("basic") && d.setState(function(t) {
                return {
                    formData: _extends({}, t.formData, {
                        ticket: a,
                        randstr: e
                    }),
                    captchaModalVisible: !1
                };
            }, function() {
                d.handleLoginClick();
            }), !1;
        }, d.handleConfirmClose = function() {
            d.setState({
                captchaModalVisible: !1
            });
        }, d.setName = function(t) {
            var a = t.detail.value;
            d.setState(function(t) {
                return {
                    formData: _extends({}, t.formData, {
                        name: a
                    }),
                    statusText: _const.STATUS_TEXT[_asyncStatus.DEFAULT]
                };
            });
        }, d.setPwd = function(t) {
            var a = t.detail.value;
            d.setState(function(t) {
                return {
                    formData: _extends({}, t.formData, {
                        password: a
                    }),
                    statusText: _const.STATUS_TEXT[_asyncStatus.DEFAULT]
                };
            });
        }, d.handleLoginClick = function() {
            ma.report("chooseBasicLogin", {
                need_captcha: d.state.needCaptcha
            });
            var t = d.props, a = t.appid, e = t.useTCaptcha;
            console.log(a, e);
            var n = d.state, s = n.status, o = n.formData, i = n.needCaptcha, r = n.captchaPayload;
            if (s === _asyncStatus.PENDING) return !1;
            var c = _extends({}, RULES);
            i && !e && (c.captcha_solution = {
                validator: "required",
                message: "请输入验证码"
            }, o.captcha_id = r.captcha_id);
            var u = (0, _validate4.default)(o, c), p = _slicedToArray(u, 3), l = p[0], _ = (p[1], 
            p[2]);
            if (!l) return (0, _index.showModal)({
                title: "出错啦",
                content: _,
                showCancel: !1
            }), !1;
            d.setState({
                status: _asyncStatus.PENDING,
                statusText: _const.STATUS_TEXT[_asyncStatus.PENDING]
            }), (0, _basicLogin2.default)(a, o).then(function(t) {
                var a = t.data, e = a.status, n = a.message, s = Object.assign({}, a, {
                    type: _const.LOGIN_TYPE_BASIC
                });
                e === _const.LOGIN_SUCCESS ? (d.setState({
                    status: _asyncStatus.SUCCESS,
                    statusText: _const.STATUS_TEXT[_asyncStatus.SUCCESS]
                }), d.props.onLoginSuccess({
                    detail: s
                })) : n === _const.LOGIN_MESSAGE_NEED_CAPTCHA ? d.setState({
                    captchaModalVisible: !0,
                    captchaModalConfig: {
                        content: "请先完成图形验证"
                    },
                    needCaptcha: !0,
                    captchaPayload: a.payload,
                    status: _asyncStatus.FAIL,
                    statusText: _const.STATUS_TEXT[_asyncStatus.DEFAULT]
                }) : (d.setState(function(t) {
                    return {
                        formData: _extends({}, t.formData, {
                            password: ""
                        }),
                        status: _asyncStatus.FAIL,
                        statusText: _const.STATUS_TEXT[_asyncStatus.FAIL]
                    };
                }), d.props.onLoginFailed({
                    detail: s
                }));
            }).catch(function(t) {
                _const.LOGIN_TYPE_BASIC;
                d.setState({
                    status: _asyncStatus.FAIL
                }), i && !e && d.refreshCaptcha();
            });
        }, d.refreshCaptcha = function() {
            (0, _refreshCaptcha2.default)().then(function(t) {
                d.setState({
                    captchaPayload: t
                });
            }).catch(function(t) {
                (0, _index.showModal)({
                    title: "刷新失败",
                    content: "请重试",
                    showCancel: !1
                });
            });
        }, d.setCaptchaSolution = function(t) {
            var a = t.captcha_solution, e = t.payload, n = d.state.formData;
            d.setState({
                formData: _extends({}, n, {
                    captcha_solution: a,
                    captcha_id: e.captcha_id
                }),
                captchaPayload: e,
                statusText: _const.STATUS_TEXT[_asyncStatus.DEFAULT]
            });
        }, d.toTCptchaVerify = function() {
            d.setState({
                captchaModalVisible: !1
            });
        }, d.customComponents = [ "Captcha", "ConfirmModal" ], _possibleConstructorReturn(d, a);
    }
    return _inherits(o, _index.Component), _createClass(o, [ {
        key: "_constructor",
        value: function() {
            _get(o.prototype.__proto__ || Object.getPrototypeOf(o.prototype), "_constructor", this).apply(this, arguments), 
            this.state = {
                formData: {
                    name: "",
                    password: "",
                    captcha_id: "",
                    captcha_solution: "",
                    ticket: "",
                    randstr: ""
                },
                status: _asyncStatus.DEFAULT,
                statusText: _const.STATUS_TEXT[_asyncStatus.DEFAULT],
                needCaptcha: !1,
                captchaPayload: {},
                captcha_id: "",
                captcha_solution: "",
                captchaModalVisible: !1,
                captchaModalConfig: {
                    content: "请先完成图形验证"
                }
            }, this.$$refs = new _index2.default.RefsArray();
        }
    }, {
        key: "_createData",
        value: function() {
            this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {};
            arguments[2];
            var t = this.$prefix, a = (0, _index.genCompid)(t + "$compid__107"), e = _slicedToArray(a, 2), n = e[0], s = e[1], o = (0, 
            _index.genCompid)(t + "$compid__108"), i = _slicedToArray(o, 2), r = i[0], c = i[1], u = (0, 
            _index.genCompid)(t + "$compid__109"), p = _slicedToArray(u, 2), l = p[0], _ = p[1], d = this.__props.useTCaptcha, h = this.__state, f = h.status, y = h.formData, C = (h.statusText, 
            h.captchaModalVisible), m = h.captchaModalConfig, S = h.captchaPayload, T = y.name, g = y.password, v = f === _asyncStatus.PENDING || this.isInfoEmpty;
            return C && !d && _index.propsManager.set({
                refreshCaptcha: this.refreshCaptcha,
                setCaptchaSolution: this.setCaptchaSolution,
                payload: S
            }, s, n), C && d && _index.propsManager.set({
                config: m
            }, c, r), C && d && _index.propsManager.set({
                onVerifyClick: this.toTCptchaVerify,
                payload: S,
                useTCaptcha: d,
                ontCaptchaSuccess: this.handletCaptchaSuccess,
                ontCaptchFailed: this.handletCaptchaFailed
            }, _, l), Object.assign(this.__state, {
                $compid__107: s,
                $compid__108: c,
                $compid__109: _,
                name: T,
                password: g,
                useTCaptcha: d,
                isLoginDisabled: v,
                isInfoEmpty: this.isInfoEmpty
            }), this.__state;
        }
    }, {
        key: "isInfoEmpty",
        get: function() {
            var t = this.state.formData, a = t.password;
            return !(t.name && a);
        }
    } ]), o;
}();

BasicLogin.$$events = [ "setName", "setPwd", "handleLoginClick" ], BasicLogin.$$componentPath = "modules/weapp-douban-login/taroComponents/BasicLogin/index", 
BasicLogin.defaultProps = {
    useTCaptcha: !1,
    onLoginSuccess: function() {},
    onLoginFailed: function() {}
}, exports.default = BasicLogin, Component(require("../../../../B3C56234C9B4369CD5A30A33B9E328F4.js").default.createComponent(BasicLogin));
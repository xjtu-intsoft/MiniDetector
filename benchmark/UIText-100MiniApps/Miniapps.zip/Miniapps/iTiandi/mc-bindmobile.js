var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../utils/common.js")), a = e(require("../../utils/config/api.js")), o = e(require("../../utils/config/site.js"));

Component({
    properties: {
        isShow: {
            type: Boolean,
            default: !1,
            observer: function(e) {
                this.setData({
                    isShow: e,
                    _bottom: e ? 0 : "-100%"
                });
            }
        },
        conContext: {
            type: String,
            value: null,
            observer: function(e) {
                this.setData({
                    context: e
                });
            }
        },
        showDataContent: {
            type: Object,
            value: null,
            observer: function(e) {
                this.setData({
                    showData: e.showData,
                    status: e.status
                });
            }
        }
    },
    data: {
        isShow: !1,
        _bottom: "-100%",
        content: "当前操作需要提供您的手机号",
        mobile: "",
        disabled: "",
        code: null,
        showData: {},
        status: !1,
        isShowGetMobile: !0
    },
    methods: {
        onTap: function() {
            this.triggerEvent("customevent");
        },
        closepal: function() {
            this.setData({
                _bottom: "-100%",
                isShow: !1
            });
        },
        refresh: function() {
            this.triggerEvent("closepal");
        },
        mc_bm_bindMobile: function() {
            this.closepal();
            var e = getApp().globalData.domain + "a/user/" + getApp().globalData.mallId + "/bindmobile?gmishidden=true&isCouponBindMobile=true&redirectUrl=" + encodeURIComponent(this.pageUrl);
            return t.default.goRoutePage(e), !1;
        },
        mc_bm_bindMobile2: function() {
            this.close(), this.setData({
                isShow: !0,
                _bottom: 0
            });
        },
        close: function() {
            this.setData({
                status: !1
            }), this.triggerEvent("closepal");
        },
        getPhoneNumber: function(e) {
            this.setData({
                disabled: "disabled"
            });
            var t = e.detail;
            if (t.errMsg.indexOf("ok") > 0) {
                var a = {
                    Code: this.data.code,
                    AppID: getApp().globalData.appId,
                    EncryptedData: t.encryptedData,
                    Iv: t.iv
                };
                if (a) JSON.stringify(a).length > 2 ? this.bindMobile(a) : this.setData({
                    disabled: !1
                });
            }
        },
        gm_getPhoneCode: function() {
            var e = this;
            t.default.getcode(function(t) {
                e.setData({
                    code: t
                });
            });
        },
        bindMobile: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, i = this, l = a.default.LiteAppCheckAndBindMobile, s = 8, n = {
                Mobile: "",
                MallID: getApp().globalData.mallId,
                SNSType: s,
                SMSType: 5,
                VCode: "",
                OauthID: t.default.getCookie(o.default.Cookie_MiniProgramOpenIDName),
                Keyword: "",
                Scene: 1,
                GraphicType: 2,
                GraphicVCode: "",
                AppID: e.AppID || "",
                Code: e.Code,
                InternationalMobileCode: "",
                EncryptedData: e.EncryptedData || "",
                Iv: e.Iv || ""
            };
            t.default.invokeAPI(l, n, {
                successCallback: function(e) {
                    if (i.gm_getPhoneCode(), e.d.IsBindSucess) return i.setData({
                        disabled: !1
                    }), i.data.mobile || i.setData({
                        mobile: e.d.Mobile
                    }), t.default.setCookie(o.default.Cookie_Mobile, i.data.mobile || ""), i.closepal(), 
                    i.refresh(), !1;
                },
                errorCallback: function(e) {
                    if (i.gm_getPhoneCode(), i.setData({
                        disabled: !1
                    }), i.data.mobile || i.setData({
                        mobile: e.d.Mobile
                    }), t.default.setCookie(o.default.Cookie_Mobile, i.data.mobile || ""), i.closepal(), 
                    326 != e.m) {
                        if (322 == e.m) return i.setData({
                            status: !0,
                            showData: {
                                showType: 1,
                                nickName: e.d.NickName,
                                mobile: i.data.mobile
                            }
                        }), !1;
                        if (i.closepal(), e.d.IsBindSucess) return t.default.setCookie(o.default.Cookie_Mobile, mobile || ""), 
                        !1;
                        t.default.showToast(e.e);
                    } else i.setData({
                        status: !0,
                        showData: {
                            showType: 2,
                            nickName: e.d.NickName,
                            mobile: i.data.mobile
                        }
                    });
                }
            });
        },
        mergecount: function() {
            var e = this, i = a.default.LiteAppMergeWX, l = {
                UserID: t.default.getCookie(o.default.Cookie_UidName),
                Mobile: e.data.showData.mobile,
                MallID: getApp().globalData.mallId,
                WeChatOpenID: t.default.getWxOpenId(),
                WeChatMiniProgramOpenID: t.default.getCookie(o.default.Cookie_MiniProgramOpenIDName),
                SNSType: 8
            };
            t.default.invokeAPI(i, l, {
                successCallback: function(a) {
                    t.default.setCookie(o.default.Cookie_TokenName, a.d.Token + "," + a.d.ProjectType), 
                    t.default.setCookie(o.default.Cookie_UidName, a.d.UID), t.default.setCookie(o.default.Cookie_Mobile, a.d.Mobile || ""), 
                    e.close();
                }
            });
        }
    },
    ready: function() {
        this.setData({
            jifen: getApp().globalData.jifen
        }), this.gm_getPhoneCode();
    }
});
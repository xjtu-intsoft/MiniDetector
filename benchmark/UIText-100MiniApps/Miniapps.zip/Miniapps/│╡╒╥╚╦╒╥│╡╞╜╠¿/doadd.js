function a(a, t, e) {
    return t in a ? Object.defineProperty(a, t, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : a[t] = e, a;
}

var t = getApp(), e = require("../../zanui/index"), o = require("../../utils/util.js");

Page(Object.assign({}, e.Toast, e.NoticeBar, e.Field, e.TopTips, e.Actionsheet, e.Switch, e.Stepper, {
    data: {
        pre_code: "",
        tel_from_wx: 0,
        showStartPlaceWin: !1,
        showEndPlaceWin: !1,
        startPlaceData: {
            state_code: 0,
            state_name: "",
            city_code: 0,
            city_name: "",
            xian_code: 0,
            xian_name: ""
        },
        endPlaceData: {
            state_code: 0,
            state_name: "",
            city_code: 0,
            city_name: "",
            xian_code: 0,
            xian_name: ""
        },
        ooid: 0,
        addstatus: 1,
        status: 0,
        sonstatus: 1,
        zanToast: "",
        sharetext: "海报可以分享到微信朋友圈、QQ群",
        username: "",
        addtype: 1,
        forauto: 0,
        movable: {
            text: ""
        },
        baseActionsheet: {
            show: !1,
            cancelText: "取消",
            closeOnClickOverlay: !0,
            componentId: "baseActionsheet",
            actions: [ {
                name: "男"
            }, {
                name: "女"
            } ]
        },
        datepickparam: {
            show: !1,
            value: [ 0, 0, 0 ],
            tempvalue: [ 0, 0, 0 ],
            year: [ 2017 ],
            month: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 ],
            day: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31 ]
        },
        timepickparam: {
            show: !1,
            value: [ 0, 0, 0 ],
            tempvalue: [ 0, 0, 0 ],
            hour: [ 0, 1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23 ],
            min: [ 0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55 ]
        },
        paymoney: 0,
        isPublish: 0,
        truename: "",
        listshow: !1,
        provincelist: [],
        tel: "",
        wx_id: "",
        templist: [],
        searchlist: [],
        inputkeyword: "",
        placetype: 1,
        fromprovincename: "",
        fromprovincecode: "",
        fromcityname: "",
        fromcitycode: "",
        fromxianname: "",
        fromxiancode: "",
        fromstreet: "",
        frombaseplace: "",
        toprovincecode: "",
        toprovincename: "",
        tocitycode: "",
        tocityname: "",
        toxiancode: "",
        toxianname: "",
        tostreet: "",
        tobaseplace: "",
        sex: "男",
        datestr: "",
        timestr: "",
        stepper1: {
            stepper: 1,
            min: 1,
            max: 50
        },
        mannum: 1,
        cartype: "",
        numtitle: "乘车人数",
        remark: "",
        checked: "0",
        is_top: 0,
        toptip: "",
        sharepic: !1,
        picpath: "",
        fromfrienddata: {
            id: 0,
            doing: 1,
            icon: "",
            addtypename: "",
            tasktype: 1,
            frommainplace: "",
            from_street: "",
            tomainplace: "",
            to_street: "",
            dttime: "",
            start_time: "",
            car_model: "",
            remark: "",
            sex: "",
            truename: ""
        },
        oldsharefrienddata: {},
        isios: 0,
        showsharefrind: !1,
        tpllist: [],
        showtpllist: !1,
        tpldata: {
            issavetpl: !1,
            tplname: ""
        },
        showsettpl: !1
    },
    setinitdata: function() {
        this.setData({
            frombaseplace: "",
            tobaseplace: "",
            fromprovincename: "",
            fromprovincecode: "",
            fromcityname: "",
            fromcitycode: "",
            fromxianname: "",
            fromxiancode: "",
            fromstreet: "",
            toprovincecode: "",
            toprovincename: "",
            tocitycode: "",
            tocityname: "",
            toxiancode: "",
            toxianname: "",
            tostreet: ""
        });
    },
    settplname: function(a) {
        this.setData({
            "tpldata.tplname": a.detail.value
        });
    },
    getTel: function(a) {
        var e = this, o = a.detail;
        o.iv && (t.globalData.pre_code ? (o.code = t.globalData.pre_code, t.getUserTel(o, function(a) {
            e.setData({
                tel: a
            });
        })) : t.showError("系统错误，请重新进入发布页面。"));
    },
    onShow: function() {
        var a = {
            isios: t.globalData.isios,
            showsettpl: t.globalData.apkshowsettpl
        };
        t.globalData.isios && (a.showsettpl = t.globalData.iosshowsettpl), this.setData(a);
    },
    onLoad: function(a) {
        var e = this;
        if (a.showfriend) return e.setData({
            addstatus: 3,
            "fromfrienddata.id": a.id
        }), void e.getShareFriendData();
        var i = new Date(), n = t.globalData.notice2;
        if (a != {}) {
            var c = "空位数", r = parseInt(a.type);
            1 == r && (c = "乘车人数", n = t.globalData.notice1), e.setData({
                addtype: r,
                numtitle: c
            }), wx.setNavigationBarTitle({
                title: 1 == r ? "发布人找车" : "发布车找人"
            });
        }
        a.forauto && (e.setData({
            forauto: 1
        }), wx.setNavigationBarTitle({
            title: "托管设置"
        }), n = t.globalData.notice1);
        var d = i.getHours() - 1;
        d < 0 && (d = 0);
        var s = t.globalData.userInfo.gender;
        e.setData({
            "datepickparam.year": [ i.getFullYear(), i.getFullYear() + 1 ],
            "datepickparam.tempvalue": [ 0, i.getMonth(), i.getDate() - 1 ],
            "datepickparam.value": [ 0, i.getMonth(), i.getDate() - 1 ],
            "timepickparam.value": [ d, 0 ],
            "timepickparam.tempvalue": [ d, 0 ],
            "movable.text": n,
            truename: t.globalData.userInfo.nickName,
            sex: 1 == s ? "男" : "女",
            isPublish: t.globalData.isPublish,
            tel_from_wx: t.globalData.tel_from_wx
        }), e.caldateandtime(), e.setData({
            sharetext: t.globalData.sharetext,
            username: t.globalData.userInfo.nickName
        }), setTimeout(function() {
            e.initZanNoticeBarScroll("movable");
        }, 100);
        var m = t.globalData.baseUrl + "/carandman/User/getUserContact", l = {
            forauto: e.data.forauto
        };
        t.post_mini(m, l, function(a) {
            if (a.data.truename) {
                var t = {
                    truename: a.data.truename,
                    sex: a.data.sex,
                    tel: a.data.tel,
                    wx_id: a.data.wx_id,
                    tpllist: a.data.tpllist
                };
                if (e.data.forauto) {
                    var i = {
                        state_code: (t = {
                            truename: a.data.truename,
                            sex: a.data.sex,
                            tel: a.data.tel,
                            wx_id: a.data.wx_id,
                            frombaseplace: o.comBasePlace(a.data.from_province, a.data.from_city, a.data.from_xian),
                            tobaseplace: o.comBasePlace(a.data.to_province, a.data.to_city, a.data.to_xian),
                            fromprovincename: a.data.from_province,
                            fromprovincecode: a.data.from_province_code,
                            fromcityname: a.data.from_city,
                            fromcitycode: a.data.from_city_code,
                            fromxianname: a.data.from_xian,
                            fromxiancode: a.data.from_xian_code,
                            fromstreet: a.data.from_street,
                            toprovincecode: a.data.to_province_code,
                            toprovincename: a.data.to_province,
                            tocitycode: a.data.to_city_code,
                            tocityname: a.data.to_city,
                            toxiancode: a.data.to_xian_code,
                            toxianname: a.data.to_xian,
                            tostreet: a.data.to_street,
                            remark: a.data.remark,
                            cartype: a.data.car_model,
                            mannum: a.data.mannum,
                            "stepper1.stepper": a.data.mannum
                        }).fromprovincecode,
                        state_name: t.fromprovincename,
                        city_code: t.fromcitycode,
                        city_name: t.fromcityname,
                        xian_code: t.fromxiancode,
                        xian_name: t.fromxianname
                    }, n = {
                        state_code: t.toprovincecode,
                        state_name: t.toprovincename,
                        city_code: t.tocitycode,
                        city_name: t.tocityname,
                        xian_code: t.toxiancode,
                        xian_name: t.toxianname
                    };
                    t.startPlaceData = i, t.endPlaceData = n;
                }
                e.setData(t);
            }
        }), wx.login({
            success: function(a) {
                t.globalData.pre_code = a.code;
            }
        }), e.trigglePayMoney();
    },
    trigglesavetpl: function() {
        var a = this.data.tpldata.issavetpl;
        this.setData({
            "tpldata.issavetpl": !a
        });
    },
    getShareFriendData: function() {
        var a = this, e = t.globalData.baseUrl + "/carandman/Task/frienddetail", o = {
            id: a.data.fromfrienddata.id
        };
        t.post(e, o, function(e) {
            0 == e.status ? a.setData({
                fromfrienddata: e.data
            }) : t.showAlert(e.msg);
        }, function() {
            t.showAlert("网络错误");
        });
    },
    testShare: function() {
        var a = {
            showfriend: 1,
            id: 24366
        };
        this.onLoad(a);
    },
    trigglePayMoney: function() {
        var a = this;
        if (t.globalData.is_vip) a.setData({
            paymoney: 0
        }); else {
            var e = t.globalData.fee1;
            2 == a.data.addtype && (e = t.globalData.fee2), a.data.is_top && (e += t.globalData.topmoney), 
            a.setData({
                paymoney: e / 100
            });
        }
    },
    setauto: function() {
        var a = this, e = {};
        if ("" != a.data.truename) if (e.truename = a.data.truename, e.sex = a.data.sex, 
        a.data.tel || a.data.wx_id) if (e.tel = a.data.tel, e.wx_id = a.data.wx_id, !a.data.tel || o.isMobile(a.data.tel)) if (e.start_time = a.data.timestr, 
        e.timestr = a.data.timestr, "" != a.data.fromprovincecode) if (e.fromprovincecode = a.data.fromprovincecode, 
        e.fromprovincename = a.data.fromprovincename, "" != a.data.fromcitycode) if (e.fromcitycode = a.data.fromcitycode, 
        e.fromcityname = a.data.fromcityname, e.fromxiancode = a.data.fromxiancode, e.fromxianname = a.data.fromxianname, 
        e.fromstreet = a.data.fromstreet, "" != a.data.toprovincecode) if (e.toprovincecode = a.data.toprovincecode, 
        e.toprovincename = a.data.toprovincename, "" != a.data.tocitycode) if (e.tocitycode = a.data.tocitycode, 
        e.tocityname = a.data.tocityname, e.toxiancode = a.data.toxiancode, e.toxianname = a.data.toxianname, 
        e.tostreet = a.data.tostreet, e.mannum = a.data.mannum, e.remark = a.data.remark, 
        e.cartype = a.data.cartype, "0" != a.data.checked) {
            e.addtype = a.data.addtype, e.tasktype = a.data.addtype;
            var i = t.globalData.baseUrl + "/carandman/Vip/saveauto";
            t.post_mini(i, e, function(a) {
                0 == a.status && wx.showModal({
                    title: "",
                    content: "托管设置成功,您可以再次点击“托管设置”按钮来进行管理。",
                    showCancel: !1,
                    confirmText: "<<返回",
                    success: function() {
                        wx.navigateBack({});
                    }
                });
            });
        } else a.showtip("请同意免责声明!"); else a.showtip("请选择目的市"); else a.showtip("请选择目的省市县"); else a.showtip("请选择出发城市"); else a.showtip("请选择出发省市县!"); else a.showtip("手机号码填写错误!"); else a.showtip("手机号和微信号必填一项"); else a.showtip("姓名不能为空");
    },
    goVip: function() {
        t.go("vip");
    },
    onShareAppMessage: function() {
        var a = this;
        return {
            title: "",
            path: "/pages/index/index?fromshare=CAR" + a.data.ooid,
            imageUrl: a.data.picpath
        };
    },
    onShareTimeline: function() {
        var a = this, t = {
            title: "微信搜一搜“车找人找车平台”",
            query: "showfriend=1&id=" + a.data.ooid,
            imageUrl: ""
        };
        if (a.data.ooid) {
            t.imageUrl = "https://wx.jaypc.cn/p5/public/app/careshare/to/img/manfindcar.png", 
            2 == a.data.addtype && (t.imageUrl = "https://wx.jaypc.cn/p5/public/app/careshare/to/img/carfindman.png");
            var e = "从";
            "市辖区" != a.data.oldsharefrienddata.fromcityname && (e += a.data.oldsharefrienddata.fromcityname), 
            "市辖区" != a.data.oldsharefrienddata.fromxianname && a.data.oldsharefrienddata.fromxianname != a.data.oldsharefrienddata.fromcityname && (e += a.data.oldsharefrienddata.fromxianname), 
            e += " 至 ", "市辖区" != a.data.oldsharefrienddata.tocityname && (e += a.data.oldsharefrienddata.tocityname), 
            "市辖区" != a.data.oldsharefrienddata.toxianname && a.data.oldsharefrienddata.toxianname != a.data.oldsharefrienddata.tocityname && (e += a.data.oldsharefrienddata.toxianname), 
            t.title = e;
        }
        return t;
    },
    goagree: function() {
        t.go("agree");
    },
    setWxIdFfromTel: function() {
        var a = this;
        a.setData({
            wx_id: a.data.tel
        });
    },
    closeshare: function() {
        this.setData({
            sharepic: !1
        });
    },
    alsoadd: function() {
        t.showAlert("请前往小程序后再进入发布页面进行发布！", function() {
            wx.switchTab({
                url: t.comurl("index")
            });
        });
    },
    actContact: function(a) {
        var e = t.getHtmlData(a, "doing"), o = t.getHtmlData(a, "tel"), i = t.getHtmlData(a, "wx_id"), n = [ "电话联系", "微信联系" ];
        o || (n = [ "微信联系" ]), "1" == e ? wx.showActionSheet({
            itemList: n,
            success: function(a) {
                var e = n[a.tapIndex];
                "电话联系" == e ? wx.makePhoneCall({
                    phoneNumber: o
                }) : "微信联系" == e && (i || (i = o), wx.setClipboardData({
                    data: i,
                    success: function(a) {
                        t.showSuccess("已复制微信号");
                    },
                    fail: function() {
                        t.showError("操作失败");
                    }
                }));
            }
        }) : t.showError("已结束,信息已过期");
    },
    showpicshare: function(a) {
        this.setData({
            picpath: a.pic,
            sharepic: !0,
            addstatus: 2,
            ooid: a.ooid
        });
    },
    downsharepic: function() {
        var a = this;
        wx.showLoading({
            title: "下载中..."
        }), wx.downloadFile({
            url: a.data.picpath,
            success: function(e) {
                wx.saveImageToPhotosAlbum({
                    filePath: e.tempFilePath,
                    success: function(e) {
                        t.showSuccess("保存成功"), a.closeshare();
                    },
                    fail: function(e) {
                        t.showError("保存失败"), a.closeshare();
                    }
                });
            },
            fail: function() {
                t.showError("保存失败");
            },
            complete: function() {
                wx.hideLoading();
            }
        });
    },
    switchchange: function(a) {
        var e = this;
        if (a.detail.value) {
            var o = "+" + t.globalData.topmoney / 100 + "元";
            t.globalData.topmoney || (o = ""), e.setData({
                is_top: 1,
                toptip: o
            });
        } else e.setData({
            is_top: 0,
            toptip: ""
        });
        e.trigglePayMoney();
    },
    addtask: function() {
        var a = this, e = {};
        if ("" != a.data.truename) if (e.truename = a.data.truename, e.sex = a.data.sex, 
        a.data.tel || a.data.wx_id) if (e.tel = a.data.tel, e.wx_id = a.data.wx_id, !a.data.tel || o.isMobile(a.data.tel)) if (o.isGoodDate(a.data.datestr)) if (e.dttime = a.data.datestr, 
        e.datestr = a.data.datestr, e.start_time = a.data.timestr, e.timestr = a.data.timestr, 
        "" != a.data.fromprovincecode) if (e.fromprovincecode = a.data.fromprovincecode, 
        e.fromprovincename = a.data.fromprovincename, "" != a.data.fromcitycode) if (e.fromcitycode = a.data.fromcitycode, 
        e.fromcityname = a.data.fromcityname, e.fromxiancode = a.data.fromxiancode, e.fromxianname = a.data.fromxianname, 
        e.fromstreet = a.data.fromstreet, "" != a.data.toprovincecode) if (e.toprovincecode = a.data.toprovincecode, 
        e.toprovincename = a.data.toprovincename, "" != a.data.tocitycode) if (e.tocitycode = a.data.tocitycode, 
        e.tocityname = a.data.tocityname, e.toxiancode = a.data.toxiancode, e.toxianname = a.data.toxianname, 
        e.tostreet = a.data.tostreet, e.mannum = a.data.mannum, e.remark = a.data.remark, 
        e.cartype = a.data.cartype, "0" != a.data.checked) {
            if (e.is_top = a.data.is_top, e.token1 = t.globalData.token1, e.token2 = t.globalData.token2, 
            e.addtype = a.data.addtype, a.data.tpldata.issavetpl) {
                if (!t.globalData.is_vip) return void a.showtplsay();
                if (!a.data.tpldata.tplname) return void t.showError("请输入模板名称");
                for (var i = a.data.tpllist, n = a.data.tpldata.tplname, c = 0; c < i.length; c++) if (n == i[c]) return void t.showError("该模板名称已存在！");
                e.tplname = a.data.tpldata.tplname;
            }
            var r = t.globalData.fee1;
            2 == a.data.addtype && (r = t.globalData.fee2), 1 == a.data.is_top && (r += t.globalData.topmoney), 
            t.globalData.is_vip && (r = 0), e.fee = r, e.tasktype = a.data.addtype, a.setData({
                oldsharefrienddata: e
            });
            var d = t.globalData.baseUrl + "/carandman/Task/saveTask";
            t.post_mini(d, e, function(e) {
                0 == e.status && (r > 0 ? wx.requestPayment({
                    timeStamp: e.data.timeStamp,
                    nonceStr: e.data.nonceStr,
                    package: e.data.package,
                    signType: e.data.signType,
                    paySign: e.data.paySign,
                    success: function() {
                        t.showSuccess("发布成功"), setTimeout(function() {
                            a.afterPay(e.data.foid, e.data.toid);
                        }, 500);
                    },
                    fail: function() {
                        a.showtip("支付失败");
                    }
                }) : a.afterPay(e.data.foid, e.data.toid));
            });
        } else a.showtip("请同意免责声明!"); else a.showtip("请选择目的市"); else a.showtip("请选择目的省"); else a.showtip("请选择出发城市"); else a.showtip("请选择出发省!"); else a.showtip("出发日期应大于等于今天!"); else a.showtip("手机号码填写错误!"); else a.showtip("手机号和微信号必填一项"); else a.showtip("姓名不能为空");
    },
    showtplsay: function() {
        var a = this;
        wx.showModal({
            title: "温馨提示",
            content: "保存模板是VIP用户权益，VIP用户既可免费发布，也可永久使用保存的模板,是否前往查看详情？",
            cancelText: "不了",
            confirmText: "好的",
            success: function(e) {
                e.confirm ? t.go("vip") : t.globalData.is_vip || a.setData({
                    "tpldata.issavetpl": !1
                });
            }
        });
    },
    gomylog: function() {
        t.go("mylog");
    },
    afterPay: function(a, e) {
        var o = this, i = {
            foid: a,
            toid: e
        }, n = t.globalData.baseUrl + "/carandman/Share/afterPay";
        t.post_mini(n, i, function(a) {
            0 == a.status && (o.showpicshare(a.data), o.setinitdata());
        });
    },
    checkboxcheck: function(a) {
        var t = this;
        "0" == a.currentTarget.dataset.checked ? t.setData({
            checked: "1"
        }) : t.setData({
            checked: "0"
        });
    },
    deltpl: function(a) {
        var e = this, i = t.getHtmlData(a, "index"), n = e.data.tpllist[i], c = "确定要删除 " + n.name + " 这个模板吗？";
        wx.showModal({
            title: "温馨提示",
            content: c,
            success: function(a) {
                if (a.confirm) {
                    var c = t.globalData.baseUrl + "/carandman/Task/delTpl", r = {
                        taskid: n.taskid
                    };
                    t.post_mini(c, r, function() {
                        t.showSuccess("操作成功！");
                        var a = o.cloneObject(e.data.tpllist);
                        a.splice(i, 1), e.setData({
                            tpllist: a
                        });
                    });
                }
            }
        });
    },
    userTpl: function(a) {
        var e = this, i = t.getHtmlData(a, "index"), n = e.data.tpllist[i], c = "是否加载 " + n.name + " 模板？加载后会覆盖当前所有内容。";
        wx.showModal({
            title: "温馨提示",
            content: c,
            success: function(a) {
                if (a.confirm) {
                    var i = t.globalData.baseUrl + "/carandman/Task/getTplData", c = {
                        taskid: n.taskid
                    };
                    t.post_mini(i, c, function(a) {
                        var i = {
                            truename: a.data.truename,
                            sex: a.data.sex,
                            tel: a.data.tel,
                            wx_id: a.data.wx_id,
                            frombaseplace: o.comBasePlace(a.data.from_province, a.data.from_city, a.data.from_xian),
                            tobaseplace: o.comBasePlace(a.data.to_province, a.data.to_city, a.data.to_xian),
                            fromprovincename: a.data.from_province,
                            fromprovincecode: a.data.from_province_code,
                            fromcityname: a.data.from_city,
                            fromcitycode: a.data.from_city_code,
                            fromxianname: a.data.from_xian,
                            fromxiancode: a.data.from_xian_code,
                            fromstreet: a.data.from_street,
                            toprovincecode: a.data.to_province_code,
                            toprovincename: a.data.to_province,
                            tocitycode: a.data.to_city_code,
                            tocityname: a.data.to_city,
                            toxiancode: a.data.to_xian_code,
                            toxianname: a.data.to_xian,
                            tostreet: a.data.to_street,
                            remark: a.data.remark,
                            cartype: a.data.car_model,
                            mannum: a.data.mannum,
                            "stepper1.stepper": a.data.mannum
                        }, n = {
                            state_code: i.fromprovincecode,
                            state_name: i.fromprovincename,
                            city_code: i.fromcitycode,
                            city_name: i.fromcityname,
                            xian_code: i.fromxiancode,
                            xian_name: i.fromxianname
                        }, c = {
                            state_code: i.toprovincecode,
                            state_name: i.toprovincename,
                            city_code: i.tocitycode,
                            city_name: i.tocityname,
                            xian_code: i.toxiancode,
                            xian_name: i.toxianname
                        };
                        i.startPlaceData = n, i.endPlaceData = c, i.showtpllist = !1, e.setData(i), t.showError("应用成功！请注意修改出发时间。");
                    });
                }
            }
        });
    },
    handleZanStepperChange: function(t) {
        var e, o = t.componentId, i = t.stepper;
        this.setData((e = {}, a(e, o + ".stepper", i), a(e, "mannum", i), e)), console.log("乘车人数：" + i);
    },
    caldateandtime: function() {
        var a = this;
        setTimeout(function() {
            var t = a.data.datepickparam.year[a.data.datepickparam.value[0]], e = o.formatNumber(a.data.datepickparam.month[a.data.datepickparam.value[1]]), i = o.formatNumber(a.data.datepickparam.day[a.data.datepickparam.value[2]]), n = o.formatNumber(a.data.timepickparam.hour[a.data.timepickparam.value[0]]), c = o.formatNumber(a.data.timepickparam.min[a.data.timepickparam.value[1]]);
            a.setData({
                datestr: t + "-" + e + "-" + i,
                timestr: n + ":" + c
            });
        }, 50);
    },
    showtip: function(a) {
        this.showZanTopTips(a);
    },
    handleZanActionsheetClick: function(t) {
        var e, o = t.componentId, i = t.index, n = this;
        0 == i ? n.setData({
            sex: "男"
        }) : 1 == i && n.setData({
            sex: "女"
        }), this.setData((e = {}, a(e, o + ".show", !1), a(e, o + ".actions[" + i + "].loading", !1), 
        e));
    },
    checksex: function() {
        this.setData({
            "baseActionsheet.show": !0
        });
    },
    handleZanActionsheetCancel: function(t) {
        var e = t.componentId;
        this.setData(a({}, e + ".show", !1));
    },
    surepickdate: function() {
        var a = this;
        a.setData({
            "datepickparam.show": !1,
            "datepickparam.value": a.data.datepickparam.tempvalue
        }), a.caldateandtime();
    },
    surepicktime: function() {
        var a = this;
        a.setData({
            "timepickparam.show": !1,
            "timepickparam.value": a.data.timepickparam.tempvalue
        }), a.caldateandtime();
    },
    cancelpickdate: function() {
        this.setData({
            "datepickparam.show": !1
        });
    },
    cancelpicktime: function() {
        this.setData({
            "timepickparam.show": !1
        });
    },
    pickdateclick: function() {
        this.setData({
            "datepickparam.show": !0
        });
    },
    picktimeclick: function() {
        this.setData({
            "timepickparam.show": !0
        });
    },
    handleZanFieldBlur: function(a) {
        var e = this, o = {};
        o[t.getHtmlData(a, "componentId")] = a.detail.value, console.log(o), e.setData(o);
    },
    handlePopupDateChange: function(a) {
        this.setData({
            "datepickparam.tempvalue": a.detail.value
        });
    },
    handlePopupTimeChange: function(a) {
        this.setData({
            "timepickparam.tempvalue": a.detail.value
        });
    },
    hideDatePopup: function() {
        this.setData({
            "pickdate.show": !1
        });
    },
    openWin: function(a) {
        var e = this, o = {};
        o[t.getHtmlData(a, "winvar")] = !0, e.setData(o);
    },
    closeWin: function(a) {
        var e = this, o = {};
        o[t.getHtmlData(a, "winvar")] = !1, e.setData(o);
    },
    outStartPlace: function(a) {
        var t = this, e = a.detail;
        t.setData({
            showStartPlaceWin: !1,
            startPlaceData: e,
            fromprovincecode: e.state_code,
            fromprovincename: e.state_name,
            fromcitycode: e.city_code,
            fromcityname: e.city_name,
            fromxiancode: e.xian_code,
            fromxianname: e.xian_name,
            frombaseplace: o.comBasePlace(e.state_name, e.city_name, e.xian_name)
        });
    },
    outEndPlace: function(a) {
        var t = this, e = a.detail;
        t.setData({
            showEndPlaceWin: !1,
            endPlaceData: e,
            toprovincecode: e.state_code,
            toprovincename: e.state_name,
            tocitycode: e.city_code,
            tocityname: e.city_name,
            toxiancode: e.xian_code,
            toxianname: e.xian_name,
            tobaseplace: o.comBasePlace(e.state_name, e.city_name, e.xian_name)
        });
    }
}));
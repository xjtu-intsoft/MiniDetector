var t = getApp(), e = require("../../../utils/CommonUtils.js");

Component({
    properties: {
        isShow: {
            type: Boolean,
            value: "",
            observer: function(e, a) {
                if (e) {
                    var o = t.globalData;
                    this.setData({
                        inputLayoutWidth: o.windowWidth - 80
                    });
                }
            }
        }
    },
    data: {
        inputLayoutWidth: "auto",
        phone: "",
        maxLength: 11
    },
    methods: {
        phoneChange: function(t) {
            this.setData({
                phone: t.detail.value
            });
        },
        operation: function(t) {
            switch (t.target.dataset.id) {
              case "cancel":
                this.triggerEvent("onHide");
                break;

              case "confirm":
                var a = this.data.phone || "";
                11 === a.length ? this.triggerEvent("onSave", {
                    phone: a
                }) : e.showToast("请输入正确的手机号码");
            }
        }
    }
});
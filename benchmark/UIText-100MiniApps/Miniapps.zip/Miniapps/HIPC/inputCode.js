var t = require("../../utils/httpClient.js"), e = getApp();

Page({
    data: {
        codeValue: "",
        countdown: 60,
        phone: "",
        type: ""
    },
    inputCode: function(t) {
        var e = this, n = t.detail.value;
        e.setData({
            codeValue: n
        }), 4 == n.length && e.bindPhone();
    },
    retrieve: function(n) {
        var o = this;
        o.submiPhoneCall({
            code: 100
        });
        var a = "alter" == this.data.type ? "user_phone_update" : "user_phone_bind";
        t.post(e.globalData.api_url + "/api/verifycode/sms", {
            scene: a,
            phone: o.data.phone
        }).then(function(t) {
            100 == t.code ? wx.showToast({
                title: "发送成功"
            }) : wx.showToast({
                title: "发送失败"
            });
        });
    },
    submiPhoneCall: function(t) {
        var e = this;
        100 == t.code && (e.setData({
            countdown: 60
        }), e.startCountdown(), e.setData({
            codeValue: t.value
        }));
    },
    startCountdown: function(t) {
        var e = this, n = setInterval(function(t) {
            0 != e.data.countdown ? e.setData({
                countdown: e.data.countdown - 1
            }) : clearInterval(n);
        }, 1e3);
    },
    bindPhone: function() {
        var n = this, o = this;
        "bind" == this.data.type && t.post(e.globalData.api_url + "/api/useroauthphone/bind", {
            phone: o.data.phone,
            code: o.data.codeValue
        }).then(function(t) {
            console.log(t), n.resultBind(t);
        }), "alter" == this.data.type && (t.post(e.globalData.api_url + "/api/useroauthphone/update", {
            phone: o.data.phone,
            code: o.data.codeValue
        }).then(function(t) {
            n.resultAlter(t);
        }), wx.navigateTo({
            url: "/pages/bindPhone/bindPhone"
        }), wx.navigateBack({
            delta: 1
        }));
    },
    resultBind: function(t) {
        100 == t.code ? (wx.showToast({
            title: "绑定成功",
            icon: "none",
            duration: 2e3
        }), wx.navigateBack({
            delta: 2
        })) : wx.showToast({
            title: t.message,
            icon: "none",
            duration: 2e3
        });
    },
    resultAlter: function(t) {
        100 == t.code ? (wx.showToast({
            title: "更换成功",
            icon: "none",
            duration: 2e3
        }), wx.navigateBack({
            delta: 3
        })) : wx.showToast({
            title: t.message,
            icon: "none",
            duration: 2e3
        });
    },
    onLoad: function(t) {
        this.setData({
            phone: t.phone,
            codeValue: t.value,
            type: t.type
        }), console.log("inputCode", t);
    },
    onReady: function() {},
    onShow: function() {
        this.startCountdown();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {}
});
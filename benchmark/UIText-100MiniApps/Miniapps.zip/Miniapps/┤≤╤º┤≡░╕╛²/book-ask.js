(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/book-ask/book-ask" ], {
    "0ad0": function(t, n, e) {
        e.r(n);
        var a = e("4e4c"), o = e.n(a);
        for (var c in a) "default" !== c && function(t) {
            e.d(n, t, function() {
                return a[t];
            });
        }(c);
        n.default = o.a;
    },
    2482: function(t, n, e) {
        var a = e("662a");
        e.n(a).a;
    },
    "4e4c": function(t, n, e) {
        (function(t) {
            Object.defineProperty(n, "__esModule", {
                value: !0
            }), n.default = void 0;
            var a = e("b25c"), o = {
                name: "book-ask",
                data: function() {
                    return {
                        name: "",
                        author: "",
                        isbn: "",
                        cover: "",
                        imgUrl: ""
                    };
                },
                methods: {
                    uploadcover: function() {
                        var n = this;
                        (0, a.getQiniuTk)().then(function(e) {
                            console.log(e), 0 === e.code && t.chooseImage({
                                count: 1,
                                success: function(a) {
                                    var o = a.tempFilePaths;
                                    t.uploadFile({
                                        url: "https://upload-z2.qiniup.com/",
                                        filePath: o[0],
                                        name: "file",
                                        formData: {
                                            token: e.data.qiniuToken
                                        },
                                        success: function(t) {
                                            200 === t.statusCode && (n.imgUrl = "https://daan.dreamcapsule.top/" + JSON.parse(t.data).key, 
                                            n.cover = JSON.parse(t.data).key);
                                        }
                                    });
                                }
                            });
                        });
                    },
                    submitHandler: function() {
                        "" != this.name && "" != this.author && "" != this.isbn ? (0, a.applyBook)({
                            msg: this.name,
                            author: this.author,
                            isbn: this.isbn,
                            cover: this.cover
                        }).then(function(n) {
                            console.log(n), 0 === n.code && t.showToast({
                                title: "提交成功",
                                mask: !0,
                                icon: "success",
                                success: function() {
                                    setTimeout(function() {
                                        t.navigateBack({
                                            delta: 1
                                        });
                                    }, 800);
                                }
                            });
                        }) : t.showModal({
                            title: "提示",
                            mask: !0,
                            showCancel: !1,
                            content: "字段不能为空"
                        });
                    }
                },
                onShareAppMessage: function() {
                    return {
                        title: "@你，这里有你需要的大学课后习题答案哦！",
                        imageUrl: "https://daan.dreamcapsule.top/%E6%B5%B7%E6%8A%A5.jpg" + "?userId=".concat(t.getStorageSync("uid"), "&userToken=").concat(t.getStorageSync("userToken"))
                    };
                }
            };
            n.default = o;
        }).call(this, e("543d").default);
    },
    "662a": function(t, n, e) {},
    "6baf": function(t, n, e) {
        (function(t) {
            function n(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            e("6cdc"), e("921b"), n(e("66fd")), t(n(e("cf42")).default);
        }).call(this, e("543d").createPage);
    },
    9771: function(t, n, e) {
        e.d(n, "b", function() {
            return a;
        }), e.d(n, "c", function() {
            return o;
        }), e.d(n, "a", function() {});
        var a = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, o = [];
    },
    cf42: function(t, n, e) {
        e.r(n);
        var a = e("9771"), o = e("0ad0");
        for (var c in o) "default" !== c && function(t) {
            e.d(n, t, function() {
                return o[t];
            });
        }(c);
        e("2482");
        var u = e("f0c5"), i = Object(u.a)(o.default, a.b, a.c, !1, null, "0cb3345c", null, !1, a.a, void 0);
        n.default = i.exports;
    }
}, [ [ "6baf", "common/runtime", "common/vendor" ] ] ]);
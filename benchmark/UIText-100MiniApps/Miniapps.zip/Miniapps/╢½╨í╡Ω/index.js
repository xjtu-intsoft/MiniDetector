var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../util.js")), i = requirePlugin("loginPlugin"), t = e.default.getLoginConfig(), o = require("../fm.min.js");

Page({
    data: {
        config: t,
        stopClick: !1,
        checkboxChecked: !t.author
    },
    smsloginResListener: function() {
        var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        e.default.handleJump(i.detail);
    },
    showLoad: function() {
        wx.showToast({
            title: "请阅读并勾选页面底部协议",
            icon: "none",
            duration: 3e3
        });
    },
    changeCheckbox: function(e) {
        this.setData({
            checkboxChecked: e.detail
        });
    },
    needAuthor: function() {
        this.data.checkboxChecked || this.showLoad();
    },
    getPhoneNumber: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = this.data.stopClick, o = e.detail, n = o.iv, a = o.encryptedData;
        i.clickLog({
            event: e,
            eid: "WLogin_Diversion_Wechat"
        }), n && a && (t ? wx.showToast({
            icon: "none",
            title: "请不要重复点击"
        }) : (wx.showLoading({
            title: "加载中"
        }), this.setData({
            detail: o,
            stopClick: !0
        }), this.mobileLogin(), i.clickLog({
            event: e,
            eid: "WLogin_DiversionWechat_Allow"
        })));
    },
    mobileLogin: function() {
        var t = this, o = this.data, n = o.code, a = o.detail, c = a.iv, s = a.encryptedData;
        if (n && c && s) {
            i.WXMobileLogin({
                iv: c,
                encryptedData: s,
                code: n
            }).then(function(e) {
                return 32 == e.err_code ? i.loginRequest({}) : 124 == e.err_code ? t.getWxcode() : e;
            }).then(function(t) {
                var o = t.pt_key, n = t.rsa_modulus, a = t.guid;
                !o && n && a && (t.pluginUrl = i.formatPluginPage("main")), e.default.handleJump(t);
            }).catch(function(e) {
                wx.hideLoading(), t.setData({
                    stopClick: !1
                }), console.jdLoginLog(e);
            });
        }
    },
    getWxcode: function() {
        var e = this;
        wx.login({
            success: function() {
                var i = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                console.log("页面的wxcode", i.code), e.setData({
                    code: i.code
                });
            }
        });
    },
    onLoad: function(t) {
        var o = t.riskFail;
        this.setData({
            config: e.default.getLoginConfig(t)
        }), console.log(e.default.getLoginConfig(t)), o || e.default.setLoginParamsStorage(t), 
        i.setLog({
            url: "pages/login/index/index",
            pageId: "WLogin_Diversion"
        }), e.default.setCustomNavigation(), this.getWxcode(), this.setFingerData();
    },
    setFingerData: function() {
        o.config(this, {
            bizKey: i.bizKey
        }), o.init(), o.getEid(function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            i.setJdStorageSync("finger_tk", e.tk);
        });
    },
    onShow: function() {
        i.pvLog();
    }
});
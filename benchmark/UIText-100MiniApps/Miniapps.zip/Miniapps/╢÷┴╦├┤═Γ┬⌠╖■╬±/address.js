var e = require("../../@babel/runtime/helpers/interopRequireDefault"), d = e(require("../../@babel/runtime/helpers/slicedToArray")), t = e(require("@ali/ele-arsenal")), s = getApp(), a = s.services, r = a.User, i = a.Cart, o = a.Ubt, n = a.imageHash, c = a.Geohash, l = a.AliLog, h = i.address, u = !1, f = {
    data: {
        imageHash: n,
        viewMode: "list",
        fromCheckout: !1,
        fromOrder: !1,
        address: {
            name: "",
            sex: 0,
            phone: "",
            address: "",
            address_detail: "",
            poi_type: 0
        },
        loaded: !1
    },
    loadUserAddress: function() {
        var e = this;
        h.load({
            SID: r.SID,
            userId: r.id
        }).then(function(d) {
            e.data.loaded = !0, d = e.getEditAddress(d), e.setData(s.extend([ d, e.data ]));
        });
    },
    getEditAddress: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        if ("edit" === this.mode) {
            var d = wx.getStorageSync("EDIT_ADDRESS");
            (e.addresses || []).filter(function(t) {
                t.id === d.id && (e.address = t, e.viewMode = "edit", e.fromOrder = !0, wx.removeStorageSync("EDIT_ADDRESS"));
            });
        }
        return e;
    },
    loadOrderAddress: function() {
        var e = this;
        i.loadAddress(r.SID).then(function(d) {
            var t = d.availableAddresses, s = d.unavailableAddresses, a = d.address;
            e.setData({
                address: a,
                availableAddresses: t,
                unavailableAddresses: s,
                loaded: !0
            });
        });
    },
    initAddressesData: function() {
        var e = getCurrentPages().splice(-2, 1)[0];
        e && /pages\/checkout\//.test(e.__route__) ? (this.setData({
            fromCheckout: !0
        }), this.loadOrderAddress()) : e && /pages\/location\//.test(e.__route__) ? (this.setData({
            fromLocation: !0
        }), this.showAddAddress()) : "add" === this.mode ? (this.setData({
            fromOrder: !0
        }), this.showAddAddress()) : this.loadUserAddress();
    },
    onShow: function() {
        this.exlogUpdateConfig(), "list" === this.data.viewMode && this.initAddressesData(), 
        o.sendPv(), l.sendPv();
    },
    editAddress: function(e) {
        try {
            h.edit(this.data.addresses[e.currentTarget.dataset.index]), wx.navigateTo({
                url: "/pages/address/edit/index"
            });
        } catch (d) {
            try {
                (0, t.default)().exlog.customerror("跳转编辑地址失败", d);
            } catch (e) {}
        }
    },
    goToAddAddress: function() {
        try {
            wx.navigateTo({
                url: "/pages/address/add/index"
            });
        } catch (e) {
            try {
                (0, t.default)().exlog.customerror("跳转添加地址失败", e);
            } catch (e) {}
        }
    },
    showAddAddress: function() {
        this.setData({
            viewMode: "add",
            address: {
                name: "",
                sex: 0,
                phone: "",
                address: "",
                address_detail: "",
                poi_type: 0
            }
        }), wx.setNavigationBarTitle({
            title: "新增地址"
        });
    },
    confirmAddAddress: function() {
        var e = this;
        u || (u = !0, h.add(r, this.data.address).then(function() {
            return u = !1, e.data.fromLocation ? (e.confirmAddAddressFromLocation(e.data.address), 
            void wx.switchTab({
                url: "/pages/index/index"
            })) : e.data.fromOrder ? (wx.navigateBack(), void wx.setStorageSync("UPDATE_ADDRESS", !0)) : void e.showAddressList();
        }).catch(function() {
            return u = !1;
        }));
    },
    showAddressList: function() {
        this.setData({
            viewMode: "list",
            address: {
                name: "",
                sex: 0,
                phone: "",
                address: "",
                address_detail: "",
                poi_type: 0
            }
        }), this.initAddressesData();
    },
    showEditAddress: function(e) {
        this.setData({
            viewMode: "edit",
            address: this.data.addresses[e.currentTarget.dataset.index]
        });
    },
    removeAddress: function() {
        var e = this;
        wx.showModal({
            title: "删除地址",
            content: "确定删除该收货地址吗？",
            cancelColor: "#666",
            confirmColor: "#666",
            success: function(d) {
                d.confirm && h.remove(r, e.data.address).then(function() {
                    if (e.data.fromOrder) return wx.navigateBack(), void wx.setStorageSync("UPDATE_ADDRESS", !0);
                    e.showAddressList();
                }, function(e) {
                    wx.showModal({
                        title: "删除地址失败",
                        content: "请稍后再试"
                    });
                    try {
                        (0, t.default)().exlog.customerror("删除地址失败", e);
                    } catch (e) {}
                });
            }
        });
    },
    confirmEditAddress: function() {
        var e = this;
        u || (u = !0, h.update(r, this.data.address).then(function() {
            if (u = !1, e.data.fromOrder) return wx.navigateBack(), void wx.setStorageSync("UPDATE_ADDRESS", !0);
            e.showAddressList();
        }).catch(function(e) {
            (0, t.default)().exlog.jserror("confirmEditAddress", e), u = !1;
        }));
    },
    selectAddress: function(e) {
        h.select(this.data.availableAddresses[e.currentTarget.dataset.index]), wx.navigateBack();
    },
    showEditAvailableAddress: function(e) {
        this.setData({
            viewMode: "edit",
            address: this.data.availableAddresses[e.currentTarget.dataset.index]
        });
    },
    showEditUnavailableAddress: function(e) {
        this.setData({
            viewMode: "edit",
            address: this.data.unavailableAddresses[e.currentTarget.dataset.index]
        });
    },
    confirmAddAddressFromLocation: function(e) {
        var t = c.decode(e.geohash || e.st_geohash), s = (0, d.default)(t, 2), a = s[0], r = s[1], i = {
            geohash: e.st_geohash,
            latitude: a,
            longitude: r,
            address: e.address + e.address_detail,
            name: e.address,
            city_id: e.city_id,
            district_id: e.district_id,
            city: e.city
        };
        console.log("address", i), wx.setStorageSync("FROM_LOCATION_BACK", !0), wx.setStorageSync("PLACE", i);
    },
    onError: function(e) {
        (0, t.default)().exlog.jserror("收货地址搜索页报错", e);
    },
    exlogUpdateConfig: function() {
        try {
            (0, t.default)().exlog.updateConfig({
                biz: l.getParams().spmab
            });
        } catch (e) {}
    }
};

Page(s.extend([ {}, f, require("./templates/add-or-edit-address-panel/index.js") ]));
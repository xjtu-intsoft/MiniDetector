var a = getApp();

Page({
    data: {
        domain_name: a.url,
        navLists: [ {
            id: 1,
            type: "upload-headimg",
            title: "修改头像",
            name: "headimgurl"
        }, {
            id: 2,
            type: "input",
            title: "修改名字",
            maxlength: "10",
            name: "name"
        }, {
            id: 3,
            type: "mobile",
            title: "授权手机",
            maxlength: "15",
            name: "mobile"
        } ],
        showCropperFlag: !1,
        cropperOption: {
            CROPPER_AREA_RATIO: 1,
            imageSrc: "",
            uploadUrl: "/my/save_headimg"
        },
        navListsValueFlag: ""
    },
    onLoad: function(t) {
        var e = this;
        if (a.ajax({
            method: "post",
            url: "/my/my_info",
            data: {}
        }).then(function(a) {
            var t = e.data.navLists;
            t.filter(function(t, e) {
                return t.value = a.data[t.name], t.soValue = a.data[t.name], !0;
            }), e.setData({
                navLists: t
            });
        }), 1 == a.globalData.loginInfo.user_type) {
            var n = e.data.navLists;
            n.push({
                id: 4,
                type: "set-card",
                title: "名片设置",
                name: "set_card",
                block: "top"
            }), e.setData({
                navLists: n
            });
        }
        a.updateJsCode();
    },
    upImage: function(a) {
        var t = this, e = a.currentTarget.dataset.flag;
        t.setData({
            navListsValueFlag: e
        }), wx.chooseImage({
            count: 1,
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(a) {
                var e = a.tempFilePaths[0];
                t.setData({
                    "cropperOption.imageSrc": e,
                    showCropperFlag: !0
                });
            }
        });
    },
    cropperFn: function(a) {
        var t = this.data.navListsValueFlag;
        this.setData({
            [t]: a.detail.url
        }), this.postFn("row[headimgurl]", a.detail.url);
    },
    closeCropper: function() {
        this.setData({
            showCropperFlag: !1
        });
    },
    inputAllFn: function(a) {
        var t = a.detail.value, e = a.currentTarget.dataset.flag;
        this.setData({
            [e]: t
        });
    },
    bindblurFn: function(a) {
        var t = a.detail.value, e = a.currentTarget.dataset.name, n = a.currentTarget.dataset.flag, o = a.currentTarget.dataset.index;
        if (e = "row[".concat(e, "]"), !t) return this.setData({
            [n]: this.data.navLists[o].soValue
        });
        this.postFn(e, t);
    },
    getPhoneNumber: function(t) {
        var e = this, n = t.currentTarget.dataset.str;
        a.wxGetPhoneLogin(t, function(a) {
            e.setData({
                [n]: a.mobile
            });
        });
    },
    postFn: function(t, e) {
        var n = {};
        n[t] = e, a.ajax({
            method: "post",
            url: "/my/edit_info",
            data: n
        }).then(function(n) {
            if ("row[headimgurl]" == t && 1 != a.globalData.loginInfo.user_type) {
                var o = wx.getStorageSync("loginInfo");
                o.avatar = e, wx.setStorageSync("loginInfo", o), a.globalData.loginInfo = o;
            }
        });
    },
    jumpCardEditFn: function() {
        wx.navigateTo({
            url: "/pages/my/card_edit/card_edit"
        });
    },
    jumpPosterFn: function() {
        wx.navigateTo({
            url: "/pages/my/se_poster/se_poster"
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        return a.shareFn();
    }
});
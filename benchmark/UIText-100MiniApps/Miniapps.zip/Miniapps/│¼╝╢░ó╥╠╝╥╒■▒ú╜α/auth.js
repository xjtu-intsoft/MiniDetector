require("../../utils/util.js");

var e, t, o, a = require("../../utils/md5.js"), n = getApp();

wx.getSystemInfo({
    success: function(e) {
        t = e.windowWidth, o = 750 / t;
    }
}), Page({
    data: {
        phone: "",
        code: "",
        checked: !0,
        codeText: "发送验证码",
        codeBtnDisabled: !1,
        correctVerifyCode: "",
        verifyCode: "",
        referralDisabled: !1
    },
    loginTap: function() {
        "function" == typeof n.globalData.loginCallback && n.globalData.loginCallback(), 
        wx.navigateBack({
            delta: 100
        });
    },
    codeSubmit: function(t) {
        var o = this, i = t.detail.value.phone || "", l = t.detail.value.verifyCode || "";
        if (11 == i.length) if (0 != l.length) {
            if (l.toLowerCase() != this.data.correctVerifyCode.toLowerCase()) return wx.showModal({
                title: "超级阿姨",
                content: "请输入正确的图形验证码",
                confirmText: "知道了",
                showCancel: !1
            }), this.setData({
                verifyCode: ""
            }), void this.initCodeView();
            var r = a.hexMD5("captcha" + l.toLowerCase() + "phone_number" + i + "user_typecustomer60C3DFC217DE75EDA6B5DCB4B50D022D"), c = n.globalData.production + "/users", s = {
                phone_number: i,
                user_type: "customer",
                captcha: l,
                sign: r,
                release: !0
            };
            n.call({
                url: c,
                data: s,
                type: "POST",
                successCB: function(e) {
                    "error" == e.data.status && wx.showModal({
                        title: "超级阿姨",
                        content: e.data.errors,
                        confirmText: "好的",
                        showCancel: !1
                    }), console.log("success: ", e);
                },
                failCB: function(e) {
                    console.log("fail: ", e);
                }
            }), this.setData({
                codeBtnDisabled: !0
            });
            var d, f, h = new Date();
            !function t() {
                f = new Date(), d = Math.max(0, 60 - Math.round((f.getTime() - h.getTime()) / 1e3)), 
                o.setData({
                    codeText: d + "秒后可重发"
                }), d > 0 ? (clearInterval(e), e = setInterval(t, 1e3)) : (clearInterval(e), o.setData({
                    codeText: "发送验证码",
                    codeBtnDisabled: !1
                }));
            }();
        } else wx.showModal({
            title: "超级阿姨",
            content: "请输入图形验证码",
            confirmText: "知道了",
            showCancel: !1
        }); else wx.showModal({
            title: "超级阿姨",
            content: "请输入正确的电话号码",
            confirmText: "知道了",
            showCancel: !1
        });
    },
    formSubmit: function(e) {
        var t = this, o = e.detail.value.phone, a = e.detail.value.code, i = e.detail.value.agreement, l = e.detail.value.verifyCode || "", r = e.detail.value.referral || "";
        if (0 != i.length) if (11 == o.length) if (0 != l.length) {
            if (l.toLowerCase() != this.data.correctVerifyCode.toLowerCase()) return wx.showModal({
                title: "超级阿姨",
                content: "请输入正确的图形验证码",
                confirmText: "知道了",
                showCancel: !1
            }), this.setData({
                verifyCode: ""
            }), void this.initCodeView();
            if (0 != a.length) {
                var c = n.globalData.production + "/users/login.json", s = {
                    phone_number: o,
                    password: a,
                    referral_code: r
                };
                n.getOpenId(o, function(e) {
                    e.length > 0 && n.call({
                        url: c,
                        data: s,
                        type: "POST",
                        successCB: function(a) {
                            var i = a.data.data.id, l = a.header["access-token"], c = a.header.client;
                            wx.setStorageSync("accessToken", l), wx.setStorageSync("client", c), wx.setStorageSync("phone-new", o);
                            var s = {
                                wx_openid: e,
                                user_id: i
                            };
                            t.postOpenid(s, function(e) {
                                1 == e && (a = a.data, wx.setStorageSync("customerObj", a.data), r.length > 0 ? wx.showModal({
                                    title: "绑定成功",
                                    content: "欢迎使用超级阿姨，您已绑定成功",
                                    confirmText: "知道了",
                                    showCancel: !1,
                                    success: function(e) {
                                        e.confirm && wx.navigateBack({
                                            delta: 100,
                                            complete: function(e) {}
                                        });
                                    }
                                }) : wx.navigateBack({
                                    delta: 100,
                                    complete: function(e) {
                                        setTimeout(function() {
                                            n.checkUser(function(e) {
                                                "function" == typeof n.globalData.loginCallback && n.globalData.loginCallback(o);
                                            });
                                        }, 700);
                                    }
                                }));
                            });
                        },
                        failCB: function(e) {
                            console.log("login fail: ", e), (e = e.data).errors ? wx.showModal({
                                title: "超级阿姨",
                                content: e.errors[0],
                                confirmText: "知道了",
                                showCancel: !1
                            }) : e.description && wx.showModal({
                                title: "超级阿姨",
                                content: e.description,
                                confirmText: "知道了",
                                showCancel: !1
                            });
                        }
                    });
                });
            } else wx.showModal({
                title: "超级阿姨",
                content: "请输入手机验证码",
                confirmText: "知道了",
                showCancel: !1
            });
        } else wx.showModal({
            title: "超级阿姨",
            content: "请输入图形验证码",
            confirmText: "知道了",
            showCancel: !1
        }); else wx.showModal({
            title: "超级阿姨",
            content: "请输入正确的电话号码",
            confirmText: "知道了",
            showCancel: !1
        }); else wx.showModal({
            title: "超级阿姨",
            content: "请阅读并同意《服务协议》和《隐私政策》",
            confirmText: "知道了",
            showCancel: !1
        });
    },
    cancelLoginTap: function() {
        wx.reLaunch({
            url: "../order/order?isAuth=false"
        });
    },
    postOpenid: function(e, t) {
        n.call({
            url: n.globalData.production + "/api/v1/users/wx_mini_openid",
            data: e,
            type: "POST",
            successCB: function(e) {
                "function" == typeof t && t(!0);
            },
            failCB: function(e) {
                "function" == typeof t && t(!1), console.log("postOpenid fail: ", e), (e = e.data).errors ? wx.showModal({
                    title: "超级阿姨",
                    content: e.errors[0],
                    confirmText: "知道了",
                    showCancel: !1
                }) : e.description && wx.showModal({
                    title: "超级阿姨",
                    content: e.description,
                    confirmText: "知道了",
                    showCancel: !1
                });
            }
        });
    },
    checkboxChange: function(e) {
        console.log("checkbox发生change事件，携带value值为：", e.detail.value);
    },
    agreementTap: function() {
        wx.navigateTo({
            url: "../agreement/agreement"
        });
    },
    privacyPolicyTap: function() {
        wx.navigateTo({
            url: "../PrivacyPolicy/PrivacyPolicy"
        });
    },
    codeViewTap: function() {
        this.initCodeView();
    },
    initCodeView: function() {
        for (var e = wx.createCanvasContext("firstCanvas"), t = [ "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "i", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z" ], a = "", n = 0; n < 4; n++) a += t[Math.floor(Math.random() * t.length)];
        this.setData({
            correctVerifyCode: a
        });
        var i = parseInt(100 * Math.floor(256 * Math.random()) / 255), l = parseInt(100 * Math.floor(256 * Math.random()) / 255), r = parseInt(100 * Math.floor(256 * Math.random()) / 255);
        e.setFillStyle("rgba(" + i + ", " + l + ", " + r + ", 0.5)"), e.fillRect(0, 0, 180 / o, 60 / o);
        for (var c, s, d = 155 / a.length - 10, f = 0; f < 4; f++) e.setFillStyle("black"), 
        20, e.setFontSize(20), c = Math.floor(Math.random() * d + 5) + 155 / a.length * f, 
        s = Math.floor(21 * Math.random() + 35), e.fillText(a.substr(f, 1), c / o, s / o);
        for (var h = 0; h < 10; h++) e.beginPath(), i = parseInt(100 * Math.floor(256 * Math.random()) / 255), 
        l = parseInt(100 * Math.floor(256 * Math.random()) / 255), r = parseInt(100 * Math.floor(256 * Math.random()) / 255), 
        e.setStrokeStyle("rgba(" + i + ", " + l + ", " + r + ", 0.5)"), c = Math.floor(180 * Math.random()), 
        s = Math.floor(60 * Math.random()), e.moveTo(c / o, s / o), c = Math.floor(180 * Math.random()), 
        s = Math.floor(60 * Math.random()), e.lineTo(c / o, s / o), e.stroke();
        e.draw();
    },
    onLoad: function(e) {
        console.log("Page:auth onLoad: ", e), "undefined" != e.referral && e.referral && this.setData({
            referral: e.referral,
            referralDisabled: !0
        });
    },
    onReady: function() {
        this.initCodeView();
    },
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {
        clearInterval(e);
    },
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});
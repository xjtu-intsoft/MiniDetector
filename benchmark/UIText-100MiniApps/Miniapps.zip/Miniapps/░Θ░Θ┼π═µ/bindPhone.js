(wx.webpackJsonp = wx.webpackJsonp || []).push([ [ 6 ], {
    10: function(n, t, e) {
        n.exports = e.p + "base/assets/images/lazy.gif";
    },
    1162: function(n, t, e) {
        "use strict";
        e.r(t), e(721);
        var o, a = e(2), i = e.n(a), s = (t = e(0), e.n(t)), r = e(3), c = e(5), u = e(6), p = e(14), l = e(8), f = e(12), h = e(27), y = e(51), d = e(1);
        function _(n, t) {
            for (var e = 0; e < t.length; e++) {
                var o = t[e];
                o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), 
                Object.defineProperty(n, o.key, o);
            }
        }
        function b(n, t) {
            if (!n) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? n : t;
        }
        function g() {
            var n, t;
            !function(n, t) {
                if (!(n instanceof t)) throw new TypeError("Cannot call a class as a function");
            }(this, g);
            for (var e = arguments.length, o = Array(e), a = 0; a < e; a++) o[a] = arguments[a];
            return (n = t = b(this, (n = g.__proto__ || Object.getPrototypeOf(g)).call.apply(n, [ this ].concat(o)))).$usedState = [ "anonymousState__temp", "show", "closeabled", "appPlatform", "__fn_on" ], 
            t.state = {
                show: !1
            }, t.getValide = function() {
                r.a.isLogined && Object(y.a)().then(function(n) {
                    t.setState({
                        show: !n
                    }), n || "weapp" == f.a.appPlatform && h.a.updateSession();
                });
            }, t.handleLogin = function() {
                t.getValide();
            }, t.customComponents = [], b(t, n);
        }
        e(722), a = function(n, t, e) {
            return t && _(n.prototype, t), e && _(n, e), n;
        }, (function(n, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            n.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: n,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(n, t) : n.__proto__ = t);
        }(g, t.PureComponent), a(g, [ {
            key: "_constructor",
            value: function(n) {
                (function n(t, e, o) {
                    null === t && (t = Function.prototype);
                    var a = Object.getOwnPropertyDescriptor(t, e);
                    return void 0 !== a ? "value" in a ? a.value : void 0 !== (a = a.get) ? a.call(o) : void 0 : null !== (t = Object.getPrototypeOf(t)) ? n(t, e, o) : void 0;
                })(g.prototype.__proto__ || Object.getPrototypeOf(g.prototype), "_constructor", this).call(this, n), 
                this.$$refs = new s.a.RefsArray();
            }
        }, {
            key: "componentWillMount",
            value: function() {
                this.getValide();
            }
        }, {
            key: "componentDidMount",
            value: function() {
                s.a.eventCenter.on(d.a.EventLogin, this.handleLogin);
            }
        }, {
            key: "componentWillUnmount",
            value: function() {
                s.a.eventCenter.off(d.a.EventLogin, this.handleLogin);
            }
        }, {
            key: "componentDidShow",
            value: function() {}
        }, {
            key: "componentDidHide",
            value: function() {}
        }, {
            key: "componentDidCatchError",
            value: function() {}
        }, {
            key: "componentDidNotFound",
            value: function() {}
        }, {
            key: "onClose",
            value: function() {
                this.setState({
                    show: !1
                }), p.a.ta.track("phone_pop", {
                    click_button: "cancel"
                });
            }
        }, {
            key: "_logOut",
            value: function() {
                r.a.logout(), c.a.doLogin();
            }
        }, {
            key: "toBind",
            value: function() {
                c.a.push("/pkgProfile/pages/profile/bindphone");
            }
        }, {
            key: "onBindgetphonenumber",
            value: (o = function(n) {
                return function() {
                    var t = n.apply(this, arguments);
                    return new Promise(function(n, e) {
                        return function o(a, i) {
                            try {
                                var s = t[a](i), r = s.value;
                            } catch (a) {
                                return void e(a);
                            }
                            if (!s.done) return Promise.resolve(r).then(function(n) {
                                o("next", n);
                            }, function(n) {
                                o("throw", n);
                            });
                            n(r);
                        }("next");
                    });
                };
            }(i.a.mark(function n(t) {
                var e;
                return i.a.wrap(function(n) {
                    for (;;) switch (n.prev = n.next) {
                      case 0:
                        if (console.log("wx自动绑定手机号"), e = this, r.a.isLogined) {
                            n.next = 5;
                            break;
                        }
                        return console.log("wdl"), n.abrupt("return");

                      case 5:
                        p.a.ta.track("phone_pop", {
                            click_button: "ok"
                        }), s.a.checkSession({
                            success: function() {
                                var n = (o = t.detail).encryptedData, o = o.iv;
                                n && o ? u.a.postJson("mini/bindPhone", {
                                    data: encodeURIComponent(n),
                                    iv: encodeURIComponent(o),
                                    session_key: r.a.sessionKey
                                }).then(function() {
                                    console.log("手机号绑定ok"), e.onClose(), l.a.show("绑定成功"), s.a.eventCenter.trigger("BindPhone:OK"), 
                                    p.a.ta.track("phone_wechat_pop", {
                                        click_button: "ok"
                                    });
                                }).catch(function(n) {
                                    l.a.show(n.message || "绑定失败"), e._logOut(), p.a.ta.track("phone_wechat_pop", {
                                        click_button: n.message || "绑定失败"
                                    });
                                }) : c.a.push("/pkgProfile/pages/profile/bindphone");
                            },
                            fail: function(n) {
                                console.log("session 失效", n), e._logOut(), l.a.show("绑定失败"), p.a.ta.track("phone_wechat_pop", {
                                    click_button: JSON.stringify(n) || "session 失效"
                                });
                            }
                        });

                      case 7:
                      case "end":
                        return n.stop();
                    }
                }, n, this);
            })), function(n) {
                return o.apply(this, arguments);
            })
        }, {
            key: "_createData",
            value: function() {
                var n = this;
                this.__state = arguments[0] || this.state || {}, this.__props = arguments[1] || this.props || {}, 
                this.$prefix;
                var t = this.__props.closeabled, o = this.__state.show, a = f.a.appPlatform;
                return o ? (this.anonymousFunc0 = function(n) {
                    n.stopPropagation();
                }, this.anonymousFunc1 = function(e) {
                    e.stopPropagation(), t && n.onClose();
                }, o = t ? e(723) : null, Object.assign(this.__state, {
                    anonymousState__temp: o,
                    closeabled: t,
                    appPlatform: a
                }), this.__state) : null;
            }
        }, {
            key: "anonymousFunc0",
            value: function(n) {
                n.stopPropagation();
            }
        }, {
            key: "anonymousFunc1",
            value: function(n) {
                n.stopPropagation();
            }
        } ]), a = t = g, t.$$events = [ "anonymousFunc0", "anonymousFunc1", "onBindgetphonenumber", "toBind" ], 
        t.$$componentPath = "base/components/bindPhone/bindPhone", t = a).defaultProps = {
            closeabled: !1
        }, a = t, Component(e(0).default.createComponent(t));
    },
    220: function(n, t, e) {
        n.exports = e.p + "base/components/bindPhone/bindPhone.wxml";
    },
    721: function(n, t, e) {
        "use strict";
        e(220);
    },
    722: function(n, t, e) {},
    723: function(n, t, e) {
        n.exports = e.p + "base/components/bindPhone/x.png";
    }
}, [ [ 1162, 0, 1, 2, 3 ] ] ]);
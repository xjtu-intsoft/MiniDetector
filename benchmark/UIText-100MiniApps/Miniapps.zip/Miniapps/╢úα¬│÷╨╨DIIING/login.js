var e, t, o = getApp(), a = require("../../utils/util.js"), n = require("../../managerJs/APIManager.js"), a = require("../../utils/util.js");

Page({
    data: {
        userInfo: {},
        phone: "",
        code: "",
        message: "发送验证码",
        plain: !0,
        disabled: !1,
        selected: !1,
        textcolor: "color:#D9D8D8",
        fromP: "home",
        showProtocal: !1
    },
    disagree: function() {
        this.setData({
            showProtocal: !1
        });
    },
    onPullDownRefresh: function() {
        wx.stopPullDownRefresh();
    },
    onLoad: function(e) {
        var o = this;
        e.from && o.setData({
            fromP: e.from
        }), t = e.backPage;
    },
    onReady: function() {},
    onShow: function() {
        clearInterval(e), this.setGetVcodeBtnStatus(!0, 0);
    },
    onHide: function() {
        clearInterval(e);
    },
    onUnload: function() {},
    getPhone: function(e) {
        this.setData({
            phone: e.detail.value
        });
    },
    checkcode: function(e) {
        this.setData({
            code: e.detail.value
        });
    },
    getWebvcode: function(t) {
        var o = this;
        wx.showLoading({
            title: "正在获取验证码..."
        }), n.getVcode(t, function(t) {
            0 != t.retcode ? a.showTips(t.retmsg, "success", "../../img/error@3x.png", 1, !0, function() {
                clearInterval(e), o.setGetVcodeBtnStatus(!0, 0), console.log("获取验证码失败弹出窗成功");
            }, null) : a.showTips("获取验证码成功", "success", null, 1, null);
        }, function() {
            a.showTips("请检查您的网络", "fail", "../../img/error@3x.png", 1, null), clearInterval(e), 
            o.setGetVcodeBtnStatus(!0, 0);
        });
    },
    getcheckcode: function(t) {
        var o = this;
        if (1 != o.data.selected) {
            o.setData({
                selected: !1
            });
            var n = this.data.phone;
            if (1 == this.isMobilePhone(n)) {
                o.setGetVcodeBtnStatus(!1, 60);
                var s = 60;
                e = setInterval(function() {
                    0 == s ? (clearInterval(e), o.setGetVcodeBtnStatus(!0, 0)) : s > 0 && (s -= 1, o.setGetVcodeBtnStatus(!1, s));
                }, 1e3), o.getWebvcode(n);
            } else a.showTips("请输入正确手机号", "fail", "../../img/error@3x.png", 1, null);
        } else console.log("重复点击");
    },
    setGetVcodeBtnStatus: function(e, t) {
        var o = this;
        e ? o.setData({
            message: "获取验证码",
            disabled: !1,
            selected: !1,
            textcolor: "color:#7664F4"
        }) : o.setData({
            message: "重新发送(" + t + "s)",
            disabled: !0,
            selected: !0,
            textcolor: "color:#D9D8D8"
        });
    },
    agree: function() {
        this.setData({
            showProtocal: !1
        });
        var e = this.data.phone, t = this.data.code;
        e && t ? this.isMobilePhone(e) ? this.getLoginApi(e, t) : a.showTips("请填正确手机号", "fail", "../../img/error@3x.png", 1, null) : a.showTips("验证码或手机号缺失", "fail", "../../img/error@3x.png", 1, null);
    },
    loadin: function(e, t) {
        var e = this.data.phone, t = this.data.code;
        "" != e && "" != t && this.setData({
            showProtocal: !0
        });
    },
    getLoginApi: function(t, s) {
        var i = this;
        wx.showLoading({
            title: "正在登录..."
        }), n.login(t, s, function(t) {
            if (wx.hideLoading(), 0 == t.retcode) {
                n.getBizInfo(function(t) {
                    wx.setStorageSync("bizinfo", t), 0 != t.retcode ? a.showTips("登录失败请重试", "fail", "../../img/error@3x.png", 1, null) : (clearInterval(e), 
                    "bindcard" == i.data.fromP ? wx.navigateBack({
                        delta: 1
                    }) : (o.globalData.login = !0, o.globalData.firstLogin = !0, wx.navigateBack({
                        delta: 1
                    })));
                });
            } else a.showTips(t.retmsg, "fail", "../../img/error@3x.png", 1, null);
        });
    },
    isMobilePhone: function(e) {
        return !!/^1(3|4|5|7|8|6|9)\d{9}$/.test(e);
    },
    goUserProtocol: function() {
        wx.navigateTo({
            url: "../protocal/protocal?url=" + a.h5ProtocalUrl.privacyUrl
        });
    }
});
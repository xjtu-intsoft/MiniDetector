(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/artist/artist" ], {
    "2bd1": function(t, e, n) {
        (function(t) {
            function e(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }
            n("aa3e"), e(n("66fd")), t(e(n("3778")).default);
        }).call(this, n("543d").createPage);
    },
    3778: function(t, e, n) {
        n.r(e);
        var i = n("548a"), o = n("939c");
        for (var r in o) "default" !== r && function(t) {
            n.d(e, t, function() {
                return o[t];
            });
        }(r);
        n("9d29");
        var a = n("f0c5"), c = Object(a.a)(o.default, i.b, i.c, !1, null, "7b903480", null, !1, i.a, void 0);
        e.default = c.exports;
    },
    4417: function(t, e, n) {
        (function(t) {
            function i(t, e) {
                var n = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var i = Object.getOwnPropertySymbols(t);
                    e && (i = i.filter(function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable;
                    })), n.push.apply(n, i);
                }
                return n;
            }
            function o(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? i(Object(n), !0).forEach(function(e) {
                        r(t, e, n[e]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : i(Object(n)).forEach(function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e));
                    });
                }
                return t;
            }
            function r(t, e, n) {
                return e in t ? Object.defineProperty(t, e, {
                    value: n,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = n, t;
            }
            function a(t) {
                return l(t) || s(t) || u(t) || c();
            }
            function c() {
                throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            function u(t, e) {
                if (t) {
                    if ("string" == typeof t) return f(t, e);
                    var n = Object.prototype.toString.call(t).slice(8, -1);
                    return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? f(t, e) : void 0;
                }
            }
            function s(t) {
                if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t);
            }
            function l(t) {
                if (Array.isArray(t)) return f(t);
            }
            function f(t, e) {
                (null == e || e > t.length) && (e = t.length);
                for (var n = 0, i = new Array(e); n < e; n++) i[n] = t[n];
                return i;
            }
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var d = function(t) {
                return t && t.__esModule ? t : {
                    default: t
                };
            }(n("66fd")), h = {
                data: function() {
                    return {
                        list: [],
                        page: 0,
                        size: 10,
                        search_val: "",
                        no_more: !1,
                        admin_count: 0,
                        timeout: null
                    };
                },
                onLoad: function(e) {
                    t.showLoading({
                        title: "拉取中..."
                    }), this.handleConfig();
                },
                onPullDownRefresh: function() {
                    this.search_val = "", this.clean(), this.getList();
                },
                onReachBottom: function() {
                    this.getList();
                },
                onShareAppMessage: function() {
                    this.$incrementScore(5);
                },
                onShareTimeline: function() {},
                onTabItemTap: function() {
                    var e = this;
                    this.admin_count++, this.timeout || (this.timeout = setTimeout(function() {
                        6 === e.admin_count ? (t.showToast({
                            title: "管理员模式"
                        }), d.default.prototype.$is_admin_mode = !0) : d.default.prototype.$is_admin_mode = !1, 
                        clearTimeout(e.timeout), e.timeout = null, e.admin_count = 0;
                    }, 3e3));
                },
                methods: {
                    handleConfig: function() {
                        var t = this;
                        this.isVerifyStatus() ? this.getList() : this.$http.read("Config", {
                            where: {
                                platform: "weixin_mp"
                            }
                        }).then(function(e) {
                            var n = e[0];
                            t.$global_data.status = n.status;
                        }).finally(function(e) {
                            t.getList();
                        });
                    },
                    getList: function() {
                        var e = this;
                        if (!this.no_more) {
                            var n = this.search_val;
                            n && this.clean();
                            var i = {};
                            this.$is_admin_mode || (this.$global_data.status !== this.$global_data.VERIFY_STATUS_NUMBER ? i.status = 1 : i.verify = 1), 
                            n && (i.name = {
                                $regex: n,
                                $options: "i"
                            }), this.$http.read("Artist", {
                                limit: this.size,
                                skip: this.size * this.page,
                                order: "-updatedAt",
                                where: i
                            }).then(function(n) {
                                if (!n.length) return e.no_more = !0, void t.showToast({
                                    title: "没有更多了",
                                    icon: "none"
                                });
                                e.list = [].concat(a(e.list), a(n.map(function(t) {
                                    return o(o({}, t), {}, {
                                        cover_img: t.cover_img + "?imageView2/0/w/200/h/200",
                                        background_color: "rgba(".concat(~~(255 * Math.random()) - 120, ", ").concat(~~(255 * Math.random()) - 120, ", ").concat(~~(255 * Math.random()) - 120, ", 0.3)")
                                    });
                                }))), e.page = e.page + 1, t.stopPullDownRefresh();
                            }).catch(function(e) {
                                t.showModal({
                                    title: "提示",
                                    content: e.message
                                }), t.stopPullDownRefresh();
                            }).finally(function(e) {
                                t.hideLoading();
                            });
                        }
                    },
                    search: function(t) {
                        var e = t.detail.value;
                        e || (e = t.target.value);
                        var n = e.trim();
                        this.search_val = n, n ? this.getList(n) : (this.clean(), this.getList());
                    },
                    clean: function() {
                        this.page = 0, this.no_more = !1, this.list = [];
                    },
                    adLoad: function() {
                        this.$incrementScore(2);
                    }
                }
            };
            e.default = h;
        }).call(this, n("543d").default);
    },
    "548a": function(t, e, n) {
        n.d(e, "b", function() {
            return i;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {});
        var i = function() {
            var t = this;
            t.$createElement;
            t._self._c;
        }, o = [];
    },
    "939c": function(t, e, n) {
        n.r(e);
        var i = n("4417"), o = n.n(i);
        for (var r in i) "default" !== r && function(t) {
            n.d(e, t, function() {
                return i[t];
            });
        }(r);
        e.default = o.a;
    },
    "9d29": function(t, e, n) {
        var i = n("e709");
        n.n(i).a;
    },
    e709: function(t, e, n) {}
}, [ [ "2bd1", "common/runtime", "common/vendor" ] ] ]);
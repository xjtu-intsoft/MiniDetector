var t = "", e = require("../../../../utils/qs");

Component({
    properties: {},
    data: {
        code: "获取验证码",
        num: 60,
        oneclick: !1,
        imgshow: !1,
        phone: null,
        codeNum: null,
        imageUrl: "",
        api_ticket: "",
        verify_code: "",
        image_code: "",
        logined: 0
    },
    methods: {
        goAgreement: function() {
            wx.navigateTo({
                url: "../../../pages/public/webview/webview?title=用户协议及隐私政策&url=https://picture.eclicks.cn/kaojiazhao/public/claim/yhxy.html"
            });
        },
        settTest: function() {
            var e = this;
            e.data.num--, e.data.num > 0 ? e.setData({
                code: e.data.num + "s"
            }) : (clearInterval(t), e.setData({
                code: "重新获取",
                num: 60,
                oneclick: !1
            }));
        },
        testcode: function(a) {
            var i = this;
            if (null != this.data.phone) if (/^1\d{10}$/.test(this.data.phone)) {
                if (!i.data.oneclick) {
                    var s = {};
                    s.phone = 1 * i.data.phone, 1 == a && (s.verify_code = i.data.verify_code, s.image_code = i.data.image_code, 
                    s.api_ticket = i.data.api_ticket), wx.request({
                        url: getApp().pass_port + "api_v2/get_sms_captcha?os=h5",
                        header: {
                            "content-type": "application/x-www-form-urlencoded"
                        },
                        method: "post",
                        data: e.json2Form(s),
                        success: function(a) {
                            if (1 == a.data.code) i.setData({
                                oneclick: !0
                            }), clearInterval(t), t = setInterval(i.settTest.bind(i), 1e3); else if (15001 == a.data.code) {
                                i.setData({
                                    api_ticket: a.data.data.api_ticket,
                                    imgshow: !0
                                });
                                var s = a.data.data.captcha_url;
                                getApp().change_api_show || "https" != s.substring(0, 5) && (s = "https" + s.substring(4, s.length - 1)), 
                                i.refesh(s);
                            } else e.setDataToptips(i, a.data.msg);
                        }
                    });
                }
            } else e.setDataToptips(this, "请输入正确的手机号"); else e.setDataToptips(this, "手机号不能为空");
        },
        refesh: function(t) {
            var e = this;
            wx.request({
                url: t,
                method: "get",
                responseType: "arraybuffer",
                header: {
                    "content-type": "application/json;charset=UTF-8"
                },
                success: function(t) {
                    var a = wx.arrayBufferToBase64(t.data);
                    e.setData({
                        imageUrl: "data:image/png;base64," + a,
                        image_code: t.header["Set-Cookie"].split(";")[0].split("=")[1]
                    });
                }
            });
        },
        getPhone: function(t) {
            this.data.phone = this.trim(t.detail.value);
        },
        getImgcode: function(t) {
            this.data.verify_code = this.trim(t.detail.value);
        },
        getCode: function(t) {
            this.data.codeNum = this.trim(t.detail.value);
        },
        trim: function(t) {
            return t.replace(/^\s+/, "").replace(/\s+$/, "");
        },
        delImgCode: function(t) {
            if (this.data.logined) this.goLogin(); else if (1 * t.currentTarget.dataset.del) {
                if ("" == this.data.verify_code) return void e.setDataToptips(this, "图形验证码不能为空");
                if (4 != this.data.verify_code.length) return void e.setDataToptips(this, "请输入正确的图形验证码");
                this.testcode(1), this.setData({
                    imgshow: !1
                });
            } else this.setData({
                imgshow: !1
            });
        },
        goLogin: function() {
            var t = this;
            if (null != this.data.phone) if (/^1\d{10}$/.test(this.data.phone)) if (null != this.data.codeNum) if (6 == this.data.codeNum.length) {
                var a = {};
                a.phone = t.data.phone, a.captcha = t.data.codeNum, 1 == this.data.logined && (a.verify_code = t.data.verify_code, 
                a.image_code = t.data.image_code, a.api_ticket = t.data.api_ticket), wx.request({
                    url: getApp().pass_port + "api_v2/login_with_captcha?os=h5",
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    method: "post",
                    data: e.json2Form(a),
                    success: function(a) {
                        if (1 == a.data.code) {
                            var i = t.data.phone, s = a.data.data;
                            s.phone = t.data.phone, s.phonemd = i.replace(/(\d{3})\d{5}(\d{3})/, "$1*****$2"), 
                            wx.setStorageSync("cl_login_msg", s), t.go_jihuo_bgcart({
                                uid: a.data.data.uid,
                                tel: t.data.phone
                            });
                        } else if (15001 == a.data.code) {
                            t.setData({
                                api_ticket: a.data.data.api_ticket,
                                imgshow: !0,
                                logined: 1
                            });
                            var o = a.data.data.captcha_url;
                            getApp().change_api_show || "https" != o.substring(0, 5) && (o = "https" + o.substring(4, o.length - 1)), 
                            t.refesh(o);
                        } else e.setDataToptips(t, a.data.msg);
                    }
                });
            } else e.setDataToptips(this, "请输入正确的验证码"); else e.setDataToptips(this, "验证码不能为空"); else e.setDataToptips(this, "请输入正确的手机号"); else e.setDataToptips(this, "手机号不能为空");
        },
        go_jihuo_bgcart: function(t) {
            var a = this, i = getApp().getApiParams();
            i.uid = t.uid, i.tel = t.tel, wx.request({
                url: getApp().JK_BASE_URL + "/xc_v6/jktWxapp/shareOpenInsurance?" + getApp().getSendUrl(i),
                header: {
                    "content-type": "application/json"
                },
                method: "get",
                success: function(t) {
                    if (console.log(t.data), 1 == t.data.code) {
                        var i = {
                            init_code: 1
                        }, s = {};
                        a.triggerEvent("myevent", i, s);
                    } else e.setDataToptips(a, t.data.message);
                }
            });
        }
    }
});
var t = require("../../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../../@babel/runtime/helpers/defineProperty")), i = getApp().globalData, e = i.Api.UserBaseInfo, a = i.$post;

Page({
    data: {
        loading: !1,
        weight: 0,
        weightList: [],
        height: 0,
        heightList: [],
        index: "",
        user: {}
    },
    onLoad: function(t) {
        this.initHeightList(), this.initWeightList();
        var i = t.index, e = getApp().globalData.memberListBrief[i];
        this.setData({
            user: e,
            index: i,
            weight: Math.max((e.weight || 0) - 20, 0),
            height: Math.max((e.height || 0) - 100, 0)
        });
    },
    initHeightList: function() {
        for (var t = [], i = 100; i <= 200; i++) t.push(i);
        this.setData({
            heightList: t
        });
    },
    initWeightList: function() {
        for (var t = [], i = 20; i <= 100; i++) t.push(i);
        this.setData({
            weightList: t
        });
    },
    changePicker: function(i) {
        this.setData((0, t.default)({}, i.target.dataset.key, i.detail.value));
    },
    submit: function() {
        var t = this;
        if (this.data.loading) return !1;
        this.setData({
            loading: !0
        }), a({
            url: e,
            params: {
                height: this.data.heightList[this.data.height],
                weight: this.data.weightList[this.data.weight],
                memberId: this.data.user.memberId,
                merchantId: this.data.user.merchantId
            }
        }).then(function(i) {
            getApp().globalData.memberList[t.data.index].weight = t.data.weightList[t.data.weight], 
            getApp().globalData.memberList[t.data.index].height = t.data.heightList[t.data.height], 
            t.setData({
                loading: !1
            }), wx.redirectTo({
                url: "/pages/mine/user-info/user-info?index=" + t.data.index
            });
        }, function() {
            t.setData({
                loading: !1
            });
        });
    }
});
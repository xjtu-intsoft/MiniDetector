function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var t = require("../../config/config"), a = e(require("../../utils/platform")), n = e(require("../../utils/datamodel")), o = require("../../utils/util"), i = require("../..//utils/auth"), r = require("../../utils/wxcharts"), l = getApp(), c = l.globalData.appInfo, s = {
    flag: null,
    hasDriveCount: 0,
    wantDriveCount: 0
};

Page({
    data: {
        ch: "",
        carLogo: "",
        carModel: "",
        modelName: "",
        carTime: "",
        carMile: "",
        city: "",
        emission: "",
        maintain: "",
        accident: "",
        reportId: null,
        priceBn: "-",
        evalPrice: "-",
        compre: "-",
        antiCompre: "-",
        antiCompreRatio: "-",
        monthlyDepreciation: "-",
        carMonthes: 0,
        carYears: 0,
        totalSearchCount: "-",
        modelSearchCount: "-",
        hasDriveFlag: null,
        hasDriveCount: 0,
        wantDriveCount: 0,
        commentRecommend: 1,
        isCommented: null,
        comment: "",
        commitCommentBtn: !1,
        phone: "",
        privatePlatform: [],
        auctionPlatform: []
    },
    closeComment: function(e) {
        "comment-wrapper" === e.target.id && this.setData({
            isCommented: null
        });
    },
    doComment: function(e) {
        var t = !!e.detail.value;
        this.setData({
            comment: e.detail.value,
            commitCommentBtn: t
        });
    },
    commitComment: function(e) {
        var a = this, o = c.currentModelSelect.slug, i = this.data.comment;
        if (i) {
            var r = l.getLoginToken().token;
            (0, n.default)(t.CAR_COMMENTS_API, {
                model_slug: o,
                attitude: !0 === this.data.hasDriveFlag ? this.data.commentRecommend : 0,
                comment: i
            }, {
                method: "POST",
                header: {
                    Authorization: "JWT " + r
                },
                show_loading: !0,
                show_error_dialog: !0
            }, function(e, t) {
                e || (a.setData({
                    isCommented: !0
                }), wx.navigateTo({
                    url: "../usercenter/comments/comments?model_slug=" + o
                }));
            });
        }
    },
    getIsCommented: function(e) {
        var a = this;
        (0, i.isLoginV2)().then(function(o, i) {
            (0, n.default)(t.CAR_COMMENTS_API, {
                self: 1,
                model_slug: e
            }, {
                header: {
                    Authorization: "JWT " + i.token
                }
            }, function(e, t) {
                var n = !1;
                !e && t.data.count > 0 && (n = !0, setTimeout(function() {
                    wx.showToast({
                        title: "您已经发表评论",
                        icon: "success",
                        duration: 1e3
                    });
                }, 500)), a.setData({
                    isCommented: n,
                    comment: "",
                    commitCommentBtn: !1
                });
            });
        });
    },
    phoneInputhandler: function(e) {
        var t = e.detail.value;
        this.setData({
            phone: t
        });
    },
    toggleSelectPlatform: function(e) {
        var t = e.currentTarget.dataset.platform;
        this.setData({
            privatePlatform: this.data.privatePlatform.map(function(e) {
                return e.dealer_name === t && (e.selected = !e.selected), e;
            }),
            auctionPlatform: this.data.auctionPlatform.map(function(e) {
                return e.dealer_name === t && (e.selected = !e.selected), e;
            })
        });
    },
    sellCar: function(e) {
        (0, o.isValidPhone)(this.data.phone) ? this.data.privatePlatform.filter(function(e) {
            return e.selected;
        }).length + this.data.auctionPlatform.filter(function(e) {
            return e.selected;
        }).length !== 0 ? (0, n.default)(t.SELL_CAR_SUBMIT, {
            brand: c.currentBrandSelect.slug,
            model: c.currentModelSelect.slug,
            model_detail: c.currentModelDetailSelect.slug,
            phone: this.data.phone,
            mile: +c.mile,
            year: c.year,
            month: c.month,
            city: c.city,
            source: "wx_mina_" + this.data.ch
        }, {
            method: "POST",
            hideErrTip: !0
        }, function(e, t) {
            e ? t && t.data && 100210001 === t.data.code ? wx.showModal({
                content: "您已提交过卖车信息",
                showCancel: !1
            }) : wx.showModal({
                content: e,
                showCancel: !1
            }) : wx.showModal({
                content: "恭喜您，提交卖车信息成功！",
                showCancel: !1
            });
        }) : wx.showModal({
            content: "请至少选择一个卖车平台",
            showCancel: !1
        }) : wx.showModal({
            content: "请输入正确的手机号码",
            showCancel: !1
        });
    },
    setRecommend: function(e) {
        var t = e.currentTarget.dataset.recommend;
        this.setData({
            commentRecommend: t
        });
    },
    loginGuideAllow: function(e) {
        var t = this;
        l.getUserInfo(function(a, n) {
            a ? "USER_REJECT_ALLOW" === a ? "EVAL" === e ? wx.showModal({
                content: "您拒绝了用户信息授权，暂无法保存您的报告",
                showCancel: !1,
                success: function(e) {
                    l.resetAppInfo(), wx.navigateBack({
                        delta: 2
                    });
                }
            }) : wx.showModal({
                content: "您拒绝了用户信息授权，暂无法使用该功能，请稍后重试",
                showCancel: !1
            }) : wx.showModal({
                content: "登录失败，请稍后重试",
                showCancel: !1
            }) : l.saveReportData(function() {
                "SET_WANT_DRIVE" === e ? t.getWantDriveData(!0) : "EVAL" === e && (wx.showToast({
                    title: "已保存估值报告",
                    icon: "success",
                    duration: 1e3
                }), setTimeout(function() {
                    l.resetAppInfo(), wx.navigateBack({
                        delta: 2
                    });
                }, 1e3));
            });
        });
    },
    gotoRank: function() {
        wx.navigateTo({
            url: "../rank/rank"
        });
    },
    back: function() {
        var e = this;
        (0, i.isLogin)(function(t, a) {
            t ? wx.showModal({
                content: "是否保存您的估计报告？",
                confirmText: "保存",
                cancelText: "不，谢谢",
                success: function(t) {
                    t.confirm ? e.loginGuideAllow("EVAL") : (l.resetAppInfo(), wx.navigateBack({
                        delta: 2
                    }));
                }
            }) : (l.resetAppInfo(), wx.navigateBack({
                delta: 2
            }));
        });
    },
    onShareAppMessage: function() {
        var e = l.getLoginToken(), t = e.uuid, a = e.nickname;
        return this.data.reportId ? {
            title: "评估汪：爱车评估吓了一跳，敢来测吗？",
            desc: " ",
            path: "/pages/sharereport/sharereport?" + (0, o.buildQuery)({
                share_type: "eval_report_c2c",
                share_from: t || "",
                report_id: this.data.reportId,
                backbtn: "show",
                nickname: a || ""
            })
        } : {
            title: "评估汪：爱车评估吓了一跳，敢来测吗？",
            desc: " ",
            path: "/pages/index/index?" + (0, o.buildQuery)({
                share_type: "others",
                share_from: t || ""
            })
        };
    },
    onPullDownRefresh: function() {
        this.getReportData(function() {
            wx.stopPullDownRefresh();
        });
    },
    renderChart: function(e, t, a) {
        var n = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : 0;
        new r({
            animation: !0,
            canvasId: e,
            type: "ring",
            offsetAngle: n,
            title: {
                name: a,
                fontSize: 18,
                color: "#ff701b"
            },
            subtitle: {
                name: "每月贬值",
                fontSize: 12,
                color: "#999999"
            },
            series: t,
            width: 150,
            height: 150,
            dataLabel: !1,
            legend: !1,
            padding: 0
        });
    },
    getReportData: function(e) {
        var a = this;
        e = e || function() {
            return !0;
        };
        var o = {};
        (0, i.isLogin)(function(i, r) {
            i || (o.Authorization = "JWT " + r.token), (0, n.default)(t.EVAL_REPORT_C2C, {
                model_detail_slug: c.currentModelDetailSelect.slug,
                year: c.year,
                month: c.month,
                mile: c.mile,
                city: c.city,
                accident: c.accident,
                maintenance: c.maintain
            }, {
                show_loading: !0,
                show_error_dialog: !0,
                header: o
            }, function(t, n) {
                !1 === e() || t || a.processData(n.data.data);
            });
        });
    },
    setWantDriveHandler: function(e) {
        var t = e.currentTarget.dataset.flag;
        t !== this.data.hasDriveFlag && this.setWantDrive(t);
    },
    setWantDrive: function(e) {
        var a = this;
        (0, i.isLoginV2)().then(function(o, i) {
            o ? a.loginGuideAllow("SET_WANT_DRIVE") : (0, n.default)(t.USER_WANT_DRIVE_API, {
                model_slug: c.currentModelSelect.slug,
                has_driven: e
            }, {
                method: "PUT",
                header: {
                    Authorization: "JWT " + i.token
                }
            }, function(e, t) {
                var n = t.data.has_driven;
                !0 === n ? a.setData({
                    hasDriveFlag: !0,
                    hasDriveCount: s.hasDriveCount + 1,
                    wantDriveCount: s.wantDriveCount
                }) : !1 === n && a.setData({
                    hasDriveFlag: !1,
                    hasDriveCount: s.hasDriveCount,
                    wantDriveCount: s.wantDriveCount + 1
                }), a.getIsCommented(c.currentModelSelect.slug);
            });
        });
    },
    getWantDriveData: function(e) {
        var a = this, o = {};
        (0, i.isLogin)(function(i, r) {
            i || (o.Authorization = "JWT " + r.token), (0, n.default)(t.USER_WANT_DRIVE_API, {
                model_slug: c.currentModelSelect.slug
            }, {
                header: o
            }, function(t, n) {
                t || (s.flag = n.data.has_driven, s.hasDriveCount = +n.data.has_driven_counts[1], 
                s.wantDriveCount = +n.data.has_driven_counts[0], a.setData({
                    hasDriveFlag: s.flag,
                    hasDriveCount: s.hasDriveCount,
                    wantDriveCount: s.wantDriveCount
                }), e && a.getIsCommented(c.currentModelSelect.slug));
            });
        });
    },
    processData: function(e) {
        var t = e.price_bn, a = e.eval_price, n = e.report_id, o = e.month_depreciation, i = Math.round(o.monthly_depreciation * o.months), r = 1e4 * t - i, l = Math.round(o.monthly_depreciation), c = [ {
            data: r,
            color: "#3aadff"
        }, {
            data: i,
            color: "#ff9571"
        } ], s = a / t, u = -Math.PI * s, d = l;
        l > 1e4 && (d = (l / 1e4).toFixed(2) + "万"), this.renderChart("evalChart", c, d + "元", u);
        var h = Math.floor(o.months / 12), m = o.months % 12;
        this.setData({
            reportId: n,
            priceBn: t.toFixed(1),
            evalPrice: a.toFixed(1),
            compre: (i / 1e4).toFixed(1),
            antiCompre: (r / 1e4).toFixed(1),
            monthlyDepreciation: l,
            carMonthes: m,
            carYears: h,
            antiCompreRatio: Math.round(r / t / 100)
        });
    },
    getSellCarPlatform: function(e) {
        var t = e.map(function(e) {
            return e.selected = !0, e;
        });
        this.setData({
            privatePlatform: t.filter(function(e) {
                return "personal" === e.dealer_type;
            }),
            auctionPlatform: t.filter(function(e) {
                return "dealer" === e.dealer_type;
            })
        });
    },
    onLoad: function() {
        this.setData({
            ch: c.ch || "direct",
            carLogo: c.currentModelSelect.logo,
            carModel: c.currentModelSelect.name + " " + c.currentModelDetailSelect.name,
            carModelShort: c.currentModelSelect.name,
            modelName: c.currentModelSelect.name,
            carTime: c.year + "年" + c.month + "月",
            carMile: c.mile,
            city: c.city,
            emission: c.currentModelDetailSelect.emissionStandard,
            maintain: c.maintain,
            accident: c.accident,
            totalSearchCount: c.totalSearchCount,
            modelSearchCount: c.modelSearchCount
        }), this.getReportData(), this.getWantDriveData(), this.getSellCarPlatform(a.default);
    }
});
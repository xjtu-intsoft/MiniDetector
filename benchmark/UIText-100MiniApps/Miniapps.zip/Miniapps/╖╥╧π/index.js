var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = require("../../@babel/runtime/helpers/interopRequireWildcard"), s = require("../../2C1D277754C69A8C4A7B4F70DD008B36.js"), o = t(require("../../04BE2BE454C69A8C62D843E3D3EF7B36.js")), n = e(require("../../3C34EE6154C69A8C5A528666BFCD7B36.js")), i = getApp();

Page({
    data: {
        inviteCode: "",
        time: "获取验证码",
        currentTime: 61,
        disabled: !1,
        suffix: "",
        phone: "",
        smsCode: ""
    },
    onLoad: function(e) {
        var t = e.inviteCode;
        t && this.setData({
            inviteCode: t
        });
    },
    toUserAggreement: function() {
        wx.navigateTo({
            url: "/pages/web/index?url=".concat(n.default.agreementUrl, "/#/about/user-agreement/user")
        });
    },
    toPrivacyAggreement: function() {
        wx.navigateTo({
            url: "/pages/web/index?url=".concat(n.default.agreementUrl, "/#/about/user-agreement/privacy")
        });
    },
    phoneOnChange: function(e) {
        this.setData({
            phone: e.detail.value
        });
    },
    smsCodeChange: function(e) {
        this.setData({
            smsCode: e.detail.value
        });
    },
    getVerificationCode: function() {
        this.data.disabled || this.getCode();
    },
    getCode: function() {
        var e = this, t = e.data.phone;
        o.validatePhone(t) ? (0, s.http)("/send/loginCode", {
            phone: t
        }, "POST", !1).then(function(t) {
            if (t.success) {
                o.showToast("success", "已发送"), e.setData({
                    smsCode: "",
                    disabled: !0
                });
                var s = null, n = e.data.currentTime;
                s = setInterval(function() {
                    n--, e.setData({
                        time: n,
                        suffix: "秒后可重新获取"
                    }), n <= 0 && (clearInterval(s), e.setData({
                        time: "重新发送",
                        suffix: "",
                        currentTime: 61,
                        disabled: !1
                    }));
                }, 1e3);
            } else o.showToast("none", t.msg || "发送验证码失败，请稍后重试");
        }).catch(function(t) {
            o.showToast("none", "发送验证码失败"), e.setData({
                inviteCode: ""
            });
        }) : o.showToast("none", "请输入正确的手机号码");
    },
    loginByPhone: function() {
        var e = this.data.phone.trim();
        if (e) if (o.validatePhone(e)) if (this.data.smsCode.trim()) if (this.data.smsCode.trim().length > 6) o.showToast("none", "短信验证码不正确"); else {
            var t = this, n = {
                phone: this.data.phone.trim(),
                code: this.data.smsCode.trim()
            };
            (0, s.http)("/loginByPhone", n, "POST", !1).then(function(e) {
                if (!e.success && i.sensors.track("login_result", {
                    login_method: "手机号",
                    is_success: !1,
                    fail_reason: e.msg
                }), e.success) {
                    var t = e.data.userInfo, s = e.data.sessionId;
                    wx.setStorageSync("isLogin", !0), wx.setStorageSync("userInfo", t), wx.setStorageSync("sessionId", s), 
                    wx.setStorageSync("loginByPhone", !0), i.sensors.registerApp({
                        app_platform_type: "小程序",
                        inviteCode: t.inviteCode,
                        roleId: t.roleId
                    }), i.sensors.login(t.inviteCode), i.sensors.track("login_result", {
                        login_method: "手机号",
                        is_success: !0
                    }), i.globalData.login = !0, i.globalData.loginByPhone = !0, i.globalData.userInfo = t, 
                    i.globalData.sessionId = s, wx.reLaunch({
                        url: "/pages/index/index",
                        success: function(e) {},
                        fail: function(e) {
                            console.log("reLaunch===>", e);
                        }
                    }), wx.showToast({
                        title: "登录成功~",
                        icon: "success",
                        duration: 2e3
                    });
                } else wx.showToast({
                    title: e.msg,
                    icon: "none",
                    duration: 2e3
                });
            }).catch(function(e) {
                i.sensors.track("login_result", {
                    login_method: "手机号",
                    is_success: !1,
                    fail_reason: e
                }), console.error(e), wx.showToast({
                    title: "登录失败，请稍后重试",
                    icon: "none",
                    duration: 2e3
                }), t.setData({
                    inviteCode: ""
                });
            });
        } else o.showToast("none", "短信验证码不能为空"); else o.showToast("none", "手机号格式不正确"); else o.showToast("none", "手机号不能为空");
    }
});
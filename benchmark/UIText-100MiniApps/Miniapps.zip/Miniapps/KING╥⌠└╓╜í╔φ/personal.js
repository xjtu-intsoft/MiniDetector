var a = getApp();

require("../../libs/tabbarset.js");

Page({
    data: {
        items: [ {
            name: "超级管理员",
            value: "超级管理员",
            flag: !0
        }, {
            name: "管理员",
            value: "管理员",
            flag: !0
        }, {
            name: "前台",
            value: "前台",
            flag: !0
        }, {
            name: "教练",
            value: "教练",
            flag: !0
        }, {
            name: "会籍顾问",
            value: "会籍顾问",
            flag: !0
        }, {
            name: "VIP超级私教会员",
            value: "VIP超级私教会员",
            flag: !0
        }, {
            name: "VIP私教会员",
            value: "VIP私教会员",
            flag: !0
        }, {
            name: "VIP年卡会员",
            value: "VIP年卡会员",
            flag: !0
        }, {
            name: "普通会员",
            value: "普通会员",
            flag: !0
        }, {
            name: "游客",
            value: "游客",
            flag: !0
        } ],
        roleButtonFlag: !0,
        myRoleFlag: !0,
        mynamecardFlag: !0,
        myfriendsFlag: !0,
        mywishesFlag: !0,
        userInfo: {},
        phoneNumber: "",
        phoneNumberFlag: !0,
        manager: {},
        userType: "",
        lastType: "",
        idmyuser: "",
        personalInfo: ""
    },
    exitLogin: function() {},
    instructionsTap: function(a) {
        wx.navigateTo({
            url: "/pages/instructions/instructions"
        });
    },
    getPhoneNumber: function(e) {
        var l = this;
        console.log("cloudID-云函数获取手机号", e.detail), "getPhoneNumber:ok" == e.detail.errMsg ? wx.cloud.callFunction({
            name: "getPhone",
            data: {
                weRunData: wx.cloud.CloudID(e.detail.cloudID),
                obj: {
                    shareInfo: wx.cloud.CloudID(e.detail.cloudID)
                }
            },
            success: function(e) {
                a.globalData.phoneNumber = e.result.event.weRunData.data.phoneNumber;
                var n = "call updatemyuserphonenumber('" + a.globalData.manager.openid + "','" + a.globalData.phoneNumber + "');";
                console.log("updatemyuserphonenumberdata:", n), wx.cloud.callFunction({
                    name: "mysqltecent",
                    data: {
                        host: a.globalData.manager.host,
                        port: a.globalData.manager.port,
                        user: a.globalData.manager.user,
                        database: a.globalData.manager.database,
                        password: a.globalData.manager.password,
                        type: n
                    }
                }).then(function(e) {
                    console.log("updatemyuserphonenumber:", e), l.setData({
                        phoneNumber: e.result.rows[0][0].phoneNumber,
                        phoneNumberFlag: !0
                    }), wx.showModal({
                        title: "惊喜礼包",
                        content: "感谢您的手机号授权，请收下惊喜礼包！",
                        showCancel: !1,
                        success: function(e) {
                            e.confirm && wx.redirectTo({
                                url: "/pages/introduce/awardcredits/awardcredits?creditssourcename=手机授权有礼&&awardopenid=" + a.globalData.manager.openid
                            });
                        }
                    });
                });
            }
        }) : wx.showModal({
            title: "你拒绝了授权手机号！",
            content: "这是健身的虚拟世界，拒绝授权手机号将影响使用所有功能！"
        });
    },
    deleteManagerInfo: function(e) {
        wx.showModal({
            title: "警告",
            content: "确定不再使用当前门店吗？",
            success: function(e) {
                e.confirm ? (console.log("用户点击确定"), wx.cloud.callFunction({
                    name: "deleteManagerInfo",
                    data: {
                        openid: a.globalData.manager.openid,
                        database: a.globalData.manager.database
                    }
                }).then(function(a) {
                    console.log("deleteManagerInfo:", a), wx.reLaunch({
                        url: "/pages/first/first"
                    });
                })) : e.cancel && console.log("用户点击取消");
            }
        });
    },
    relaunchFirst: function(a) {
        wx.reLaunch({
            url: "/pages/first/first"
        });
    },
    myRoleTap: function() {
        this.setData({
            myRoleFlag: !this.data.myRoleFlag
        });
    },
    radioChange: function(e) {
        var l = this, n = this, o = e.detail.value;
        console.log("角色：", e.detail.value), wx.showModal({
            title: "角色调整",
            content: "调整为" + e.detail.value,
            success: function(e) {
                if (e.confirm) {
                    console.log("角色调整的openid:", a.globalData.manager.openid);
                    var t = 'call updatemyuserlasttype("' + a.globalData.manager.openid + '","' + o + '");';
                    console.log("updatemyuserlasttypedata:", t), wx.cloud.callFunction({
                        name: "mysqltecent",
                        data: {
                            host: a.globalData.manager.host,
                            port: a.globalData.manager.port,
                            user: a.globalData.manager.user,
                            database: a.globalData.manager.database,
                            password: a.globalData.manager.password,
                            type: t
                        }
                    }).then(function(e) {
                        a.globalData.lastType = o, n.setData({
                            myRoleFlag: !l.data.myRoleFlag
                        }), console.log("user update:", e), wx.switchTab({
                            url: "/pages/introduce/introduce"
                        });
                    });
                } else e.cancel && console.log("角色调整取消！");
            }
        });
    },
    onLoad: function(e) {
        console.log("personal-onload app.globalData:", a.globalData);
    },
    onReady: function() {
        wx.setNavigationBarTitle({
            title: a.globalData.setup.gymname
        });
    },
    onShow: function() {
        var e = !0, l = !0, n = this.data.items, o = this;
        console.log("app.globalData:", a.globalData);
        for (var t = 0; t < n.length; t++) n[t].name == a.globalData.lastType ? n[t].flag = !1 : n[t].flag = !0;
        var u = [];
        switch (e = "超级管理员" != a.globalData.userType && "管理员" != a.globalData.userType && "前台" != a.globalData.userType && "教练" != a.globalData.userType && "会籍顾问" != a.globalData.userType, 
        a.globalData.userType) {
          case "超级管理员":
            u = [ {
                name: "超级管理员",
                value: "超级管理员"
            }, {
                name: "管理员",
                value: "管理员"
            }, {
                name: "前台",
                value: "前台"
            }, {
                name: "教练",
                value: "教练"
            }, {
                name: "会籍顾问",
                value: "会籍顾问"
            }, {
                name: "VIP超级私教会员",
                value: "VIP超级私教会员"
            }, {
                name: "VIP私教会员",
                value: "VIP私教会员"
            }, {
                name: "VIP年卡会员",
                value: "VIP年卡会员"
            }, {
                name: "普通会员",
                value: "普通会员"
            }, {
                name: "游客",
                value: "游客"
            } ];
            break;

          case "管理员":
            u = [ {
                name: "管理员",
                value: "管理员"
            }, {
                name: "前台",
                value: "前台"
            }, {
                name: "教练",
                value: "教练"
            }, {
                name: "会籍顾问",
                value: "会籍顾问"
            }, {
                name: "VIP超级私教会员",
                value: "VIP超级私教会员"
            }, {
                name: "VIP私教会员",
                value: "VIP私教会员"
            }, {
                name: "VIP年卡会员",
                value: "VIP年卡会员"
            }, {
                name: "普通会员",
                value: "普通会员"
            }, {
                name: "游客",
                value: "游客"
            } ];
            break;

          case "前台":
            u = [ {
                name: "前台",
                value: "前台"
            }, {
                name: "教练",
                value: "教练"
            }, {
                name: "会籍顾问",
                value: "会籍顾问"
            }, {
                name: "VIP超级私教会员",
                value: "VIP超级私教会员"
            }, {
                name: "VIP私教会员",
                value: "VIP私教会员"
            }, {
                name: "VIP年卡会员",
                value: "VIP年卡会员"
            }, {
                name: "普通会员",
                value: "普通会员"
            }, {
                name: "游客",
                value: "游客"
            } ];
            break;

          case "教练":
            u = [ {
                name: "教练",
                value: "教练"
            }, {
                name: "会籍顾问",
                value: "会籍顾问"
            }, {
                name: "VIP超级私教会员",
                value: "VIP超级私教会员"
            }, {
                name: "VIP私教会员",
                value: "VIP私教会员"
            }, {
                name: "VIP年卡会员",
                value: "VIP年卡会员"
            }, {
                name: "普通会员",
                value: "普通会员"
            }, {
                name: "游客",
                value: "游客"
            } ];
            break;

          case "会籍顾问":
            u = [ {
                name: "会籍顾问",
                value: "会籍顾问"
            }, {
                name: "VIP超级私教会员",
                value: "VIP超级私教会员"
            }, {
                name: "VIP私教会员",
                value: "VIP私教会员"
            }, {
                name: "VIP年卡会员",
                value: "VIP年卡会员"
            }, {
                name: "普通会员",
                value: "普通会员"
            }, {
                name: "游客",
                value: "游客"
            } ];
            break;

          case "游客":
            u = [ {
                name: "VIP超级私教会员",
                value: "VIP超级私教会员"
            }, {
                name: "VIP私教会员",
                value: "VIP私教会员"
            }, {
                name: "VIP年卡会员",
                value: "VIP年卡会员"
            }, {
                name: "普通会员",
                value: "普通会员"
            }, {
                name: "游客",
                value: "游客"
            } ];
        }
        for (var s = 0; s < u.length; s++) u[s].name == a.globalData.lastType ? (u[s].checked = !0, 
        console.log("authority,i=", s)) : u[s].checked = !1;
        console.log("authority:", u), "" != a.globalData.phoneNumber && null != a.globalData.phoneNumber && null != a.globalData.phoneNumber && "null" != a.globalData.phoneNumber || (l = !1);
        var r = "call viewpersonalinfo('" + a.globalData.manager.openid + "','" + a.globalData.lastType + "');";
        wx.cloud.callFunction({
            name: "mysqltecent",
            data: {
                host: a.globalData.manager.host,
                port: a.globalData.manager.port,
                user: a.globalData.manager.user,
                database: a.globalData.manager.database,
                password: a.globalData.manager.password,
                type: r
            }
        }).then(function(t) {
            console.log(t.result.rows[0][0]), o.setData({
                phoneNumber: a.globalData.phoneNumber,
                userInfo: a.globalData.userInfo,
                items: n,
                manager: a.globalData.manager,
                userType: a.globalData.userType,
                lastType: a.globalData.lastType,
                idmyuser: a.globalData.idmyuser,
                phoneNumberFlag: l,
                authority: u,
                roleButtonFlag: e,
                personalInfo: t.result.rows[0][0]
            });
        });
    },
    statisticTap: function(a) {
        wx.navigateTo({
            url: "/pages/statistic/statistic"
        });
    },
    creditsTap: function(a) {
        wx.navigateTo({
            url: "/pages/credits/credits"
        });
    },
    couponTap: function(a) {
        wx.navigateTo({
            url: "/pages/coupon/coupon"
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {
        var e = "/pages/first/first?database=" + a.globalData.manager.database + "&&inviter=" + a.globalData.manager.openid;
        return {
            title: a.globalData.manager.gymname,
            path: e,
            imageUrl: a.globalData.setupdata.shareurl
        };
    }
});
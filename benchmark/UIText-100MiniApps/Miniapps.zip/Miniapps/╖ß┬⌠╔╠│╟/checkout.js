var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/helpers/defineProperty")), o = e(require("../../utils/dateUtil")), s = e(require("../../utils/util")), a = require("../../models/GoodsModel.js"), r = require("../../models/OrderModel.js"), n = require("../../models/AddressModel.js"), i = require("../../models/UserModel.js");

function d(e, t) {
    var o = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var s = Object.getOwnPropertySymbols(e);
        t && (s = s.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), o.push.apply(o, s);
    }
    return o;
}

function l(e) {
    for (var o = 1; o < arguments.length; o++) {
        var s = null != arguments[o] ? arguments[o] : {};
        o % 2 ? d(Object(s), !0).forEach(function(o) {
            (0, t.default)(e, o, s[o]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(s)) : d(Object(s)).forEach(function(t) {
            Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(s, t));
        });
    }
    return e;
}

var u = new a.GoodsModel(), c = new r.OrderModel(), f = new n.AddressModel(), m = new i.UserModel(), h = getApp();

Page({
    data: {
        from: "",
        orderId: "",
        goodsList: [],
        totalFee: .1,
        address: {},
        addressFlag: !1,
        validateFlag: !0,
        sumbitLoading: !1,
        note: "",
        isMember: !1,
        realNameShow: !1,
        fullname: "",
        identityNumber: ""
    },
    inputUsername: function(e) {
        this.setData({
            fullname: e.detail.value
        });
    },
    inputIdCard: function(e) {
        this.setData({
            identityNumber: e.detail.value
        });
    },
    updateUserIdCard: function() {
        var e = this;
        "" != this.data.fullname.trim() ? "" != this.data.identityNumber.trim() ? s.default.checkIdCard(this.data.identityNumber) ? m.updateUserIdCard(this.data.fullname, this.data.identityNumber, function(t) {
            t.result && 0 != t.result.code ? wx.showToast({
                title: t.result.message || "更新身份信息错误",
                icon: "none"
            }) : (e.submitOrder(), e.setData({
                realNameShow: !1
            }));
        }) : wx.showToast({
            title: "身份证号码格式不正确",
            icon: "none"
        }) : wx.showToast({
            title: "身份证号码不能为空",
            icon: "none"
        }) : wx.showToast({
            title: "姓名不能为空",
            icon: "none"
        });
    },
    onLoad: function(e) {
        var t = this;
        if (console.log(e), h.globalData.userInfo.isMember != this.data.isMember && this.setData({
            isMember: h.globalData.userInfo.isMember
        }), "order" != e.from) {
            for (var o = JSON.parse(e.goods), s = [], a = 0, r = o.length; a < r; a++) s.push(o[a].skuId);
            u.querySkuBySkuIds(s, function(e) {
                var s = e.result.data, a = [], r = 0, n = t.data.isMember;
                console.log("sku", s);
                for (var i = 0, d = o.length; i < d; i++) for (var l = o[i].skuId, u = 0, c = s.length; u < c; u++) if (l == s[u]._id) {
                    var f = s[u];
                    f.skuId = l, f.count = o[i].count > s[u].stockNum ? s[u].stockNum : o[i].count, 
                    f.specText = (f.colorTitle ? f.colorTitle : "颜色") + ": " + f.colorValue, f.sizeValue && (f.specText += " " + (f.sizeTitle ? f.sizeTitle : "尺寸") + ": " + f.sizeValue), 
                    n && f.memberPrice && (f.productPrice = f.memberPrice), f.isOnSale && !f.deleted && (r += f.productPrice * f.count, 
                    a.push(f));
                    break;
                }
                if (0 == a.length) return wx.showModal({
                    content: "商品已删除或下架，请重新选择商品"
                }), void t.setData({
                    validateFlag: !1
                });
                r *= 100, t.setData({
                    goodsList: a,
                    totalFee: r
                });
            }), f.queryDefaultAddress(function(e) {
                if (e.result && e.result.data && e.result.data.data && e.result.data.data.length > 0) {
                    var o = e.result.data.data[0];
                    t.setAddressInfo(o);
                }
            });
        } else {
            var n = e.orderId;
            c.getOrderById(n, function(e) {
                if (0 != e.result.code) return wx.showModal({
                    content: e.result.message
                }), void t.setData({
                    validateFlag: !1
                });
                for (var o = e.result.data, s = [], a = 0, r = {
                    userName: o.userName,
                    postalCode: o.postalCode,
                    province: o.province,
                    city: o.city,
                    county: o.county,
                    telNumber: o.telNumber,
                    detailInfo: o.detailInfo,
                    fullAddress: o.fullAddress
                }, i = o.orderItems, d = 0, l = i.length; d < l; d++) {
                    var u = {
                        goodsName: i[d].goodsName,
                        productPrice: i[d].price,
                        count: i[d].qty,
                        specText: i[d].specText,
                        goodsGalleryUrl: i[d].goodsGalleryUrl
                    };
                    a += u.productPrice * u.count, s.push(u);
                }
                a *= 100, t.setData({
                    orderId: n,
                    goodsList: s,
                    totalFee: a,
                    address: r,
                    addressFlag: !0,
                    note: o.note || ""
                });
            });
        }
        this.setData({
            from: e.from
        });
    },
    setAddressInfo: function(e) {
        var t = {
            userName: e.userName,
            postalCode: e.postalCode,
            province: e.provinceName,
            city: e.cityName,
            county: e.countyName,
            telNumber: e.telNumber,
            detailInfo: e.detailInfo,
            fullAddress: e.provinceName + e.cityName + e.countyName + e.detailInfo
        };
        this.setData({
            address: t,
            addressFlag: !0
        });
    },
    changeNote: function(e) {
        this.setData({
            note: e.detail.value
        });
    },
    realNameClose: function() {
        this.setData({
            realNameShow: !1
        });
    },
    getUuid: function() {
        return o.default.formatDate(new Date(), "yyyyMMddHHmmssSSS") + parseInt(10 * Math.random());
    },
    submitOrder: function() {
        var e = this;
        if (this.data.addressFlag) if (0 != this.data.goodsList.length) {
            this.setData({
                sumbitLoading: !0
            });
            var t = {
                address: this.data.address,
                from: this.data.from,
                orderId: this.data.orderId,
                note: this.data.note
            };
            if ("order" != this.data.from) {
                for (var o = this.data.goodsList, s = [], a = 0, r = o.length; a < r; a++) s.push({
                    skuId: o[a].skuId,
                    goodsId: o[a].goodsId,
                    qty: o[a].count
                });
                t.goods = s;
            }
            c.submitOrder(t, function(t) {
                if (400 != t.result.code) if (401 != t.result.code) {
                    var o = t.result.data;
                    "SUCCESS" == o.returnCode && "SUCCESS" == o.resultCode ? e.pay(o) : wx.showToast({
                        title: o.errCodeDes || o.returnMsg,
                        icon: "none"
                    });
                } else e.setData({
                    realNameShow: !0,
                    sumbitLoading: !1
                }); else wx.showToast({
                    title: t.result.message,
                    icon: "none"
                });
            });
        } else wx.showToast({
            title: "请先选择商品",
            icon: "none"
        }); else wx.showToast({
            title: "请选择收货地址",
            icon: "none"
        });
    },
    pay: function(e) {
        var t = e.payment;
        wx.requestPayment(l(l({}, t), {}, {
            success: function(e) {
                console.log("pay success", e), wx.showToast({
                    title: "支付成功"
                }), wx.requestSubscribeMessage({
                    tmplIds: [ "QHCZNnUlQGXJSzO-Cw2xqNCDoeuULf6t_I4kmVDgF5w" ],
                    complete: function() {
                        setTimeout(function() {
                            wx.reLaunch({
                                url: "/pages/my/my"
                            });
                        }, 1e3);
                    }
                });
            },
            fail: function(e) {
                console.log("pay fail", e), wx.showToast({
                    title: "支付失败",
                    icon: "none",
                    mask: !0,
                    complete: function() {
                        setTimeout(function() {
                            wx.reLaunch({
                                url: "/pages/my/my"
                            });
                        }, 2e3);
                    }
                });
            }
        }));
    },
    chooseAddress: function() {
        wx.navigateTo({
            url: "/pages/address-list/address-list?chooseMode=true"
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});
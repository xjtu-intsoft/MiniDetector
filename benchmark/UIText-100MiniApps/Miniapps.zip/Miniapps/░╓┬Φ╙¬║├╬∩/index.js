require("./../../../webpack-require")("E0Nm", Object.assign({}, require("./../../../vendors.js").modules, require("./../../../commons.js").modules, {
    E0Nm: function(t, o, n) {
        n.r(o);
        var e = n("NERQ"), a = n("hHpg"), i = n("8B9M"), s = n("HaEp"), c = Object(i.a)();
        Component({
            properties: {
                show: {
                    type: Boolean,
                    value: !1
                },
                title: {
                    type: String,
                    value: "帐号密码登录"
                },
                subTitle: {
                    type: String,
                    value: "为了你的帐号安全，请用手机号登录"
                },
                redirectUrl: {
                    type: String,
                    value: "/packages/account/settings/index"
                }
            },
            data: {
                formData: {
                    countryCode: "+86",
                    mobile: "",
                    wxMobile: "",
                    captcha: "",
                    captchaTime: null,
                    password: ""
                },
                captcha: {
                    text: "获取验证码",
                    code: "",
                    times: 1,
                    countdown: 60,
                    textStyle: "acc-code__btn--enabled",
                    btnStyle: "",
                    timer: null
                },
                loginBtn: {
                    text: "同意协议并登录",
                    disabled: !0,
                    wxDisabled: !1
                },
                agreement: {
                    text: "《用户使用协议》",
                    url: "https://bbs.youzan.com/forum.php?mod=viewthread&tid=672890&page=1&extra=#pid3837866"
                }
            },
            lifetimes: {
                attached: function() {},
                detached: function() {}
            },
            methods: {
                setState: function() {},
                _checkMobile: function(t) {
                    return !(!t || 11 != t.length);
                },
                _checkPassword: function(t) {
                    return !!t;
                },
                login: function() {
                    var t = this, o = this.data.loginBtn.disabled, n = this.data.formData, e = n.mobile, a = n.password, i = n.countryCode;
                    if (!o) {
                        if (!this._checkMobile(e)) return wx.showToast({
                            icon: "none",
                            title: "请输入正确的手机号"
                        });
                        if (!this._checkPassword(a)) return wx.showToast({
                            icon: "none",
                            title: "请输入正确的密码"
                        });
                        var r = {
                            countryCode: i,
                            mobile: e,
                            password: a
                        };
                        this._beforeLogin(), s.a.loginByPassword(r, function() {
                            return c.login(function() {}).then(function() {
                                t._loginSuccess();
                            });
                        }, function(o) {
                            if (t._loginFail(o), 135200018 === o.code || 135200019 === o.code) return t.configDialog();
                            wx.showToast({
                                icon: "none",
                                title: o.msg || "服务请求出错，请稍后再试"
                            });
                        });
                    }
                },
                _loginSuccess: function() {
                    return a.a.clear(), this.triggerEvent("loginSuccess", {}, {}), this.setData({
                        show: !1
                    }), wx.showToast({
                        title: "登录成功",
                        icon: "success",
                        mask: !1
                    });
                },
                _loginFail: function(t) {
                    a.a.clear();
                    var o = this.data.formData, n = o.mobile, e = o.password, i = !(n && e), s = o.countryCode, c = o.wxMobile;
                    if (t) {
                        var r = t.res;
                        r && r.data && r.data.countryCode && (s = r.data.countryCode, c = r.data.mobile);
                    }
                    this.setData({
                        "loginBtn.disabled": i,
                        "formData.countryCode": s,
                        "formData.wxMobile": c
                    }), this.triggerEvent("loginFail", {
                        error: t
                    }, {});
                },
                bindMobileInput: function(t) {
                    this.setData({
                        "formData.mobile": t.detail,
                        "loginBtn.disabled": !(t.detail && this.data.formData.password)
                    });
                },
                bindPasswordInput: function(t) {
                    this.setData({
                        "formData.password": t.detail,
                        "loginBtn.disabled": !(t.detail && this.data.formData.mobile)
                    });
                },
                _beforeLogin: function() {
                    this.loginLoading(), this.setData({
                        "loginBtn.disabled": !0
                    });
                },
                configDialog: function(t, o) {
                    var n, a = this;
                    if (void 0 === t && (t = !1), void 0 === o && (o = {}), t) {
                        if (!o.mobile) return wx.showToast({
                            icon: "none",
                            title: "授权获取手机号码失败，请重启小程序重新授权"
                        });
                        n = o.mobile;
                    } else {
                        if (!this.data.formData.mobile) return wx.showToast({
                            icon: "none",
                            title: "请正确填写手机号码"
                        });
                        n = this.data.formData.mobile;
                    }
                    var i = [];
                    i.push(n.substring(0, 3)), i.push("****"), i.push(n.substring(7));
                    var s = "手机号" + i.join("") + "已与其他微信帐号绑定";
                    e.a.confirm({
                        message: s,
                        confirmButtonText: "继续登录",
                        cancelButtonText: "换个手机号",
                        context: this,
                        zIndex: 99999
                    }).then(function() {
                        a.confirmLogin(o);
                    }).catch(function(t) {});
                },
                confirmLogin: function(t) {
                    void 0 === t && (t = {});
                    var o = t.mobile || this.data.formData.mobile, n = t.countryCode || this.data.formData.countryCode, e = this.data.redirectUrl, a = "/packages/account/to-bind/index?mobile=" + o + "&countryCode=" + encodeURIComponent(n) + "&redirectUrl=" + encodeURIComponent(e);
                    return wx.redirectTo({
                        url: a
                    });
                },
                _countDownForCaptchaCode: function() {
                    var t = this, o = this.data.captcha.countdown;
                    0 !== o ? (o--, this.setData({
                        "captcha.countdown": o,
                        "captcha.text": "已发送(" + o + "s)"
                    }), this.data.captcha.timer = setTimeout(function() {
                        t._countDownForCaptchaCode();
                    }, 1e3)) : this.setData({
                        "captcha.countdown": 60,
                        "captcha.text": "重新发送",
                        "captcha.btnStyle": "",
                        "captcha.textStyle": "acc-code__btn--enabled"
                    });
                },
                readAgreement: function() {
                    var t = encodeURIComponent(this.data.agreement.url), o = this.data.agreement.text;
                    wx.navigateTo({
                        url: "/pages/common/webview-page/index?src=" + t,
                        success: function() {},
                        error: function() {
                            wx.showToast({
                                icon: "none",
                                title: "打开" + o + "失败"
                            });
                        }
                    });
                },
                loginLoading: function(t) {
                    return void 0 === t && (t = "正在登录..."), a.a.clear(), a.a.loading({
                        mask: !1,
                        context: this,
                        selector: "#login-loading-van-toast",
                        message: t
                    });
                }
            }
        });
    },
    HaEp: function(t, o, n) {
        var e = n("YkMM"), a = n("8B9M"), i = Object(a.a)(), s = function(t) {
            return void 0 === t && (t = {}), t = Object.assign({
                config: {
                    skipKdtId: !0,
                    skipShopInfo: !0,
                    noQuery: !0
                },
                method: "POST",
                header: {
                    "content-type": "application/x-www-form-urlencoded"
                },
                origin: "uic",
                data: {},
                success: function() {},
                fail: function() {}
            }, t), i.request(t);
        };
        o.a = {
            fetchCode: function(t, o, n, e) {
                return s({
                    origin: "uic",
                    pathname: "/passport/login/sms.json",
                    path: "/passport/login/sms.json",
                    data: {
                        mobile: t,
                        countryCode: "+86",
                        sessionId: i.getSessionId()
                    },
                    success: function(t) {
                        n(t);
                    },
                    fail: e
                });
            },
            loginBySms: function(t, o, n) {
                return s({
                    origin: "uic",
                    pathname: "/passport/login.json",
                    path: "/passport/login.json",
                    data: t,
                    success: function(t) {
                        o(t);
                    },
                    fail: n
                });
            },
            loginByWx: function(t, o, n) {
                return s({
                    origin: "uic",
                    pathname: "/passport/login/wx.json",
                    path: "/passport/login/wx.json",
                    data: t,
                    success: function(t) {
                        return o(t);
                    },
                    fail: n
                });
            },
            loginByPassword: function(t, o, n) {
                return t.password = e.a.encrypt(t.password), s({
                    origin: "uic",
                    path: "/passport/login/password.json",
                    data: t,
                    success: function(t) {
                        o(t);
                    },
                    fail: n
                });
            }
        };
    }
}));
(global.webpackJsonp = global.webpackJsonp || []).push([ [ "components/PhoneNumber" ], {
    "5bb1": function(e, t, n) {
        n.r(t);
        var r = n("b5b5"), o = n("dacd");
        for (var a in o) "default" !== a && function(e) {
            n.d(t, e, function() {
                return o[e];
            });
        }(a);
        n("70ee");
        var u = n("f0c5"), c = Object(u.a)(o.default, r.b, r.c, !1, null, null, null, !1, r.a, void 0);
        t.default = c.exports;
    },
    "5fe9": function(e, t, n) {},
    "70ee": function(e, t, n) {
        var r = n("5fe9");
        n.n(r).a;
    },
    "8df5": function(e, t, n) {
        (function(e) {
            function r(e, t) {
                return i(e) || c(e, t) || a(e, t) || o();
            }
            function o() {
                throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
            }
            function a(e, t) {
                if (e) {
                    if ("string" == typeof e) return u(e, t);
                    var n = Object.prototype.toString.call(e).slice(8, -1);
                    return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(n) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? u(e, t) : void 0;
                }
            }
            function u(e, t) {
                (null == t || t > e.length) && (t = e.length);
                for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
                return r;
            }
            function c(e, t) {
                if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) {
                    var n = [], r = !0, o = !1, a = void 0;
                    try {
                        for (var u, c = e[Symbol.iterator](); !(r = (u = c.next()).done) && (n.push(u.value), 
                        !t || n.length !== t); r = !0) ;
                    } catch (e) {
                        o = !0, a = e;
                    } finally {
                        try {
                            r || null == c.return || c.return();
                        } finally {
                            if (o) throw a;
                        }
                    }
                    return n;
                }
            }
            function i(e) {
                if (Array.isArray(e)) return e;
            }
            function s(e, t, n, r, o, a, u) {
                try {
                    var c = e[a](u), i = c.value;
                } catch (e) {
                    return void n(e);
                }
                c.done ? t(i) : Promise.resolve(i).then(r, o);
            }
            function f(e) {
                return function() {
                    var t = this, n = arguments;
                    return new Promise(function(r, o) {
                        function a(e) {
                            s(c, r, o, a, u, "next", e);
                        }
                        function u(e) {
                            s(c, r, o, a, u, "throw", e);
                        }
                        var c = e.apply(t, n);
                        a(void 0);
                    });
                };
            }
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var l = function(e) {
                return e && e.__esModule ? e : {
                    default: e
                };
            }(n("4795")), d = n("4a1b"), p = {
                data: function() {
                    return {
                        code: ""
                    };
                },
                mounted: function() {
                    var t = this;
                    return f(l.default.mark(function n() {
                        var o, a, u, c;
                        return l.default.wrap(function(n) {
                            for (;;) switch (n.prev = n.next) {
                              case 0:
                                return n.next = 2, e.login();

                              case 2:
                                if (o = n.sent, a = r(o, 2), u = a[0], c = a[1], !u) {
                                    n.next = 8;
                                    break;
                                }
                                return n.abrupt("return", e.showToast({
                                    title: "出了点小问题"
                                }));

                              case 8:
                                t.code = c.code, console.log(c);

                              case 10:
                              case "end":
                                return n.stop();
                            }
                        }, n);
                    }))();
                },
                methods: {
                    getPhoneNumber: function(t) {
                        var n = this;
                        return f(l.default.mark(function o() {
                            var a, u, c, i;
                            return l.default.wrap(function(o) {
                                for (;;) switch (o.prev = o.next) {
                                  case 0:
                                    a = t.detail, u = a.encryptedData, c = a.iv, i = n, wx.checkSession({
                                        success: function() {
                                            var t = f(l.default.mark(function t() {
                                                var r;
                                                return l.default.wrap(function(t) {
                                                    for (;;) switch (t.prev = t.next) {
                                                      case 0:
                                                        return t.next = 2, (0, d.setPhoneNum)({
                                                            encrypted_data: u,
                                                            iv: c,
                                                            js_code: i.code
                                                        });

                                                      case 2:
                                                        if (!(r = t.sent).errcode) {
                                                            t.next = 5;
                                                            break;
                                                        }
                                                        return t.abrupt("return", e.showToast({
                                                            title: "请稍后重试"
                                                        }));

                                                      case 5:
                                                        n.$store.state.isRegistered = !0, e.showToast({
                                                            title: "绑定成功"
                                                        }), i.close();

                                                      case 8:
                                                      case "end":
                                                        return t.stop();
                                                    }
                                                }, t);
                                            }));
                                            return function() {
                                                return t.apply(this, arguments);
                                            };
                                        }(),
                                        fail: function() {
                                            var t = f(l.default.mark(function t() {
                                                var o, a, s, f, p;
                                                return l.default.wrap(function(t) {
                                                    for (;;) switch (t.prev = t.next) {
                                                      case 0:
                                                        return t.next = 2, e.login();

                                                      case 2:
                                                        if (o = t.sent, a = r(o, 2), s = a[0], f = a[1], !s) {
                                                            t.next = 8;
                                                            break;
                                                        }
                                                        return t.abrupt("return", e.showToast({
                                                            title: "出了点小问题"
                                                        }));

                                                      case 8:
                                                        return t.next = 10, (0, d.setPhoneNum)({
                                                            encrypted_data: u,
                                                            iv: c,
                                                            js_code: f.code
                                                        });

                                                      case 10:
                                                        if (!(p = t.sent).errcode) {
                                                            t.next = 13;
                                                            break;
                                                        }
                                                        return t.abrupt("return", e.showToast({
                                                            title: "请稍后重试"
                                                        }));

                                                      case 13:
                                                        n.$store.state.isRegistered = !0, e.showToast({
                                                            title: "绑定成功"
                                                        }), i.close();

                                                      case 16:
                                                      case "end":
                                                        return t.stop();
                                                    }
                                                }, t);
                                            }));
                                            return function() {
                                                return t.apply(this, arguments);
                                            };
                                        }()
                                    });

                                  case 3:
                                  case "end":
                                    return o.stop();
                                }
                            }, o);
                        }))();
                    },
                    close: function() {
                        this.$emit("close");
                    }
                }
            };
            t.default = p;
        }).call(this, n("543d").default);
    },
    b5b5: function(e, t, n) {
        var r = function() {
            var e = this;
            e.$createElement;
            e._self._c;
        }, o = [];
        n.d(t, "b", function() {
            return r;
        }), n.d(t, "c", function() {
            return o;
        }), n.d(t, "a", function() {});
    },
    dacd: function(e, t, n) {
        n.r(t);
        var r = n("8df5"), o = n.n(r);
        for (var a in r) "default" !== a && function(e) {
            n.d(t, e, function() {
                return r[e];
            });
        }(a);
        t.default = o.a;
    }
} ]), (global.webpackJsonp = global.webpackJsonp || []).push([ "components/PhoneNumber-create-component", {
    "components/PhoneNumber-create-component": function(e, t, n) {
        n("543d").createComponent(n("5bb1"));
    }
}, [ [ "components/PhoneNumber-create-component" ] ] ]);
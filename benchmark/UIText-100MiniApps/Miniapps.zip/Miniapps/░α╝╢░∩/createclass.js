var e = getApp(), a = require("../../../utils/log"), s = require("../../../utils/stat"), t = require("../../../utils/common"), i = require("../../../utils/config"), n = require("../../../utils/data");

Page({
    data: {
        className: "",
        teaName: "",
        pickerVal: "",
        pickerLabel: "",
        ranges: [],
        applying: !1
    },
    onLoad: function() {
        s.initPage();
    },
    onReady: function() {},
    onShow: function() {
        var e = this;
        a.log("createclass.onShow"), n.queryRangeList().then(function(a) {
            e.setData({
                ranges: a
            });
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onPageScroll: function() {},
    onTabItemTap: function() {},
    onShareAppMessage: function() {
        return t.getShareInfo({
            page: "createclass",
            classCode: !1
        });
    },
    changeClassName: function(e) {
        var a = e.detail.value;
        this.setData({
            className: a
        });
    },
    changeTeaName: function(e) {
        var a = e.detail.value;
        this.setData({
            teaName: a
        });
    },
    pickerChange: function(e) {
        var a = this.data.ranges, s = e.detail.value;
        this.setData({
            pickerVal: s,
            pickerLabel: a[s].name
        });
    },
    doCreate: function() {
        var n = this;
        a.log("createclass.doCreate");
        var o = this.data, l = o.className, c = o.teaName, r = o.ranges, u = o.pickerVal, h = o.applying;
        if (s.track("createclass_doclass", {
            relation: u ? r[u].name : ""
        }), !h) {
            var p = new RegExp("[`~!@#$^&*=|{}':;',\\[\\].<>《》/?~！@#￥……&*——|{}【】‘；：”“'。，、？ ]");
            if (l) if (l.length > 15 || p.test(l)) t.tips("班级名称最多不能超过15个字，且不能包含字符"); else if (u) if (c) if (c.length > 10 || p.test(c)) t.tips("姓名最多不超过10个字，且不能包含字符"); else {
                var g = r[u], d = {
                    teaName: c,
                    className: l,
                    bjlbCode: g.code,
                    bjlbName: g.name,
                    origin: e.globalData.origin,
                    inviteId: e.globalData.qdUid,
                    inviteClassCode: e.globalData.qdClassCode
                };
                this.setData({
                    applying: !0
                }), wx.showLoading({
                    title: "创建中..."
                }), t.postSign({
                    url: i.SERVICE + "/wxapp/oauth/oauthCreateClass",
                    params: d,
                    success: function(e) {
                        wx.hideLoading(), "001" == e.resultCode ? n._refreshRoles(e.item.classCode) : (n.setData({
                            applying: !1
                        }), t.tips(e.resultMsg));
                    },
                    fail: function(e) {
                        wx.hideLoading(), n.setData({
                            applying: !1
                        }), t.tips("/oauthCreateClass服务异常:".concat(e.statusCode));
                    }
                });
            } else t.tips("请填写姓名"); else t.tips("请选择学段类型"); else t.tips("请填写班级名称");
        }
    },
    _refreshRoles: function(e, s) {
        var n = this;
        this.setData({
            applying: !0
        }), t.refreshRolesByClassCode({
            classCode: e,
            success: function() {
                t.switchRole(e, s);
                var a = [ "KYyVw2rRagjCMME2xMOjH8ZbKtSLxzQeqDhyFp310Pg", "hC4U30XnkK0-yOnrsn1EHuZfEBKtWpUorGbLDh8qoFc" ];
                i.isDev && (a = [ "PEXLIX9DZuGVlRnP77UN8HWnum039ydHAGaqDNjSYEc", "9UsPS2NrqC3gfhMw7Qb6xZ6A08kdlSxBvT0mHVlb0GQ" ]), 
                i.isSim && (a = [ "xtY0AuJHFxtuYxubi1xEUJUIEje9iTOkY2UTn-NYFic", "KrLhDRCnEiTLNLqP_-HAY3wdtbFJWn3FNBKeWfVu2SQ" ]), 
                wx.requestSubscribeMessage({
                    tmplIds: a,
                    success: function(s) {
                        console.log(s);
                        var i = [];
                        "accept" == s[a[0]] && i.push("1"), "accept" == s[a[1]] && i.push("2"), t.subscrWxTemMessage({
                            classCode: e,
                            subscribeType: i
                        }).then(function() {
                            wx.switchTab({
                                url: "/pages/main/home/home"
                            });
                        }, function() {
                            wx.switchTab({
                                url: "/pages/main/home/home"
                            });
                        });
                    },
                    complete: function() {
                        wx.switchTab({
                            url: "/pages/main/home/home"
                        });
                    }
                });
            },
            fail: function() {
                var s = n.data, t = s.teaName, i = s.className;
                a.error({
                    type: a.ERROR_TYPE_ACTION,
                    classCode: e,
                    data: {
                        msg: "创建班级后刷新角色失败",
                        teaName: t,
                        className: i
                    }
                });
            }
        });
    }
});
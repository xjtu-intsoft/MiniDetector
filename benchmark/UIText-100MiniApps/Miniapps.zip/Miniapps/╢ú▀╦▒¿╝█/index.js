function e(e, t, i) {
    return t in e ? Object.defineProperty(e, t, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = i, e;
}

var t = require("../../../34B2E2965724F3DF52D48A91C5139771.js"), i = require("../../../A3CC69315724F3DFC5AA01368FD29771.js");

Page({
    data: {
        company: "",
        initModel: null,
        payAlert: !1,
        payChannels: [],
        totalAmount: 0,
        quoted: !1
    },
    onLoad: function(e) {
        var t = e.params, i = e.fromCar, n = e.type, o = JSON.parse(decodeURIComponent(t));
        n && this.setData({
            quoted: !0
        }), this.setData({
            initModel: o,
            company: o.payer
        }), this.commitSource = i ? "shoppingCart" : "goodsDetail";
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    showContent: function(e) {
        wx.showToast({
            title: e,
            icon: "none"
        });
    },
    submitAction: function(e) {
        var i = this.data.initModel;
        if (this.data.quoted || null != i.mallAddress && null != i.mallAddress.id) if (i.commitable || this.data.quoted) {
            if (this.data.quoted) {
                if (null == this.addressName || 0 == this.addressName.length) return void this.showContent("请输入收货人姓名");
                if (null == this.addressMobile || 11 != this.addressMobile.length) return void this.showContent("请输入11有效的手机号码");
            }
            if (i.globalPurchasing) {
                if (null == this.name || 0 == this.name.length) return void this.showContent("因海关需要,请填写收货人真实姓名");
                if (null == this.idCard || 0 == this.idCard.length) return void this.showContent("因海关需要,请填写收货人身份证号");
            }
            var n = {
                addressId: i.mallAddress.id
            };
            if (i.globalPurchasing && (n.idNo = this.idCard, n.idName = this.name), this.data.quoted) {
                n.tradeId = this.data.initModel.tradeId, n.recipientName = this.addressName, n.recipientMobile = this.addressMobile, 
                wx.showLoading({
                    title: ""
                }), null != this.memo && (n.memo = this.memo);
                C = this;
                t.handle.purchaseConfirmTrade(n, function(e) {
                    var t = e.payChannels, i = e.tradeAmount;
                    C.setData({
                        payChannels: t,
                        totalAmount: i,
                        payAlert: !0
                    });
                }, function() {});
            } else {
                var o = [], a = 0, r = !0, s = !1, d = void 0;
                try {
                    for (var l, u = i.merchantCellList[Symbol.iterator](); !(r = (l = u.next()).done); r = !0) {
                        var c = l.value, h = {};
                        h.merchantId = c.merchantId;
                        var f = a + "";
                        this.inputValues && this.inputValues[f] && (h.memo = this.inputValues[f]);
                        var m = [], y = !0, g = !1, v = void 0;
                        try {
                            for (var p, x = c.skuList[Symbol.iterator](); !(y = (p = x.next()).done); y = !0) {
                                var w = p.value;
                                m.push({
                                    goodsSkuId: w.skuId,
                                    quantity: w.count
                                });
                            }
                        } catch (e) {
                            g = !0, v = e;
                        } finally {
                            try {
                                !y && x.return && x.return();
                            } finally {
                                if (g) throw v;
                            }
                        }
                        h.items = m, o.push(h), a++;
                    }
                } catch (e) {
                    s = !0, d = e;
                } finally {
                    try {
                        !r && u.return && u.return();
                    } finally {
                        if (s) throw d;
                    }
                }
                n.merchants = o, n.commitSource = this.commitSource, console.log("confirm order:...", n), 
                wx.showLoading();
                var C = this;
                t.handle.buyerSubmit(n, function(e) {
                    var t = getCurrentPages(), i = t.findIndex(function(e) {
                        return "pages/cat/index/index" == e.route;
                    });
                    i >= 0 && (o = t[i]).getCarList();
                    var n = t.findIndex(function(e) {
                        return "pages/home/goods/index" == e.route;
                    });
                    if (n >= 0) {
                        var o = t[n];
                        o.requestData();
                    }
                    console.log("submit----succ:", e);
                    var a = e.payChannels, r = e.orderId, s = e.totalAmount, d = e.tradeIds;
                    C.setData({
                        payChannels: a,
                        totalAmount: s,
                        payAlert: !0
                    }), C.payOrderId = r, C.paryTrades = d;
                }, function() {});
            }
        } else this.showContent("该收货地址超出配送范围"); else this.showContent("请选择收货地址");
    },
    confirmDone: function(e) {
        if (console.log("confirm pay:", e), this.setData({
            payAlert: !1
        }), "offline" == e.detail.payCode) wx.redirectTo({
            url: "/pages/order/finish/index"
        }); else {
            var i = this;
            if (this.data.quoted) return void wx.login({
                success: function(e) {
                    console.log("login res:", e), wx.showLoading(), t.handle.weixinPay(i.data.initModel.tradeId, e.code, function(e) {
                        console.log("result:", e);
                        var t = e.prepay;
                        t.success = function() {
                            console.log("pay succ"), wx.reLaunch({
                                url: "/pages/order/order/index?index=3"
                            });
                        }, t.fail = function(e) {
                            wx.reLaunch({
                                url: "/pages/order/order/index?index=1"
                            });
                        }, wx.requestPayment(t);
                    }, function(e) {});
                }
            });
            var n = this.paryTrades.join(",");
            wx.login({
                success: function(e) {
                    console.log("login res:", e), wx.showLoading(), t.handle.weixinCombinePay(n, e.code, function(e) {
                        console.log("result:", e);
                        var t = e.prepay;
                        t.success = function() {
                            console.log("pay succ"), wx.reLaunch({
                                url: "/pages/order/order/index?index=3"
                            });
                        }, t.fail = function(e) {
                            console.log("pay error:", e), wx.reLaunch({
                                url: "/pages/order/order/index?index=1"
                            });
                        }, wx.requestPayment(t);
                    }, function(e) {});
                },
                fail: function(e) {
                    console.log("error:", e);
                }
            });
        }
    },
    onHideChoise: function() {
        this.setData({
            payAlert: !1
        }), wx.reLaunch({
            url: "/pages/order/order/index?index=1"
        });
    },
    inputListener: function(e) {
        if (console.log("eeee:", e), this.data.quoted) this.memo = e.detail.value; else {
            var t = e.detail, i = t.value, n = t.inputName;
            null == this.inputValues && (this.inputValues = {});
            var o = n + "";
            this.inputValues[o] = i;
        }
    },
    cInputListener: function(e) {
        var t = e.detail, i = t.value, n = t.inputName;
        1 == n ? this.name = i : 2 == n ? this.idCard = i : 3 == n ? this.addressName = i : 4 == n && (this.addressMobile = i);
    },
    choiseAddress: function(t) {
        var i = {};
        i.addressDetail = t.fullAddress, i.receiverName = t.name, i.mobile = t.mobile, i.id = t.addressId, 
        i.city = t.cityCode, i.province = t.provinceCode, i.district = t.districtCode;
        this.setData(e({}, "initModel.mallAddress", i)), this.getGoodsFregight();
    },
    gotoChoiseAddress: function() {
        wx.navigateTo({
            url: "/pages/address/list/index?type=1"
        });
    },
    modifyPayer: function() {
        this.setData({
            showPay: !0
        });
    },
    confirmPay: function(e) {
        console.log("confirm pay:", e.detail.value), this.setData({
            company: e.detail.value,
            showPay: !1
        });
    },
    closeAlert: function(e) {
        this.setData({
            showPay: !1
        });
    },
    gotoEditAddress: function() {
        wx.navigateTo({
            url: "/pages/address/add/index?typeIndex=1"
        });
    },
    getGoodsFregight: function() {
        var e = this.data.initModel, t = [], n = !0, o = !1, a = void 0;
        try {
            for (var r, s = e.merchantCellList[Symbol.iterator](); !(n = (r = s.next()).done); n = !0) {
                var d = r.value, l = !0, u = !1, c = void 0;
                try {
                    for (var h, f = d.skuList[Symbol.iterator](); !(l = (h = f.next()).done); l = !0) {
                        var m = h.value;
                        t.push({
                            skuId: m.skuId,
                            count: m.count
                        });
                    }
                } catch (e) {
                    u = !0, c = e;
                } finally {
                    try {
                        !l && f.return && f.return();
                    } finally {
                        if (u) throw c;
                    }
                }
            }
        } catch (e) {
            o = !0, a = e;
        } finally {
            try {
                !n && s.return && s.return();
            } finally {
                if (o) throw a;
            }
        }
        var y = {
            skus: t,
            province: e.mallAddress.province,
            city: e.mallAddress.city,
            district: e.mallAddress.district
        }, g = this;
        i.handle.getGoodsFreight(y, function(e) {
            g.configFregight(e);
        }, function(e) {});
    },
    configFregight: function(e) {
        var t = this.data.initModel, i = e.skuIdToFregight, n = e.commitable, o = !0, a = !1, r = void 0;
        try {
            for (var s, d = t.merchantCellList[Symbol.iterator](); !(o = (s = d.next()).done); o = !0) {
                var l = s.value, u = !0, c = !1, h = void 0;
                try {
                    for (var f, m = l.skuList[Symbol.iterator](); !(u = (f = m.next()).done); u = !0) {
                        var y = f.value, g = y.skuId + "";
                        null != i && null != i[g] ? y.freightAmount = i[g] : y.freightAmount = null;
                    }
                } catch (e) {
                    c = !0, h = e;
                } finally {
                    try {
                        !u && m.return && m.return();
                    } finally {
                        if (c) throw h;
                    }
                }
            }
        } catch (e) {
            a = !0, r = e;
        } finally {
            try {
                !o && d.return && d.return();
            } finally {
                if (a) throw r;
            }
        }
        t.commitable = n, this.setData({
            initModel: t
        });
    }
});
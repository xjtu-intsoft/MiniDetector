var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../@babel/runtime/helpers/defineProperty"));

function t(e, t) {
    var a = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
        })), a.push.apply(a, r);
    }
    return a;
}

var a = getApp();

Page({
    data: {
        bodyTop: a.globalData.navHeight,
        act: "",
        checkColor: "#FF8000",
        pickerShow: !1,
        provinceLs: [],
        cityLs: [],
        areaLs: [],
        pcValue: [ 0, 0, 0 ],
        screenProvincesOut: [ "北京市", "上海市", "天津市", "重庆市" ],
        form: {
            is_default: 1
        }
    },
    onLoad: function(e) {
        var t = e.act, a = e.addressId;
        this.setData({
            act: t,
            addressId: a
        }), this.getPCList(), "edit" == t && this.getAddressById(a);
    },
    getAddressById: function(e) {
        var t = this;
        wx.showLoading({
            title: "获取中",
            mask: !0
        }), t.$http({
            method: "post",
            url: "".concat(a.globalData.baseUrl, "/order/get_address_info?format=json"),
            data: {
                address_id: e
            }
        }).then(function(e) {
            if (wx.hideLoading(), e.error_code) wx.showToast({
                title: e.error_msg,
                icon: "none",
                mask: !0,
                duration: 2e3,
                success: function() {
                    setTimeout(function() {
                        wx.navigateBack({
                            delta: 1
                        });
                    }, 2100);
                }
            }); else {
                var a = e.data, r = t.data.form;
                r.receiver = a.receiver, r.mobile = a.mobile, r.pc_text = [ a.province_name, a.city_name, a.area_name ].join("-"), 
                r.address = a.address, r.province = a.province, r.city = a.city, r.area = a.area, 
                t.setData({
                    form: r
                });
            }
        });
    },
    getPCList: function() {
        var e = this, t = this;
        t.$http({
            method: "post",
            url: "".concat(a.globalData.baseUrl, "/tool/get_city_list?format=json"),
            data: {}
        }).then(function(a) {
            var r = a, o = r[0].city, n = o[0].area;
            e.data.screenProvincesOut.indexOf(r[0].name) >= 0 && (n = null), t.setData({
                provinceLs: r,
                cityLs: o,
                areaLs: n
            });
        });
    },
    showPickerFun: function() {
        this.setData({
            pickerShow: !0
        });
    },
    bindChange: function(e) {
        var t = this.data.provinceLs, a = e.detail.value, r = t[a[0]], o = r.city, n = o[a[1]].area;
        this.data.screenProvincesOut.indexOf(r.name) >= 0 && (n = null), this.setData({
            pcValue: a,
            cityLs: o,
            areaLs: n
        });
    },
    cancle: function() {
        this.setData({
            pickerShow: !1
        });
    },
    confirm: function() {
        var e = this.data, t = e.pcValue, a = e.provinceLs[t[0]], r = a.city[t[1]], o = r.area[t[2]], n = e.form;
        n.province = a.id, n.city = r.id, this.data.screenProvincesOut.indexOf(a.name) >= 0 ? (n.area = "", 
        n.pc_text = [ a.name, r.name ].join("-")) : (n.area = o.id, n.pc_text = [ a.name, r.name, o.name ].join("-")), 
        this.setData({
            form: n,
            pickerShow: !1
        });
    },
    setFormValue: function(e) {
        var t = this.data.form, a = e.currentTarget.dataset.key;
        switch (a) {
          default:
            var r = e.detail.value;
            t[a] = r;
            break;

          case "is_default":
            var o;
            t[a] = t[a] ? 0 : 1, o = 1 === t[a] ? "#FF8000" : "#C6C7CC", this.setData({
                checkColor: o
            });
        }
        this.setData({
            form: t
        });
    },
    submit: function() {
        var r, o, n = this, i = n.data, s = i.form;
        if (r = {}, o = !0, [ {
            key: "receiver",
            errortext: "必填"
        }, {
            key: "mobile",
            reg: /^1[3456789]\d{9}$/,
            errortext: "请填写合法手机号"
        }, {
            key: "pc_text",
            errortext: "必填"
        }, {
            key: "address",
            errortext: "必填"
        } ].forEach(function(e) {
            var t = e.key, a = s[t], n = e.reg;
            n ? n.test(a) ? r[t] = "" : (r[t] = e.errortext, o = !1) : a ? r[t] = "" : (r[t] = e.errortext, 
            o = !1);
        }), n.setData({
            errorMsg: r
        }), o) {
            var c = function(a) {
                for (var r = 1; r < arguments.length; r++) {
                    var o = null != arguments[r] ? arguments[r] : {};
                    r % 2 ? t(Object(o), !0).forEach(function(t) {
                        (0, e.default)(a, t, o[t]);
                    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(a, Object.getOwnPropertyDescriptors(o)) : t(Object(o)).forEach(function(e) {
                        Object.defineProperty(a, e, Object.getOwnPropertyDescriptor(o, e));
                    });
                }
                return a;
            }({
                act: i.act,
                address_id: i.addressId
            }, s, {
                uid: a.globalData.userInfo.uid
            });
            wx.showLoading({
                title: "提交中",
                mask: !0
            }), n.$http({
                method: "post",
                url: "".concat(a.globalData.baseUrl, "/order/user_address_change?format=json"),
                data: c
            }).then(function(e) {
                wx.hideLoading(), e.error_code ? wx.showToast({
                    title: e.error_msg,
                    icon: "none",
                    mask: !0,
                    duration: 2e3
                }) : wx.navigateBack({
                    delta: 1
                });
            });
        }
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    defalutOnShareAppMessageFun: !0
});
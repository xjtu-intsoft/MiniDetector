var t = require("../../366FE3F5412D25BF50098BF28BB60724.js"), i = (require("../../4D268FB4412D25BF2B40E7B30C070724.js"), 
require("../../C19DDF21412D25BFA7FBB7265F660724.js"));

getApp();

Page({
    data: {
        hotCityList: [],
        allCityList: [],
        lists: [],
        touchmove: !1,
        touchmoveIndex: -1,
        titleHeight: 0,
        indexBarHeight: 0,
        indexBarItemHeight: 0,
        scrollViewId: "",
        winHeight: 0,
        inputShowed: !1,
        inputVal: "",
        searchResult: [],
        localCity: "",
        localCityId: 0
    },
    onLoad: function(t) {
        var i = this;
        i.setData({
            localCity: wx.getStorageSync("position_name") || "未知",
            localCityId: wx.getStorageSync("position_id")
        }), i.getHotCities(), i.getAllCities(), setTimeout(function() {
            wx.getSystemInfo({
                success: function(t) {
                    var e = t.windowHeight, a = e - t.windowWidth / 750 * 204;
                    i.setData({
                        winHeight: e,
                        indexBarHeight: a,
                        indexBarItemHeight: a / 25,
                        titleHeight: t.windowWidth / 750 * 132
                    });
                }
            });
        }, 50);
    },
    getHotCities: function() {
        var e = this, a = {
            url: i.HotCityList,
            method: "GET",
            data: {}
        };
        t.request(a).then(function(t) {
            e.setData({
                hotCityList: t
            });
        });
    },
    getAllCities: function() {
        var e = this, a = {
            url: i.CityList,
            method: "GET",
            data: {}
        };
        t.request(a).then(function(t) {
            e.setData({
                allCityList: t
            });
        });
    },
    showInput: function() {
        this.setData({
            inputShowed: !0
        });
    },
    clearInput: function() {
        this.setData({
            inputVal: "",
            inputShowed: !1,
            searchResult: []
        }), wx.hideKeyboard();
    },
    inputTyping: function(t) {
        var i = this;
        this.setData({
            inputVal: t.detail.value
        }, function() {
            i.searchCity();
        });
    },
    searchCity: function() {
        var t = this, i = [];
        this.data.allCityList.forEach(function(e) {
            e.items.forEach(function(e) {
                console.log(t.data.inputVal.toLocaleUpperCase()), console.log(e.name), -1 !== e.name.indexOf(t.data.inputVal.toLocaleUpperCase()) && i.push({
                    id: e.id,
                    alias: e.alias
                });
            });
        }), this.setData({
            searchResult: i
        });
    },
    selectCity: function(t) {
        var i = t.currentTarget.dataset.name, e = t.currentTarget.dataset.id;
        wx.setStorageSync("city_id", e), wx.setStorageSync("city_name", i), wx.removeStorageSync("districtList"), 
        wx.reLaunch({
            url: "/pages/index/index"
        });
    },
    touchStart: function(t) {
        this.setData({
            touchmove: !0
        });
        var i = t.touches[0].pageY, e = Math.floor((i - this.data.titleHeight) / this.data.indexBarItemHeight) - 1, a = this.data.allCityList[0 === e ? 0 : e - 1];
        a && this.setData({
            scrollViewId: a.title,
            touchmoveIndex: e - 1
        });
    },
    touchMove: function(t) {
        var i = t.touches[0].pageY, e = Math.floor((i - this.data.titleHeight) / this.data.indexBarItemHeight) - 1, a = this.data.allCityList[0 === e ? 0 : e - 1];
        a && this.setData({
            scrollViewId: a.title,
            touchmoveIndex: e - 1
        });
    },
    touchEnd: function() {
        this.setData({
            touchmove: !1,
            touchmoveIndex: -1
        });
    },
    touchCancel: function() {
        this.setData({
            touchmove: !1,
            touchmoveIndex: -1
        });
    }
});
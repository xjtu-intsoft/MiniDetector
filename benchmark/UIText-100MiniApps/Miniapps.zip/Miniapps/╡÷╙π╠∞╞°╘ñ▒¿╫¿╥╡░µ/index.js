var e = require("../../../utils/api"), t = require("../../../config.js");

getApp();

Page({
    data: {
        showBack: !0,
        isLeft: !0,
        isTel: !1,
        sexs: [ {
            value: "0",
            name: "男",
            checked: "true"
        }, {
            value: "1",
            name: "女"
        } ],
        curSex: 0,
        date: "请选择出生日期",
        startDate: "1939-10-01",
        endDate: "",
        userPic: "",
        curPic: "",
        userName: "",
        userTel: "",
        curPhone: "",
        verify: "获取验证码",
        verifyCode: "",
        inviteCode: "",
        codeCount: 120,
        getCodeing: !1,
        showBindTel: !1,
        showMotai: !1,
        curUploadPics: []
    },
    formatDate: function(e, t) {
        var a;
        (a = e ? new Date(e) : new Date()).setDate(a.getDate() + t);
        var o = a.getFullYear(), n = a.getMonth() + 1;
        n < 10 && (n = "0" + n);
        var i = a.getDate();
        i < 10 && (i = "0" + i);
        a.getHours(), a.getMinutes(), a.getSeconds();
        return o + "-" + n + "-" + i;
    },
    tapMotaiBg: function() {
        this.showMotai = !1;
    },
    radioChange: function(e) {
        this.curSex = parseInt(e.detail.value);
    },
    bindDateChange: function(e) {
        this.date = e.detail.value;
    },
    changeName: function(e) {
        this.setData({
            userName: e.detail.value
        });
    },
    changeTel: function(e) {
        this.setData({
            userTel: e.detail.value
        });
    },
    changeVerifyCode: function(e) {
        this.setData({
            verifyCode: e.detail.value
        });
    },
    tapChangeTel: function() {
        wx.navigateTo({
            url: "/pages/me/changeTel/index"
        });
    },
    tapGetVerifyCode: function() {
        var e = /^1[0-9]{10}$/, t = this;
        console.log(this.data.userTel), console.log(this.data.curPhone), "获取验证码" == this.data.verify ? e.test(this.data.userTel) ? this.data.userTel == this.data.curPhone && "" != this.data.userTel ? wx.showToast({
            title: "手机号未修改",
            icon: "none"
        }) : t.getDataVerifyCode() : wx.showToast({
            title: "手机号错误",
            icon: "none"
        }) : wx.showToast({
            title: "请稍后",
            icon: "none"
        });
    },
    mverify: function(e) {
        console.log(e), e.msg && (this.showMotai = !1, this.getDataVerifyCode());
    },
    getDataVerifyCode: function() {
        var t = this;
        console.log(this.data.userTel), e.EditTelSendVerify({
            phone: this.data.userTel
        }).then(function(e) {
            console.log(e), 100 == e.code ? (wx.showToast({
                title: "验证码已发送",
                icon: "none"
            }), t.setData({
                getCodeing: !0
            }), t.reduceCount()) : wx.showToast({
                title: e.msg,
                icon: "none"
            });
        });
    },
    reduceCount: function() {
        if (1 == this.data.getCodeing) if (this.data.codeCount < 0) this.setData({
            verify: "获取验证码",
            codeCount: 120,
            timeOut: ""
        }); else {
            this.setData({
                verify: this.data.codeCount + "s",
                codeCount: this.data.codeCount - 1
            });
            var e = this;
            this.timeOut = setTimeout(function() {
                e.reduceCount();
            }, 1e3);
        } else this.setData({
            timeOut: ""
        });
    },
    tapBindTel: function() {
        console.log(this.data.userTel), console.log(this.data.verifyCode);
        var t = this, a = /^1[0-9]{10}$/;
        "" != this.data.userTel ? a.test(this.data.userTel) ? "" != this.data.verifyCode ? "" != this.data.userTel && a.test(this.data.userTel) && this.data.verifyCode && e.BindTel({
            code: this.data.verifyCode,
            phone: this.data.userTel
        }).then(function(e) {
            console.log(e), 100 == e.code ? (wx.showToast({
                title: "绑定成功",
                icon: "none"
            }), t.setData({
                showBindTel: !1,
                verify: "获取验证码",
                codeCount: 120,
                timeOut: ""
            })) : setTimeout(function() {
                wx.showToast({
                    title: e.msg,
                    icon: "none"
                });
            }, 100), t.getUserData();
        }) : wx.showToast({
            title: "请输入验证码",
            icon: "none"
        }) : wx.showToast({
            title: "手机号错误",
            icon: "none"
        }) : wx.showToast({
            title: "请输入手机号",
            icon: "none"
        });
    },
    tapUpload: function() {
        var e = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(t) {
                console.log(t);
                t.tempFilePaths;
                e.setData({
                    curUploadPics: t.tempFilePaths
                }), e._upload();
            },
            fail: function(e) {}
        });
    },
    _upload: function() {
        wx.showLoading({
            title: "图片上传中"
        });
        var e = this.data.curUploadPics;
        console.log(e[0]);
        var a = this, o = wx.getStorageSync("token");
        wx.uploadFile({
            url: t.uploadUrl,
            filePath: e[0],
            header: {
                "X-Token": o
            },
            name: "files",
            success: function(t) {
                var o = JSON.parse(t.data);
                console.log(o), 100 == o.code ? (wx.showToast({
                    title: "上传成功",
                    icon: "none"
                }), e.shift(), a.setData({
                    curUploadPics: e,
                    userPic: o.data
                })) : (wx.showToast({
                    title: "上传失败",
                    icon: "none"
                }), wx.hideLoading());
            },
            fail: function(e) {
                console.log(e), wx.hideLoading();
            }
        });
    },
    tapSave: function() {
        var t = "";
        this.data.userName ? (this.data.userPic != this.data.curPic && (t = this.data.userPic), 
        e.EditUserInfo({
            avatarUrl: t,
            nickName: this.data.userName
        }).then(function(e) {
            console.log(e), 100 == e.code ? (wx.showToast({
                title: "修改成功",
                icon: "none"
            }), wx.reLaunch({
                url: "/pages/me/index/index"
            })) : wx.showToast({
                title: e.msg,
                icon: "none"
            });
        })) : wx.showToast({
            title: "请填写用户昵称",
            icon: "none"
        });
    },
    getUserData: function() {
        var t = this;
        e.PersonalCenter({}).then(function(e) {
            console.log(e), 100 == e.code ? (t.setData({
                userName: e.data.nickName,
                userPic: e.data.avatarUrl,
                curPic: e.data.avatarUrl,
                userTel: e.data.phone,
                curPhone: e.data.phone
            }), e.data.phone && t.setData({
                isTel: !0
            })) : wx.showToast({
                title: "获取信息失败",
                icon: "none"
            });
        });
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {
        this.getUserData();
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});
var e = require("../../public/getKey");

Page({
    data: {
        pic_code: ""
    },
    onLoad: function(e) {
        wx.setNavigationBarTitle({
            title: "绑定手机号"
        }), this.setData({
            api_url: getApp().globalData.api_url,
            mobile: "",
            time: "获取验证码",
            disabled: !1,
            pcode: "",
            code: "",
            mycode: "",
            user: wx.getStorageSync("user")
        }), this.changePicCode();
    },
    bindMobile: function(e) {
        this.setData({
            mobile: e.detail.value
        });
    },
    bindPicCode: function(e) {
        this.setData({
            pcode: e.detail.value
        });
    },
    bindCode: function(e) {
        this.setData({
            mycode: e.detail.value
        });
    },
    getCode: function(t) {
        var a = this;
        e.checkPhone(a.data.mobile) ? a.data.pcode ? wx.request({
            url: a.data.api_url + "user/verify_code",
            data: {
                access_token: "xx",
                mobile: a.data.mobile,
                code: a.data.pcode
            },
            method: "POST",
            header: {
                "Content-Type": "application/json"
            },
            success: function(e) {
                if ("success" == e.data.status) {
                    a.setData({
                        code: e.data.code
                    });
                    var t = 60;
                    !function e() {
                        0 == t ? (a.setData({
                            time: "获取验证码",
                            disabled: !1
                        }), t = 60) : (a.setData({
                            time: t + "s后重新发送",
                            disabled: !0
                        }), t--, setTimeout(function() {
                            e();
                        }, 1e3));
                    }();
                } else wx.showModal({
                    title: "提示",
                    content: "图片验证码错误",
                    showCancel: !1
                });
            }
        }) : wx.showModal({
            title: "提示",
            content: "请填写图片验证码",
            showCancel: !1
        }) : wx.showModal({
            title: "提示",
            content: "手机号格式不正确！",
            showCancel: !1
        });
    },
    update: function() {
        var e = this;
        this.data.mycode == this.data.code ? wx.request({
            url: e.data.api_url + "user/update",
            method: "POST",
            header: {
                "Content-Type": "application/json"
            },
            data: {
                "3rd_session": wx.getStorageSync("3rd_session"),
                code: e.data.code,
                data: {
                    mobile: e.data.mobile
                }
            },
            success: function(t) {
                "10402" == t.data.code ? wx.showModal({
                    title: "很抱歉！",
                    content: "您的微信号手机号存在订单信息，为了保障您的账号安全，需平台审核后为您账户绑定。",
                    confirmText: "提交审核",
                    success: function(t) {
                        t.confirm && wx.request({
                            url: e.data.api_url + "user/feedback",
                            data: {
                                "3rd_session": wx.getStorageSync("3rd_session"),
                                data: {
                                    message: "用户id：" + e.data.user.id + " 申请绑定号码：" + e.data.mobile,
                                    type: 4
                                }
                            },
                            method: "POST",
                            header: {
                                "Content-Type": "application/json"
                            },
                            success: function(e) {
                                wx.showToast({
                                    icon: "success",
                                    title: "提交成功"
                                }), setTimeout(function() {
                                    wx.navigateBack();
                                }, 1500);
                            }
                        });
                    }
                }) : "success" == t.data.status ? ("user" in t.data && (e.data.user.id = e.data.user.id, 
                e.data.user.vip = e.data.user.vip), e.data.user.mobile = e.data.mobile, wx.setStorageSync("user", e.data.user), 
                wx.showToast({
                    icon: "success",
                    title: "绑定成功"
                }), setTimeout(function() {
                    wx.navigateBack();
                }, 1500)) : wx.showToast({
                    icon: "none",
                    title: "绑定错误"
                });
            }
        }) : wx.showModal({
            title: "提示",
            content: "验证码不正确！",
            showCancel: !1
        });
    },
    changePicCode: function() {
        this.setData({
            pic_code: "https://api.vcbeat.top/user/imgcode?" + Math.random()
        });
    }
});
var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../utils/db.js")), a = getApp(), t = {
    "小车": "02",
    "大车": "01",
    "新能源小车": "52",
    "新能源大车": "51"
};

Page({
    data: {
        provinceShortName: [ "京", "沪", "浙", "苏", "粤", "鲁", "晋", "冀", "豫", "川", "渝", "辽", "吉", "黑", "皖", "鄂", "湘", "赣", "闽", "陕", "甘", "宁", "蒙", "津", "贵", "云", "桂", "琼", "青", "新", "藏" ],
        provinceIndex: 1,
        carNo: "",
        regDate: "",
        carTypeMap: Object.keys(t),
        seatMap: [ "4座", "5座", "6座", "7座", "8座", "9座" ],
        isPrivateMap: [ "非营运", "营运" ],
        carType: 0,
        seatLimit: 1,
        isPrivate: 0,
        noAccident: !0,
        carNoInputFocused: !1,
        showSelectProvince: !1,
        isEdit: !1,
        ecode: "",
        vcode: "",
        garageId: "",
        agreementChecked: !1,
        showVcode: !1
    },
    onLoad: function(i) {
        var o = this;
        if (i.garageId) wx.setNavigationBarTitle({
            title: "编辑车辆"
        }), this.setData({
            isEdit: !0,
            garageId: i.garageId
        }), e.default.request({
            url: e.default.host("ucapi") + "Garage/getInfo?from=chaweizhang",
            type: "GET",
            data: {
                garageId: i.garageId
            },
            success: function(e) {
                if (o.setCarNoData(e.data.carno), e.data.inspection_regist_time) {
                    var a = o.unixtime2date(e.data.inspection_regist_time);
                    o.setData({
                        regDate: a
                    });
                }
                var i = 1, n = !0;
                e.data.seat_limit && o.data.seatMap.forEach(function(a, t) {
                    a.indexOf(e.data.seat_limit) >= 0 && (i = t);
                });
                var r = 0;
                e.data.cartype && Object.keys(t).forEach(function(a, i) {
                    t[a] == e.data.cartype && (r = i);
                });
                var s = e.data.syxcmc || 0;
                e.data.car_no_accident >= 0 && (n = e.data.car_no_accident > 0), o.setData({
                    carType: r,
                    seatLimit: i,
                    isPrivate: s,
                    noAccident: n,
                    ecode: e.data.ecode || "",
                    vcode: e.data.vcode || "",
                    showVcode: !!e.data.vcode
                });
            },
            error: function(e) {}
        }); else {
            var n = a.globalData.licenseInfo;
            n.plateNO && this.setCarNoData(n.plateNO);
            var r = "";
            n.registerDate && (r = n.registerDate);
            var s = 0;
            n.useCharacter && 2 == n.useCharacter.length && (s = 1);
            var c = 0;
            n.vehicleTypeId && Object.keys(t).forEach(function(e, a) {
                t[e] == n.vehicleTypeId && (c = a);
            }), this.setData({
                regDate: r,
                isPrivate: s,
                carType: c,
                ecode: n.engineNO || "",
                vcode: n.VIN || "",
                showVcode: !!n.VIN
            });
        }
    },
    unixtime2date: function(e) {
        var a = new Date(1e3 * e), t = a.getMonth() + 1, i = a.getDate();
        return t < 10 && (t = "0" + t), i < 10 && (i = "0" + i), a.getFullYear() + "-" + t + "-" + i;
    },
    setCarNoData: function(e) {
        var a = e.len, t = e.substring(0, 1), i = e.substring(1, a), o = this.data.provinceShortName.indexOf(t);
        -1 == o && (o = 1), this.setData({
            provinceIndex: o,
            carNo: i
        });
    },
    inputCarno: function(e) {
        var a = e.detail.value.replace(/[\u4E00-\u9FA5]|[\uFE30-\uFFA0]/g, "");
        a = a.toUpperCase(), this.setData({
            carNo: a
        });
    },
    inputEcode: function(e) {
        this.setData({
            ecode: e.detail.value
        });
    },
    inputVcode: function(e) {
        this.setData({
            vcode: e.detail.value
        });
    },
    carTypeChange: function(e) {
        this.setData({
            carType: e.detail.value
        });
    },
    regDateChange: function(e) {
        this.setData({
            regDate: e.detail.value
        });
    },
    isPrivateChange: function(e) {
        this.setData({
            isPrivate: e.detail.value
        });
    },
    seatLimitChange: function(e) {
        this.setData({
            seatLimit: e.detail.value
        });
    },
    noAccidentChange: function(e) {
        console.log(e), this.setData({
            noAccident: e.detail.value
        });
    },
    agreementChange: function(e) {
        this.setData({
            agreementChecked: !this.data.agreementChecked
        });
    },
    selectProvide: function(e) {
        console.log(e.target.dataset.index), this.setData({
            provinceIndex: e.target.dataset.index,
            carNoInputFocused: !0
        }), this.triggerSelectProvince();
    },
    triggerSelectProvince: function() {
        this.data.isEdit || this.setData({
            showSelectProvince: !this.data.showSelectProvince
        });
    },
    closePop: function(e) {
        console.log(e), e.target.id == e.currentTarget.id && this.triggerSelectProvince();
    },
    delCar: function() {
        var a = this;
        wx.showModal({
            title: "操作提示",
            content: "确定要删除吗",
            success: function(t) {
                t.confirm && e.default.request({
                    url: e.default.host("ucapi") + "Garage/delete?from=garage",
                    type: "POST",
                    headType: 1,
                    data: {
                        garageId: a.data.garageId
                    },
                    successText: "删除成功",
                    success: function(e) {
                        wx.navigateBack({
                            delta: 1
                        });
                    },
                    error: function(e) {}
                });
            },
            fail: function() {}
        });
    },
    saveCar: function() {
        var i = this;
        if (this.data.isEdit || this.data.agreementChecked) if (this.data.carNo) if (this.data.carNo.length < 5) wx.showToast({
            title: "请输入正确的车牌",
            icon: "none",
            duration: 2500
        }); else if (this.data.ecode) {
            var o = this.data.provinceShortName[this.data.provinceIndex] + this.data.carNo, n = this.data.regDate;
            n = new Date(n).getTime() / 1e3, console.log("regDate", n);
            this.data.seatMap[this.data.seatLimit];
            var r = t[this.data.carTypeMap[this.data.carType]], s = Date.parse(new Date()), c = {
                carno: o,
                ecode: this.data.ecode,
                inspection_regist_time: n,
                syxcmc: this.data.isPrivate,
                order_time: s / 1e3,
                cartype: r
            };
            this.data.vcode && "undefined" !== this.data.vcode && (c.vcode = this.data.vcode);
            var d = "add", g = "添加成功";
            this.data.garageId && (c.garageId = this.data.garageId, d = "edit", g = "编辑成功"), 
            e.default.request({
                url: e.default.host("ucapi") + "Garage/" + d + "?from=chaweizhang",
                type: "POST",
                headType: 1,
                data: c,
                successText: g,
                success: function(e) {
                    if (console.log(d + "car success:" + e), a.globalData.licenseInfo = {}, "add" == d) {
                        var t = i.data.garageId || e.data;
                        wx.navigateTo({
                            url: "/pages/query-violation/query-violation?garageId=" + t + "&carno=" + o + "&ecode=" + i.data.ecode + "&cartype=" + r + "&vcode=" + i.data.vcode
                        });
                    } else wx.navigateBack({
                        delta: 1
                    });
                },
                error: function(e) {
                    console.log(d + "car Error:" + e);
                }
            });
        } else wx.showToast({
            title: "请输入发动机号",
            icon: "none",
            duration: 2500
        }); else wx.showToast({
            title: "请输入车牌",
            icon: "none",
            duration: 2500
        }); else wx.showToast({
            title: "请同意《车轮平台用户注册协议》",
            icon: "none",
            duration: 2500
        });
    },
    toTakePhoto: function() {
        wx.navigateTo({
            url: "/pages/take-photo/take-photo"
        });
    },
    onShareAppMessage: function(e) {
        return {
            title: a.globalData.shareTitle,
            imageUrl: a.globalData.shareImageUrl,
            path: a.globalData.sharePath,
            success: function(e) {},
            fail: function(e) {}
        };
    }
});
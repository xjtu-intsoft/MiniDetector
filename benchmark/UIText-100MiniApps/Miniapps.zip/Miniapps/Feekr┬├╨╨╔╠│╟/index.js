var t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/toConsumableArray")), e = require("../../utils/util.js"), a = require("../../config/api.js"), i = getApp();

Page({
    data: {
        haseChecked: !1,
        list: [],
        isIphoneX: i.globalData.isIphoneX,
        maskShow: !1,
        submitData: {},
        modalShow: !1,
        emailTxt: "",
        orderId: "",
        isPaper: !1
    },
    onLoad: function(t) {
        (0, e.showLoading)(), this.setData({
            orderId: t.orderId
        }), this.getInvoiceList();
    },
    getInvoiceList: function() {
        var i = this;
        (0, e.request)({
            url: a.api.invoice_detail,
            data: {
                orderId: i.data.orderId
            },
            success: function(a) {
                var s = a.list;
                s.forEach(function(t) {
                    if (1 === t.payer_type && (t.selected = !1), t.other_item) {
                        var e = Object.assign({}, JSON.parse(t.other_item));
                        t.companInfo = e;
                    }
                    t.totalNum = t.hotel.reduce(function(t, e) {
                        return Number(t) + Number(e.num);
                    }, 0), t.renderTime = i.getYYMMDD(1e3 * t.create_time), t.isEmail = i.isEmail(t.receiveraddr), 
                    t.detailShow = !1;
                });
                var r = s.every(function(t) {
                    return 1 !== t.payer_type;
                });
                i.setData({
                    list: (0, t.default)(s),
                    isPaper: r
                }), (0, e.hideLoading)();
            }
        });
    },
    checkboxChange: function(t) {
        t.currentTarget.dataset.checked ? this.data.list.forEach(function(t) {
            t.selected = !1;
        }) : this.data.list.forEach(function(t) {
            t.selected = !0;
        }), this.setData({
            haseChecked: !t.currentTarget.dataset.checked,
            list: this.data.list
        });
    },
    checkboxChangeLi: function(t) {
        var e = t.currentTarget.dataset;
        this.data.list.forEach(function(t) {
            t.id === Number(e.sid) && (t.selected = !t.selected);
        });
        var a = this.data.list.filter(function(t) {
            return 1 === t.payer_type;
        });
        this.data.haseChecked = a.every(function(t) {
            return t.selected;
        }), this.setData({
            haseChecked: this.data.haseChecked,
            list: this.data.list
        });
    },
    showAllInfo: function(t) {
        var e = t.currentTarget.dataset;
        this.data.list.forEach(function(t) {
            t.id === Number(e.sid) && (t.detailShow = !t.detailShow);
        }), this.setData({
            list: this.data.list
        });
    },
    nexTap: function() {
        this.data.list.some(function(t) {
            return t.selected;
        }) ? (console.log("弹窗显示"), this.setData({
            maskShow: !0,
            modalShow: !this.data.modalShow
        })) : i.toast("error", "请勾选发票");
    },
    modalClose: function() {
        this.setData({
            modalShow: !this.data.modalShow
        });
    },
    getEmail: function(t) {
        this.setData({
            emailTxt: t.detail.value
        });
    },
    submitBtn: function() {
        if (this.isEmail(this.data.emailTxt)) {
            var t = this.data.list.map(function(t) {
                return t.selected ? t.id : "";
            }).filter(function(t) {
                return t;
            });
            console.log("submitData", t), console.log("emailTxt", this.data.emailTxt);
            (0, e.request)({
                url: a.api.invoice_rest,
                data: {
                    orderId: this.data.orderId,
                    email: this.data.emailTxt,
                    ids: t
                },
                method: "POST",
                success: function(t) {
                    1 == t.operation && (i.toast("success", "提交成功"), wx.navigateBack({
                        delta: 1
                    }));
                }
            });
        } else i.toast("error", "邮箱格式有误");
    },
    getYYMMDD: function(t) {
        var e = new Date(t);
        return "".concat(e.getFullYear(), ".").concat(this.fixTwo(e.getMonth() + 1), ".").concat(this.fixTwo(e.getDate()));
    },
    fixTwo: function(t) {
        return "0".concat(t).slice(-2);
    },
    isEmail: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
        return !(!t || !/^[a-zA-Z0-9]+([-+.][a-zA-Z0-9]+)*@[a-zA-Z0-9]+([-.][a-zA-Z0-9]+)*\.[a-zA-Z0-9]+([-.][a-zA-Z0-9]+)*$/.test(t));
    }
});
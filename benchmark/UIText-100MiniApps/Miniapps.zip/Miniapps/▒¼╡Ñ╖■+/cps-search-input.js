Component({
    properties: {},
    options: {
        addGlobalClass: !0
    },
    data: {
        text: ""
    },
    methods: {
        bindSearchConfirm: function(t) {
            this.triggerEvent("didSearchConfifm", t.detail.value || this.data.text);
        },
        didInput: function(t) {
            this.setData({
                text: t.detail.value
            });
        }
    }
});
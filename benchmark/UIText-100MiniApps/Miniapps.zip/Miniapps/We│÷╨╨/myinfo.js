var e = wx.cloud.database(), n = getApp(), t = require("../../config.js");

Page({
    data: {
        adonoff: !1,
        ids: -1,
        email: "",
        phone: "",
        namenum: "",
        id: "",
        wxnum: "",
        campus: JSON.parse(t.data).campus
    },
    onLoad: function(e) {
        n.openid && (this.setData({
            id: n.userinfo._id
        }), console.log("useropenid: ", this.data.id)), " " !== n.userinfo && (this.setData({
            issign: !0,
            newSign: !1,
            nickName: n.userinfo.nickName,
            userPic: n.userinfo.userPic,
            email: n.userinfo.email,
            phone: n.userinfo.phone,
            namenum: n.userinfo.name,
            wxnum: n.userinfo.wxnum
        }), console.log("user: ", this.data.wxnum)), n.userinfo.adonoff && (this.setData({
            adonoff: !0
        }), console.log("app:", this.data.adonoff));
    },
    choose: function(e) {
        this.setData({
            ids: e.detail.value
        });
    },
    getPhoneNumber: function(e) {
        var n = this;
        e.detail.errMsg && "getPhoneNumber:ok" == e.detail.errMsg ? (wx.showLoading({
            title: "获取手机号中..."
        }), wx.login({
            success: function(t) {
                wx.cloud.callFunction({
                    name: "regist",
                    data: {
                        $url: "phone",
                        encryptedData: e.detail.encryptedData,
                        iv: e.detail.iv,
                        code: t.code
                    },
                    success: function(e) {
                        if (console.log(e), wx.hideLoading(), null == e.result) return wx.showToast({
                            title: "获取失败,请重新获取",
                            icon: "none",
                            duration: 2e3
                        }), !1;
                        n.setData({
                            phone: e.result.data.phoneNumber
                        });
                    },
                    fail: function(e) {
                        console.error(e), wx.hideLoading(), wx.showToast({
                            title: "获取失败,请重新获取",
                            icon: "none",
                            duration: 2e3
                        });
                    }
                });
            },
            fail: function(e) {
                console.error(e), wx.hideLoading(), wx.showToast({
                    title: "获取失败,请重新获取",
                    icon: "none",
                    duration: 2e3
                });
            }
        })) : wx.showToast({
            title: "获取手机号失败",
            icon: "none"
        });
    },
    wxInput: function(e) {
        this.setData({
            wxnum: e.detail.value
        }), console.log(this.data.wxnum);
    },
    nameInput: function(e) {
        this.setData({
            namenum: e.detail.value
        }), console.log(this.data.namenum);
    },
    emInput: function(e) {
        this.setData({
            email: e.detail.value
        }), console.log(this.data.email);
    },
    phoneInput: function(e) {
        this.setData({
            phone: e.detail.value
        }), console.log(this.data.phone);
    },
    getUserInfo: function(e) {
        console.log(e), "-1" == e.detail.errMsg.indexOf("ok") ? wx.showToast({
            title: "请授权后方可使用",
            icon: "none",
            duration: 2e3
        }) : (this.setData({
            userInfo: e.detail.userInfo
        }), this.upinfo());
    },
    onSet: function() {
        var t = this, a = t.data.email;
        return /^\w+((.\w+)|(-\w+))@[A-Za-z0-9]+((.|-)[A-Za-z0-9]+).[A-Za-z0-9]+$/.test(a) ? t.data.phone ? void e.collection("user").doc(t.data.id).update({
            data: {
                email: t.data.email,
                phone: t.data.phone,
                name: t.data.namenum,
                wxnum: t.data.wxnum
            },
            success: function(e) {
                n.userinfo.email = t.data.email, n.userinfo.phone = t.data.phone, t.tip(), wx.showModal({
                    title: "提交成功",
                    showCancel: !1,
                    content: "感谢您完善个人信息！",
                    confirmText: "返回",
                    success: function(e) {
                        e.confirm && wx.navigateBack({});
                    }
                }), console.log("[数据库] [222记录] 成功，记录 _id: ", e);
            },
            fail: function(e) {
                wx.showToast({
                    title: "提交失败，请再次提交"
                }), console.error("[数据库] [更新记录] 失败：", e);
            }
        }) : (wx.showToast({
            title: "请输入手机号",
            icon: "none",
            duration: 2e3
        }), !1) : (wx.showToast({
            title: "请输入正确邮箱",
            icon: "none",
            duration: 2e3
        }), !1);
    },
    tip: function() {
        wx.cloud.callFunction({
            name: "email",
            data: {
                type: 11,
                email: this.data.email,
                title: "注册信息成功！"
            },
            success: function(e) {
                console.log(e);
            }
        });
    },
    check: function() {
        this.data.phone;
        var n = this.data.email;
        if (!/^\w+((.\w+)|(-\w+))@[A-Za-z0-9]+((.|-)[A-Za-z0-9]+).[A-Za-z0-9]+$/.test(n)) return wx.showToast({
            title: "请输入邮箱",
            icon: "none",
            duration: 2e3
        }), !1;
        this.data.namenum, this.data.wxnum;
        wx.showLoading({
            title: "正在提交"
        }), e.collection("user").doc(this.data.openid).update({
            data: {
                phone: this.data.phone,
                name: this.data.namenum,
                email: this.data.email,
                wxnum: this.data.wxnum
            },
            success: function(e) {
                wx.hideLoading(), console.log(e);
            },
            fail: function() {
                wx.hideLoading(), wx.showToast({
                    title: "注册失败，请重新提交",
                    icon: "none"
                });
            }
        });
    }
});
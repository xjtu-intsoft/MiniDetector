(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/session/codelogin/codelogin" ], {
    "07ed": function(n, t, o) {
        o.r(t);
        var e, i = o("555d"), u = o.n(i);
        for (e in i) "default" !== e && function(n) {
            o.d(t, n, function() {
                return i[n];
            });
        }(e);
        t.default = u.a;
    },
    2141: function(n, t, o) {
        o.d(t, "b", function() {
            return e;
        }), o.d(t, "c", function() {
            return i;
        }), o.d(t, "a", function() {});
        var e = function() {
            this.$createElement;
            this._self._c;
        }, i = [];
    },
    "24a3": function(n, t, o) {
        o.r(t);
        var e, i = o("2141"), u = o("07ed");
        for (e in u) "default" !== e && function(n) {
            o.d(t, n, function() {
                return u[n];
            });
        }(e);
        o("94f9");
        var a = o("f0c5"), i = Object(a.a)(u.default, i.b, i.c, !1, null, null, null, !1, i.a, void 0);
        t.default = i.exports;
    },
    "37eb": function(n, t, o) {},
    "555d": function(n, e, i) {
        (function(o) {
            var n;
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var t = {
                mixins: [ ((n = i("6753")) && n.__esModule ? n : {
                    default: n
                }).default ],
                computed: {
                    urlForSessionPrivacy: function() {
                        return this.$App.urls.getUrlForSessionPrivacy();
                    }
                },
                onLoad: function() {},
                data: function() {
                    return {
                        phoneData: "",
                        passData: "",
                        verCode: "",
                        showAgree: !1,
                        isRotate: !1
                    };
                },
                components: {
                    wInput: function() {
                        i.e("components/watch-login/watch-input").then(function() {
                            return resolve(i("486b"));
                        }.bind(null, i)).catch(i.oe);
                    },
                    wButton: function() {
                        Promise.all([ i.e("common/vendor"), i.e("components/watch-login/watch-button") ]).then(function() {
                            return resolve(i("f8b6"));
                        }.bind(null, i)).catch(i.oe);
                    }
                },
                mounted: function() {
                    this.isLogin();
                },
                methods: {
                    isLogin: function() {
                        this.$App.account.islogin() && o.redirectTo({
                            url: this.$App.urls.getUrlForMyIndex()
                        });
                    },
                    isShowAgree: function() {
                        this.showAgree = !this.showAgree;
                    },
                    getVerCode: function() {
                        var t = this;
                        t.$App.util.getVerCode(t.phoneData).then(function(n) {
                            t.$refs.runCode.$emit("runCode");
                        }).catch(function(n) {});
                    },
                    startReg: function() {
                        var t = this;
                        if (this.isRotate) return !1;
                        if (0 == this.showAgree) return o.showToast({
                            icon: "none",
                            position: "bottom",
                            title: "请先同意《隐私政策》"
                        }), !1;
                        if (!t.$App.util.isMobile(t.phoneData)) return o.showToast({
                            icon: "none",
                            position: "bottom",
                            title: "手机号不正确"
                        }), !1;
                        if (4 != this.verCode.length) return o.showToast({
                            icon: "none",
                            position: "bottom",
                            title: "验证码不正确"
                        }), !1;
                        t.isRotate = !0;
                        var n = {
                            phone: t.phoneData,
                            code: t.verCode
                        };
                        t.$App.api.apiSessionCodeLogin(n).then(function(n) {
                            n = n.data;
                            null != n.memberInfo && null != n.memberInfo.uid && (t.$App.account.user = n, t.setUserInfo(t.$App.account.user), 
                            t.$App.informer.postNotificationName("userlogined"), t.$App.util.goBack());
                        }).catch(function(n) {
                            t.$App.dialog.toast(n.message);
                        }).finally(function() {
                            t.isRotate = !1;
                        });
                    }
                }
            };
            e.default = t;
        }).call(this, i("543d").default);
    },
    "7a52": function(n, t, o) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            o("d989"), t(o("66fd")), n(t(o("24a3")).default);
        }).call(this, o("543d").createPage);
    },
    "94f9": function(n, t, o) {
        var e = o("37eb");
        o.n(e).a;
    }
}, [ [ "7a52", "common/runtime", "common/vendor" ] ] ]);
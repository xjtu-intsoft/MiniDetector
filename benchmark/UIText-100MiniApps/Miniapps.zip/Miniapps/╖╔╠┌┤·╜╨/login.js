require("../../libs/amap-wx.js"), require("../../libs/wgs2mars.min.js");

var e = require("../../libs/MD5.js"), t = {
    latitude: "",
    longitude: ""
}, a = getApp();

Page({
    data: {
        user_phone: "",
        disabled: !0,
        code_text: "点击获取",
        code_disabled: !1,
        code: ""
    },
    user_phone: function(e) {
        this.setData({
            user_phone: e.detail.value
        });
    },
    onLoad: function(e) {
        wx.getLocation({
            type: "wgs84",
            success: function(e) {
                t.latitude = e.latitude, t.longitude = e.longitude;
            }
        });
    },
    clearPhone: function() {
        console.log("已清除"), this.setData({
            user_phone: ""
        });
    },
    loginBtnUse: function(e) {
        this.setData({
            disabled: !1,
            code: e.detail.value
        });
    },
    getCode: function() {
        var o = this;
        o.setData({
            code_disabled: !0
        });
        var s = o.data.user_phone;
        if (console.log(s), !/^(((13[0-9]{1})|(14[0-9]{1})|(15[0-9]{1})|(17[0-9]{1})|(18[0-9]{1}))+\d{8})$/.test(s)) return wx.showToast({
            title: "手机号有误！"
        }), !1;
        var n = 60, i = setInterval(function() {
            n -= 1, o.setData({
                code_text: n + "(s)"
            }), 0 == n && (clearInterval(i), o.setData({
                code_text: "重新获取",
                code_disabled: !1
            }));
        }, 1e3), d = Date.parse(new Date());
        d /= 1e3, console.log("当前时间戳为：" + d);
        var l = "cpor" + d + "7u3dE0mwI6xAkr" + d + "qbT73gsdytsciC";
        l = e.hexMD5(l), console.log("token:" + l), wx.getStorage({
            key: "openid",
            success: function(e) {
                wx.getStorage({
                    key: "currentCity",
                    success: function(o) {
                        wx.request({
                            url: a.urlData.login,
                            data: {
                                company: a.globalData.company,
                                appname: a.globalData.appname,
                                latitude: "" + t.latitude,
                                longitude: "" + t.longitude,
                                openid: e.data,
                                phoneno: s,
                                time: "" + d,
                                token: l
                            },
                            method: "GET",
                            success: function(e) {
                                console.log(e), "pass" == e.data.result ? wx.setStorage({
                                    key: "c_id",
                                    data: e.data.customer_manager_id
                                }) : wx.showToast({
                                    title: e.data.message
                                });
                            }
                        });
                    }
                });
            }
        });
    },
    login: function() {
        var e = this;
        console.log("电话：" + e.data.user_phone), console.log("验证码：" + e.data.code), wx.request({
            url: a.urlData.account_verify,
            data: {
                phoneno: e.data.user_phone,
                smscode: e.data.code,
                version: a.globalData.version
            },
            method: "GET",
            success: function(e) {
                console.log(e), "pass" == e.data.result ? (wx.setStorage({
                    key: "c_id",
                    data: e.data.customer_manager_id
                }), wx.setStorage({
                    key: "user_mobile",
                    data: e.data.mobile
                }), wx.reLaunch({
                    url: "../index/index",
                    success: function(e) {},
                    fail: function(e) {},
                    complete: function(e) {}
                })) : wx.showToast({
                    title: e.data.message
                });
            }
        });
    }
});
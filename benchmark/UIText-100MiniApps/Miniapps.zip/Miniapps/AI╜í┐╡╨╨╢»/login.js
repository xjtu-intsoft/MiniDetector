function e(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

var a = e(require("../../utils/util")), t = e(require("../../utils/tongji")), o = e(require("../../utils/api")), i = getApp();

Page({
    data: {
        logo: "https://ins-pro-luban.miao.cn/online/source/image/71925da0-f97c-11ea-a72b-592b37123625.png",
        loginImgs: {
            choose: "../../assets/image/select.png",
            unchoose: "../../assets/image/unselect.png",
            suc: "https://ins-pro-luban.miao.cn/online/source/image/8f4b8000-6a71-11ea-815e-29b7b0dc6a01.png"
        },
        agreePrivacy: !1,
        showMask: !1,
        loginInfo: null
    },
    onLoad: function() {
        a.default.getSessioinKey();
    },
    onShow: function() {
        t.default.pageRecord("login");
    },
    getPhoneNumber: function(e) {
        e.detail.iv ? this.login(e.detail.encryptedData, e.detail.iv) : a.default.showToast("登录失败");
    },
    login: function(e, t) {
        var n = this, s = {
            wx_key: i.globalData.sessionKey,
            gid: i.globalData.cookies.gid,
            encrypted_data: e,
            iv: t,
            timestamp: Date.now()
        };
        a.default.httpRequest({
            showLoading: !0,
            url: o.default.login,
            type: "POST",
            data: s,
            success: function(e) {
                200 === e.code ? n.setData({
                    showMask: !0,
                    loginInfo: e.data
                }) : 10007 === e.code ? a.default.showToast("登录失败, 请重试", 2e3) : 10009 === e.code ? (i.globalData.sessionKey = "", 
                a.default.getSessioinKey(), a.default.showToast("登录失败, 请重试", 2e3)) : a.default.showToast(e.message, 2e3);
            }
        });
    },
    getUser: function(e) {
        this.setData({
            showMask: !1
        });
        var t = e.detail.userInfo;
        t ? (console.log("授权了"), i.globalData.userInfo = t, a.default.setMyStorage("user", t), 
        this.jumpOut(), a.default.httpRequest({
            url: o.default.decryptUserInfo,
            type: "POST",
            data: {
                encrypted_data: e.detail.encryptedData,
                iv: e.detail.iv,
                profile_id: this.data.loginInfo.profile_id,
                wx_key: i.globalData.sessionKey
            },
            success: function(e) {}
        })) : a.default.showToast("登录失败", 2e3);
    },
    jumpOut: function() {
        a.default.setMyStorageSync("login_info", this.data.loginInfo), a.default.saveLoginInfoToGlobalData(this.data.loginInfo), 
        "" !== i.globalData.routeNo ? a.default.route() : wx.reLaunch({
            url: "/pages/home/home"
        });
    },
    authLoginTip: function() {
        a.default.showToast("请先阅读并勾选《隐私政策条款》《用户服务协议》", 2e3);
    },
    toggleAgreePrivacy: function() {
        this.setData({
            agreePrivacy: !this.data.agreePrivacy
        });
    },
    toPrivacy: function() {
        var e = a.default.makeUrl("mp/login/privacy");
        wx.navigateTo({
            url: a.default.makeWebviewUrl(e)
        });
    },
    toAgreement: function() {
        var e = a.default.makeUrl("mp/login/agreement");
        wx.navigateTo({
            url: a.default.makeWebviewUrl(e)
        });
    }
});
function _interopRequireDefault(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}

function _asyncToGenerator(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function i(r, a) {
                try {
                    var o = t[r](a), s = o.value;
                } catch (e) {
                    return void n(e);
                }
                if (!o.done) return Promise.resolve(s).then(function(e) {
                    i("next", e);
                }, function(e) {
                    i("throw", e);
                });
                e(s);
            }
            return i("next");
        });
    };
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
}

function _possibleConstructorReturn(e, t) {
    if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return !t || "object" != typeof t && "function" != typeof t ? e : t;
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            enumerable: !1,
            writable: !0,
            configurable: !0
        }
    }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
}

Object.defineProperty(exports, "__esModule", {
    value: !0
});

var _createClass = function() {
    function e(e, t) {
        for (var n = 0; n < t.length; n++) {
            var i = t[n];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), 
            Object.defineProperty(e, i.key, i);
        }
    }
    return function(t, n, i) {
        return n && e(t.prototype, n), i && e(t, i), t;
    };
}(), _wepy = require("./../npm/wepy/lib/wepy.js"), _wepy2 = _interopRequireDefault(_wepy), _CityJsonData = require("./../utils/Storage/CityJsonData.js"), _Util = require("./../utils/Util.js"), _common = require("./../mixins/common.js"), _common2 = _interopRequireDefault(_common), _WxNotificationCenter = require("./../utils/WxNotificationCenter/WxNotificationCenter.js"), _WxNotificationCenter2 = _interopRequireDefault(_WxNotificationCenter), _api = require("./../api/api.js"), _api2 = _interopRequireDefault(_api), _track = require("./../api/track.js"), _track2 = _interopRequireDefault(_track), _Util2 = require("./../utils/Util.js"), _platformInfo = require("./../lib/request/process/platformInfo.js"), CityPicker = function(e) {
    function t() {
        var e, n, i, r;
        _classCallCheck(this, t);
        for (var a = arguments.length, o = Array(a), s = 0; s < a; s++) o[s] = arguments[s];
        return n = i = _possibleConstructorReturn(this, (e = t.__proto__ || Object.getPrototypeOf(t)).call.apply(e, [ this ].concat(o))), 
        i.config = {
            navigationBarTitleText: "选择城市",
            enablePullDownRefresh: !1,
            backgroundTextStyle: "dark"
        }, i.mixins = [ _common2.default ], i.data = {
            allCity: {},
            hotCity: {},
            sectionTitle: [],
            searchResult: [],
            searchingFlag: !1,
            locateCity: {
                id: null,
                name: "定位中..."
            },
            tappedIndex: "a",
            tappingIndexFlag: !1,
            fontSize: 30,
            windowWidth: (0, _Util.getDeviceSizeInRpx)().width,
            windowHeight: 0,
            offsetY: 0
        }, i.methods = {
            pickCity: function() {
                function e(e) {
                    return t.apply(this, arguments);
                }
                var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                    var n, i;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (n = t.currentTarget.dataset, null !== n.id) {
                                e.next = 5;
                                break;
                            }
                            wx.showToast({
                                title: "请等待定位成功",
                                icon: "loading"
                            }), e.next = 11;
                            break;

                          case 5:
                            return i = {
                                id: n.cityId,
                                name: n.cityName,
                                englishName: n.cityEnglishName
                            }, e.next = 8, (0, _Util.setGlobalCity)(i);

                          case 8:
                            _WxNotificationCenter2.default.postNotificationName("FromChooseCity", i), wx.navigateBack(), 
                            _track2.default.index({
                                src: "home_choosecity",
                                tid: i.englishName
                            });

                          case 11:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return e;
            }(),
            onInput: function(e) {
                var t = e.detail.value;
                if (!t) return this.searchingFlag = !1, void this.$apply();
                var n = [];
                for (var i in this.allCity) for (var r in this.allCity[i]) {
                    var r = this.allCity[i][r];
                    -1 === r.name.indexOf(t) && 0 !== r.englishName.indexOf(t) || (n = n.concat(r));
                }
                this.searchResult = n, this.searchingFlag = !0, this.$apply();
            },
            cityIndexTap: function(e) {
                this.couldScroll = !1, this.tappingIndexFlag = !0;
                var t = (e.changedTouches[0].clientY - this.offsetY) / this.getFontHeightInPx();
                (t = Math.floor(t)) < -2 || t > this.data.sectionTitle.length + 2 || (t = Math.max(t, 0), 
                t = Math.min(t, this.data.sectionTitle.length), this.tappedIndex = this.data.sectionTitle[t], 
                this.$apply());
            },
            cityIndexEndTap: function(e) {
                this.tappingIndexFlag = !1, this.$apply();
            }
        }, r = n, _possibleConstructorReturn(i, r);
    }
    return _inherits(t, e), _createClass(t, [ {
        key: "getSysInfo",
        value: function() {
            return new Promise(function(e, t) {
                wx.getSystemInfo({
                    success: function(t) {
                        e(t);
                    }
                });
            });
        }
    }, {
        key: "getFontHeightInPx",
        value: function() {
            return this.fontSize / 750 * this.windowWidth;
        }
    }, {
        key: "getAllAreaData",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n = this;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        t = [ _api2.default.areaGetAllCities(), _api2.default.areaGetHotCities() ], Promise.all(t).then(function() {
                            var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                                var i, r, a, o;
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        return e.next = 2, n.getSysInfo();

                                      case 2:
                                        i = e.sent, r = (0, _CityJsonData.getSortedCityJson)(t[0].data.info.area.getAllCities), 
                                        a = t[1].data.info.area.getHotCities, o = Object.keys(r).sort(), n.windowWidth = i.windowWidth, 
                                        n.windowHeight = i.windowHeight, n.offsetY = (i.windowHeight - n.getFontHeightInPx() * o.length) / 2, 
                                        n.allCity = r, n.hotCity = a, n.sectionTitle = o, n.$apply();

                                      case 13:
                                      case "end":
                                        return e.stop();
                                    }
                                }, e, n);
                            }));
                            return function(t) {
                                return e.apply(this, arguments);
                            };
                        }()).catch(function(e) {
                            console.log(e);
                        });

                      case 2:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    }, {
        key: "onLoad",
        value: function() {
            function e() {
                return t.apply(this, arguments);
            }
            var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, this.getAllAreaData();

                      case 2:
                        return e.next = 4, (0, _Util2.resolveLatLng)();

                      case 4:
                        if (t = e.sent, n = void 0, t) {
                            e.next = 12;
                            break;
                        }
                        return e.next = 9, _api2.default.areaGetCurrentCity();

                      case 9:
                        n = e.sent, e.next = 15;
                        break;

                      case 12:
                        return e.next = 14, _api2.default.areaGetCurrentCityByLocation(t);

                      case 14:
                        n = e.sent;

                      case 15:
                        this.locateCity = n || {
                            id: null,
                            name: "定位失败"
                        }, this.$apply();

                      case 17:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }));
            return e;
        }()
    } ]), t;
}(_wepy2.default.page);

Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(CityPicker, "pages/citypicker"));
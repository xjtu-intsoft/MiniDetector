var t = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/helpers/defineProperty")), a = getApp();

wx.cloud.init(), Component({
    data: {
        theme: "light",
        _vibrateswitch: !1,
        isDisabled: !1,
        showTopTips: !1,
        years: [],
        yearsIndex: 3,
        term: [ "第一学期", "第二学期" ],
        termIndex: 0,
        formData: {
            username: "",
            password: "",
            term: "",
            year: ""
        },
        rules: [ {
            name: "username",
            rules: {
                required: !0,
                message: "学号必填"
            }
        }, {
            name: "password",
            rules: [ {
                required: !0,
                message: "密码必填"
            } ]
        } ],
        temp: !1
    },
    methods: {
        bindYearsChange: function(a) {
            var e = this.data.years[a.detail.value];
            this.setData((0, t.default)({
                yearsIndex: a.detail.value
            }, "formData.year", e));
        },
        bindTermChange: function(a) {
            var e = parseInt(a.detail.value) + 1;
            this.setData((0, t.default)({
                termIndex: a.detail.value
            }, "formData.term", e));
        },
        formInputChange: function(a) {
            var e = a.currentTarget.dataset.field;
            this.setData((0, t.default)({}, "formData.".concat(e), a.detail.value));
        },
        submitForm: function() {
            var t = this;
            this.data._vibrateswitch && wx.vibrateShort({});
            var a = this;
            this.setData({
                temp: !1
            }), this.selectComponent("#form").validate(function(a, e) {
                if (a) t.setData({
                    isDisabled: !0
                }); else {
                    var r = Object.keys(e);
                    r.length ? t.setData({
                        temp: !0,
                        error: e[r[0]].message
                    }) : t.setData({
                        temp: !1
                    });
                }
            }), this.data.temp || (wx.showToast({
                title: "查询中...",
                icon: "loading",
                duration: 1e6
            }), console.log(this.data.formData), wx.cloud.callFunction({
                name: "getScore",
                data: {
                    username: this.data.formData.username,
                    password: this.data.formData.password,
                    year: this.data.formData.year,
                    term: this.data.formData.term
                },
                complete: function(t) {
                    var e = t.result;
                    if (console.log("导入模块[成功]回调", e), e.length > 0) wx.setStorageSync("score_data", JSON.stringify(e)), 
                    wx.hideToast(), a.setData({
                        isDisabled: !1
                    }), wx.navigateTo({
                        url: "./step2"
                    }); else {
                        var r = e.error;
                        "可能是成绩接口地址不对，请尝试更改use_api值" == e.error && (r = "成绩查询接口暂停使用,请等待学校开放"), a.setData({
                            error: r,
                            isDisabled: !1
                        }), wx.hideToast();
                    }
                },
                fail: function() {
                    a.setData({
                        error: "网络崩溃",
                        isDisabled: !1
                    }), wx.hideToast();
                }
            }));
        },
        onShow: function() {
            var t = this, e = wx.getStorageSync("vibrateswitch");
            isNaN(e) ? this.setData({
                theme: a.globalData.theme,
                _vibrateswitch: !1
            }) : this.setData({
                theme: a.globalData.theme,
                _vibrateswitch: e
            }), wx.onThemeChange(function(e) {
                t.setData({
                    theme: a.globalData.theme
                });
            });
        },
        onLoad: function(t) {
            var a = wx.getStorageSync("vibrateswitch");
            isNaN(a) ? this.setData({
                _vibrateswitch: !1
            }) : this.setData({
                _vibrateswitch: a
            });
            for (var e = [], r = 0, s = new Date(), i = 4; i > 0; i--) {
                var o = (r = s.getMonth() < 6 ? s.getFullYear() - i : s.getFullYear() - i + 1) + "-" + (r + 1);
                e.push(o);
            }
            this.setData({
                years: e
            }), this.data.formData.year = this.data.years[3], this.data.formData.term = this.data.termIndex + 1;
        }
    }
});
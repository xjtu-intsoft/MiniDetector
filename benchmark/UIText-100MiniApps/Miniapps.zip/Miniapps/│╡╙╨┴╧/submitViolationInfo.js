var e = function(e) {
    return e && e.__esModule ? e : {
        default: e
    };
}(require("../../../https/index")), a = require("../../../https/api"), o = getApp();

Page({
    data: {
        bannerBaseUrl: o.globalData.bannerBaseUrl,
        switch1: !1,
        codeArray: [],
        infoJson: {},
        vioData: {},
        pageFrom: "",
        plateNo: "",
        name: "",
        phone: wx.getStorageSync("owner_user_info").mobile,
        proxyPhoneLen: "",
        JashiZhengHao: "",
        proxyCardNoLen: "",
        IDCard: "",
        CarCode: "12",
        CarDrive: "12",
        DanganBianHao: "",
        FilePhone: "",
        CheliangZhengShu: "",
        TiaoXingMa: "",
        XingShiZhengHao: "",
        DrivingLicense: "",
        DrivingSecondLicense: "",
        MajorViolation: "",
        MajorSecondViolation: "",
        VerifyCodeLen: "",
        VehicleBarcode: "",
        showDetail: !1
    },
    showDetail: function() {
        this.setData({
            showDetail: !this.data.showDetail
        });
    },
    onChange: function(e) {
        var a = e.detail;
        this.setData({
            switch1: a.value
        });
    },
    getVCode: function() {
        e.default.cylRequest("sendViolationCode", "POST", {
            plateNo: this.data.plateNo
        }).then(function(e) {
            wx.showToast({
                title: "发送成功",
                icon: "success",
                duration: 2e3
            });
        }).catch(function(e) {});
    },
    onLoad: function(e) {
        console.log("ui-------", JSON.parse(e.data)), console.log(wx.getStorageSync("owner_user_info").mobile);
        var a = JSON.parse(e.data);
        this.setData({
            vioData: a.records.Records,
            plateNo: a.plateNo,
            codeArray: this.getCode(a.records.Records),
            pageFrom: e.pageFrom
        }), this.getInfo(this.data.plateNo, this.getCode(a.records.Records));
    },
    uploadImg: function(e) {
        console.log("--------", e);
        var o = this;
        wx.chooseImage({
            count: 1,
            sizeType: [ "original", "compressed" ],
            sourceType: [ "album", "camera" ],
            success: function(n) {
                var i = n.tempFilePaths;
                wx.uploadFile({
                    header: {
                        Authorization: wx.getStorageSync("wstore_token")
                    },
                    url: a.ownerDomain + "/v2/api/cyl/file/uploadimg",
                    filePath: i[0],
                    name: "file",
                    success: function(a) {
                        if (200 == a.statusCode) {
                            var n = JSON.parse(a.data);
                            console.log("---=====", n);
                            var i = {};
                            "DrivingLicense" == e.currentTarget.id ? i = {
                                DrivingLicense: o.data.bannerBaseUrl + n.info
                            } : "DrivingSecondLicense" == e.currentTarget.id ? i = {
                                DrivingSecondLicense: o.data.bannerBaseUrl + n.info
                            } : "MajorViolation" == e.currentTarget.id ? i = {
                                MajorViolation: o.data.bannerBaseUrl + n.info
                            } : "MajorSecondViolation" == e.currentTarget.id && (i = {
                                MajorSecondViolation: o.data.bannerBaseUrl + n.info
                            }), console.log(i), o.setData(i);
                        }
                    }
                });
            }
        });
    },
    submitOrder: function() {
        var a = this;
        a.data.name ? a.data.phone ? a.data.JashiZhengHao || 0 == a.data.infoJson.condition.JashiZhengHaoLen ? a.data.proxyPhoneLen || 0 == a.data.infoJson.condition.proxyPhoneLen ? a.data.proxyCardNoLen || 0 == a.data.infoJson.condition.proxyCardNoLen ? a.data.IDCard || 0 == a.data.infoJson.condition.OwnerCardLen ? a.data.CarCode || 0 == a.data.infoJson.condition.CarCodeLen ? a.data.CarDrive || 0 == a.data.infoJson.condition.CarDriveLen ? a.data.DanganBianHao || 0 == a.data.infoJson.condition.DanganBianHaoLen ? a.data.FilePhone || 0 == a.data.infoJson.condition.FilePhoneLen ? a.data.CheliangZhengShu || 0 == a.data.infoJson.condition.CheliangZhengShuLen ? a.data.TiaoXingMa || 0 == a.data.infoJson.condition.TiaoXingMaLen ? a.data.XingShiZhengHao || 0 == a.data.infoJson.condition.XingShiZhengHaoLen ? a.data.VehicleBarcode || 0 == a.data.infoJson.condition.VehicleBarcode ? a.data.DrivingLicense || 0 == a.data.infoJson.condition.DrivingLicense ? a.data.DrivingSecondLicense || 0 == a.data.infoJson.condition.DrivingSecondLicense ? a.data.MajorViolation || 0 == a.data.infoJson.condition.MajorViolation ? a.data.MajorSecondViolation || 0 == a.data.infoJson.condition.MajorSecondViolation ? a.data.VerifyCodeLen || 0 == a.data.infoJson.condition.VerifyCodeLen ? e.default.cylRequest("submitViolationOrder", "POST", {
            orderType: "2",
            extra: {
                plateNo: this.data.plateNo,
                SecondaryUniqueCode: this.data.codeArray,
                isUrgent: this.data.switch1,
                orderConfig: {
                    Name: this.data.name,
                    Phone: this.data.phone,
                    Cardno: this.data.JashiZhengHao,
                    proxyPhone: this.data.proxyPhoneLen,
                    proxyCardNo: this.data.proxyCardNoLen,
                    CarCode: this.data.CarCode,
                    CarDrive: this.data.CarDrive,
                    FileNumber: this.data.DanganBianHao,
                    FilePhone: this.data.FilePhone,
                    CheliangZhengShu: this.data.CheliangZhengShu,
                    QRCode: this.data.TiaoXingMa,
                    XingShiZhengHao: this.data.XingShiZhengHao,
                    DrivingUrl: this.data.DrivingLicense,
                    DrivingSecondUrl: this.data.DrivingSecondLicense,
                    DriverUrl: this.data.MajorViolation,
                    DriverSecondUrl: this.data.MajorSecondViolation,
                    VerifyCode: this.data.VerifyCodeLen,
                    VehicleBarcode: this.data.VehicleBarcode
                }
            }
        }).then(function(e) {
            console.log("下单成功", e), a.createOrder();
        }).catch(function(e) {
            console.log("jieguo失败===", e);
        }) : wx.showToast({
            title: "请输入验证码",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请上传驾驶证照片（背页）",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请上传驾驶证照片（正页）",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请上传行驶证照片（背页）",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请上传行驶证照片（正页）",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入行驶证条形码",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入行驶证档案编号",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入驾驶证条形码编号",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入车辆登记证书号",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入车主车管所驾驶证登记电话",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入驾驶证档案编号",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入发动机号",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入车架号",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入车主身份证号",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入办理人驾驶证号",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入办理人登记手机号",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入车主驾驶证号",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入车主电话",
            icon: "none",
            duration: 2e3
        }) : wx.showToast({
            title: "请输入真实姓名",
            icon: "none",
            duration: 2e3
        });
    },
    delImg: function(e) {
        var a = {};
        "DrivingLicense" == e.currentTarget.dataset.id ? a = {
            DrivingLicense: ""
        } : "DrivingSecondLicense" == e.currentTarget.dataset.id ? a = {
            DrivingSecondLicense: ""
        } : "MajorViolation" == e.currentTarget.dataset.id ? a = {
            MajorViolation: ""
        } : "MajorSecondViolation" == e.currentTarget.dataset.id && (a = {
            MajorSecondViolation: ""
        }), this.setData(a);
    },
    createOrder: function() {
        var a = this;
        e.default.cylRequest("createOrder", "POST", {}).then(function(e) {
            console.log("新下单成功", e), a.getWXPayDetail(e);
        }).catch(function(e) {
            console.log("jieguo失败===", e);
        });
    },
    getWXPayDetail: function(a) {
        var o = [];
        for (var n in a) o.push(a[n].orderId);
        var i = this;
        e.default.cylRequest("getWXPayInfo", "POST", {
            payType: 3,
            useWallet: !1,
            orderId: o
        }).then(function(a) {
            console.log("获取微信下单信息", a);
            var o = {
                unifiedorder: {
                    timeStamp: a.timestamp,
                    nonceStr: a.noncestr,
                    prepay_id: a.prepayid,
                    paySign: a.sign
                }
            };
            e.default.wxPayMethod(o, function(e) {
                console.log("支付成功==", e), wx.navigateBack({
                    delta: parseInt(i.data.pageFrom)
                });
            }, function() {
                console.log("支付失败了", i.data.pageFrom);
            });
        }).catch(function(e) {
            console.log("jieguo失败===", e);
        });
    },
    inputChange: function(e) {
        var a = {};
        "name" == e.currentTarget.id ? a = {
            name: e.detail.value
        } : "phone" == e.currentTarget.id ? a = {
            phone: e.detail.value
        } : "proxyPhoneLen" == e.currentTarget.id ? a = {
            proxyPhoneLen: e.detail.value
        } : "JashiZhengHao" == e.currentTarget.id ? a = {
            JashiZhengHao: e.detail.value
        } : "proxyCardNoLen" == e.currentTarget.id ? a = {
            proxyCardNoLen: e.detail.value
        } : "IDCard" == e.currentTarget.id ? a = {
            IDCard: e.detail.value
        } : "CarCode" == e.currentTarget.id ? a = {
            CarCode: e.detail.value
        } : "CarDrive" == e.currentTarget.id ? a = {
            CarDrive: e.detail.value
        } : "DanganBianHao" == e.currentTarget.id ? a = {
            DanganBianHao: e.detail.value
        } : "FilePhone" == e.currentTarget.id ? a = {
            FilePhone: e.detail.value
        } : "CheliangZhengShu" == e.currentTarget.id ? a = {
            CheliangZhengShu: e.detail.value
        } : "TiaoXingMa" == e.currentTarget.id ? a = {
            TiaoXingMa: e.detail.value
        } : "XingShiZhengHao" == e.currentTarget.id ? a = {
            XingShiZhengHao: e.detail.value
        } : "VerifyCodeLen" == e.currentTarget.id ? a = {
            VerifyCodeLen: e.detail.value
        } : "VehicleBarcode" == e.currentTarget.id && (a = {
            VehicleBarcode: e.detail.value
        }), this.setData(a);
    },
    getCode: function(e) {
        var a = [];
        for (var o in e) console.log("==11==", e[o]), 1 == e[o].CanProcess && a.push(e[o].SecondaryUniqueCode);
        return a;
    },
    getInfo: function(a, o) {
        var n = this;
        e.default.cylRequest("getViolationSubmitInfo", "POST", {
            plateNo: a,
            SecondaryUniqueCode: o
        }).then(function(e) {
            console.log("0-90--0-", e), n.setData({
                infoJson: e.info
            });
        }).catch(function(e) {
            console.log("jieguo失败===", e);
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});
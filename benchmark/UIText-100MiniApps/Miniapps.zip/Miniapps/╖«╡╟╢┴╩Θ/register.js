var e = getApp(), t = require("../../utils/util.js"), a = require("../../public/service/service.js"), o = require("../../utils/gio-minp.js");

Page({
    data: {
        deleteInputVal: !0,
        codeText: "获取验证码",
        areaCode: "86",
        codeStyle: "code-text-weight",
        codeType: !0,
        loginStyle: "login-weight",
        phoneNum: "",
        passwordNum: "",
        codeNum: "",
        loginText: "密码登录",
        loginType: !0,
        modal: !0,
        positioning: e.globalData.positioning,
        latitudeLongitude: e.globalData.latitudeLongitude
    },
    onShow: function() {
        var e = this;
        getCurrentPages().length;
        wx.getStorage({
            key: "areaCode",
            success: function(t) {
                e.setData({
                    areaCode: t.data
                }), wx.removeStorage({
                    key: "areaCode"
                });
            }
        });
    },
    bindPickerChange: function(e) {
        console.log("picker发送选择改变，携带值为", e.detail.value), this.setData({
            index: e.detail.value
        });
    },
    getCode: function() {
        var e = this, o = e.data.areaCode, n = "86" == o ? e.data.phoneNum : "+" + o + e.data.phoneNum, i = t.isValidMobile(e.data.phoneNum);
        return n ? i || "86" != o ? !!e.data.codeType && void a.verificationCode({
            mobile: n
        }).then(function(a) {
            wx.showToast({
                title: "已发送至手机" + n,
                icon: "none",
                duration: 1e3
            }), t.settime(60, function(t, a) {
                e.setData({
                    codeText: t,
                    codeType: a,
                    codeStyle: a ? "code-text-weight" : "code-text-light"
                });
            });
        }) : (wx.showToast({
            title: "手机号错误，请重新填写",
            icon: "none",
            duration: 1e3
        }), !1) : (wx.showToast({
            title: "请填写手机号",
            icon: "none",
            duration: 1e3
        }), !1);
    },
    phoneVal: function(e) {
        var t = this;
        e.detail.value ? t.setData({
            deleteInputVal: !1,
            phoneNum: e.detail.value
        }) : t.setData({
            deleteInputVal: !0,
            phoneNum: e.detail.value
        });
    },
    codeVal: function(e) {
        this.setData({
            codeNum: e.detail.value
        });
    },
    passwordVal: function(e) {
        var t = this;
        e.detail.value && t.setData({
            passwordNum: e.detail.value
        });
    },
    cutLoginType: function() {
        var e = this;
        e.data.loginType ? e.setData({
            loginText: "手机验证码登录",
            loginType: !1
        }) : e.setData({
            loginText: "密码登录",
            loginType: !0
        });
    },
    cancel: function() {
        this.setData({
            phoneNum: "",
            deleteInputVal: !0
        });
    },
    login: t.throttle(function() {
        var n = getCurrentPages().length;
        wx.showLoading({
            mask: !0,
            title: "加载中"
        });
        var i = this, d = this.data.loginType, r = this.data.areaCode, s = 86 == r ? i.data.phoneNum : "+" + r + i.data.phoneNum, u = e.globalData.scene, l = t.getScene(u) ? 2 : 1, g = e.globalData.shareId;
        if (!i.data.phoneNum) return wx.showToast({
            title: "请填写手机号",
            icon: "none",
            duration: 1e3
        }), !1;
        if (d) {
            if (!i.data.codeNum) return wx.showToast({
                title: "请填写验证码",
                icon: "none",
                duration: 1e3
            }), !1;
            a.login({
                mobile: s,
                verificationCode: i.data.codeNum,
                openId: wx.getStorageSync("openId"),
                unionId: wx.getStorageSync("unionId"),
                source: l,
                shareUserId: g,
                positioning: e.globalData.positioning,
                latitudeLongitude: e.globalData.latitudeLongitude
            }).then(function(t) {
                wx.hideLoading(), console.log(t);
                wx.getStorageSync("pageSource");
                e.globalData.isLogin = !0, o("setUserId", t.userId), wx.setStorageSync("token", t.token), 
                wx.setStorageSync("userId", t.userId), wx.setStorageSync("userName", t.username), 
                wx.setStorageSync("reload", !0), wx.setStorageSync("pageSource", "register");
                var i = wx.getStorageSync("loginPage");
                a.addVipTerm(), i && 2 != n ? wx.navigateBack({
                    delta: 2
                }) : wx.switchTab({
                    url: "/pages/index/index"
                });
            }).catch(function(e) {
                setTimeout(function() {
                    wx.hideLoading();
                }, 1500);
            });
        } else {
            if (!i.data.passwordNum) return wx.showToast({
                title: "请填写密码",
                icon: "none",
                duration: 1e3
            }), !1;
            a.login({
                mobile: s,
                password: i.data.passwordNum,
                openId: wx.getStorageSync("openId"),
                unionId: wx.getStorageSync("unionId"),
                source: l,
                shareUserId: g,
                positioning: e.globalData.positioning,
                latitudeLongitude: e.globalData.latitudeLongitude
            }).then(function(t) {
                wx.getStorageSync("pageSource");
                e.globalData.isLogin = !0, o("setUserId", t.userId), e.globalData.userId = t.userId, 
                e.globalData.userName = t.userName, wx.setStorageSync("token", t.token), wx.setStorageSync("userId", t.userId), 
                wx.setStorageSync("userName", t.username), wx.setStorageSync("reload", !0), wx.setStorageSync("pageSource", "register");
                var i = wx.getStorageSync("loginPage");
                a.addVipTerm(), i && 2 != n ? wx.navigateBack({
                    delta: 2
                }) : wx.switchTab({
                    url: "/pages/index/index"
                });
            }).catch(function(e) {
                setTimeout(function() {
                    wx.hideLoading();
                }, 1500);
            });
        }
    }, 3e3),
    getAreaCode: t.throttle(function() {
        wx.navigateTo({
            url: "../areaCode/areaCode"
        });
    }),
    agreeMent: t.throttle(function() {
        wx.navigateTo({
            url: "../../pages/agreement/agreement"
        });
    }),
    onMyEvent: function(e) {
        console.log(e);
    }
});
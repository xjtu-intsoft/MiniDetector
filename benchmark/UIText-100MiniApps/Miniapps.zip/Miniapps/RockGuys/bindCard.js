function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var a = t(require("../../utils/validate")), e = t(require("../../libs/zanui/index")), n = require("../../constant"), o = getApp(), i = null;

Page(Object.assign({}, e.default.Toast, {
    data: {
        accountTypes: [ "个人账户", "对公账户" ],
        accountType: "0",
        inSubmit: !1
    },
    onLoad: function(t) {
        var a = getCurrentPages();
        i = a[a.length - 2];
    },
    onReady: function() {},
    onShow: function() {},
    accountTypeChange: function(t) {
        this.setData({
            accountType: t.detail.value
        });
    },
    submit: function(t) {
        var e = this;
        if (!this.data.inSubmit) {
            console.log(t);
            var s = t.detail.value;
            if ("1" == this.data.accountType && a.default.isNullOrEmpty(s.accountName)) this.showZanToast("开户名称不能为空"); else if (a.default.isNullOrEmpty(s.accountNo)) this.showZanToast("银行账户不能为空"); else {
                if (!a.default.isBankCard(s.accountNo)) return console.log(s), void this.showZanToast("银行账户不正确");
                if (a.default.isNullOrEmpty(s.bank)) this.showZanToast("开户银行不能为空"); else if (a.default.isNullOrEmpty(s.outlet)) this.showZanToast("开户网点不能为空"); else if ("1" == this.data.accountType && a.default.isNullOrEmpty(s.tax)) this.showZanToast("税号不能为空"); else if (a.default.isNullOrEmpty(s.name)) this.showZanToast("持卡人姓名不能为空"); else if (a.default.isNullOrEmpty(s.idcard)) this.showZanToast("身份证号不能为空"); else if (a.default.isIDCardNo(s.idcard)) if (a.default.isNullOrEmpty(s.mobile)) this.showZanToast("手机号码不能为空"); else if (a.default.isMobile(s.mobile)) {
                    this.setData({
                        inSubmit: !0
                    });
                    var u = wx.getStorageSync(n.CURRENT_USER_ID), c = {
                        type: this.data.accountTypes[this.data.accountType],
                        bank: "",
                        account: s.accountNo,
                        openbank: s.bank,
                        openarea: s.outlet,
                        taxe: "",
                        name: s.name,
                        identity: s.idcard,
                        phone: s.mobile,
                        user_id: u
                    };
                    this.data.accountType && (c.bank = s.accountName, c.taxe = s.tax), o.api.bindBankCard(c).then(function(t) {
                        console.log(t), e.setData({
                            inSubmit: !1
                        }), i.setData({
                            bankAccount: {
                                id: t.id,
                                accountNo: i.cardStar(t.account),
                                name: i.nameStar(t.name),
                                accountName: t.accountName,
                                bank: t.openbank,
                                accountType: e._getAccountTypeIndex(t.type)
                            }
                        }), wx.navigateBack({});
                    }).catch(function(t) {
                        console.log(t), e.setData({
                            inSubmit: !1
                        });
                    });
                } else this.showZanToast("手机号码不正确"); else this.showZanToast("身份证号不正确");
            }
        }
    },
    _getAccountTypeIndex: function(t) {
        for (var a = -1, e = 0; e < this.data.accountTypes.length; e++) this.data.accountTypes[e] == t && (a = e);
        return a;
    }
}));
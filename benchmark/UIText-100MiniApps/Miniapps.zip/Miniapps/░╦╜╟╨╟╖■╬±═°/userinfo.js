(global["webpackJsonp"] = global["webpackJsonp"] || []).push([ [ "pages/person/userinfo" ], {
    "3d1b": function d1b(n, e, t) {
        "use strict";
        t.d(e, "b", function() {
            return i;
        }), t.d(e, "c", function() {
            return u;
        }), t.d(e, "a", function() {
            return o;
        });
        var o = {
            uForm: function uForm() {
                return t.e("uview-ui/components/u-form/u-form").then(t.bind(null, "820d"));
            },
            uFormItem: function uFormItem() {
                return Promise.all([ t.e("common/vendor"), t.e("uview-ui/components/u-form-item/u-form-item") ]).then(t.bind(null, "f13e"));
            },
            uInput: function uInput() {
                return Promise.all([ t.e("common/vendor"), t.e("uview-ui/components/u-input/u-input") ]).then(t.bind(null, "76f0"));
            },
            uButton: function uButton() {
                return t.e("uview-ui/components/u-button/u-button").then(t.bind(null, "403b"));
            },
            uLine: function uLine() {
                return t.e("uview-ui/components/u-line/u-line").then(t.bind(null, "bd19"));
            }
        }, i = function i() {
            var n = this, e = n.$createElement;
            n._self._c;
        }, u = [];
    },
    "4ad3": function ad3(n, e, t) {
        "use strict";
        t.r(e);
        var o = t("8d41"), i = t.n(o);
        for (var u in o) {
            "default" !== u && function(n) {
                t.d(e, n, function() {
                    return o[n];
                });
            }(u);
        }
        e["default"] = i.a;
    },
    6786: function _(n, e, t) {
        "use strict";
        var o = t("8ca3"), i = t.n(o);
        i.a;
    },
    "8ca3": function ca3(n, e, t) {},
    "8d41": function d41(n, e, t) {
        "use strict";
        (function(n) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = void 0;
            var o = u(t("a34a")), i = (u(t("1d84")), t("9ebf"));
            function u(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            function r(n, e, t, o, i, u, r) {
                try {
                    var a = n[u](r), c = a.value;
                } catch (s) {
                    return void t(s);
                }
                a.done ? e(c) : Promise.resolve(c).then(o, i);
            }
            function a(n) {
                return function() {
                    var e = this, t = arguments;
                    return new Promise(function(o, i) {
                        var u = n.apply(e, t);
                        function a(n) {
                            r(u, o, i, a, c, "next", n);
                        }
                        function c(n) {
                            r(u, o, i, a, c, "throw", n);
                        }
                        a(void 0);
                    });
                };
            }
            var c = {
                data: function data() {
                    return {
                        username: "",
                        wxBinded: !1,
                        form: {
                            infoTel: "",
                            infoName: "",
                            infoCard: "",
                            fromId: "804"
                        },
                        rules: {
                            username: [ {
                                required: !0,
                                min: 6,
                                max: 20,
                                message: "请填写6-20位用户名",
                                trigger: [ "change", "blur" ]
                            } ],
                            infoTel: [ {
                                min: 10,
                                max: 11,
                                message: "请填写11位电话号",
                                trigger: "change"
                            } ],
                            infoName: [ {
                                min: 1,
                                max: 10,
                                message: "请填写姓名",
                                trigger: "change"
                            } ],
                            infoCard: [ {
                                min: 17,
                                max: 18,
                                message: "请填写18位身份证",
                                trigger: "change"
                            } ]
                        }
                    };
                },
                onLoad: function onLoad() {
                    this.userinfo();
                },
                methods: {
                    userinfo: function userinfo() {
                        var e = this;
                        return a(o.default.mark(function t() {
                            var i;
                            return o.default.wrap(function(t) {
                                while (1) {
                                    switch (t.prev = t.next) {
                                      case 0:
                                        return t.next = 2, e.$apis.userInfo();

                                      case 2:
                                        i = t.sent, i.succ ? (e.username = i.data.userName, e.form.infoTel = i.data.infoTel, 
                                        e.form.infoName = i.data.infoName, e.form.infoCard = i.data.infoCard, e.wxBinded = i.data.unionId) : n.showToast({
                                            title: e.i18n.t("common.data_fail"),
                                            icon: "none"
                                        });

                                      case 4:
                                      case "end":
                                        return t.stop();
                                    }
                                }
                            }, t);
                        }))();
                    },
                    submit: function submit() {
                        var e = this;
                        return a(o.default.mark(function t() {
                            var i;
                            return o.default.wrap(function(t) {
                                while (1) {
                                    switch (t.prev = t.next) {
                                      case 0:
                                        return t.next = 2, e.$apis.update(e.form);

                                      case 2:
                                        i = t.sent, i.succ ? n.showToast({
                                            title: i.msg,
                                            icon: "none",
                                            complete: function complete() {
                                                setTimeout(function() {
                                                    this.$store.dispatch("setInfoName", this.form.infoName), n.navigateBack({
                                                        delta: 1
                                                    });
                                                }, 500);
                                            }
                                        }) : n.showToast({
                                            title: e.i18n.t("common.data_fail"),
                                            icon: "none"
                                        });

                                      case 4:
                                      case "end":
                                        return t.stop();
                                    }
                                }
                            }, t);
                        }))();
                    },
                    getWxUserInfo: function getWxUserInfo(e) {
                        var t = e.detail, o = new Object();
                        o.rawData = t.rawData, o.signature = t.signature, o.encryptedData = t.encryptedData, 
                        o.iv = t.iv;
                        var u = this;
                        wx.login({
                            success: function success(e) {
                                if (e.code) {
                                    new Object();
                                    o.code = e.code, o.fromId = u.$mUtils.getFromId(), o.loginType = u.wxBinded ? "3" : "2", 
                                    (0, i.wxLogin)(o).then(function(e) {
                                        e.succ ? n.showToast({
                                            title: e.msg,
                                            icon: "none",
                                            complete: function complete() {
                                                setTimeout(function() {
                                                    u.userinfo();
                                                }, 500);
                                            }
                                        }) : n.showToast({
                                            title: e.msg,
                                            icon: "none"
                                        });
                                    });
                                }
                            }
                        });
                    }
                }
            };
            e.default = c;
        }).call(this, t("543d")["default"]);
    },
    b65d: function b65d(n, e, t) {
        "use strict";
        t.r(e);
        var o = t("3d1b"), i = t("4ad3");
        for (var u in i) {
            "default" !== u && function(n) {
                t.d(e, n, function() {
                    return i[n];
                });
            }(u);
        }
        t("6786");
        var r, a = t("f0c5"), c = Object(a["a"])(i["default"], o["b"], o["c"], !1, null, null, null, !1, o["a"], r);
        e["default"] = c.exports;
    },
    db70: function db70(n, e, t) {
        "use strict";
        (function(n) {
            t("5fb8");
            o(t("66fd"));
            var e = o(t("b65d"));
            function o(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            n(e.default);
        }).call(this, t("543d")["createPage"]);
    }
}, [ [ "db70", "common/runtime", "common/vendor" ] ] ]);
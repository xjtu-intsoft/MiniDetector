var t = getApp();

Page({
    data: {
        showCostExplain: !1,
        shopid: "",
        biztype: 0,
        counts: [ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ],
        count: 0,
        ename: "",
        cname: "",
        cpt: 0,
        goods: {},
        ticketsdetail: [],
        total: 0,
        geter: {},
        currentItem: 0,
        cday: "",
        ctime: "",
        showDate: !1
    },
    backDetail: function() {
        wx.navigateTo({
            url: "../detail/viewDetail?id=" + this.data.shopid
        });
    },
    checkDay: function() {
        var t = this.data.cday;
        if (!t) {
            var a = new Date();
            t = a.getFullYear() + "-" + (a.getMonth() + 1) + "-" + a.getDate();
        }
        wx.navigateTo({
            url: "../checkDate/checkDay?shopId=" + this.data.shopid + "&cday=" + t
        });
    },
    checkTime: function() {
        wx.navigateTo({
            url: "../checkDate/checkTime"
        });
    },
    choosecp: function(t) {
        this.setData({
            cpt: t.currentTarget.id,
            currentItem: t.currentTarget.dataset.index
        }), this.data.count > 0 && this.dosum();
    },
    chooseday: function(t) {
        this.setData({
            cday: t.currentTarget.id
        });
    },
    choosetime: function(t) {
        this.setData({
            ctime: t.currentTarget.id
        });
    },
    goPay: function() {
        if (1 == this.data.biztype && "" == this.data.cday) return wx.showToast({
            title: "请选择日期"
        }), -1;
        if (0 == this.data.total) return wx.showToast({
            title: "请选择票数"
        }), -1;
        var t = this;
        wx.showLoading({
            title: "请稍侯",
            success: function() {
                setTimeout(function() {
                    wx.hideLoading({
                        success: function() {
                            t.dopay();
                        }
                    });
                }, 1e3);
            }
        });
    },
    dosum: function() {
        var t = [], a = 0, s = this.data.cpt;
        if (2 == this.data.biztype) t.push({
            name: this.data.goods[s].name,
            goodsId: this.data.goods[s].goodsId,
            nums: this.data.count,
            price: this.data.goods[s].price
        }), a += this.data.goods[s].price * this.data.count; else for (var e in this.data.goods.goodsList) t.push({
            name: this.data.goods.goodsList[e].name,
            goodsId: this.data.goods.goodsList[e].goodsId,
            nums: this.data.counts[e],
            price: this.data.goods.goodsList[e].price
        }), a += this.data.goods.goodsList[e].price * this.data.counts[e];
        this.setData({
            total: a.toFixed(2),
            ticketsdetail: t
        });
    },
    dopay: function() {
        wx.request({
            url: t.globalData.apiURL + "/order/submit",
            header: {
                memberId: wx.getStorageSync("memberid"),
                token: wx.getStorageSync("token")
            },
            data: {
                ordersItemList: this.data.ticketsdetail,
                buyerId: this.data.geter.buyerId,
                shopId: this.data.shopid,
                day: this.data.cday,
                timeslot: this.data.ctime
            },
            method: "POST",
            success: function(a) {
                if ("E500" == a.data.code) return wx.showToast({
                    title: a.data.msg
                }), -1;
                wx.request({
                    url: t.globalData.apiURL + "/pay/sign",
                    header: {
                        memberId: wx.getStorageSync("memberid"),
                        token: wx.getStorageSync("token")
                    },
                    data: {
                        orderId: a.data.result
                    },
                    method: "POST",
                    success: function(t) {
                        if ("E500" == a.data.code) return wx.showToast({
                            title: t.data.msg
                        }), -1;
                        wx.requestPayment({
                            timeStamp: t.data.result.timeStamp,
                            nonceStr: t.data.result.nonceStr,
                            package: t.data.result.package,
                            signType: t.data.result.signType,
                            paySign: t.data.result.paySign,
                            success: function(t) {
                                wx.showLoading({
                                    title: "正在出票",
                                    success: function() {
                                        setTimeout(function() {
                                            wx.hideLoading({
                                                success: function() {
                                                    wx.navigateTo({
                                                        url: "../payticket/paySuccess?orderId=" + a.data.result
                                                    });
                                                }
                                            });
                                        }, 3e3);
                                    }
                                });
                            },
                            fail: function(t) {
                                console.log(t), wx.showToast({
                                    title: "支付取消"
                                });
                            }
                        });
                    }
                });
            }
        });
    },
    moneyMessage: function() {
        this.setData({
            showCostExplain: !this.data.showCostExplain
        });
    },
    showDialog: function() {
        this.setData({
            showCostExplain: !0
        });
    },
    hideDialog: function() {
        this.setData({
            showCostExplain: !1
        });
    },
    checkUser: function() {
        wx.navigateTo({
            url: "../checkUser/checkUser"
        });
    },
    showterm: function() {
        wx.navigateTo({
            url: "../payticket/ticketType"
        });
    },
    onShow: function() {
        this.setData({
            geter: t.globalData.geter
        });
    },
    onLoad: function(a) {
        var s = this;
        wx.request({
            url: t.globalData.apiURL + "/shop/info?shopId=" + a.shopid,
            success: function(t) {
                s.setData({
                    shopid: a.shopid,
                    biztype: t.data.result.bizType,
                    ename: t.data.result.englishName,
                    cname: t.data.result.shopName
                });
            }
        }), wx.request({
            url: t.globalData.apiURL + "/goods/list?shopId=" + a.shopid,
            success: function(t) {
                s.setData({
                    goods: t.data.result
                });
            }
        }), s.setData({
            geter: wx.getStorageSync("geter")
        }), wx.setNavigationBarTitle({
            title: "确认订单"
        });
    },
    reducecount: function() {
        this.data.count > 0 && (this.data.count -= 1, this.setData({
            count: this.data.count
        })), this.dosum();
    },
    addcount: function() {
        if (this.data.count > 7) return wx.showToast({
            title: "每笔订单限购8张",
            icon: "loading"
        }), -1;
        this.data.count = this.data.count + 1, this.setData({
            count: this.data.count
        }), this.dosum();
    },
    reducecounts: function(t) {
        var a = t.currentTarget.id, s = this.data.counts;
        this.data.counts[a] > 0 && (s[a] = this.data.counts[a] - 1, this.setData({
            counts: s
        })), this.dosum();
    },
    addcounts: function(t) {
        var a = t.currentTarget.id;
        if (this.data.counts[a] > 7) return wx.showToast({
            title: "每笔订单限购8张",
            icon: "loading"
        }), -1;
        var s = this.data.counts;
        s[a] = this.data.counts[a] + 1, this.setData({
            counts: s
        }), this.dosum();
    }
});
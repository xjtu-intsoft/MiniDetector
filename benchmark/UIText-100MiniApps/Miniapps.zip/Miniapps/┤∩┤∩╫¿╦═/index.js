var t = require("../../../../@babel/runtime/helpers/interopRequireDefault"), e = t(require("../../../../@babel/runtime/regenerator")), a = t(require("../../../../@babel/runtime/helpers/asyncToGenerator")), i = t(require("../../../../@babel/runtime/helpers/defineProperty")), o = require("./api"), n = require("../../../utils/map"), s = require("../../../utils/uuid"), r = require("../../../utils/commonMethods"), d = require("../../../utils/commonApiDiff"), l = require("../../../constants/index"), c = require("../../../utils/login"), h = require("../../../utils/location"), u = require("../../../utils/checkOrderInfo");

function g(t, e) {
    var a = Object.keys(t);
    if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(t);
        e && (i = i.filter(function(e) {
            return Object.getOwnPropertyDescriptor(t, e).enumerable;
        })), a.push.apply(a, i);
    }
    return a;
}

function m(t) {
    for (var e = 1; e < arguments.length; e++) {
        var a = null != arguments[e] ? arguments[e] : {};
        e % 2 ? g(Object(a), !0).forEach(function(e) {
            (0, i.default)(t, e, a[e]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(a)) : g(Object(a)).forEach(function(e) {
            Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(a, e));
        });
    }
    return t;
}

var f, p = getApp(), b = p.globalData.subPackages.track, D = {
    name: "地址编辑",
    data: {
        addrInfo: null,
        intelligentFillingStr: "",
        addressSearchStatus: "noSearch",
        searchPoiList: null,
        searchFrom: "history",
        isTEL: !1,
        phonePlaceholder: "手机号码",
        type: "",
        hasCliboardInfo: !1,
        intelligentResult: null,
        title: "完善地址信息",
        intelligentFillingStrLength: 0
    },
    _data: {
        cliboardInfo: ""
    },
    onShow: function() {
        var t = this, e = p.globalData.commonAddress, a = e.edit, i = e.type;
        this.options && "service" !== this.options.from && this.initCliboardData(), this.options && "service" === this.options.from ? this.handleServiceSesrch().then(function(e) {
            p.globalData.commonAddress = m({}, p.globalData.commonAddress, {
                sender: m({}, p.globalData.commonAddress.sender, {}, e)
            }), "sender" === (i = p.globalData.commonAddress.type) && (p.globalData.commonAddress.edit = e), 
            t.handleSetAddInfo(p.globalData.commonAddress.edit, i);
        }) : "search" !== this.data.searchFrom && "" === a.poiName && "sender" === i ? this.initAddress().then(function(e) {
            t.handleSetAddInfo(e, i);
        }) : this.handleSetAddInfo(p.globalData.commonAddress.edit, i);
    },
    onReady: function() {
        var t = p.globalData.commonAddress.title, e = void 0 === t ? "完善地址信息" : t;
        this.name = e, this.setData({
            title: e
        }), (0, d.setTitle)(this, p, {
            title: e
        });
    },
    handleSetAddInfo: function(t, e) {
        this.setData({
            addrInfo: m({}, t),
            type: e,
            isTEL: this.checkTEL(t.phone)
        });
    },
    handlePoiList: function() {
        var t = p.globalData.commonAddress, e = t.poiList, a = t.location, i = a.lat, o = a.lng;
        return e && e.length ? Promise.resolve({
            poiList: e
        }) : (0, n.reverseGeocoder)({
            lat: i,
            lng: o
        });
    },
    initAddress: function() {
        var t = this;
        return this.handlePoiList().then(function(e) {
            if (e.poiList && e.poiList.length > 0) {
                var a = e.poiList[0];
                p.globalData.commonAddress.edit = m({}, p.globalData.commonAddress.edit, {}, a), 
                p.globalData.commonAddress.poiList = e.poiList, t.setSearchFrom("poi"), t.setIsPoi(!0);
            } else t.setIsPoi(!1);
            return p.globalData.commonAddress.edit;
        });
    },
    initCliboardData: function() {
        if (!this._data.cliboardInfo) {
            var t = this;
            (0, d.getClipboardData)({
                success: function(e) {
                    var a = e.data || e.text;
                    if (a) {
                        if (a.length > 100) return;
                        t._data.cliboardInfo = a, t.getIntelligentFillingInfo("cliboard");
                    }
                }
            });
        }
    },
    setCliboardData: function(t) {
        var e = t.poi, a = t.phone;
        e && a && (this.setData({
            intelligentResult: t
        }), this.toggleCliboard());
    },
    submitIntelligentFillingInfo: function(t) {
        this.data.intelligentFillingStr ? (this.trackClick(t), this.getIntelligentFillingInfo("submit")) : (0, 
        d.showToast)({
            title: "请先粘贴发货信息",
            icon: "none"
        });
    },
    getIntelligentFillingInfo: function(t) {
        var e = this, a = this.data.intelligentFillingStr || this._data.cliboardInfo, i = p.globalData.isBwm ? l.ADDRESS_TYPE.bwm : "sender" === p.globalData.commonAddress.type ? l.ADDRESS_TYPE.sender : l.ADDRESS_TYPE.receiver, n = {
            requestId: (0, s.getRequestId)(),
            address: a,
            clientType: p.globalData.isBwm ? "WECHAT-APPLET-BWM" : "WECHAT-APPLET-DADA",
            addressType: i
        }, r = {
            toast: !1
        };
        "submit" === t && (this.setSearchStatus("isSearching"), this.setIsPoi(!1), r = {
            toast: !0
        }), (0, o.getIntelligentFillingInfo)(n, r).then(function(a) {
            "submit" === t ? e.getPoiByKeyworNew(a) : e.setCliboardData(a);
        }).catch(function(a) {
            "cliboard" !== t && e.setSearchStatus("searchWithoutResult");
        });
    },
    setAddrInfo: function(t) {
        var e = "tel" === t.phoneType;
        this.setData({
            addrInfo: m({}, this.data.addrInfo, {
                name: t.name,
                phone: t.phone,
                doorplate: t.number,
                poiAddress: "",
                poiName: ""
            }),
            isTEL: e
        }), this.setEditInfo();
    },
    getPoiByKeyworNew: function(t) {
        var e = this, a = t.poi;
        if (this.setAddrInfo(t), p.globalData.commonAddress.keyword = "", "" !== t.poi) {
            var i = {
                keyword: a,
                city: p.globalData.commonAddress.location.city,
                location: p.globalData.commonAddress.location
            };
            (0, n.getPoiByKeyword)(i).then(function(t) {
                t && t.length > 0 ? (p.globalData.commonAddress.keyword = a, e.setData({
                    searchPoiList: t
                }), e.setEditInfo(), e.setSearchStatus("searchOver")) : e.setSearchStatus("searchWithoutResult");
            });
        } else this.setSearchStatus("searchWithoutResult");
        this.setSearchFrom("search");
    },
    chooseAddress: function(t) {
        var e = t.currentTarget.dataset.item;
        this.setIsPoi(!1), this.setSearchStatus("noSearch"), this.setData({
            addrInfo: m({}, this.data.addrInfo, {}, e)
        }), p.globalData.commonAddress.keyword = e.poiName, this.setEditInfo();
    },
    goAddrPoiList: function() {
        this.setSearchStatus("noSearch"), wx.navigateTo({
            url: "/common/pages/address/addrPoiList/index?searchFrom=".concat(this.data.searchFrom)
        });
    },
    saveAddrInfo: (f = (0, a.default)(e.default.mark(function t() {
        var a, i, n, s, r, d, c;
        return e.default.wrap(function(t) {
            for (;;) switch (t.prev = t.next) {
              case 0:
                if (a = this.data.addrInfo, i = p.globalData.commonAddress.type, n = this, s = a.poiName, 
                r = a.name, d = a.phone, !this.checkEmpty(s)) {
                    t.next = 9;
                    break;
                }
                return this.showCheckMsg("请填写地址信息"), t.abrupt("return");

              case 9:
                if (!this.checkEmpty(r)) {
                    t.next = 14;
                    break;
                }
                return this.showCheckMsg("请填写联系人姓名"), t.abrupt("return");

              case 14:
                if (!this.checkEmpty(d)) {
                    t.next = 19;
                    break;
                }
                return this.showCheckMsg("请填写电话号码"), t.abrupt("return");

              case 19:
                if (!(d.replace(/ /g, "").length < 7)) {
                    t.next = 24;
                    break;
                }
                return this.showCheckMsg("电话号码长度不可小于7位有效数字"), t.abrupt("return");

              case 24:
                return t.next = 26, this.handleSensitiveWords();

              case 26:
                if (!t.sent) {
                    t.next = 28;
                    break;
                }
                return t.abrupt("return");

              case 28:
                c = "common/pages/address/addrList/index" === p.globalData.commonAddress.from, a.id ? (0, 
                o.updateAddress)(m({}, this.data.addrInfo, {
                    addressType: l.ADDRESS_TYPE[i]
                })).then(function(t) {
                    !c && (p.globalData.commonAddress[i] = t), n.backFrom();
                }) : (0, o.addAddress)(m({}, this.data.addrInfo, {
                    addressType: l.ADDRESS_TYPE[i]
                })).then(function(t) {
                    !c && (p.globalData.commonAddress[i] = t), n.backFrom();
                });

              case 30:
              case "end":
                return t.stop();
            }
        }, t, this);
    })), function() {
        return f.apply(this, arguments);
    }),
    backFrom: function() {
        var t = getCurrentPages();
        (0, r.trackingOrder)("finishAddressEdit", {
            type: p.globalData.commonAddress.type
        }), "service" !== p.globalData.commonAddress.from && 1 !== t.length ? wx.navigateBack({
            delta: 1
        }) : wx.reLaunch({
            url: p.globalData.isBwm ? "/pages/home/index" : "/pages/index/index"
        });
    },
    changeAddrInfo: function(t) {
        var e = t.detail.value, a = t.currentTarget.dataset.key;
        this.setData({
            addrInfo: m({}, this.data.addrInfo, (0, i.default)({}, a, e))
        }), p.globalData.commonAddress.edit[a] = e;
    },
    changeIntelligentFillingStr: function(t) {
        var e = t.detail.value;
        this.setData({
            intelligentFillingStr: e,
            intelligentFillingStrLength: e.length
        });
    },
    clearIntelligentFillingInfo: function(t) {
        this.setData({
            intelligentFillingStr: ""
        }), this.trackClick(t);
    },
    toggleMobile: function() {
        var t = "";
        t = this.data.isTEL ? "手机号码" : "座机号码", this.setData({
            phonePlaceholder: t,
            isTEL: !this.data.isTEL,
            addrInfo: m({}, this.data.addrInfo, {
                phone: ""
            })
        }), this.setEditInfo(), b.manuallyTrack({
            clickId: "ClickCheckPhoneStatus",
            clickPar: {
                status: this.data.isTEL ? "telephone" : "mobile"
            }
        });
    },
    toggleCliboard: function() {
        this.setData({
            hasCliboardInfo: !this.data.hasCliboardInfo
        });
    },
    closeCliboard: function(t) {
        this.toggleCliboard(), this.trackClick(t);
    },
    useCliboardInfo: function(t) {
        this.setSearchStatus("isSearching"), this.setIsPoi(!1), this.getPoiByKeyworNew(this.data.intelligentResult), 
        this.toggleCliboard(), this.trackClick(t);
    },
    setEditInfo: function() {
        p.globalData.commonAddress.edit = m({}, p.globalData.commonAddress.edit, {}, this.data.addrInfo);
    },
    setSearchStatus: function(t) {
        this.setData({
            addressSearchStatus: t
        });
    },
    setSearchFrom: function(t) {
        this.setData({
            searchFrom: t
        });
    },
    setIsPoi: function(t) {
        this.setData({
            addrInfo: m({}, this.data.addrInfo, {
                isPoi: t
            })
        }), p.globalData.commonAddress.edit = m({}, p.globalData.commonAddress.edit, {
            isPoi: t
        });
    },
    checkTEL: function(t) {
        return "" !== t && /0\d{2,3}\d{7,8}/.test(t);
    },
    trackClick: function(t) {
        var e = t.currentTarget.dataset.clickid;
        b.manuallyTrack({
            clickId: e
        });
    },
    checkEmpty: function(t) {
        return "" === t;
    },
    showCheckMsg: function(t) {
        (0, d.showToast)({
            title: t,
            icon: "none"
        });
    },
    handleServiceSesrch: function() {
        var t = this;
        return new Promise(function(e, a) {
            if (!(0, c.checkLogin)({
                mode: "getLoginStatusAndJump",
                url: "/common/pages/login/index"
            })) return a(new Error("未登录新用户"));
            var i = t.options, n = i.from, s = i.type, r = i.lat, d = i.lng, l = i.adCode, u = i.city, g = i.originLat, f = i.originLng, b = i.poiAddress, D = i.poiName, I = i.id, A = i.name, S = i.doorplate, y = i.phone;
            if (t.options.originLat) {
                var k = {
                    adCode: l,
                    lat: g,
                    lng: f,
                    city: decodeURIComponent(u)
                };
                p.globalData.commonAddress = m({}, p.globalData.commonAddress, {
                    location: k,
                    currentLocation: k,
                    type: s,
                    from: n
                });
            } else (0, h.getLocationPoi)();
            if (!I) {
                var v = {
                    lat: r,
                    lng: d,
                    poiAddress: b ? decodeURIComponent(b) : "",
                    poiName: D ? decodeURIComponent(D) : "",
                    name: A ? decodeURIComponent(A) : "",
                    doorplate: S ? decodeURIComponent(S) : "",
                    city: u,
                    adCode: l,
                    phone: y
                };
                return t.options = {}, e(v);
            }
            (0, o.getAddressInfo)({
                id: I
            }).then(function(a) {
                return t.options = {}, e(a);
            });
        });
    },
    handleSensitiveWords: function() {
        var t = this.data.addrInfo, e = t.name, a = t.doorplate;
        return (0, u.handleCheckSensitiveWords)({
            texts: [ {
                key: "name",
                textType: 1,
                text: e
            }, {
                key: "doorplate",
                textType: 9,
                text: a
            } ]
        });
    }
};

Page(D);
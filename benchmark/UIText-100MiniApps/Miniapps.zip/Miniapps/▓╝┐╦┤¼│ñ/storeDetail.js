!function() {
    "use strict";
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var e = function() {
        function e(e, t) {
            for (var n = 0; n < t.length; n++) {
                var r = t[n];
                r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), 
                Object.defineProperty(e, r.key, r);
            }
        }
        return function(t, n, r) {
            return n && e(t.prototype, n), r && e(t, r), t;
        };
    }(), t = r(require("./../../npm/wepy/lib/wepy.js")), n = r(require("./../../common/api.js"));
    function r(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function o(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
    }
    function a(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    var i = function(r) {
        function i() {
            var e, n, r;
            o(this, i);
            for (var u = arguments.length, s = Array(u), c = 0; c < u; c++) s[c] = arguments[c];
            return n = r = a(this, (e = i.__proto__ || Object.getPrototypeOf(i)).call.apply(e, [ this ].concat(s))), 
            r.config = {
                navigationBarTitleText: "商家详情"
            }, r.data = {
                storeId: 0,
                store: {},
                sendWay: {
                    1: "商家自配送",
                    2: "快递",
                    3: "即时配送"
                }
            }, r.methods = {
                navigate: function(e) {
                    t.default.navigateTo({
                        url: e
                    });
                },
                selectModalSwitch: function() {
                    this.selectModal = !this.selectModal;
                },
                phoneCall: function() {
                    t.default.makePhoneCall({
                        phoneNumber: this.store.phone
                    });
                },
                openLocation: function() {
                    t.default.openLocation({
                        latitude: parseFloat(this.store.lat),
                        longitude: parseFloat(this.store.lng),
                        scale: 15
                    });
                },
                none: function() {}
            }, a(r, n);
        }
        var u, s;
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(i, r), e(i, [ {
            key: "getData",
            value: (u = regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                      case 0:
                        return e.next = 2, n.default.get({
                            api: "stores/" + this.storeId,
                            version: "v4.0"
                        });

                      case 2:
                        (t = e.sent) && (this.store = t.data, this.$apply());

                      case 4:
                      case "end":
                        return e.stop();
                    }
                }, e, this);
            }), s = function() {
                var e = u.apply(this, arguments);
                return new Promise(function(t, n) {
                    return function r(o, a) {
                        try {
                            var i = e[o](a), u = i.value;
                        } catch (e) {
                            return void n(e);
                        }
                        if (!i.done) return Promise.resolve(u).then(function(e) {
                            r("next", e);
                        }, function(e) {
                            r("throw", e);
                        });
                        t(u);
                    }("next");
                });
            }, function() {
                return s.apply(this, arguments);
            })
        }, {
            key: "onLoad",
            value: function(e) {
                this.storeId = e.storeId, this.getData();
            }
        }, {
            key: "onShow",
            value: function() {}
        } ]), i;
    }(t.default.page);
    Page(require("./../../npm/wepy/lib/wepy.js").default.$createPage(i, "pages/rent/storeDetail"));
}();
!function() {
    "use strict";
    function e(e) {
        return e && e.__esModule ? e : {
            default: e
        };
    }
    function t(e) {
        return function() {
            var t = e.apply(this, arguments);
            return new Promise(function(e, a) {
                return function n(r, i) {
                    try {
                        var o = t[r](i), s = o.value;
                    } catch (e) {
                        return void a(e);
                    }
                    if (!o.done) return Promise.resolve(s).then(function(e) {
                        n("next", e);
                    }, function(e) {
                        n("throw", e);
                    });
                    e(s);
                }("next");
            });
        };
    }
    function a(e, t, a) {
        return t in e ? Object.defineProperty(e, t, {
            value: a,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = a, e;
    }
    function n(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
    }
    function r(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return !t || "object" != typeof t && "function" != typeof t ? e : t;
    }
    Object.defineProperty(exports, "__esModule", {
        value: !0
    });
    var i = function() {
        function e(e, t) {
            for (var a = 0; a < t.length; a++) {
                var n = t[a];
                n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), 
                Object.defineProperty(e, n.key, n);
            }
        }
        return function(t, a, n) {
            return a && e(t.prototype, a), n && e(t, n), t;
        };
    }(), o = e(require("./../npm/wepy/lib/wepy.js")), s = e((require("./../tool/lodash.js"), 
    require("./../tool/storage.js"))), u = e(require("./../tool/canvasUtil.js")), c = e(require("./../tool/request.js")), l = e(require("./../tool/msgTool.js")), d = e(require("./../tool/msg.js")), h = (e(require("./../npm/@clevok/actions/lib/index.js")), 
    require("./../tool/tool.js")), p = e(h), f = e(require("./../tool/time.js")), g = require("./../common/config.js"), v = e(require("./../components/followWechatModel.js")), y = e(require("./../common/event.js")), m = e(require("./../common/bank.js")), w = e(require("./../common/poster.js")), b = e(require("./../api/index.js")), S = e(require("./../tool/collectUtil.js")), x = e(require("./../tool/cardUtil.js")), k = e(require("./../tool/security.js")), C = e(require("./../tool/iCopy.js")), T = e(require("./../components/dialog.js")), D = e(require("./../tool/base.js")), I = e(require("./mixins/vipMixin.js")), A = e(require("./mixins/perfermanceMixin.js")), P = e(require("./../common/addressRouter.js")), $ = function(e) {
        if (e && e.__esModule) return e;
        var t = {};
        if (null != e) for (var a in e) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
        return t.default = e, t;
    }(require("./../npm/@clevok/wx-customer-update/lib/index.js")), R = e(require("./../npm/@clevok/event/lib/index.js")), U = e(require("./../api/courier/api.js")), M = require("./../api/groupapi.js"), L = require("./../tool/activity.js"), N = require("./../api/cash.js"), _ = require("./../api/redEnvelope.js"), B = e(require("./../common/upgradeVip.js")), E = require("./../tools/enum.js"), O = (require("./../common/area.js"), 
    require("./../publicService/UserThirdShopService.js")), F = require("./../common/collectGroup.js"), W = require("./../common/setUserInfo.js"), G = e(require("./../components/VIdentityModel.js")), V = function(e) {
        function h() {
            var e, i, u, c;
            n(this, h);
            for (var l = arguments.length, p = Array(l), f = 0; f < l; f++) p[f] = arguments[f];
            return u = c = r(this, (e = h.__proto__ || Object.getPrototypeOf(h)).call.apply(e, [ this ].concat(p))), 
            c.config = {
                navigationBarTitleText: "风火递",
                navigationStyle: "custom",
                usingComponents: {
                    "v-update-model": "/components/VUpdateModel/VUpdateModel",
                    "c-modal": "/components/CPop/CModal/CModal",
                    "c-modal-btn": "/components/CPop/CModal/CModalBtn",
                    "c-modal-btn-type": "/components/CPop/CModal/CModalBtnType",
                    "c-drawer": "/components/CPop/CDrawer/CDrawer",
                    "v-index-cell-view": "/components/VIndexCellView/VIndexCellView",
                    "v-index-cell": "/components/VIndexCell/VIndexCell",
                    "c-shop-hot": "/pagesComponents/index/CShopHot/CShopHot",
                    "c-footer-view": "/components/CProtocolFooter/CProtocolFooter",
                    "v-index-banner": "/pagesComponents/index/VIndexBanner/index",
                    "v-index-activity": "/pagesComponents/index/VIndexActivity/index",
                    "c-viprenew-view": "/components/CVipRenewView/CVipRenewView",
                    "c-index-topview": "/pagesComponents/index/CIndexTopView/CIndexTopView",
                    "c-alert-model": "/pagesComponents/index/CAlertModel/CAlertModel",
                    "c-index-news": "/pagesComponents/index/CIndexNews/CIndexNews",
                    "c-post-dialog": "/pagesComponents/index/Dialog/index",
                    processScan: "/pagesComponents/index/CShopHot/CShopHot",
                    "c-navi-bar": "/separate/index/CNaviBar/CNaviBar",
                    "c-user-info": "/separate/index/CUserInfo/CUserInfo",
                    "c-functional": "/separate/index/CFunctional/CFunctional",
                    "c-sale-data": "/separate/index/CSaleDataView/CSaleDataView",
                    "c-user-role-dialog": "/separate/index/CUserRoleDialog/CUserRoleDialog",
                    "c-user-role-dialog-V2": "/separate/index/CUserRoleDialogV2/CUserRoleDialog",
                    IntroModal: "/components/IntroModal/index",
                    "c-account-notice": "/components/CAccountNotice/CAccountNotice",
                    "c-home-mask": "/pagesComponents/common/CHomeMask/CHomeMask",
                    "c-dia-log": "/pagesComponents/index/CDialog/index",
                    "c-cainiao-wait-view": "/pagesComponents/packageList/CCainiaoWaitView/CCainiaoWaitView",
                    "c-new-store-pop": "/pagesComponents/index/newStorePop/newStorePop",
                    "c-dialog": "/components/VIndexBanner/CDialog/index"
                }
            }, c.$repeat = {}, c.$props = {
                toMiniDialog: {
                    "xmlns:v-bind": "",
                    "v-bind:isShow.sync": "toMiniModal"
                },
                VIdentityModel: {
                    "xmlns:wx": "",
                    "xmlns:v-bind": "",
                    "v-bind:isShow.sync": "identityModalShow"
                }
            }, c.$events = {}, c.components = {
                toMiniDialog: T.default,
                chooseCardDialog: T.default,
                followWechatModel: v.default,
                VIdentityModel: G.default
            }, c.mixins = [ I.default, A.default ], c.data = (a(i = {
                nowTime: 0,
                shopId: null,
                base64Img: null,
                visitorNum: 0,
                teamChanged: !1,
                myTeam: null,
                doubleSms: !1,
                safeHeight: 20,
                chooseUserRole: !1,
                deliverFunctionalArr: [],
                saleSuperArr: [],
                saleBaseFunctionalArr: [],
                saleProFunctionalArr: [],
                selected: 0,
                userType: "",
                indexshopAc: !1,
                ios: !1,
                show_prewarm: !1,
                showBadge: !1,
                indexNoticeObj: null,
                indexNoticeShow: !1,
                userVip: null,
                bank: null,
                singleDayShop: !1,
                indexShopBadge: null,
                canShowPrinter: !0,
                showJoinGroup: !1,
                loadDeviceListHandler: "",
                screenWidth: 0,
                canvasSize: {},
                selectPrinter: {},
                thirdAuthData: {},
                deliver: !1,
                userInfo: {},
                guideList: wx.getStorageSync("index/getNotices/list") || [],
                shareBannerUrl: "",
                rePostModalShow: !1,
                tempHideImage: !1,
                hiddenCanvas: !1,
                toMiniModal: !1,
                openedPack: !1,
                shadowTop: null,
                ptBtom: !1,
                sparkBT: !1,
                flyInPhone: null,
                awardShow: !1,
                group: null,
                groupInfo: null,
                needShare: !1,
                needShareSend: !1,
                canvasShow: !1,
                items: [ {
                    name: "receive",
                    value: "收件人信息"
                }, {
                    name: "sender",
                    value: "寄件人信息"
                } ],
                showModalList: !1,
                teamModalList: [ {
                    title: "我的团队",
                    value: 1,
                    selected: !1
                }, {
                    title: "个人",
                    value: 0,
                    selected: !1
                } ],
                hasScribe: !1,
                loaded: !1,
                iCopy: new C.default(),
                groupModel: !1,
                subpackAccount: 51,
                clickedsms: !1,
                clickedshopCode: !1,
                transAddressTemp: null,
                needShowPopover: !1,
                clickedNewQRcode: !1,
                inputQrCodeFocus: !1,
                icopyModalShow: !1,
                taskCount: 0,
                funNeedShow: !0,
                isLoadingPrinter: !0,
                isFirstScan: !0,
                groupApplyCount: 0,
                thirdAuthImage: "",
                thirdAuthTitle: "",
                thirdAuthAppid: "",
                thirdAuthPath: "",
                thirdAuthEnvVersion: "",
                shopAppid: "",
                shopPath: "",
                shopEnvVersion: "",
                scanModalShow: !1,
                scanAlertModalShow: !1,
                scanInputAlertModalShow: !1,
                isClick: !1,
                greenAlert: !1,
                chooseEditOrCheck: !1,
                searchPrinter: !1,
                version: "",
                deviceManager: o.default.$instance.globalData.deviceManager,
                printerActionSheet: o.default.$instance.globalData.printerActionSheet,
                qrCodeInputText: "",
                currentDevice: {},
                shipInfoCount: 0,
                shareWlbModalShow: !1,
                wayBillNumber: "",
                chooseCardOpt: !1,
                chooseCard: !1,
                tempCard: {},
                processFhdCodeHandler: null,
                processScanHandler: null,
                isFirstCountTask: !1,
                afterLoginNavigateToHandler: null,
                afterLoginToDoHandler: null,
                expert: null,
                sharedUserId: "",
                adCanvas: null,
                chooseIndex: null,
                userRole: g.UserRole,
                isCaptain: !1,
                isLoading: !0,
                loginSuccess: !1,
                isChangeToCustomer: !1,
                visible_fhy_dialog: !1,
                visible_kxc_dialog: !1,
                path_fhy: "",
                is_encore: !1,
                gift_11: {},
                prewarm_type: "flight",
                show_identitySelection: !1,
                isShowActivity: !1,
                selectIndex: 1,
                selectedIdentityBtn: !1,
                isShowMask: !1,
                showRedEnvelope: !1,
                show_redEnvelope: !1,
                userBankInfoList: [],
                moreMoney: !0,
                showWithdrawal: !1,
                countDownDay: "",
                countDownHour: "",
                countDownMinute: "",
                countDownSecond: "",
                userCount: 0,
                redPackageTimer: null,
                canUseBankInfoHandler: null,
                ShowOpenShopActivity: !1,
                showActivities: !1,
                ShowOpenShopDialogSwitch: !0,
                userifClickFhyxButton: !1,
                ifSignUpFhyx: !0,
                showAddWeichatGroup: !1,
                currentTime: 0,
                AddWeichatGroupImgSwitch: !0,
                isPickUpShop: !1,
                scanCodeJump: !1,
                identityModalShow: !1,
                userSelectIdentity: null,
                isSwitchUserIdentity: !1,
                holidayImage: "",
                isScrollTop: !0,
                lifeMemberDialogVisible: !1,
                lifeMemberType: 1,
                isShowVIdentityModel: !0,
                popUrl: [ "https://mmbiz.qpic.cn/mmbiz_png/jqsBVctRUTCKcMI6AeSBYiazDiaRLNJUpZz0SmBf8Suc25CjhYq2Lw3XtIXc2s1xibPFIiaE5lSIa3zwDZSeJfkOmA/0?wx_fmt=png", "https://mmbiz.qpic.cn/mmbiz_gif/jqsBVctRUTCKcMI6AeSBYiazDiaRLNJUpZPPWuhXs7dLEdlJy4r2IDnmRYREbbKeMBJxoDwSz2zCyqN0achouWkw/0?wx_fmt=gif" ],
                pop: [ "https://engine.sshhli.com/index/activity?appKey=3aNisPe3FbUfuU5yYPD9uhgr24VT&adslotId=388438", "https://engine.sshhli.com/index/activity?appKey=3aNisPe3FbUfuU5yYPD9uhgr24VT&adslotId=388438" ],
                newPopShow: !1,
                popIndex: null,
                NewBusinessActivityDialogVisible: !1,
                NewBusinessActivityFloatVisible: !1,
                cashbackActivityIsShowDialog: !1,
                cashbackActivityIsShowFloat: !1,
                showLDModal: !1,
                deliveryCode: "",
                LDPrinterId: "",
                isLDNoCheck: !1
            }, "popIndex", null), a(i, "secondsKllActivityDialogVisible", !1), a(i, "isShowGetPhoneNumberMask", !1), 
            a(i, "showCommunityPoPup", !1), a(i, "isSHowDialog", !1), a(i, "isShopShowMask", !1), 
            a(i, "showSecondSkllDialog", !1), a(i, "showCouponDialog", !1), a(i, "generalData", {}), 
            a(i, "noNeedGetAddress", !1), a(i, "paymentActivitiesDialogVisible", !1), a(i, "paymentActivitiesFloat", !1), 
            a(i, "userActivityData", {}), i), c.methods = {
                onTapPop: function() {
                    this.data.pop && this.navigateToWebview(this.data.pop[0]);
                },
                closeLifeMemberDialog: function() {
                    this.lifeMemberDialogVisible = !1, this.$apply();
                },
                closeNewBusinessActivity: function() {
                    this.NewBusinessActivityDialogVisible = !1, this.$apply();
                },
                onCloseCashbackActivityDialog: function() {
                    this.cashbackActivityIsShowDialog = !1, this.$apply();
                },
                onCloseSecondsKllActivity: function() {
                    this.secondsKllActivityDialogVisible = !1, (0, F.indicators)("popup_seckillclose_click"), 
                    this.$apply();
                },
                onClosePaymentActivities: function() {
                    this.paymentActivitiesDialogVisible = !1, this.$apply();
                },
                jumpLifeMember: function() {
                    wx.navigateTo({
                        url: "/sub-LifeMember/pages/index/index?userType=" + this.lifeMemberType
                    });
                },
                toBussinessInfoMationPage: function() {
                    wx.navigateTo({
                        url: "../sub-businessInformation/pages/index/index"
                    });
                },
                toSecondSkllCreat: function() {
                    this.showSecondSkllDialog = !1, this.$apply(), wx.navigateTo({
                        url: "../sub-secondsKll/pages/create"
                    });
                },
                toCouponCreat: function() {
                    this.showCouponDialog = !1, this.$apply(), wx.navigateTo({
                        url: "../sub-Coupon/pages/create/index"
                    });
                },
                toPaymentActivitiesPages: function() {
                    this.paymentActivitiesDialogVisible = !1, (0, F.indicators)("paymentActivities_ClickPopCount"), 
                    this.$apply(), wx.navigateTo({
                        url: "../sub-paymentActivities/pages/index/index"
                    });
                },
                holidayImageClick: function() {},
                refreshPage: function(e) {
                    this.userType = e.detail.userType, this.$apply();
                },
                toCommunityActivities: function() {
                    (0, F.indicators)("float-click"), wx.navigateTo({
                        url: "/sub-CommunityActivities/pages/index"
                    });
                },
                toNewBusinessActivity: function() {
                    wx.navigateTo({
                        url: "/sub-newBusinessActivity/pages/index/index"
                    });
                },
                closeNewBusinessActivityDialog: function() {
                    this.NewBusinessActivityDialogVisible = !1, this.$apply();
                },
                onOpenAccount: function() {
                    "sale" !== this.userType && "deliver" !== this.userType ? (this.$data.isShowActivity = !1, 
                    this.isShowActivity = !0, this.$apply()) : d.default.alert("您不符合活动规则~");
                },
                bannerToSelectedPage: function() {
                    wx.$Uba({
                        fid: "openShopActivity_homePageBannerClickCount"
                    })(), wx.navigateTo({
                        url: "/sub-StoreOpenActivities/pages/openStore/openStore?userifClickFhyxButton=" + this.userifClickFhyxButton
                    });
                },
                toVisiter: function() {
                    S.default.uba(null, null, {
                        fid: "index-visit"
                    }), wx.navigateTo({
                        url: "/sub-business/pages/followList?shopId=" + this.shopId
                    });
                },
                clickSubTitle: function() {
                    S.default.uba(null, null, {
                        fid: "index-shareshop"
                    }), this.$wxpage.selectComponent("#sharePop").show();
                },
                onOpenRedEnvelope: function() {
                    wx.getStorageSync("userReceived1") ? (console.log("用户已点击打开红包按钮"), this.showWithdrawal = !0, 
                    this.$apply()) : (console.log("用户没有点击打开红包按钮"), this.showRedEnvelope = !0, this.$apply());
                },
                toOpenStore: function() {
                    wx.$Uba({
                        fid: "openShopActivity_homePageFlotClickCount"
                    })(), this.userifClickFhyxButton ? wx.navigateTo({
                        url: "/sub-StoreOpenActivities/pages/selectCommpdity/selectCommpdity"
                    }) : wx.navigateTo({
                        url: "/sub-StoreOpenActivities/pages/openStore/openStore"
                    });
                },
                addWeichatGroupBtn: function() {
                    wx.setStorage({
                        key: "isAddWeichatGroup1",
                        data: !0
                    }), (0, F.indicators)("click_888session"), this.showAddWeichatGroup = !1, this.$apply();
                },
                CashbackActivityDialogBtn: function() {
                    (0, F.indicators)("cashbackActivities_signUpCount");
                },
                cashbackActivityFloatBtn: function() {
                    (0, F.indicators)("cashbackActivities_flaotCount");
                },
                toAddQuestionnaire: function() {},
                toSpringGodness: function() {
                    S.default.uba(null, null, {
                        fid: "activity_spring_indextip_click",
                        params: ""
                    }), wx.navigateTo({
                        url: "/pages/webPage?url=" + encodeURIComponent("https://actstatic.fhd001.com/activity/fhdwx/20210304/index.html#/activity/women")
                    });
                },
                DialogToOpenStore: function() {
                    var e = new Date().getMonth() + 1, t = new Date().getDate();
                    wx.setStorage({
                        key: "OpenShopActivityclickTime",
                        data: {
                            month: e,
                            day: t
                        }
                    }), wx.$Uba({
                        fid: "openShopActivity_homePageReceiveClickCount"
                    })(), this.userifClickFhyxButton ? (this.ShowOpenShopActivity = !1, this.$apply(), 
                    wx.navigateTo({
                        url: "/sub-StoreOpenActivities/pages/selectCommpdity/selectCommpdity"
                    })) : (this.ShowOpenShopActivity = !1, this.$apply(), wx.navigateTo({
                        url: "/sub-StoreOpenActivities/pages/openStore/openStore"
                    }));
                },
                toSecondsKllActivity: function() {
                    this.secondsKllActivityDialogVisible = !1, this.$apply(), (0, F.indicators)("popup_seckilltoactivity_click"), 
                    wx.navigateTo({
                        url: "../sub-secondsKllActivity/pages/index/index"
                    });
                },
                DialogOnCloseOpenStore: function() {
                    var e = new Date().getMonth() + 1, t = new Date().getDate();
                    wx.setStorage({
                        key: "OpenShopActivityclickTime",
                        data: {
                            month: e,
                            day: t
                        }
                    }), wx.$Uba({
                        fid: "openShopActivity_homePageOnCloseDialogCount"
                    })(), this.ShowOpenShopActivity = !1, this.$apply();
                },
                toWx: function() {
                    wx.navigateTo({
                        url: "/sub-payment/pages/index"
                    });
                },
                hideUserRole: function() {
                    this.chooseUserRole = !1, this.userType = o.default.$instance.globalData.userType, 
                    R.default.emitAll("updateUserType", this.userType), this.$apply();
                },
                toOmsDirect: function() {
                    this.indexshopAc ? wx.navigateTo({
                        url: "/sub-contact/pages/fth"
                    }) : wx.navigateToMiniProgram({
                        appId: "wx77dec7b930544409",
                        path: "pages/index/index"
                    });
                },
                tooms: function() {
                    this.saleProFunctionalArr.filter(function(e) {
                        "对接电商" == e.title && (e.showBubble = !1);
                    }), this.$apply(), wx.$Uba({
                        fid: "index-shophot-click-tooms"
                    })(), wx.navigateTo({
                        url: "/packages/fhdoms/pages/index"
                    });
                },
                toShop: function() {
                    wx.$Uba({
                        fid: "index-shophot-click-more"
                    })(), wx.navigateToMiniProgram({
                        appId: "wx77dec7b930544409",
                        path: "/pages/index"
                    });
                },
                onCloseFhyDialog: function() {
                    this.visible_fhy_dialog = !1, this.$apply();
                },
                onCloseKxcDialog: function() {
                    this.visible_kxc_dialog = !1, this.$apply();
                },
                onCloseShowOpenShopDialog: function() {
                    this.ShowOpenShopActivity = !1, this.$apply();
                },
                onCloseSelectIdentityDialog: function() {
                    this.isShowActivity = !1, this.$apply();
                },
                onCloseRedEnvelopeDialog: function() {
                    this.showRedEnvelope = !1, this.$apply();
                },
                onCloseWithdrawalDialog: function() {
                    this.showWithdrawal = !1, this.$apply();
                },
                onCloseaddWeichatGroupDialog: function() {
                    this.showAddWeichatGroup = !1;
                    var e = new Date().getDay();
                    wx.setStorage({
                        key: "beforeShowDialogTime",
                        data: e
                    }), this.$apply();
                },
                indexPosterRouter: function() {
                    w.default.router();
                },
                toOpenAccount: function() {
                    wx.navigateTo({
                        url: "/payment/wallet/openAccount"
                    }), S.default.uba(null, null, {
                        fid: "openAccount_activity_toOpenAccount",
                        params: ""
                    });
                },
                toCodeList: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOCODELIST,
                        params: ""
                    }), wx.reportAnalytics("tocodelist", {}), !this.groupModel || this.groupModel && this.isCaptain ? o.default.navigateTo({
                        url: "/printCode/printCodeV2/codeList/index"
                    }) : d.default.alert("在团队模式下，只有团队管理员可以操作该功能!");
                },
                clickVIP: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOVIP,
                        params: ""
                    }), wx.reportAnalytics("tovip", {}), wx.navigateTo({
                        url: "/subPackages/activity/popularize"
                    });
                },
                tokxc: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOKXC,
                        params: ""
                    }), wx.getStorageSync("has_tap_kxc") ? wx.navigateToMiniProgram({
                        appId: "wx4d37f205807139de",
                        path: "pages/index"
                    }) : (wx.setStorageSync("has_tap_kxc", !0), this.visible_kxc_dialog = !0, this.$apply());
                },
                tomyfhy: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOMYFHY,
                        params: ""
                    }), wx.getStorageSync("has_tap_fhy") ? wx.navigateToMiniProgram({
                        appId: "wxdf4ae28f66351374",
                        path: this.path_fhy
                    }) : (wx.setStorageSync("has_tap_fhy", !0), this.visible_fhy_dialog = !0, this.$apply());
                },
                toLabel: function() {
                    this.methods.openOtherMiniProgram("wx999db5ccfe91874c", "", "tolabel");
                },
                openOtherMiniProgram: function(e) {
                    var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "", a = arguments[2], n = arguments[3];
                    a && wx.reportAnalytics(a, {}), S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOOTHERMP,
                        params: e
                    }), wx.navigateToMiniProgram({
                        appId: e,
                        path: t,
                        extraData: n,
                        envVersion: "trial",
                        success: function(e) {}
                    });
                },
                toOMS: function() {
                    wx.reportAnalytics("tooms", {});
                },
                toOrderHistory: function() {
                    S.default.uba(null, null, {
                        fid: "index-toOrderHistory",
                        params: ""
                    }), wx.navigateTo({
                        url: "/sub-goods/pages/order_history/index"
                    });
                },
                toShopCode: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOSHOPCODE,
                        params: ""
                    }), wx.reportAnalytics("toshopcode", {}), this.deliverFunctionalArr.filter(function(e) {
                        "查件码" == e.title && (e.showBubble = !1);
                    }), this.$apply(), o.default.navigateTo({
                        url: "../subPackages/shopCode/shopCode"
                    });
                },
                toEsheet: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOESHEET,
                        params: ""
                    }), wx.reportAnalytics("toesheet", {}), o.default.navigateTo({
                        url: "/sub-staff/pages/settings/eSheet"
                    });
                },
                toSubAddress: function() {
                    wx.navigateTo({
                        url: "/sub-address/pages/customer/index/index"
                    });
                },
                toCoupon: function() {
                    S.default.uba(null, null, {
                        fid: "indexCoupon"
                    }), this.saleSuperArr.filter(function(e) {
                        "优惠券" == e.title && (e.showBubble = !1);
                    }), "sale" === this.userInfo.userType && wx.reportEvent && wx.reportEvent("main_coupon_click", {
                        user_id: this.userInfo.userId,
                        fenghuo_id: this.userInfo.fhdCode,
                        uesr_lvname: this.generalData.uesr_lvname,
                        time: this.currentTime,
                        xcx_version: this.version
                    }), wx.navigateTo({
                        url: "/sub-Coupon/pages/index/index"
                    });
                },
                toShippingFree: function() {
                    this.saleSuperArr.filter(function(e) {
                        "包邮活动" == e.title && (e.showBubble = !1);
                    }), S.default.uba(null, null, {
                        fid: "index-postfeefree"
                    }), wx.navigateTo({
                        url: "/sub-ShippingFree/pages/index/index"
                    });
                },
                toGroupBooking: function() {
                    wx.showToast({
                        title: "即将上线，敬请期待",
                        icon: "none"
                    });
                },
                showIntro: function() {
                    S.default.uba(null, null, {
                        fid: "index-intro-show",
                        params: ""
                    }), this.$wxpage.selectComponent("#intro_modal").show();
                },
                toSaleGood: function() {
                    this.saleSuperArr.filter(function(e) {
                        "超级开单" == e.title && (e.showBubble = !1);
                    }), this.$apply(), this.userType && S.default.uba(null, null, {
                        fid: "index-toSaleGood",
                        params: ""
                    }), wx.reportEvent && wx.reportEvent("main_superbill_click", {
                        user_id: this.userInfo.userId,
                        fenghuo_id: this.userInfo.fhdCode,
                        uesr_lvname: this.generalData.uesr_lvname,
                        time: this.currentTime,
                        xcx_version: this.version
                    }), wx.navigateTo({
                        url: "/sub-goods/pages/order/index"
                    });
                },
                toHelp: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOHELP,
                        params: ""
                    }), wx.reportAnalytics("tohelp", {});
                    var e = encodeURIComponent("https://chc.xyy001.com/distribution/center.html#/indexApp?referer=fhdowx&fhdCode=" + this.userInfo.fhdCode || "");
                    wx.navigateTo({
                        url: "/pages/webPage?url=" + e
                    });
                },
                toLogisticSearch: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOLOGISTIC,
                        params: ""
                    }), o.default.navigateTo({
                        url: "/address-subpackage/pages/search"
                    });
                },
                toGroup: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOGROUP,
                        params: ""
                    }), wx.reportAnalytics("togroup", {}), o.default.navigateTo({
                        url: "/subSetting/pages/printGroup/printGroup"
                    });
                },
                toAddressList: function() {
                    var e = t(regeneratorRuntime.mark(function e() {
                        var t;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return S.default.uba(null, null, {
                                    fid: g.UserBehavior.INDEXTOADDRESS,
                                    params: ""
                                }), wx.reportAnalytics("toaddress", {}), e.next = 4, (0, P.default)("consignee");

                              case 4:
                                t = e.sent, o.default.navigateTo({
                                    url: t
                                });

                              case 6:
                              case "end":
                                return e.stop();
                            }
                        }, e, this);
                    }));
                    return function() {
                        return e.apply(this, arguments);
                    };
                }(),
                changeRole: function() {
                    o.default.$instance.globalData.isCaptain ? d.default.alert("您是团队管理员，无法切换到个人模式\n团队成员可通过切换操作，区分个人信息和团队信息") : (this.groupModel ? this.changeUserRole(this.userRole.PERSONAL.value, !0) : this.changeUserRole(this.userRole.TEAM.value, !0), 
                    this.showModalList = !this.showModalList);
                },
                toPCHelp: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOPC,
                        params: ""
                    });
                    var e = encodeURIComponent("https://chc.xyy001.com/t/h1076.do");
                    o.default.navigateTo({
                        url: "/sub-expert/pages/introduction?webUrl=" + e
                    });
                },
                toIntroduction: function(e, t, a, n) {
                    wx.reportAnalytics("topc", {}), o.default.navigateTo({
                        url: "/sub-expert/pages/introduction?id=" + e + "&index=" + t + "&title=" + a + "&subTitle=" + n
                    });
                },
                gotoWebPage: function(e) {
                    e = encodeURIComponent(e), wx.navigateTo({
                        url: "/pages/webPage?url=" + e
                    });
                },
                toDeliver: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTODELIVER,
                        params: ""
                    }), wx.reportAnalytics("todeliver", {});
                    var e = "../subPackages/courier/salesMan";
                    this.deliver || (e = "./settings/myDeliver"), o.default.navigateTo({
                        url: e
                    });
                },
                showNotice: function(e) {
                    e = e.replace("公告：", ""), d.default.alert(e, null, {
                        title: "公告"
                    });
                },
                clickedsmsfn: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOSMS,
                        params: ""
                    }), wx.reportAnalytics("tosms", {}), o.default.navigateTo({
                        url: "/subPackages/sms/sms"
                    });
                },
                formSubmit: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXCREATEPACKAGE,
                        params: ""
                    }), o.default.navigateTo({
                        url: "./packageCreat"
                    });
                },
                toFHY: function() {
                    wx.reportAnalytics("tofhy", {});
                },
                toPrintManager: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXTOPRINTER,
                        params: ""
                    }), wx.reportAnalytics("toprintmanager", {}), o.default.navigateTo({
                        url: "/sub-staff/pages/printer/printerMain?type=refresh"
                    }), S.default.uba(null, null, {
                        fid: "clickindexboxprinter",
                        params: ""
                    });
                },
                iCopyCancel: function() {
                    this.icopyModalShow = !1, this.$apply(), o.default.navigateTo({
                        url: "/subAddress/pages/address/perfectionAddress?toCreatePack=true"
                    });
                },
                closeicopyModalShow: function() {
                    this.icopyModalShow = !1;
                },
                checkboxChange: function(e) {
                    2 == e.detail.value.length ? (this.needShare = !0, this.needShareSend = !0) : (this.needShare = "receive" == e.detail.value[0], 
                    this.needShareSend = "sender" == e.detail.value[0]);
                },
                onCancel: function(e) {
                    this.showJoinGroup = !1, this.$apply();
                },
                onConfirmGroup: function() {
                    var e = this, t = 1, a = 1;
                    this.needShare && (t = 0), this.needShareSend && (a = 0), d.default.confirm("加入该团队后，与团队成员的打印伙伴关系将自动解除", function(n) {
                        n && e.scanUserGroup(e.sharedUserId, t, a);
                    }, {
                        confirmText: "我知道了",
                        cancelText: "暂不加入"
                    });
                },
                toExpert: function() {
                    o.default.navigateTo({
                        url: "/subPackages/activity/expert"
                    });
                },
                reScanAdd: function() {
                    this.processScanSearchAddPrinter();
                },
                QrInput: function(e) {
                    this.qrCodeInputText = e.detail.value;
                },
                toCreatePackageWithCard: function() {
                    this.parseCard(this.tempCardStr, "./packageCreat");
                },
                toCreateConsigneeWithCard: function() {
                    this.parseCard(this.tempCardStr, "/subAddress/pages/address/consigneeCreate");
                },
                selectPhone: function(e) {
                    for (var t = 0; t < this.tempCard.phoneSelectList.length; t++) this.tempCard.phoneSelectList[t] = !1;
                    this.tempCard.phoneSelectList[e] = !0, this.$apply();
                },
                selectAddr: function(e) {
                    for (var t = 0; t < this.tempCard.addressSelectList.length; t++) this.tempCard.addressSelectList[t] = !1;
                    this.tempCard.addressSelectList[e] = !0, this.$apply();
                },
                saveCardChoose: function() {
                    var e = {};
                    if (e.name = this.tempCard.name, this.tempCard.phoneSelectList && this.tempCard.phoneSelectList.length > 0) for (var t = 0; t < this.tempCard.phoneSelectList.length; t++) {
                        if (this.tempCard.phoneSelectList[t]) {
                            e.phoneList = [ this.tempCard.phoneList[t] ];
                            break;
                        }
                    }
                    if (this.tempCard.addressSelectList && this.tempCard.addressSelectList.length > 0) for (var a = 0; a < this.tempCard.addressSelectList.length; a++) {
                        if (this.tempCard.addressSelectList[a]) {
                            e.addressList = [ this.tempCard.addressList[a] ];
                            break;
                        }
                    }
                    this.chooseCard = !1, this.$apply(), this.goToWithCard(e, this.goToWithCardUrl);
                },
                closeChooseCardModal: function() {
                    this.chooseCard = !1;
                },
                closeSearchPrinterModal: function() {
                    this.searchPrinter = !1;
                },
                toWayBill: function() {
                    S.default.uba(null, null, {
                        fid: "toWayBillClick",
                        params: ""
                    }), d.default.showLoading(), this.toWayBill();
                },
                toEdit: function() {
                    S.default.uba(null, null, {
                        fid: "toEditClick",
                        params: ""
                    }), o.default.navigateTo({
                        url: "/sub-staff/pages/editWeight?id=" + this.wayBillNumber
                    });
                },
                userInfoHandler: function(e) {
                    this.shareWlbModalShow = !1, this.$apply(), e.detail && e.detail && e.detail.userInfo && this.updateShareWlb(e.detail);
                },
                closeScanModal: function() {
                    this.scanModalShow = !1;
                },
                closeScanAlertModal: function() {
                    this.scanAlertModalShow = !1;
                },
                closeScanInputAlertModal: function() {
                    this.scanInputAlertModalShow = !1;
                },
                closeChooseModal: function() {
                    this.chooseEditOrCheck = !1;
                },
                closeShareWlbModal: function() {
                    this.shareWlbModalShow = !1;
                },
                closeChooseCardOptModal: function() {
                    this.chooseCardOpt = !1;
                },
                toCreatFhdCode: function() {
                    var e = o.default.$instance.globalData.userType;
                    0 == e && S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXPAY,
                        params: ""
                    }), "sale" == e && S.default.uba(null, null, {
                        fid: "indexCashier",
                        params: ""
                    }), "deliver" == e && S.default.uba(null, null, {
                        fid: "indexPay-ed",
                        params: ""
                    }), this.funNeedShow && (this.clickedNewQRcode = !0, s.default.setSync("clickedNewQRcode", !0), 
                    this.$navigate("./myQrCode"));
                },
                toCreateShop: function() {
                    (0, F.indicators)("addFastItem"), wx.navigateTo({
                        url: "/sub-goods/pages/edit_goods/index"
                    });
                },
                scanQRCode: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXSHORTTAP,
                        params: ""
                    }), this.isFirstScan ? (this.isFirstScan = !1, s.default.setSync("isFirstScan", !1), 
                    this.scanAlertModalShow = !0) : this.showScanQr();
                },
                inputQRcode: function() {
                    S.default.uba(null, null, {
                        fid: g.UserBehavior.INDEXLONGTAP,
                        params: ""
                    }), this.isFirstScan ? (this.isFirstScan = !1, s.default.setSync("isFirstScan", !1), 
                    this.scanInputAlertModalShow = !0) : this.showScanInput();
                },
                inputQrCodeOver: function() {
                    this.scanModalShow = !1, this.$apply(), this.processScan(this.qrCodeInputText), 
                    this.qrCodeInputText = "";
                },
                showScanInput: function() {
                    this.scanInputAlertModalShow = !1, this.showScanInput();
                },
                showScanQr: function() {
                    this.scanAlertModalShow = !1, this.showScanQr();
                },
                showIcopy: function() {
                    this.checkNeedShowIcopy();
                },
                iCopyConfirm: function() {
                    this.icopyModalShow = !1, this.toReCreate();
                },
                onTapChooseCourier: function() {
                    console.log("点击了我是商家"), this.selectIndex = 1, this.$apply(), S.default.uba(null, null, {
                        fid: "openAccount_activity_chooseBusinessNumber",
                        params: ""
                    });
                },
                onTapChooseBusiness: function() {
                    console.log("点击了我是快递员"), this.selectIndex = 2, this.$apply();
                },
                btnGoToPage: function() {
                    var e = t(regeneratorRuntime.mark(function e() {
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                if (1 != this.selectIndex) {
                                    e.next = 14;
                                    break;
                                }
                                return this.show_identitySelection = !1, e.next = 4, this.setUserType("sale");

                              case 4:
                                if (!e.sent) {
                                    e.next = 10;
                                    break;
                                }
                                o.default.$instance.globalData.userType = "sale", this.userType = "sale", this.isShowActivity = !1, 
                                this.isShowMask = !0, this.$apply();

                              case 10:
                                wx.setStorage({
                                    key: "selectedIdentityBtn",
                                    data: !0
                                }), S.default.uba(null, null, {
                                    fid: "openAccount_activity_getInNowNumber",
                                    params: ""
                                }), e.next = 26;
                                break;

                              case 14:
                                if (2 != this.selectIndex) {
                                    e.next = 26;
                                    break;
                                }
                                return this.show_identitySelection = !1, e.next = 18, this.setUserType("deliver");

                              case 18:
                                if (!e.sent) {
                                    e.next = 24;
                                    break;
                                }
                                o.default.$instance.globalData.userType = "deliver", this.userType = "deliver", 
                                this.isShowActivity = !1, this.isShowMask = !0, this.$apply();

                              case 24:
                                wx.setStorage({
                                    key: "selectedIdentityBtn",
                                    data: !0
                                }), S.default.uba(null, null, {
                                    fid: "openAccount_activity_getInNowNumber",
                                    params: ""
                                });

                              case 26:
                              case "end":
                                return e.stop();
                            }
                        }, e, this);
                    }));
                    return function() {
                        return e.apply(this, arguments);
                    };
                }(),
                hideModel: function() {
                    this.isShowActivity = !1, this.$apply();
                },
                hideHomeMask: function() {
                    var e = t(regeneratorRuntime.mark(function e() {
                        var t, a;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                this.isShowMask = !1, this.userInfo.createTime <= 1608479999 && (t = o.default.$instance.globalData.canUseBankInfo, 
                                a = this.userCount, !t && a <= 4500 && (console.log("满足条件，可以展示出弹窗"), this.showRedEnvelope = !0, 
                                [ {
                                    from: "2020/12/16 00:00:00",
                                    to: "2020/12/31 23:59:59"
                                } ], this.showRedEnvelope = !0)), this.$apply();

                              case 3:
                              case "end":
                                return e.stop();
                            }
                        }, e, this);
                    }));
                    return function() {
                        return e.apply(this, arguments);
                    };
                }(),
                showWithdrawalDialog: function() {
                    var e = this;
                    console.log("点击成功，你已经点击了红包"), wx.setStorage({
                        key: "userReceived1",
                        data: !0
                    });
                    var t = new Date().getTime(), a = this.fun_date(3, t);
                    wx.setStorage({
                        key: "endDay",
                        data: a
                    }), a = a.replace(/-/g, "/"), this.countTime(a), setInterval(function() {
                        e.countTime(a);
                    }, 1e3), this.showRedEnvelope = !1, this.showWithdrawal = !0, this.$apply(), S.default.uba(null, null, {
                        fid: "openAccount_activity_showWithdrawalDialog",
                        params: ""
                    });
                }
            }, r(c, u);
        }
        return function(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t);
        }(h, e), i(h, [ {
            key: "navigateToWebview",
            value: function(e) {
                wx.$Uba({
                    fid: "hClickPopIndex",
                    params: {
                        popIndex: this.data.popIndex
                    }
                })(), this.newPopShow = !1, this.$apply(), wx.navigateTo({
                    url: "/pages/webPage?url=" + encodeURIComponent(e)
                });
            }
        }, {
            key: "showLifeMemberDialog",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t, a, n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (t = new Date(), a = t.getFullYear() + "-" + t.getMonth() + "-" + t.getDate(), 
                            n = wx.getStorageSync("lifeMemberDialogDay") || -1, a !== n) {
                                e.next = 5;
                                break;
                            }
                            return e.abrupt("return");

                          case 5:
                            if ("sale" === this.userType || !(Number(this.userSelectIdentity) < 201 || Number(this.userSelectIdentity) > 204)) {
                                e.next = 7;
                                break;
                            }
                            return e.abrupt("return");

                          case 7:
                            wx.setStorageSync("lifeMemberDialogDay", a), this.lifeMemberDialogVisible = !0, 
                            this.lifeMemberType = "sale" === this.userType ? 1 : 2, this.$apply();

                          case 11:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "getUserDetailSet",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if ("sale" != this.userType) {
                                e.next = 12;
                                break;
                            }
                            return t = wx.getStorageSync("openOnce") || !1, e.prev = 2, e.next = 5, (0, c.default)("/business/shop/getUserDetailSet.do", {
                                type: "USER_SHOP_RECEIVE"
                            }, {
                                baseUrl: "https://fhyapi.fhd001.com"
                            });

                          case 5:
                            e.sent.data ? (this.$wxpage.selectComponent("#newStorePop") && this.$wxpage.selectComponent("#newStorePop").hide && this.$wxpage.selectComponent("#newStorePop").hide(), 
                            this.isPickUpShop = !0, this.$apply()) : t || (wx.setStorageSync("openOnce", !0), 
                            this.$wxpage.selectComponent("#newStorePop") && this.$wxpage.selectComponent("#newStorePop").show && this.$wxpage.selectComponent("#newStorePop").show()), 
                            e.next = 12;
                            break;

                          case 9:
                            e.prev = 9, e.t0 = e.catch(2), console.log(e.t0);

                          case 12:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 2, 9 ] ]);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "goToImOrder",
            value: function() {
                this.saleProFunctionalArr.filter(function(e) {
                    "导入订单" == e.title && (e.showBubble = !1);
                }), this.$apply(), o.default.navigateTo({
                    url: "/sub-ImportOrder/pages/index/index"
                });
            }
        }, {
            key: "setUserType",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    var a;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, o.default.$instance.globalData.userTypeManager.setUserType(t, !1);

                          case 2:
                            return a = e.sent, e.abrupt("return", a);

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "IdentitySelection",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t, a, n, r, i, s;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            t = wx.getStorageSync("selectedIdentityBtn") ? wx.getStorageSync("selectedIdentityBtn") : null, 
                            a = wx.getStorageSync("selectedOldEdition") ? wx.getStorageSync("selectedOldEdition") : null, 
                            t || a || (n = [ {
                                from: "2020/12/16 00:00:00",
                                to: "2020/12/31 23:59:59"
                            } ], "sale" !== (r = o.default.$instance.globalData.userType) && "deliver" !== r && (!this.groupModel || this.groupModel && this.isCaptain) && (i = new Date().getTime(), 
                            s = new Date("2020/12/31 23:59:59").getTime(), i <= s && (this.show_identitySelection = !0, 
                            this.$apply(), this.isShowActivity = !0, (0, L.showActivityItem)(n, "isShowActivity", this, {
                                interval: 1
                            }), console.log("isShowActivity", this.isShowActivity), S.default.uba(null, null, {
                                fid: "openAccount_activity_identitySelectionNumber",
                                params: ""
                            }))));

                          case 3:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "fetchDirect",
            value: function() {
                var e = this;
                (0, c.default)("/public/getRedirectInfo.do", {
                    to: "otherMall"
                }).then(function(t) {
                    e.shopAppid = t.data.appId || "wx77dec7b930544409", e.shopPath = t.data.path || "", 
                    e.shopEnvVersion = t.data.envVersion || "release", e.$apply();
                }).catch(function(e) {
                    console.error("error", e), d.default.alert("跳转失败！请联系客服");
                });
            }
        }, {
            key: "setNvBar",
            value: function(e) {
                wx.setNavigationBarTitle({
                    title: e || "风火递"
                });
            }
        }, {
            key: "changeUserRole",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    var a, n, r, i, u, l, h, p, f = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1], g = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return f && d.default.showLoading("切换中..."), s.default.remove("userVipInfo"), e.prev = 2, 
                            a = "/user/changeUserRole.do", "" !== this.userType && void 0 !== this.userType && (a = "/user/changeUserRoleV2.do"), 
                            e.next = 7, (0, c.default)(a, {
                                userRole: t
                            });

                          case 7:
                            if (!(n = e.sent) || !n.data) {
                                e.next = 43;
                                break;
                            }
                            if (r = n.data, i = r.token, u = r.userType, o.default.$instance.globalData.token = i || n.data, 
                            !u) {
                                e.next = 31;
                                break;
                            }
                            u = u[0], e.t0 = u, e.next = "1" === e.t0 ? 16 : "2" === e.t0 ? 18 : 20;
                            break;

                          case 16:
                            return u = "sale", e.abrupt("break", 22);

                          case 18:
                            return u = "deliver", e.abrupt("break", 22);

                          case 20:
                            return u = 0, e.abrupt("break", 22);

                          case 22:
                            this.userType = u, o.default.$instance.globalData.userType = u, o.default.$instance.globalData.userInfo.userType = u, 
                            R.default.emitAll("updateUserType", this.userType), R.default.emitAll("changeGroup", t), 
                            s.default.setSync("lastUserType", u), l = wx.getStorageSync("team-upgrade-version"), 
                            h = 0 != u && (!l && 0 !== l || 0 != l && l != u), !this.isCaptain && h && (d.default.alert("团队管理员已升级至" + ("sale" == u ? "生意版" : "快递版") + "，您在团队模式下也自动升级", function() {}, {
                                confirm: "好的"
                            }), wx.setStorageSync("team-upgrade-version", u));

                          case 31:
                            if (f && d.default.message("切换成功"), 1 == t ? (s.default.setSync("groupModel", !0), 
                            o.default.$instance.globalData.groupModel = !0, this.groupModel = !0, o.default.$instance.globalData.userInfo.userRole = !0, 
                            this.setNvBar("风火递（团队）")) : (s.default.setSync("groupModel", !1), o.default.$instance.globalData.groupModel = !1, 
                            this.groupModel = !1, o.default.$instance.globalData.userInfo.userRole = !1, this.setNvBar("风火递")), 
                            this.showModalList = !1, null != g) for (this.teamModalList[g].selected = !0, p = 0; p < this.teamModalList.length; p++) this.teamModalList[p].selected = g == p;
                            return e.next = 37, this.getConfigByRole();

                          case 37:
                            this.getTargetUserCashGatewayInfo(), s.default.setSync("refreshLog", !0), s.default.setSync("refreshList", !0), 
                            f && d.default.hideLoading(), o.default.$instance.globalData.printManager.getWaybillAccount(!0), 
                            this.$apply();

                          case 43:
                            e.next = 50;
                            break;

                          case 45:
                            e.prev = 45, e.t1 = e.catch(2), console.error("ereeeeeeee", e.t1), d.default.hideLoading(), 
                            1 == e.t1.scode ? d.default.alert("切换失败或团队已解散！") : -3 != e.t1.scode && d.default.alert("切换失败！");

                          case 50:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 2, 45 ] ]);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "getConfigByRole",
            value: function() {
                var e = this;
                return new Promise(function() {
                    var a = t(regeneratorRuntime.mark(function t(a, n) {
                        var r;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.next = 2, (0, c.default)("/system/getConfig.do", {
                                    getConfigByRole: !0
                                });

                              case 2:
                                (r = e.sent).data && r.data.user && (o.default.$instance.globalData.betaInterfaceUrls = r.data.user.betaInterfaceUrls || {}), 
                                a();

                              case 5:
                              case "end":
                                return e.stop();
                            }
                        }, t, e);
                    }));
                    return function(e, t) {
                        return a.apply(this, arguments);
                    };
                }());
            }
        }, {
            key: "getTargetUserCashGatewayInfo",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t, a;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, (0, c.default)("/system/getTargetUserCashGatewayInfo.do");

                          case 2:
                            if (!(t = e.sent).data) {
                                e.next = 15;
                                break;
                            }
                            return o.default.$instance.globalData.canUseCollectCourierFee = t.data.canUseCollectCourierFee, 
                            o.default.$instance.globalData.canUseCollectMoney = t.data.canUseCollectMoney, this.getUserDefaultCashGateway(), 
                            e.next = 9, m.default.getInstance(!0).getUserBankInfo();

                          case 9:
                            a = e.sent, console.log("userBankInfouserBankInfo", a), o.default.$instance.globalData.bankInfo = a, 
                            this.bank && this.bank.setUserBankInfo(a), s.default.setSync("visitedPayments", !0), 
                            this.$apply();

                          case 15:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "getUserDefaultCashGateway",
            value: function() {
                (0, N.getUserAccountBankStatusList)().then(function(e) {
                    if (e.data && e.data.length) {
                        var t = e.data.filter(function(e) {
                            return "SUCCESS" == e.status;
                        });
                        if (1 == (t = t.sort(function(e, t) {
                            return e.createTime - t.createTime;
                        })).length) o.default.$instance.globalData.cashGateway = E.GATEWAY[t[0].gateway], 
                        o.default.$instance.globalData.cashGatewayStatus = t[0].status; else {
                            for (var a = 0; a < t.length; a++) {
                                var n = t[a];
                                if ("OPEN" == n.defaultGateway) {
                                    o.default.$instance.globalData.cashGateway = E.GATEWAY[n.gateway], o.default.$instance.globalData.cashGatewayStatus = n.status;
                                    break;
                                }
                            }
                            o.default.$instance.globalData.cashGateway || (o.default.$instance.globalData.cashGateway = E.GATEWAY[t[0].gateway], 
                            o.default.$instance.globalData.cashGatewayStatus = t[0].status);
                        }
                    } else o.default.$instance.globalData.cashGateway = 4;
                }).catch(function(e) {
                    o.default.$instance.globalData.cashGateway = 4;
                });
            }
        }, {
            key: "drawImage",
            value: function(e, t) {
                var a = this, n = e, r = {};
                return "size" == n[0].type ? (r.width = n[0].width, r.height = n[0].height) : (r.width = 76, 
                r.height = 180), r.content = n, r.layout = 1, r.length = 0, u.default.formatLabelDetail(r, o.default.$instance.getClientInfo().screenWidth, 1, 1), 
                this.canvasSize = r.ext, this.$apply(), new Promise(function(e, n) {
                    setTimeout(function() {
                        a.$apply(), e(u.default.converCode(r, !1, 1, 1, "drawImageCanvas", t));
                    }, 500);
                });
            }
        }, {
            key: "saveUserFroms",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t, a) {
                    var n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return (n = {}).formId = t, n.source = a, e.prev = 3, e.next = 6, (0, c.default)("/public/saveUserFroms.do", n);

                          case 6:
                            e.next = 11;
                            break;

                          case 8:
                            e.prev = 8, e.t0 = e.catch(3), console.error("formId提交失败");

                          case 11:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 3, 8 ] ]);
                }));
                return function(t, a) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "toReCreate",
            value: function() {
                var e = this.transAddressTemp;
                console.error("createPackageFromApp item", e);
                var t = {
                    consigneeInfo: {
                        consigneeName: e.name || "",
                        consigneeMobile: e.mobile || "",
                        consigneePhone: e.phone || "",
                        consigneeProvince: e.province || "",
                        consigneeCity: e.city || "",
                        consigneeArea: e.area || "",
                        consigneeTown: e.town || "",
                        consigneeZip: e.zip || "",
                        consigneeAddress: e.other || ""
                    }
                };
                s.default.setSync("reCreatePackage", t), o.default.navigateTo({
                    url: "./packageCreat?withoutRestore=true"
                });
            }
        }, {
            key: "checkIsAddress",
            value: function(e) {
                var t = /\S*((\+?86-?)|(\(\+86\)-)|0)?1[3-9][0-9]\d{6,8}/.test(e) || /\S*((400[0-9]{7})|((0[0-9]{2,3}-?)?[0-9]{7,8}))/.test(e), a = e.indexOf("省") > -1 || e.indexOf("市") > -1 || e.indexOf("区") > -1;
                return t && a;
            }
        }, {
            key: "checkNeedShowAlert",
            value: function() {
                var e = this;
                o.default.getClipboardData().then(function(t) {
                    if ("getClipboardData:ok" == t.errMsg) {
                        if ("" == t.data) return;
                        var a = s.default.getSync("clipboardCache");
                        if (a && a == t.data) return void (e.needShowPopover = !1);
                        s.default.setSync("clipboardCache", t.data), e.checkIsAddress(t.data) ? e.needShowPopover = !0 : e.needShowPopover = !1, 
                        e.$apply();
                    }
                }).catch(function(e) {
                    console.error(e);
                });
            }
        }, {
            key: "checkNeedShowIcopy",
            value: function() {
                var e = this;
                o.default.getClipboardData().then(function() {
                    var a = t(regeneratorRuntime.mark(function t(a) {
                        var n, r, i;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                if (n = [], "getClipboardData:ok" != a.errMsg) {
                                    t.next = 22;
                                    break;
                                }
                                if (a.data) {
                                    t.next = 4;
                                    break;
                                }
                                return t.abrupt("return");

                              case 4:
                                if (!(r = s.default.getSync("lastClipContent")) || a.data != r) {
                                    t.next = 7;
                                    break;
                                }
                                return t.abrupt("return");

                              case 7:
                                return r = a.data, s.default.setSync("lastClipContent", a.data), t.next = 11, e.iCopy.ripper(a.data, !1);

                              case 11:
                                if (i = t.sent, console.error("transAddress", i), i.province || i.city || i.area) {
                                    t.next = 15;
                                    break;
                                }
                                return t.abrupt("return");

                              case 15:
                                i.name && n.push("姓名：" + i.name), (i.mobile || i.tel) && n.push("\r\n电话：" + i.mobile || i.tel), 
                                (i.province || i.city || i.area) && (a.data.indexOf(i.province) < 0 && (e.greenAlert = !0, 
                                i.provinceFix = !0), a.data.indexOf(i.city) < 0 && (e.greenAlert = !0, i.cityFix = !0), 
                                a.data.indexOf(i.area) < 0 && (e.greenAlert = !0, i.areaFix = !0), n.push("\r\n省市区：" + i.province + i.city + i.area)), 
                                i.other && n.push("\r\n地址：" + i.other), e.transAddressTemp = i, e.icopyModalShow = !0, 
                                e.$apply();

                              case 22:
                              case "end":
                                return t.stop();
                            }
                        }, t, e);
                    }));
                    return function(e) {
                        return a.apply(this, arguments);
                    };
                }()).catch(function(e) {
                    console.error("icopy error", e);
                });
            }
        }, {
            key: "showScanInput",
            value: function() {
                this.scanInputAlertModalShow = !1, this.scanModalShow = !0, this.$apply();
            }
        }, {
            key: "showScanQr",
            value: function() {
                var e = this;
                this.scanAlertModalShow = !1, o.default.scanCode({
                    onlyFromCamera: !1
                }).then(function(t) {
                    t && t.result ? (console.log(t, JSON.stringify(t)), e.processScan(t.result)) : o.default.showToast({
                        title: "扫码错误",
                        duration: 3e3
                    });
                });
            }
        }, {
            key: "getPackageListTotal",
            value: function() {
                var e = this;
                return new Promise(function() {
                    var a = t(regeneratorRuntime.mark(function t(a, n) {
                        var r, i, o;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return (r = {}).page = 1, r.pageSize = 0, e.prev = 3, e.next = 6, (0, c.default)("/print/queryPackagePrintWait.do", r);

                              case 6:
                                i = e.sent, o = i.data.total > 0, a(o), e.next = 15;
                                break;

                              case 11:
                                e.prev = 11, e.t0 = e.catch(3), console.error("queryPackagePrintWait error", e.t0), 
                                n(!1);

                              case 15:
                              case "end":
                                return e.stop();
                            }
                        }, t, e, [ [ 3, 11 ] ]);
                    }));
                    return function(e, t) {
                        return a.apply(this, arguments);
                    };
                }());
            }
        }, {
            key: "afterLoginNavigateTo",
            value: function() {
                var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                clearTimeout(this.afterLoginNavigateToHandler), o.default.$instance.globalData.isLogining ? this.afterLoginNavigateToHandler = setTimeout(function() {
                    e.afterLoginNavigateTo(t);
                }, 500) : o.default.navigateTo({
                    url: t
                });
            }
        }, {
            key: "compareVersion",
            value: function(e, t) {
                e = e.split("."), t = t.split(".");
                for (var a = Math.max(e.length, t.length); e.length < a; ) e.push("0");
                for (;t.length < a; ) t.push("0");
                for (var n = 0; n < a; n++) {
                    var r = parseInt(e[n]), i = parseInt(t[n]);
                    if (r > i) return 1;
                    if (r < i) return -1;
                }
                return 0;
            }
        }, {
            key: "calCanshowPrinter",
            value: function() {
                var e = parseInt(o.default.$instance.globalData.userInfo.userId), t = parseInt(o.default.$instance.globalData.printerPercent) || 0;
                this.canShowPrinter = e % 100 >= t;
            }
        }, {
            key: "getVip",
            value: function() {
                var e = this;
                this.getUserVip(!0).then(function(t) {
                    e.userVip = t, o.default.$instance.globalData.userVip = e.userVip, new l.default("virusShowModel", 0, "2020/4/1").once(e.showVirusAlert.bind(e), t), 
                    new B.default(t, e.userType).checkCanUpgrade().then(function(t) {
                        t && t.data && e.getVip();
                    }), e.$apply();
                });
            }
        }, {
            key: "showVirusAlert",
            value: function(e) {
                var t = "在这个特殊时期，风火递与您共战疫情。3月31日前订购高级版，将在订购有效期的基础上免费赠送90天";
                e && (t = "在这个特殊时期，风火递与您共战疫情。您已订购的风火递高级版，有效期将免费顺延90天", this.extensionVip()), d.default.confirm(t, function(t) {
                    if (t) {
                        var a = e ? "/sub-staff/pages/profile/profile" : "/sub-vip/pages/vipMain";
                        o.default.navigateTo({
                            url: a
                        });
                    }
                }, {
                    title: "温馨提示",
                    confirmText: e ? "前往查看" : "马上订购"
                });
            }
        }, {
            key: "refreshShop",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            (0, O.fetchUserThirdShop)(!0);

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "getGroupApplyInfo",
            value: function() {
                var e = this;
                this.group && this.group.groupId && (0, M.getApplyGroupUserNum)({
                    groupId: this.group.groupId
                }).then(function(t) {
                    t && t.data && e.myTeam && (e.groupApplyCount = t.data || 0, e.myTeam.badge = e.groupApplyCount, 
                    e.$apply());
                });
            }
        }, {
            key: "toSendCodeManager",
            value: function() {
                wx.navigateTo({
                    url: "/subPackages/sendCode/sendCodeList"
                });
            }
        }, {
            key: "toSetTemplate",
            value: function() {
                S.default.uba(null, null, {
                    fid: "toSetTemplateClick",
                    params: ""
                }), this.deliverFunctionalArr.filter(function(e) {
                    "运费模板" == e.title && (e.showBubble = !1);
                }), this.$apply(), wx.navigateTo({
                    url: "/sub-freightCharge/pages/templateList"
                });
            }
        }, {
            key: "setFunctionalArr",
            value: function() {
                var e = {
                    title: "电子面单",
                    color: "color_green",
                    icon: "icon-index-list",
                    tap: "toEsheet"
                }, t = {
                    title: "打印机",
                    color: "color_blue",
                    icon: "icon-index-print",
                    tap: "toPrintManager"
                };
                this.myTeam = {
                    title: "我的团队",
                    badge: this.groupApplyCount,
                    badgeType: "string",
                    color: "color_red",
                    icon: "icon-index-team",
                    tap: "toGroup"
                };
                var a = {
                    title: "查件码",
                    color: "color_orange",
                    icon: "icon-index-searchQR",
                    tap: "toShopCode",
                    bubbleTitle: "有升级",
                    showBubble: !0,
                    bubbleKey: "isClickSearchCode"
                }, n = {
                    title: "快递查询",
                    color: "color_blue",
                    icon: "icon-index-car",
                    tap: "toLogisticSearch"
                }, r = {
                    title: "短信服务",
                    badgeType: "img",
                    badgeSrc: "",
                    color: "color_green",
                    icon: "icon-index-message",
                    tap: "clickedsmsfn"
                }, i = {
                    title: "自助打印",
                    color: "color_blue",
                    icon: "icon-index-selfPrint",
                    tap: "toCodeList"
                }, o = {
                    title: "对接电商",
                    color: "color_green",
                    badgeType: "string",
                    icon: "icon-index-link",
                    tap: "tooms",
                    bubbleTitle: "快手抖音",
                    showBubble: !0,
                    bubbleKey: "isClickTooms"
                }, s = {
                    title: "业务员",
                    color: "color_green",
                    icon: "icon-index-deliver",
                    tap: "toDeliver"
                }, u = {
                    title: "电脑打印",
                    color: "color_blue",
                    icon: "icon-index-pcPrint",
                    tap: "toPCHelp"
                }, c = {
                    title: "商品标签",
                    color: "color_red",
                    icon: "icon-index-label",
                    tap: "toLabel"
                }, l = {
                    title: "客服帮助",
                    color: "color_blue",
                    icon: "icon-index-service",
                    tap: "toHelp"
                }, d = {
                    title: "寄件码",
                    color: "color_orange",
                    icon: "icon-sendcode2",
                    tap: "toSendCodeManager"
                }, h = {
                    title: "导入订单",
                    color: "color_orange",
                    icon: "icon-import-order",
                    tap: "goToImOrder",
                    bubbleTitle: "新功能",
                    showBubble: !0,
                    bubbleKey: "isClickImportOrder"
                }, p = {
                    title: "会员权益",
                    color: "color_red",
                    icon: "icon-index-vip",
                    tap: "clickVIP"
                };
                this.deliverFunctionalArr = [ {
                    title: "运费模板",
                    color: "color_blue",
                    icon: "icon-yunfeimoban",
                    tap: "toSetTemplate",
                    bubbleTitle: "新功能",
                    showBubble: !0,
                    bubbleKey: "isClickSetTemplate"
                }, {
                    title: "收货地址",
                    color: "color_orange",
                    icon: "icon-index-address",
                    tap: "toSubAddress"
                }, e, t, this.myTeam, a, n, d, h, i, u, r, p, s, c, o, l ], this.saleSuperArr = [ {
                    title: "超级开单",
                    color: "color_blue",
                    icon: "icon-saleGood",
                    tap: "toSaleGood"
                }, {
                    title: "群接龙",
                    color: "color_orange",
                    icon: "icon-chain",
                    tap: "goToGroupChain",
                    bubbleTitle: "新功能",
                    showBubble: !0,
                    bubbleKey: "isClickGroupChain"
                }, {
                    title: "商品秒杀",
                    color: "color_red",
                    icon: "icon-seckill",
                    tap: "goToSecondsKll",
                    bubbleTitle: "领100元红包",
                    showBubble: !0,
                    bubbleKey: "isClickSecondsKll_1"
                }, {
                    title: "拼团活动",
                    icon: "icon-group-booking",
                    color: "color_ccc",
                    tap: "toGroupBooking"
                }, {
                    title: "优惠券",
                    color: "color_red",
                    icon: "icon-coupon",
                    tap: "toCoupon",
                    bubbleTitle: "新功能",
                    showBubble: !0,
                    bubbleKey: "isClickCoupon"
                }, {
                    title: "包邮活动",
                    color: "color_green",
                    icon: "icon-baoyou",
                    tap: "toShippingFree",
                    bubbleTitle: "新功能",
                    showBubble: !0,
                    bubbleKey: "isClickItemShippingFree"
                }, {
                    title: "商品管理",
                    color: "color_red",
                    icon: "icon-addGoods",
                    tap: "toGoodList"
                }, {
                    title: "商品海报",
                    color: "color_green",
                    icon: "icon-pic",
                    tap: "goToItemPoster",
                    bubbleTitle: "新功能",
                    showBubble: !0,
                    bubbleKey: "isClickItemPoster"
                }, {
                    title: "店铺订单",
                    color: "color_orange",
                    icon: "icon-goodLog",
                    tap: "gotoShopOrder"
                }, {
                    title: "店铺管理",
                    color: "color_red",
                    icon: "icon-shopmanager",
                    tap: "gotoMyShop"
                } ], this.saleBaseFunctionalArr = [ e, t, a, this.myTeam ], this.saleProFunctionalArr = [ n, o, h, r, d, i, u, c, p, s, l ], 
                this.$apply();
            }
        }, {
            key: "goToItemPoster",
            value: function() {
                this.saleSuperArr.filter(function(e) {
                    "商品海报" == e.title && (e.showBubble = !1);
                }), this.$apply(), S.default.uba(null, null, {
                    fid: "indexPoster"
                }), wx.reportEvent && wx.reportEvent("main_poster_click", {
                    user_id: this.userInfo.userId,
                    fenghuo_id: this.userInfo.fhdCode,
                    uesr_lvname: this.generalData.uesr_lvname,
                    time: this.currentTime,
                    xcx_version: this.version
                }), wx.navigateTo({
                    url: "/sub-goodsPoster/pages/index/index"
                });
            }
        }, {
            key: "goToGroupChain",
            value: function() {
                this.saleSuperArr.filter(function(e) {
                    "群接龙" == e.title && (e.showBubble = !1);
                }), this.$apply(), S.default.uba(null, null, {
                    fid: "indexGroup"
                }), wx.reportEvent && wx.reportEvent("main_groupsolitaire_click", {
                    user_id: this.userInfo.userId,
                    fenghuo_id: this.userInfo.fhdCode,
                    uesr_lvname: this.generalData.uesr_lvname,
                    time: this.currentTime,
                    xcx_version: this.version
                }), wx.navigateTo({
                    url: "/sub-groupchain/pages/index"
                });
            }
        }, {
            key: "goToSecondsKll",
            value: function() {
                this.saleSuperArr.filter(function(e) {
                    "商品秒杀" == e.title && (e.showBubble = !1);
                }), this.$apply(), S.default.uba(null, null, {
                    fid: "indexSeckill"
                }), wx.reportEvent && wx.reportEvent("main_seckill_click", {
                    user_id: this.userInfo.userId,
                    fenghuo_id: this.userInfo.fhdCode,
                    uesr_lvname: this.generalData.uesr_lvname,
                    time: this.currentTime,
                    xcx_version: this.version
                }), wx.navigateTo({
                    url: "/sub-secondsKll/pages/index"
                });
            }
        }, {
            key: "toGoodList",
            value: function() {
                S.default.uba(null, null, {
                    fid: "indexGoodlist"
                }), wx.reportEvent && wx.reportEvent("main_goodsmanage_click", {
                    user_id: this.userInfo.userId,
                    fenghuo_id: this.userInfo.fhdCode,
                    uesr_lvname: this.generalData.uesr_lvname,
                    time: this.currentTime,
                    xcx_version: this.version
                }), wx.navigateTo({
                    url: "/sub-goods/pages/index/index?isManager=true"
                });
            }
        }, {
            key: "gotoShopOrder",
            value: function() {
                S.default.uba(null, null, {
                    fid: "indexShoporder"
                }), wx.reportEvent && wx.reportEvent("main_shoporder_click", {
                    user_id: this.userInfo.userId,
                    fenghuo_id: this.userInfo.fhdCode,
                    uesr_lvname: this.generalData.uesr_lvname,
                    time: this.currentTime,
                    xcx_version: this.version
                }), wx.navigateTo({
                    url: "/sub-business/pages/tradeList"
                });
            }
        }, {
            key: "gotoMyShop",
            value: function() {
                S.default.uba(null, null, {
                    fid: "indexShopM"
                }), wx.reportEvent && wx.reportEvent("main_shopmanage_click", {
                    user_id: this.userInfo.userId,
                    fenghuo_id: this.userInfo.fhdCode,
                    uesr_lvname: this.generalData.uesr_lvname,
                    time: this.currentTime,
                    xcx_version: this.version
                }), wx.navigateTo({
                    url: "/sub-business/pages/personalStores"
                });
            }
        }, {
            key: "hasFhdUserTypeWhite",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, (0, c.default)("/business/item/hasFhdUserTypeWhite.do", {}, {
                                baseUrl: "https://fhyapi.fhd001.com"
                            });

                          case 2:
                            t = e.sent, o.default.$instance.globalData.hasFhdUserTypeWhite = t.data, this.$apply();

                          case 5:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "requestVisitors",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t, a, n, r, i, s;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, o.default.$instance.waitConfig();

                          case 2:
                            return S.default.uba(null, null, {
                                fid: "/business/shop/getAntShopInfoList.do",
                                m: "/pages/index"
                            }), e.next = 5, b.default.shopCount.getAntShopInfoList();

                          case 5:
                            return t = e.sent, a = t.data[0].shopId, this.shopId = a, console.log("shopId", a), 
                            n = new Date(), r = parseInt(+new Date(n.getFullYear() + "/" + (n.getMonth() + 1) + "/" + n.getDate() + " 23:59:59") / 1e3), 
                            i = r - 604800, e.prev = 12, e.next = 15, b.default.shopCount.getShopBuyerCountByLastVisitTime({
                                shopId: a,
                                timeRange: i + "," + r
                            });

                          case 15:
                            (s = e.sent).data && (this.visitorNum = s.data[i + "," + r]), this.$apply(), e.next = 23;
                            break;

                          case 20:
                            e.prev = 20, e.t0 = e.catch(12), console.error(e.t0);

                          case 23:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 12, 20 ] ]);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "isShowAddWeichatDroupDialog",
            value: function() {
                var e = wx.getStorageSync("beforeShowDialogTime") || null, t = new Date().getDay();
                e ? e !== t && (this.showAddWeichatGroup = !0) : this.showAddWeichatGroup = !0, 
                (0, F.indicators)("Popup_exposure"), this.$apply();
            }
        }, {
            key: "getUserConfig",
            value: function() {
                var e = this;
                return new Promise(function() {
                    var a = t(regeneratorRuntime.mark(function t(a, n) {
                        var r;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.prev = 0, e.next = 3, (0, c.default)("/user/getUserConfig.do", {
                                    type: 9
                                });

                              case 3:
                                (r = e.sent).data && a(r), e.next = 10;
                                break;

                              case 7:
                                e.prev = 7, e.t0 = e.catch(0), console.error(e.t0);

                              case 10:
                              case "end":
                                return e.stop();
                            }
                        }, t, e, [ [ 0, 7 ] ]);
                    }));
                    return function(e, t) {
                        return a.apply(this, arguments);
                    };
                }());
            }
        }, {
            key: "isSwitchUserIdentity",
            value: function() {
                var e = this, a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return new Promise(function() {
                    var n = t(regeneratorRuntime.mark(function t(n, r) {
                        var i;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.prev = 0, e.next = 3, (0, c.default)("/activityV2/isSwitchEdition.do", a);

                              case 3:
                                return i = e.sent, n(), e.abrupt("return", i.data);

                              case 8:
                                e.prev = 8, e.t0 = e.catch(0), console.error(e.t0);

                              case 11:
                              case "end":
                                return e.stop();
                            }
                        }, t, e, [ [ 0, 8 ] ]);
                    }));
                    return function(e, t) {
                        return n.apply(this, arguments);
                    };
                }());
            }
        }, {
            key: "SwitchUserIdentity",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t, a, n, r, i, s, u;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (t = Date.parse(new Date()) / 1e3, a = new Date().getDate(), n = wx.getStorageSync("isFirstLogin") || 0, 
                            "sale" === this.userType || "deliver" === this.userType) {
                                e.next = 63;
                                break;
                            }
                            return e.next = 6, this.getUserConfig().then(function(e) {
                                return e;
                            });

                          case 6:
                            if (r = e.sent, i = r.data.value, this.identityModalShow = !1, this.$apply(), wx.setStorageSync("isFirstLogin", new Date().getDate()), 
                            !i) {
                                e.next = 60;
                                break;
                            }
                            if (n != a && (0, F.indicators)("havehumanid"), s = wx.getStorageSync("NoSelectedIdentityUser") || null, 
                            u = 0, s && (u = t - s), !(s && u >= 43200 && s)) {
                                e.next = 38;
                                break;
                            }
                            if ("201" !== i && "202" !== i && "203" !== i && "204" !== i) {
                                e.next = 26;
                                break;
                            }
                            return e.next = 20, this.setUserType("sale");

                          case 20:
                            this.userType = "sale", o.default.$instance.globalData.userType = "sale", R.default.emitAll("updateUserType", this.userType), 
                            n != a && (0, F.indicators)("humansj"), e.next = 36;
                            break;

                          case 26:
                            if ("101" !== i && "102" !== i && "103" !== i) {
                                e.next = 35;
                                break;
                            }
                            return e.next = 29, this.setUserType("deliver");

                          case 29:
                            this.userType = "deliver", o.default.$instance.globalData.userType = "deliver", 
                            R.default.emitAll("updateUserType", this.userType), n != a && (0, F.indicators)("humankd"), 
                            e.next = 36;
                            break;

                          case 35:
                            n != a && (0, F.indicators)("humancj");

                          case 36:
                            e.next = 58;
                            break;

                          case 38:
                            if (s) {
                                e.next = 58;
                                break;
                            }
                            if ("201" !== i && "202" !== i && "203" !== i && "204" !== i) {
                                e.next = 48;
                                break;
                            }
                            return e.next = 42, this.setUserType("sale");

                          case 42:
                            this.userType = "sale", o.default.$instance.globalData.userType = "sale", R.default.emitAll("updateUserType", this.userType), 
                            n != a && (0, F.indicators)("humansj"), e.next = 58;
                            break;

                          case 48:
                            if ("101" !== i && "102" !== i && "103" !== i) {
                                e.next = 57;
                                break;
                            }
                            return e.next = 51, this.setUserType("deliver");

                          case 51:
                            this.userType = "deliver", o.default.$instance.globalData.userType = "deliver", 
                            R.default.emitAll("updateUserType", this.userType), n != a && (0, F.indicators)("humankd"), 
                            e.next = 58;
                            break;

                          case 57:
                            n != a && (0, F.indicators)("humancj");

                          case 58:
                            e.next = 63;
                            break;

                          case 60:
                            n != a && (0, F.indicators)("nohumanid"), (0, F.indicators)("switchIdentity_ShowPopCount"), 
                            this.identityModalShow = !0;

                          case 63:
                            this.$apply();

                          case 64:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "getUserAccountBankInFo",
            value: function() {
                var e = this, a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                return new Promise(function() {
                    var n = t(regeneratorRuntime.mark(function t(n, r) {
                        var i;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.prev = 0, e.next = 3, (0, c.default)("/activityV2/getUserAccountCount.do", a);

                              case 3:
                                (i = e.sent).data && n(i.data), e.next = 10;
                                break;

                              case 7:
                                e.prev = 7, e.t0 = e.catch(0), console.error(e.t0);

                              case 10:
                              case "end":
                                return e.stop();
                            }
                        }, t, e, [ [ 0, 7 ] ]);
                    }));
                    return function(e, t) {
                        return n.apply(this, arguments);
                    };
                }());
            }
        }, {
            key: "userCheckAccountRightsActivity",
            value: function() {
                var e = this;
                return new Promise(function() {
                    var a = t(regeneratorRuntime.mark(function t(a, n) {
                        var r;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.prev = 0, e.next = 3, (0, c.default)("/activity/business/checkAccountRightsActivity.do", {}, {
                                    baseUrl: "https://fhyapi.fhd001.com"
                                });

                              case 3:
                                (r = e.sent).data && a(r.data), e.next = 10;
                                break;

                              case 7:
                                e.prev = 7, e.t0 = e.catch(0), console.error(e.t0);

                              case 10:
                              case "end":
                                return e.stop();
                            }
                        }, t, e, [ [ 0, 7 ] ]);
                    }));
                    return function(e, t) {
                        return a.apply(this, arguments);
                    };
                }());
            }
        }, {
            key: "queryAccountRightsActivity",
            value: function() {
                var e = this;
                return new Promise(function() {
                    var a = t(regeneratorRuntime.mark(function t(a, n) {
                        var r;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.prev = 0, e.next = 3, (0, c.default)("/activity/business/queryAccountRightsActivity.do", {}, {
                                    baseUrl: "https://fhyapi.fhd001.com"
                                });

                              case 3:
                                r = e.sent, a(r.data), e.next = 10;
                                break;

                              case 7:
                                e.prev = 7, e.t0 = e.catch(0), console.error(e.t0);

                              case 10:
                              case "end":
                                return e.stop();
                            }
                        }, t, e, [ [ 0, 7 ] ]);
                    }));
                    return function(e, t) {
                        return a.apply(this, arguments);
                    };
                }());
            }
        }, {
            key: "afterLoginTodo",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(a) {
                    var n, r, i, u, l, h, p, f, g = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (clearTimeout(this.afterLoginToDoHandler), !o.default.$instance.globalData.isLogining) {
                                e.next = 4;
                                break;
                            }
                            return this.afterLoginToDoHandler = setTimeout(function() {
                                g.afterLoginTodo(a);
                            }, 500), e.abrupt("return");

                          case 4:
                            if (this.doubleSms = o.default.$instance.globalData.doubleSms, this.setFunctionalArr(), 
                            o.default.$instance.globalData.token) {
                                e.next = 8;
                                break;
                            }
                            return e.abrupt("return");

                          case 8:
                            if (setTimeout(function() {
                                g.refreshShop();
                            }, 1e3), this.noNeedGetAddress || o.default.$instance.globalData.getArea(), y.default.emitAll("app/login/success"), 
                            this.calCanshowPrinter(), n = o.default.$instance.getClientInfo(), this.ios = o.default.$instance.globalData.ios, 
                            this.screenWidth = n.windowWidth, this.userInfo = o.default.$instance.globalData.userInfo, 
                            this.indexShopBadge = o.default.$instance.globalData.indexShopBadge, this.indexshopAc = o.default.$instance.globalData.indexshopAc, 
                            this.moreMoney = o.default.$instance.globalData.moreMoney, this.AddWeichatGroupImgSwitch = o.default.$instance.globalData.AddWeichatGroupImgSwitch, 
                            this.isShowVIdentityModel = o.default.$instance.globalData.isShowVIdentityModel, 
                            this.isSHowDialog = o.default.$instance.globalData.isSHowDialog, this.currentTime = Date.parse(new Date()) / 1e3, 
                            r = Date.parse(new Date()) / 1e3, new Date().getDate(), "sale" === this.userInfo.userType || "deliver" === this.userInfo.userType || this.isLDNoCheck || wx.redirectTo({
                                url: "../sub-NewUserIdentity/pages/index/index"
                            }), "sale" !== this.userInfo.userType) {
                                e.next = 36;
                                break;
                            }
                            return e.next = 29, this.getUserConfig().then(function(e) {
                                return e;
                            });

                          case 29:
                            i = e.sent, u = i.data.value, l = {
                                fenghuo_id: this.userInfo.fhdCode,
                                uesr_lvname: u
                            }, this.generalData = l, h = wx.getStorageSync("seconSkllDialog_isShow") || "", 
                            p = wx.getStorageSync("couponDialog_isShow") || "", !h && r >= 1624982400 && r <= 1625068799 ? (wx.setStorage({
                                key: "seconSkllDialog_isShow",
                                data: !0
                            }), (0, F.indicators)("main_seckillpopup_load"), this.showSecondSkllDialog = !0) : this.showSecondSkllDialog = !1, 
                            !p && r >= 1625155200 && r <= 1625241599 ? (wx.setStorage({
                                key: "couponDialog_isShow",
                                data: !0
                            }), (0, F.indicators)("main_couponpopup_load"), this.showCouponDialog = !0) : this.showCouponDialog = !1;

                          case 36:
                            this.$apply(), this.userInfo && ("sale" === this.userInfo.userType ? (0, F.indicators)("sybActUser") : "deliver" === this.userInfo.userType ? (0, 
                            F.indicators)("kdbActUser") : (0, F.indicators)("oldActUser")), o.default.$instance.globalData.referrerInfo && o.default.$instance.globalData.referrerInfo.extraData && ("createPackage" == (f = o.default.$instance.globalData.referrerInfo.extraData).action && this.toCreateNewPackage(f.packageInfo), 
                            S.default.uba(null, null, {
                                fid: "thirdCreatePackage",
                                params: JSON.stringify(f)
                            })), o.default.$instance.globalData.clientInfo && o.default.$instance.globalData.clientInfo.SDKVersion && this.compareVersion(o.default.$instance.globalData.clientInfo.SDKVersion, "2.0.7") < 0 && d.default.alert("风火递将在下个版本（v2.0.3）中支持微信的新功能，请尽快升级到微信7.0以上的版本，以免无法正常使用风火递！"), 
                            o.default.$instance.globalData.needQueryMall ? this.fetchDirect() : (this.shopAppid = "wx77dec7b930544409", 
                            this.shopPath = "", this.shopEnvVersion = "release"), this.initUserBank(o.default.$instance.globalData.cashGateway), 
                            t(regeneratorRuntime.mark(function e() {
                                var t, a, n;
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        return t = "deliver" === g.userInfo.userType ? 6 : 7, e.next = 3, (0, c.default)("/merge/queryIndexBaseV2.do", {
                                            client: t
                                        });

                                      case 3:
                                        a = e.sent, n = a.data, o.default.$instance.globalData.hasScribe = n.hasScribe, 
                                        g.$apply(), g.queryHasScribe(n.hasScribe), g.getAccount(n.careControls, n.accountSms), 
                                        g.getNotices(n.notics);

                                      case 10:
                                      case "end":
                                        return e.stop();
                                    }
                                }, e, g);
                            }))(), t(regeneratorRuntime.mark(function e() {
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        $.check({
                                            finsh: function(e) {
                                                g.isChangeToCustomer = !0, g.$apply();
                                            }
                                        });

                                      case 1:
                                      case "end":
                                        return e.stop();
                                    }
                                }, e, g);
                            }))(), function() {
                                var e = s.default.getSync("noticeVersion");
                                o.default.$instance.globalData.noticeVersion && o.default.$instance.globalData.noticeText && (e ? o.default.$instance.globalData.noticeVersion > e && d.default.alert(o.default.$instance.globalData.noticeText) : d.default.alert(o.default.$instance.globalData.noticeText), 
                                s.default.setSync("noticeVersion", o.default.$instance.globalData.noticeVersion));
                            }(), wx.getStorageSync("isAddWeichatGroup1") || null || this.isShowAddWeichatDroupDialog(), 
                            this.$apply(), "sale" != this.userType && "deliver" != this.userType || this._showRedEnvelope(), 
                            "sale" == this.userType && this.requestVisitors(), this.showLifeMemberDialog();

                          case 51:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "initUserBank",
            value: function(e) {
                this.bank = m.default.getInstance();
            }
        }, {
            key: "toCreateNewPackage",
            value: function(e) {
                var t = {};
                if (e && e.send && (t = {
                    shippingName: e.send.shippingName || "",
                    shippingMobile: e.send.shippingMobile || "",
                    shippingProvince: e.send.shippingProvince || "",
                    shippingCity: e.send.shippingCity || "",
                    shippingArea: e.send.shippingArea || "",
                    shippingTown: e.send.shippingTown || "",
                    shippingAddress: e.send.shippingAddress || "",
                    shippingCompany: e.send.shippingCompany || "",
                    packageNote: e.packageNote,
                    packageCategory: e.packageCategory,
                    source: e.source,
                    outerTid: e.outerTid
                }), 1 == e.consignee.length) {
                    var a = e.consignee[0];
                    t.consigneeInfo = {
                        consigneeName: a.consigneeName,
                        consigneeMobile: a.consigneeMobile,
                        consigneePhone: a.consigneePhone,
                        consigneeProvince: a.consigneeProvince,
                        consigneeCity: a.consigneeCity,
                        consigneeArea: a.consigneeArea,
                        consigneeTown: a.consigneeTown,
                        consigneeAddress: a.consigneeAddress
                    };
                } else {
                    var n = e.consignee;
                    t.mulitAddress = [];
                    for (var r = 0; r < n.length; r += 1) {
                        var i = n[r];
                        t.mulitAddress.push(i);
                    }
                }
                s.default.setSync("thirdNewPackage", t), o.default.navigateTo({
                    url: "./packageCreat?withoutRestore=true"
                });
            }
        }, {
            key: "sortNoticeArr",
            value: function(e) {
                return e && e.sort(function(e, t) {
                    return "NOTICE" == e.type && "NOTICE" != t.type ? -1 : "NOTICE" == e.type && "NOTICE" == t.type ? e.showTime - t.showTime : "NOTICE" != e.type && "NOTICE" == t.type ? 1 : e.showTime - t.showTime;
                });
            }
        }, {
            key: "checkOpenedNotice",
            value: function(e) {
                var t = s.default.getSync("openedNotice");
                if (!t || 0 == t.length) return e;
                for (var a = [], n = 0; n < e.length; n++) {
                    for (var r = e[n], i = !1, o = 0; o < t.length; o++) {
                        var u = t[o];
                        r.id == u.id && (i = !0);
                    }
                    if (!i) {
                        var c = parseInt(+new Date() / 1e3);
                        r.showTime < c && c < r.expireTime && a.push(r);
                    }
                }
                return a;
            }
        }, {
            key: "canIndexModelShow",
            value: function() {
                var e = s.default.getSync("last24ModelShow");
                return !e || +new Date() - e > 864e5;
            }
        }, {
            key: "showIndexNotice",
            value: function(e) {
                this.indexNoticeObj = e, this.indexNoticeShow = !0, s.default.setSync("last24ModelShow", +new Date());
                var t = s.default.getSync("openedNotice");
                t && t.length ? t.push(e) : t = [ e ], s.default.setSync("openedNotice", t), this.$apply();
            }
        }, {
            key: "showNoticeModel",
            value: function(e) {
                var t = this;
                e.some(function(e) {
                    return "NOTICE" == e.type || t.canIndexModelShow() ? (t.showIndexNotice(e), !0) : void 0;
                });
            }
        }, {
            key: "checkNoticeModel",
            value: function(e) {
                var t = e && e.filter(function(e) {
                    if ("OPEN" == e.openWindow) return e;
                }), a = this.sortNoticeArr(this.checkOpenedNotice(t));
                this.showNoticeModel(a);
            }
        }, {
            key: "getNotices",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    var a, n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if ((a = t) && a.list) {
                                e.next = 3;
                                break;
                            }
                            return e.abrupt("return");

                          case 3:
                            return wx.setStorage({
                                key: "index/getNotices/list",
                                data: a.list
                            }), e.next = 6, this.getH5Question();

                          case 6:
                            n = e.sent, this.guideList = a.list, this.checkNoticeModel(a.list), n && this.guideList.push(n), 
                            this.checkNeedShowNewsBadge(this.guideList), this.$apply();

                          case 12:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "checkNeedShowNewsBadge",
            value: function(e) {
                var t = s.default.getSync("indexLastNewsId");
                if (this.data.guideList && this.data.guideList.length > 0) {
                    var a = this.data.guideList.shift();
                    if (!t) return s.default.setSync("indexLastNewsId", a.id), void (this.showBadge = !0);
                    a.id > t && (s.default.setSync("indexLastNewsId", a.id), this.showBadge = !0);
                }
            }
        }, {
            key: "getH5Question",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (!wx.getStorageSync("index/getH5Question/isJoin")) {
                                e.next = 3;
                                break;
                            }
                            return e.abrupt("return", null);

                          case 3:
                            return t = null, e.prev = 4, e.next = 7, (0, c.default)("/activityV2/queryHasCompleteNps.do");

                          case 7:
                            t = e.sent, e.next = 13;
                            break;

                          case 10:
                            return e.prev = 10, e.t0 = e.catch(4), e.abrupt("return", null);

                          case 13:
                            if (!t.data) {
                                e.next = 16;
                                break;
                            }
                            return wx.setStorageSync("index/getH5Question/isJoin", !0), e.abrupt("return", null);

                          case 16:
                            return e.abrupt("return", {
                                mainTitle: "风火递邀请您参加问卷调查，参与即送短信",
                                title: "风火递邀请您参加问卷调查，参与即送短信",
                                status: "OPEN",
                                id: "",
                                conType: "CLOSE",
                                content: encodeURIComponent("https://fhdowx.xyy001.com/h5/#/questionnaire?token=" + encodeURIComponent(o.default.$instance.globalData.token))
                            });

                          case 17:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 4, 10 ] ]);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "checkIfAuthed",
            value: function() {
                return "https://img1.fhd001.com/fhdowx/images/default.jpg" != o.default.$instance.globalData.userInfo.avatarUrl || (d.default.alert("您还未授权，暂时无法使用该功能，授权后方可使用", function(e) {
                    o.default.navigateTo({
                        url: "/pages/authAvatar"
                    });
                }, {
                    confirmText: "好的"
                }), !1);
            }
        }, {
            key: "processScan",
            value: function() {
                var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "", a = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                if (this.scanCodeJump = !0, this.$apply(), t = t.trim(), console.error("strstrstrstr", t), 
                clearTimeout(this.processScanHandler), o.default.$instance.globalData.isLogining) this.processScanHandler = setTimeout(function() {
                    e.processScan(t, a);
                }, 500); else if (o.default.$instance.globalData.token) {
                    if (this.checkAndRecord(t), this.funNeedShow = o.default.$instance.checkNeedShow(), 
                    this.checkFhdCode(t)) return void (this.checkIfAuthed() && this.processFhdCode(t));
                    if (!this.funNeedShow) return void d.default.alert("无法识别扫描内容");
                    if (this.checkJSLM(t)) return void (this.checkIfAuthed() && this.promoteUser(t.replace(g.ScanTag.JSLM, "")));
                    if (this.checkShareWlb(t)) return void (this.checkIfAuthed() && this.processShareWlb(t));
                    if (x.default.check(t)) return void this.showChooseCardOpt(t);
                    if (this.checkApp(t)) return void this.createPackageFromApp(t);
                    if (this.checkScanPrint(t)) return void (this.checkIfAuthed() && this.processScanPrint(t));
                    if (this.checkOutSid(t)) return void this.processOutSid(t);
                    if (this.checkAddPrinter(t)) return void this.processAddPrinter(t);
                    if (this.checkLDUrl(t)) return void this.processLdUrl(t);
                    if (this.checkLDCodeUrl(t)) return void this.processLdCodeUrl(t);
                    if (this.checkToLd(t)) return void this.processLd(t);
                    if (this.checkChangeType(t)) return void this.changeUserType(t);
                    if (this.checkAddToCourier(t)) return void this.processAddToCourier(t);
                    if (this.checkToAddPrintCode(t)) return this.saveRecommend(t.replace(g.ScanTag.ADDPRINTCODE, "")), 
                    void o.default.navigateTo({
                        url: "./printCode/createCode?isDirect=true"
                    });
                    if (this.checkLogistics(t)) return this.wayBillNumber = t.replace(g.ScanTag.LOGISTICS, ""), 
                    this.noNeedGetAddress = !0, this.$apply(), void this.toWayBill();
                    if (this.checkToShopingMall(t)) return void this.processToShopingMall(t);
                    if (this.checkToTest(t)) return void this.processTest(t);
                    if (this.checkToPage(t)) return void this.processPage(t);
                    if (this.checkACCashBack(t)) return void this.processCashBack(t);
                    if (this.checkScanSearchAddPrinter(t)) {
                        var n = t.replace(g.ScanTag.SEARCHADDPRINTER, "");
                        return n.indexOf("?") > -1 && (n = n.split("?")[0]), this.saveRecommend(n), void this.processScanSearchAddPrinter(t);
                    }
                    return this.checkFHYQuick(t) ? void this.jpToFhy(t) : this.checkReferrer(t) ? void this.saveRecommend(t.replace(g.ScanTag.RECOMMEND, ""), !0) : this.checkBindCode(t) ? void (this.checkIfAuthed() && this.processBindCustom(t)) : this.checkAcrylicCode(t) ? void (this.checkIfAuthed() && this.processAcrylicCode(t)) : this.checkBindSendCode(t) ? void (this.checkIfAuthed() && this.processBindSendCode(t)) : this.checkBindCodeQT(t) ? void (this.checkIfAuthed() && (a && o.default.$instance.globalData.openMini ? (this.thirdAuthTitle = "风火递Q", 
                    this.thirdAuthAppid = "wxb2307128931903fa", this.thirdAuthPath = "pages/index?q=" + t, 
                    this.toMiniModal = !0) : this.processBindCustom(t))) : this.checkQCode(t) ? void this.processQcode(t) : this.checkGroupCode(t) ? void (this.checkIfAuthed() && this.processJoinGroup(t)) : this.checkActivityCode(t) ? void this.processActivity(t) : this.checkCFG(t) ? void this.processCFG(t) : this.checkShareCFG(t) ? void this.processShareCFG(t) : this.checkPDDCashBack(t) ? void this.processPDDCashBack(t) : this.checkShareCdkey(t) ? void this.processShareCdkey(t) : this.checkShareTemplate(t) ? void this.processShareTemplate(t) : void d.default.confirm("无法识别扫描内容", function(e) {
                        e && o.default.navigateTo({
                            url: "./others/aboutScan"
                        });
                    }, {
                        confirmText: "查看介绍"
                    });
                }
            }
        }, {
            key: "createPackageFromApp",
            value: function(e) {
                console.error("createPackageFromApp", e), e = e.replace(g.ScanTag.APPCREATEPACKAGE, ""), 
                e = decodeURIComponent(e), console.error("createPackageFromApp decodeURIComponent", e);
                var t = {}, a = e.split("&");
                console.error("createPackageFromApp temp", a), a.forEach(function(e) {
                    var a = e.split("=");
                    console.error("createPackageFromApp ob", a), t[a[0]] = a[1];
                }), console.error("createPackageFromApp tempObj", t), this.transAddressTemp = {
                    name: t.name || "",
                    mobile: t.mobile || "",
                    phone: t.phone || "",
                    province: t.province || "",
                    city: t.city || "",
                    area: t.area || "",
                    town: t.town || "",
                    zip: t.zip || "",
                    other: t.other || ""
                }, this.toReCreate();
            }
        }, {
            key: "processCFG",
            value: function(e) {
                var t = e.replace(g.ScanTag.CFG, "").split("/"), a = t[0], n = t[1], r = ".." + o.default.$instance.globalData.printerCfg[a] + "?reg=" + n + "&brand=" + a;
                this.blueSearchreg(n, r);
            }
        }, {
            key: "processShareCFG",
            value: function(e) {
                var t = e.replace(g.ScanTag.SHARECFG, "");
                wx.navigateTo({
                    url: "/printSetting/zkSetting/index?params=" + t
                });
            }
        }, {
            key: "processPDDCashBack",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    var a, n, r;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return a = t.replace(decodeURIComponent(g.ScanTag.PDDCASHBACK), ""), e.next = 3, 
                            (0, c.default)("/activityV2/getHpCashBackLogList.do", {
                                pageSize: 1
                            });

                          case 3:
                            n = e.sent, r = n.data.total, wx.navigateTo({
                                url: "/subPackages/pdd/" + (r ? "cashback_logs" : "cashback_comment") + "/index?bindFhdCode=" + a
                            });

                          case 6:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "processShareCdkey",
            value: function(e) {
                var t = e.replace(g.ScanTag.SHARECDK, ""), a = t.split("/")[0], n = t.split("/")[1];
                wx.navigateTo({
                    url: "/sub-ActivityProgram/pages/prewarm/pay/index?uc=" + a + "&type=" + n
                });
            }
        }, {
            key: "processShareTemplate",
            value: function(e) {
                var t = e.split("?")[1];
                wx.navigateTo({
                    url: "/sub-freightCharge/pages/templateList?" + t
                });
            }
        }, {
            key: "selectDevice",
            value: function(e, t) {
                o.default.navigateTo({
                    url: e + "&device=" + encodeURIComponent(JSON.stringify(t))
                });
            }
        }, {
            key: "blueSearchreg",
            value: function(e, a) {
                var n = this, r = [ "^" + e ];
                !function e() {
                    d.default.showLoading("搜索打印机", {
                        mask: !0
                    }), o.default.$instance.globalData.blueManager.queryPrintersBySearch(function() {
                        var r = t(regeneratorRuntime.mark(function t(r, i, o) {
                            var s, u, c, l, h, p, f, g;
                            return regeneratorRuntime.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                  case 0:
                                    if (!r) {
                                        t.next = 36;
                                        break;
                                    }
                                    if (d.default.hideLoading(), !o) {
                                        t.next = 6;
                                        break;
                                    }
                                    d.default.confirm(o, function(t) {
                                        t && e();
                                    }, {
                                        confirmText: "重新搜索"
                                    }), t.next = 36;
                                    break;

                                  case 6:
                                    if (i && 0 != i.length) {
                                        t.next = 10;
                                        break;
                                    }
                                    d.default.confirm("未搜索到打印机，重新搜索", function(t) {
                                        t && e();
                                    }, {
                                        confirmText: "重新搜索",
                                        cancelText: "取消"
                                    }), t.next = 36;
                                    break;

                                  case 10:
                                    if (!(i.length > 1)) {
                                        t.next = 34;
                                        break;
                                    }
                                    for (s = [], u = !0, c = !1, l = void 0, t.prev = 15, h = i[Symbol.iterator](); !(u = (p = h.next()).done); u = !0) f = p.value, 
                                    s.push(f.name);
                                    t.next = 23;
                                    break;

                                  case 19:
                                    t.prev = 19, t.t0 = t.catch(15), c = !0, l = t.t0;

                                  case 23:
                                    t.prev = 23, t.prev = 24, !u && h.return && h.return();

                                  case 26:
                                    if (t.prev = 26, !c) {
                                        t.next = 29;
                                        break;
                                    }
                                    throw l;

                                  case 29:
                                    return t.finish(26);

                                  case 30:
                                    return t.finish(23);

                                  case 31:
                                    D.default.showActionSheet(s, i, function(e, t, r, i) {
                                        e && n.selectDevice(a, i);
                                    }), t.next = 36;
                                    break;

                                  case 34:
                                    g = i[0], n.selectDevice(a, g);

                                  case 36:
                                  case "end":
                                    return t.stop();
                                }
                            }, t, n, [ [ 15, 19, 23, 31 ], [ 24, , 26, 30 ] ]);
                        }));
                        return function(e, t, a) {
                            return r.apply(this, arguments);
                        };
                    }(), {
                        searchDeviceNameRegArr: r,
                        timeout: 5e3
                    });
                }();
            }
        }, {
            key: "checkCFG",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.CFG));
            }
        }, {
            key: "checkShareCFG",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.SHARECFG));
            }
        }, {
            key: "checkPDDCashBack",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.PDDCASHBACK));
            }
        }, {
            key: "checkFhdCode",
            value: function(e) {
                return !!(/^[0-9a-zA-Z]{7,8}$/.test(e) || e.startWith(g.ScanTag.FHDCODE) || e.startWith(g.ScanTag.QSENDERCODE));
            }
        }, {
            key: "checkShareCdkey",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.SHARECDK));
            }
        }, {
            key: "checkShareTemplate",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.SHARETEMPLATE));
            }
        }, {
            key: "processFhdCode",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t, a = this, n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (clearTimeout(this.processFhdCodeHandler), !o.default.$instance.globalData.isLogining) {
                                e.next = 4;
                                break;
                            }
                            return this.processFhdCodeHandler = setTimeout(function() {
                                a.processFhdCode(n);
                            }, 500), e.abrupt("return");

                          case 4:
                            t = (t = n.replace(g.ScanTag.FHDCODE, "")).replace(g.ScanTag.QSENDERCODE, ""), d.default.showLoading("查询中"), 
                            d.default.hideLoading(), o.default.navigateTo({
                                url: "../printCode/printCode/index?id=" + t
                            });

                          case 9:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "checkOutSid",
            value: function(e) {
                return !!/^[0-9a-zA-Z]{9,}$/.test(e);
            }
        }, {
            key: "checkScanPrint",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.PRINTCODE));
            }
        }, {
            key: "checkApp",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.APPCREATEPACKAGE));
            }
        }, {
            key: "checkAddPrinter",
            value: function(e) {
                return o.default.$instance.globalData.deviceManager.checkAddPrinter(e);
            }
        }, {
            key: "changeUserType",
            value: function(e) {
                var t = e.replace(g.ScanTag.CHANGETYPE, "");
                o.default.$instance.globalData.userTypeManager.setUserType(t, !1), this.$apply();
            }
        }, {
            key: "checkChangeType",
            value: function(e) {
                return e && e.startWith(g.ScanTag.CHANGETYPE);
            }
        }, {
            key: "checkAddToCourier",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.COURIER));
            }
        }, {
            key: "checkToAddPrintCode",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.ADDPRINTCODE));
            }
        }, {
            key: "checkToShopingMall",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.MALL));
            }
        }, {
            key: "checkLogistics",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.LOGISTICS));
            }
        }, {
            key: "checkToTest",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.TEST));
            }
        }, {
            key: "checkLDUrl",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.LDUrl));
            }
        }, {
            key: "checkLDCodeUrl",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.LDCodeUrl));
            }
        }, {
            key: "checkToLd",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.LD));
            }
        }, {
            key: "checkToPage",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.PAGE));
            }
        }, {
            key: "checkACCashBack",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.ACCASHBACK));
            }
        }, {
            key: "checkScanSearchAddPrinter",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.SEARCHADDPRINTER));
            }
        }, {
            key: "jpToFhy",
            value: function(e) {
                var t = e.replace(g.ScanTag.FHYQUICKPAY, "");
                console.error(t);
                var a = this.proUrl(t);
                console.log("valMapvalMapvalMap", a);
                var n = "";
                for (var r in a) a.hasOwnProperty(r) && (n += r + "=" + encodeURIComponent(a[r]) + "&");
                console.log("resParam", n), wx.navigateTo({
                    url: "/subPackages/order_confirm/index?" + n
                });
            }
        }, {
            key: "proUrl",
            value: function(e) {
                var t = {};
                if (!e || -1 == e.indexOf("?")) return t;
                for (var a = e.substring(e.indexOf("?") + 1, e.length).split("&"), n = 0; n < a.length; n++) {
                    var r = a[n];
                    r && (t[r.split("=")[0]] = r.substring(r.indexOf("=") + 1));
                }
                return t;
            }
        }, {
            key: "checkFHYQuick",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.FHYQUICKPAY));
            }
        }, {
            key: "checkReferrer",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.RECOMMEND));
            }
        }, {
            key: "checkBindSendCode",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.BINDSENDCODE));
            }
        }, {
            key: "checkBindCode",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.BINDCODE));
            }
        }, {
            key: "checkAcrylicCode",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.ACRYLIC));
            }
        }, {
            key: "checkBindCodeQT",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.BINDCODEQT));
            }
        }, {
            key: "checkQCode",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.QVERSION));
            }
        }, {
            key: "checkGroupCode",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.GROUPCODE));
            }
        }, {
            key: "checkActivityCode",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.ACTIVITY));
            }
        }, {
            key: "processToShopingMall",
            value: function(e) {
                console.warn("processToShopingMall", e);
                var t = "pages/index?goto=mall&itemId=100000", a = e.replace(g.ScanTag.MALL, "").replace("?", "");
                if (e.indexOf("?") > -1) {
                    a = "";
                    var n = e.parseQueryString();
                    for (var r in n) "trace" != r && (a += r + "=" + n[r] + "&");
                    a && (a = a.substring(0, a.length - 1));
                }
                a && (t = t + (-1 == t.indexOf("?") ? "?" : "&") + a), this.toMiniModal = !0, this.thirdAuthAppid = "wx77dec7b930544409", 
                this.thirdAuthPath = t, this.thirdAuthTitle = "风火递小店", this.thirdAuthData = {
                    goto: "mall",
                    itemId: "10000"
                }, this.$apply();
            }
        }, {
            key: "processTest",
            value: function(e) {
                var t = e.replace(g.ScanTag.TEST, "");
                o.default.$instance.globalData.isTestUser && o.default.navigateTo({
                    url: t
                });
            }
        }, {
            key: "processLdCodeUrl",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    var a, n, r;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.prev = 0, a = t.slice(t.indexOf("?") + 1, t.length), n = a.split("&"), 
                            r = {}, n.map(function(e) {
                                var t = e.split("=");
                                r[t[0]] = t[1];
                            }), wx.setStorageSync("LDData", r), s.default.setSync("isSelfHelpPrint", !0), e.next = 9, 
                            this.getPackageListTotal();

                          case 9:
                            e.sent ? wx.reLaunch({
                                url: "/pages/packageList?thirdPartyPrint=LD"
                            }) : wx.navigateTo({
                                url: "./packageCreat?printCode=LD&isSelfHelpPrint=true&noPackage=true"
                            }), e.next = 17;
                            break;

                          case 13:
                            e.prev = 13, e.t0 = e.catch(0), wx.showModal({
                                content: "二维码数据解析错误"
                            }), console.error(e.t0);

                          case 17:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 0, 13 ] ]);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "processLdUrl",
            value: function(e) {
                var t = e.split("/"), a = "";
                t && t.length && (a = t[t.length - 1], this.LDPrinterId = a, wx.setStorageSync("LDPrinterId", this.LDPrinterId), 
                this.$apply()), s.default.setSync("isSelfHelpPrint", !0), this.LDCheckPhone();
            }
        }, {
            key: "processLd",
            value: function(e) {
                if (e.replace(g.ScanTag.LD, "").replace("?", ""), e.indexOf("?") > -1) {
                    var t = e.parseQueryString();
                    this.LDPrinterId = t.uid, wx.setStorageSync("LDPrinterId", this.LDPrinterId), this.$apply();
                }
                s.default.setSync("isSelfHelpPrint", !0), this.LDCheckPhone();
            }
        }, {
            key: "LDCheckPhone",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var a, n = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return this.isLDNoCheck = !0, e.next = 3, o.default.$instance.waitConfig();

                          case 3:
                            if ("sale" === this.userInfo.userType || "deliver" === this.userInfo.userType) {
                                e.next = 11;
                                break;
                            }
                            return e.next = 6, this.getUserConfig().then(function(e) {
                                return e.data;
                            });

                          case 6:
                            if ("301" != e.sent.value) {
                                e.next = 10;
                                break;
                            }
                            return wx.redirectTo({
                                url: "../sub-NewUserIdentity/pages/index/index"
                            }), e.abrupt("return");

                          case 10:
                            try {
                                o.default.$instance.globalData.userType = "sale", o.default.$instance.globalData.userTypeManager.setUserType("sale", !1);
                            } catch (e) {
                                console.error(e);
                            }

                          case 11:
                            (a = o.default.$instance.globalData.userInfo.phoneNumber || !1) ? (0, c.default)("/platform/cainiao/getCloudPrinterList.do", {
                                mobile: a
                            }).then(function() {
                                var e = t(regeneratorRuntime.mark(function e(t) {
                                    return regeneratorRuntime.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            if (console.log(t), !(t.data && t.data.length > 0)) {
                                                e.next = 9;
                                                break;
                                            }
                                            return n.saveLDPrinter(), e.next = 5, n.getPackageListTotal();

                                          case 5:
                                            e.sent ? wx.reLaunch({
                                                url: "/pages/packageList?thirdPartyPrint=LD"
                                            }) : wx.navigateTo({
                                                url: "./packageCreat?printCode=LD&isSelfHelpPrint=true&noPackage=true"
                                            }), e.next = 10;
                                            break;

                                          case 9:
                                            wx.showModal({
                                                title: "提示",
                                                content: "您无权扫该码打单，请用机器打印二维码或让机主在支付宝来单‘我的’‘打印机管理’使用权限中添加您微信手机号长期授权",
                                                showCancel: !1
                                            });

                                          case 10:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e, n);
                                }));
                                return function(t) {
                                    return e.apply(this, arguments);
                                };
                            }()).catch(function(e) {
                                wx.showModal({
                                    title: "提示",
                                    content: "您无权扫该码打单，请用机器打印二维码或让机主在支付宝来单‘我的’‘打印机管理’使用权限中添加您微信手机号长期授权",
                                    showCancel: !1
                                }), console.error(e);
                            }) : wx.showModal({
                                title: "提示",
                                content: "请先授权手机号，在使用该打印机",
                                success: function(e) {
                                    e.confirm && wx.navigateTo({
                                        url: "/sub-staff/pages/profile/setPhone?EventName=LDGetPhone"
                                    });
                                }
                            });

                          case 13:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "saveLDPrinter",
            value: function() {
                (0, c.default)("/printer/savePrinter.do", {
                    deviceName: "来单打印机",
                    deviceType: 2
                });
            }
        }, {
            key: "promoteUser",
            value: function(e) {
                (0, c.default)("/user/promoteUser.do", {
                    code: e
                }).then(function(e) {
                    d.default.alert("绑定成功");
                }).catch(function(e) {
                    var t = "失败";
                    203 == e.scode && (t = "您已绑定，请勿重复绑定"), d.default.alert("绑定失败：" + t);
                });
            }
        }, {
            key: "tempSetUserType",
            value: function(e) {
                console.error("tempSetUserType", e), 8 == parseInt(e) && (S.default.uba(null, null, {
                    fid: "fromfhyOpenAccount",
                    params: o.default.$instance.globalData.userInfo.userId
                }), o.default.$instance.globalData.canUseCollectMoney = !0, o.default.$instance.globalData.cashGateway = 3, 
                (0, c.default)("/user/setUserConfig.do", {
                    type: 9,
                    status: 202
                }).then(function(e) {
                    s.default.removeSync("setting.getUserConfig");
                }).catch(function(e) {
                    console.error(e);
                }));
            }
        }, {
            key: "processCashBack",
            value: function(e) {
                console.log("str", e);
                var t = e.replace(g.ScanTag.ACCASHBACK, "").split("&"), a = t[0], n = t[1], r = a.split("="), i = n.split("="), o = r[1], s = i[1];
                wx.navigateTo({
                    url: "../sub-ActivityProgram/pages/ApplyActivity/ApplyActivity?inputFxCode=" + o + "&orderId=" + s
                });
            }
        }, {
            key: "processPage",
            value: function(e) {
                var t = e.replace(g.ScanTag.PAGE, "").split("?");
                console.error("pathArr", t, e), this.tempSetUserType(t[0]);
                var a = o.default.$instance.globalData.redirectUrls[t[0]];
                if (a) {
                    var n = a.split("@"), r = n[0];
                    t.length > 1 && (r += r.indexOf("?") > -1 ? "&" + t[1] : "?" + t[1]), "2" == r.parseQueryString().jumpType ? o.default.switchTab({
                        url: r.split("?")[0]
                    }) : n.length > 1 && n[1] ? (this.toMiniModal = !0, this.thirdAuthAppid = n[1], 
                    this.thirdAuthPath = r, this.thirdAuthTitle = n[2] || "其他", this.thirdAuthData = {
                        goto: "mall",
                        itemId: "10000"
                    }, this.$apply()) : o.default.navigateTo({
                        url: r
                    });
                }
            }
        }, {
            key: "processQcode",
            value: function(e) {
                this.toMiniModal = !0, this.thirdAuthTitle = "风火递Q", this.thirdAuthAppid = "wxb2307128931903fa", 
                this.thirdAuthPath = "pages/index?q=" + e, this.thirdAuthEnvVersion = "trial", this.thirdAuthData = {}, 
                this.$apply();
            }
        }, {
            key: "processBindCustom",
            value: function(e) {
                var t = e.replace(g.ScanTag.BINDCODE, "");
                t = t.replace(g.ScanTag.BINDCODEQT, "");
                var a = k.default.decode(t).split(",");
                this.getUserShareCheckStatus(a[0]);
            }
        }, {
            key: "processJoinGroup",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            wx.navigateTo({
                                url: "/subSetting/pages/printGroup/printGroup?str=" + t
                            });

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "processActivity",
            value: function(e) {
                var t = e.parseQueryString();
                if (t && t.goto && "activity20180103" == t.goto && "true" == o.default.$instance.globalData.redPackageFlag) {
                    var a = "../activities/activities/activity20180103?", n = t;
                    for (var r in n) a += "&" + r + "=" + n[r];
                    o.default.navigateTo({
                        url: a
                    });
                } else t && t.goto && t.goto;
            }
        }, {
            key: "getUserInfoList",
            value: function(e) {
                var a = this;
                return new Promise(function() {
                    var n = t(regeneratorRuntime.mark(function t(n, r) {
                        var i;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                (i = {}).userIds = e, (0, c.default)("/user/getUserInfoList.do", i).then(function(e) {
                                    n(e.data);
                                }).catch(function(e) {
                                    r(e);
                                });

                              case 3:
                              case "end":
                                return t.stop();
                            }
                        }, t, a);
                    }));
                    return function(e, t) {
                        return n.apply(this, arguments);
                    };
                }());
            }
        }, {
            key: "scanUserGroup",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    var a, n, r = this, i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 1, s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 1;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (e.prev = 0, t != o.default.$instance.globalData.userInfo.userId) {
                                e.next = 4;
                                break;
                            }
                            return d.default.alert("无法再加入自己的团队！"), e.abrupt("return");

                          case 4:
                            return e.next = 6, (0, c.default)("/user/scanUserGroup.do", {
                                groupUserId: t,
                                status: i,
                                shippingStatus: s
                            });

                          case 6:
                            a = e.sent, d.default.message("加入成功！"), this.group = a.data, o.default.$instance.globalData.userInfo.group = this.group, 
                            this.showJoinGroup = !1, d.default.confirm("可在首页右上角切换进入团队模式，团队模式只显示团队相关信息(包裹、收件人、寄件人、电子面单等)", function(e) {
                                r.groupModel = !1, o.default.$instance.globalData.groupModel = !1, r.$apply(), r.checkModelV2();
                            }, {}), e.next = 17;
                            break;

                          case 14:
                            e.prev = 14, e.t0 = e.catch(0), 206 == e.t0.scode ? d.default.alert("加入出错" + JSON.stringify(e.t0)) : 203 == e.t0.scode ? d.default.alert("团队状态错误") : 402 == e.t0.scode ? d.default.alert("团队不存在") : (n = "string" == typeof e.t0.data ? e.t0.data : JSON.stringify(e.t0.data), 
                            d.default.alert("加入出错！" + n));

                          case 17:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 0, 14 ] ]);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "getUserShareCheckStatus",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    var a, n, r, i = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (e.prev = 0, t != o.default.$instance.globalData.userInfo.userId) {
                                e.next = 4;
                                break;
                            }
                            return d.default.alert("无法与自己绑定！"), e.abrupt("return");

                          case 4:
                            return e.next = 6, (0, c.default)("/user/getUserShareCheckStatus.do", {
                                shareUserId: t
                            });

                          case 6:
                            if (!(a = e.sent).data || "OPEN" != a.data) {
                                e.next = 15;
                                break;
                            }
                            return e.next = 10, this.getUserInfoList([ t ]);

                          case 10:
                            n = e.sent, r = n[t], d.default.confirm('请求和"' + r.userNick + '"绑定为打单伙伴 \r\n绑定后，可以给对方提交包裹，请对方帮忙打印', function(e) {
                                e && i.scanUserShare(t);
                            }), e.next = 16;
                            break;

                          case 15:
                            this.scanUserShare(t);

                          case 16:
                            e.next = 21;
                            break;

                          case 18:
                            e.prev = 18, e.t0 = e.catch(0), 206 == e.t0.scode ? d.default.alert("请求已提交，请等待对方确认！") : 437 == e.t0.scode ? d.default.alert("团队成员之间无法操作扫码绑定") : d.default.alert("申请出错！");

                          case 21:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 0, 18 ] ]);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "scanUserShare",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.prev = 0, e.next = 3, (0, c.default)("/user/scanUserShare.do", {
                                shareUserId: t
                            });

                          case 3:
                            e.sent.data ? o.default.navigateTo({
                                url: "./packageCreat?bindUserId=" + t
                            }) : d.default.message("提交成功"), e.next = 11;
                            break;

                          case 7:
                            e.prev = 7, e.t0 = e.catch(0), 437 == e.t0.scode ? d.default.alert("团队成员之间无法操作扫码绑定") : 434 == e.t0.scode ? d.default.alert(e.t0.data) : d.default.alert("绑定出错！"), 
                            console.error("绑定出错！", e.t0);

                          case 11:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 0, 7 ] ]);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "showChooseCardOpt",
            value: function(e) {
                this.tempCardStr = e, this.chooseCardOpt = !0, this.$apply();
            }
        }, {
            key: "processOutSid",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t, a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (this.wayBillNumber = a, d.default.showLoading("查询中"), S.default.uba(null, null, {
                                fid: "processOutSidScan",
                                params: ""
                            }), e.prev = 3, !o.default.$instance.globalData.userInfo.deliver) {
                                e.next = 9;
                                break;
                            }
                            return this.chooseEditOrCheck = !0, d.default.hideLoading(), this.$apply(), e.abrupt("return");

                          case 9:
                            return e.next = 11, (0, c.default)("/print/scanWlbCode.do", {
                                wlbCode: this.wayBillNumber,
                                type: "2"
                            });

                          case 11:
                            t = e.sent, d.default.hideLoading(), t.data ? o.default.navigateTo({
                                url: "../address-subpackage/pages/logistics?wlbCode=" + t.data.wlbCode
                            }) : d.default.alert("没有数据！单号：" + this.wayBillNumber), e.next = 19;
                            break;

                          case 16:
                            e.prev = 16, e.t0 = e.catch(3), d.default.message("查询失败");

                          case 19:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 3, 16 ] ]);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "processScanPrint",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t, a, n, r, i, u = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return t = u.replace(g.ScanTag.PRINTCODE, ""), e.prev = 1, o.default.$instance.globalData.userType = "deliver", 
                            o.default.$instance.globalData.userTypeManager.setUserType("deliver", !1), e.next = 6, 
                            (0, c.default)("/print/getPrintCode.do", {
                                printCode: t
                            });

                          case 6:
                            if (!(a = e.sent).data) {
                                e.next = 19;
                                break;
                            }
                            if (this.userInfo.userId != a.data.userId) {
                                e.next = 13;
                                break;
                            }
                            n = "/printCode/printCodeV2/showQrPrintCode/index?jsonItem=" + JSON.stringify(a.data), 
                            wx.navigateTo({
                                url: n
                            }), e.next = 17;
                            break;

                          case 13:
                            return e.next = 15, this.getPackageListTotal();

                          case 15:
                            e.sent ? (s.default.setSync("isSelfHelpPrint", !0), o.default.reLaunch({
                                url: "/pages/packageList?printCode=" + t
                            })) : o.default.navigateTo({
                                url: "./packageCreat?printCode=" + t + "&isSelfHelpPrint=true&noPackage=true"
                            });

                          case 17:
                            e.next = 21;
                            break;

                          case 19:
                            r = "/printCode/printCodeV2/createCode/index?printCode=" + t, wx.navigateTo({
                                url: r
                            });

                          case 21:
                            e.next = 28;
                            break;

                          case 23:
                            e.prev = 23, e.t0 = e.catch(1), i = "/printCode/printCodeV2/createCode/index?printCode=" + t, 
                            wx.navigateTo({
                                url: i
                            }), console.error(e.t0);

                          case 28:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 1, 23 ] ]);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "processAddPrinter",
            value: function() {
                var e = this, a = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                o.default.$instance.globalData.deviceManager.processAddPrinter(a, function(t) {
                    t && e.loadDeviceList();
                }, {
                    drawPrintImage: function(a, n) {
                        return new Promise(function() {
                            var r = t(regeneratorRuntime.mark(function t(r, i) {
                                var o;
                                return regeneratorRuntime.wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                      case 0:
                                        return t.next = 2, e.drawImage(a, n);

                                      case 2:
                                        o = t.sent, r(o);

                                      case 4:
                                      case "end":
                                        return t.stop();
                                    }
                                }, t, e);
                            }));
                            return function(e, t) {
                                return r.apply(this, arguments);
                            };
                        }());
                    }
                });
            }
        }, {
            key: "processAcrylicCode",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    var a, n, r, i, s;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (a = t.replace(g.ScanTag.ACRYLIC, "").split(",")[0]) {
                                e.next = 4;
                                break;
                            }
                            return d.default.alert("没有获取到下单码！"), e.abrupt("return");

                          case 4:
                            return d.default.showLoading(), n = null, r = null, e.prev = 7, e.next = 10, (0, 
                            c.default)("/account/checkBindOrderCode.do", {
                                bindcode: a
                            });

                          case 10:
                            n = e.sent, r = n.data && JSON.stringify(n.data.codeInfo) || "", e.next = 26;
                            break;

                          case 14:
                            if (e.prev = 14, e.t0 = e.catch(7), d.default.hideLoading(), i = e.t0.data.bindUser, 
                            s = {
                                value: "",
                                code: 0
                            }, 206 == e.t0.scode && (s = i && i.userId ? i.userId == o.default.$instance.globalData.userInfo.userId ? o.default.$instance.globalData.groupModel && o.default.$instance.globalData.isCaptain ? {
                                value: "绑定人是自己",
                                code: 1
                            } : o.default.$instance.globalData.groupModel && !o.default.$instance.globalData.isCaptain ? {
                                value: "团队成员之间无法操作扫码绑定",
                                code: 0
                            } : {
                                value: "绑定人是自己",
                                code: 1
                            } : o.default.$instance.globalData.userInfo.group && i.userId == o.default.$instance.globalData.userInfo.group.userId ? o.default.$instance.globalData.isCaptain ? {
                                value: "是团队管理员",
                                code: 1
                            } : {
                                value: "仅团队管理员可以管理该下单码",
                                code: 0
                            } : {
                                value: "",
                                code: 0
                            } : {
                                value: "该下单码已绑定",
                                code: 0
                            }), 401 != e.t0.scode) {
                                e.next = 23;
                                break;
                            }
                            return d.default.alert("该下单码不存在！(FAKE) ：" + a), e.abrupt("return");

                          case 23:
                            return r = e.t0.data && JSON.stringify(e.t0.data.codeInfo) || "", s.code ? o.default.navigateTo({
                                url: "/subPackages/acrylic/acrylicManager?orderCode=" + encodeURIComponent(a) + "&codeInfo=" + encodeURIComponent(r) + "&bindUser=" + encodeURIComponent(i)
                            }) : s.value ? d.default.alert(s.value) : this.getUserShareCheckStatus(i.userId), 
                            e.abrupt("return");

                          case 26:
                            return d.default.hideLoading(), o.default.navigateTo({
                                url: "/subPackages/acrylic/bindAcrylicSendCode?orderCode=" + encodeURIComponent(a) + "&codeInfo=" + encodeURIComponent(r)
                            }), e.abrupt("return", !0);

                          case 29:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 7, 14 ] ]);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "processBindSendCode",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    var a, n, r, i, s;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (a = t.replace(g.ScanTag.BINDSENDCODE, "").split(",")[0]) {
                                e.next = 4;
                                break;
                            }
                            return d.default.alert("没有获取到 寄件码"), e.abrupt("return");

                          case 4:
                            return d.default.showLoading(), n = void 0, e.prev = 6, e.next = 9, (0, c.default)("/account/checkBindcode.do", {
                                bindcode: a
                            });

                          case 9:
                            n = e.sent, e.next = 23;
                            break;

                          case 12:
                            if (e.prev = 12, e.t0 = e.catch(6), d.default.hideLoading(), r = e.t0.data.bindUser, 
                            i = {
                                value: "该寄件码错误",
                                code: 0
                            }, 206 == e.t0.scode && (i = r && r.userId ? r.userId != o.default.$instance.globalData.userInfo.userId ? {
                                value: '该批次寄件码已被"' + r.userNick + '"绑定',
                                code: 0
                            } : {
                                value: "您已绑定该批次寄件码\r\n他人可直接扫寄件码给您下单",
                                code: 1
                            } : {
                                value: "该寄件码已绑定",
                                code: 0
                            }), i.code) {
                                e.next = 21;
                                break;
                            }
                            return d.default.alert(i.value), e.abrupt("return");

                          case 21:
                            return o.default.navigateTo({
                                url: "/subPackages/sendCode/sendCodeManager?bindcode=" + encodeURIComponent(a)
                            }), e.abrupt("return");

                          case 23:
                            return s = function() {
                                if (!n.data) return "";
                                try {
                                    if (n.data.codeInfo && n.data.codeInfo.batchNo) return n.data.codeInfo.batchNo;
                                } catch (e) {
                                    return "";
                                }
                                return "";
                            }(), d.default.hideLoading(), o.default.navigateTo({
                                url: "/subPackages/sendCode/bindSendCode?bindcode=" + encodeURIComponent(a) + "&batchNo=" + s
                            }), e.abrupt("return", !0);

                          case 27:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 6, 12 ] ]);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "parseCard",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t, a) {
                    var n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return d.default.showLoading("正在解析"), this.chooseCardOpt = !1, this.$apply(), e.prev = 3, 
                            e.next = 6, x.default.parse(t);

                          case 6:
                            if (n = e.sent, d.default.hideLoading(), n.phoneList = n.phoneList || [], n.addressList = n.addressList || [], 
                            !(n.phoneList && n.phoneList.length > 1 || n.addressList && n.addressList.length > 1)) {
                                e.next = 14;
                                break;
                            }
                            return d.default.hideLoading(), this.showChooseCard(n, a), e.abrupt("return");

                          case 14:
                            this.goToWithCard(n, a), e.next = 21;
                            break;

                          case 17:
                            e.prev = 17, e.t0 = e.catch(3), console.error(e.t0), d.default.message("解析错误");

                          case 21:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 3, 17 ] ]);
                }));
                return function(t, a) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "checkJSLM",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.JSLM));
            }
        }, {
            key: "checkShareWlb",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.SHAREWLB));
            }
        }, {
            key: "checkIsCN",
            value: function(e) {
                return !(!e || !e.startWith(g.ScanTag.FROMWEBCN));
            }
        }, {
            key: "showChooseCard",
            value: function(e, t) {
                if (this.goToWithCardUrl = t, e.phoneList && e.phoneList.length > 0) {
                    e.phoneSelectList = [];
                    for (var a = 0; a < e.phoneList.length; a++) e.phoneSelectList[a] = !1;
                    e.phoneSelectList[0] = !0;
                }
                if (e.addressList && e.addressList.length > 0) {
                    e.addressSelectList = [];
                    for (var n = 0; n < e.addressList.length; n++) e.addressSelectList[n] = !1;
                    e.addressSelectList[0] = !0;
                }
                this.tempCard = e, this.chooseCard = !0, this.$apply();
            }
        }, {
            key: "goToWithCard",
            value: function(e, t) {
                o.default.$instance.globalData.tempCard = e, wx.setClipboardData({
                    data: e
                }), o.default.navigateTo({
                    url: t
                });
            }
        }, {
            key: "toWayBill",
            value: function() {
                var e = this;
                (0, c.default)("/print/scanWlbCode.do", {
                    wlbCode: this.wayBillNumber,
                    type: "2"
                }).then(function(t) {
                    d.default.hideLoading(), t.data ? o.default.navigateTo({
                        url: "../address-subpackage/pages/logistics?wlbCode=" + t.data.wlbCode
                    }) : d.default.alert("没有数据！单号：" + e.wayBillNumber);
                });
            }
        }, {
            key: "shareWlb",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (this.shareWlbInfoStr = t, o.default.$instance.globalData.userInfo.nickName) {
                                e.next = 31;
                                break;
                            }
                            return e.prev = 2, e.next = 5, o.default.getSetting();

                          case 5:
                            if (0 != e.sent.authSetting["scope.userInfo"]) {
                                e.next = 10;
                                break;
                            }
                            return this.shareWlbModalShow = !0, this.$apply(), e.abrupt("return");

                          case 10:
                            return e.prev = 10, e.next = 13, (0, W.setUserInfo)();

                          case 13:
                            this.updateShareWlb(), e.next = 23;
                            break;

                          case 16:
                            if (e.prev = 16, e.t0 = e.catch(10), console.error("shareWlb", e.t0), "getUserInfo:fail auth deny" != e.t0.errMsg) {
                                e.next = 21;
                                break;
                            }
                            return e.abrupt("return");

                          case 21:
                            return d.default.alert("获取用户信息失败，请稍后再试！"), e.abrupt("return");

                          case 23:
                            e.next = 29;
                            break;

                          case 25:
                            e.prev = 25, e.t1 = e.catch(2), console.error("shareWlb", e.t1), d.default.alert("获取授权信息失败，请稍后再试！");

                          case 29:
                            e.next = 32;
                            break;

                          case 31:
                            this.updateShareWlb();

                          case 32:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 2, 25 ], [ 10, 16 ] ]);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "processShareWlb",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (this.shareWlbInfoStr = t.replace(g.ScanTag.SHAREWLB, ""), o.default.$instance.globalData.userInfo.nickName) {
                                e.next = 31;
                                break;
                            }
                            return e.prev = 2, e.next = 5, o.default.getSetting();

                          case 5:
                            if (0 != e.sent.authSetting["scope.userInfo"]) {
                                e.next = 10;
                                break;
                            }
                            return this.shareWlbModalShow = !0, this.$apply(), e.abrupt("return");

                          case 10:
                            return e.prev = 10, e.next = 13, (0, W.setUserInfo)();

                          case 13:
                            this.updateShareWlb(), e.next = 23;
                            break;

                          case 16:
                            if (e.prev = 16, e.t0 = e.catch(10), console.error("shareWlb", e.t0), "getUserInfo:fail auth deny" != e.t0.errMsg) {
                                e.next = 21;
                                break;
                            }
                            return e.abrupt("return");

                          case 21:
                            return d.default.alert("获取用户信息失败，请稍后再试！"), e.abrupt("return");

                          case 23:
                            e.next = 29;
                            break;

                          case 25:
                            e.prev = 25, e.t1 = e.catch(2), console.error("shareWlb", e.t1), d.default.alert("获取授权信息失败，请稍后再试！");

                          case 29:
                            e.next = 32;
                            break;

                          case 31:
                            this.updateShareWlb();

                          case 32:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 2, 25 ], [ 10, 16 ] ]);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "updateShareWlb",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    var a, n, r, i, s;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (d.default.showLoading("保存面单账号", {
                                mask: !0
                            }), t && o.default.$instance.updateUserInfo(t), a = this.shareWlbInfoStr, this.shareWlbInfoStr = null, 
                            e.prev = 4, n = k.default.decode(a), (r = n.split(",")) && !(r.length < 3)) {
                                e.next = 10;
                                break;
                            }
                            return d.default.alert("共享电子面单二维码错误！"), e.abrupt("return");

                          case 10:
                            return e.next = 12, (0, c.default)("/system/getTime.do", {});

                          case 12:
                            if (!((i = e.sent) && i.nowTime - r[2] > 300)) {
                                e.next = 16;
                                break;
                            }
                            return d.default.alert("电子面单共享二维码过期！"), e.abrupt("return");

                          case 16:
                            return (s = {}).accountId = r[0], s.shareUserId = r[1], r.length >= 4 && (s.wlbAccountType = r[3]), 
                            e.next = 22, (0, c.default)("/account/saveWaybillAccountShare.do", s);

                          case 22:
                            return d.default.message("共享成功！"), e.next = 25, o.default.$instance.globalData.printManager.getWaybillAccount(!0);

                          case 25:
                            e.next = 32;
                            break;

                          case 27:
                            return e.prev = 27, e.t0 = e.catch(4), console.error("save way bill account error", e.t0), 
                            e.t0 && 206 == e.t0.scode ? d.default.error("帐号已存在！") : 434 == e.t0.scode ? d.default.alert(e.t0.data) : 437 == e.t0.scode ? d.default.alert("团队模式下成员无法共享管理员电子面单帐号！") : 417 == e.t0.scode ? d.default.alert("无法对自己共享自己的电子面单！") : d.default.alert("保存共享电子面单错误！"), 
                            e.abrupt("return");

                          case 32:
                            o.default.navigateTo({
                                url: "/sub-staff/pages/settings/eSheet"
                            });

                          case 33:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 4, 27 ] ]);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "processAddToCourier",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    var a, n, r, i, o, s, u;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return a = t.replace(g.ScanTag.COURIER, ""), d.default.showLoading("扫描完成", {
                                mask: !0
                            }), e.prev = 2, n = k.default.decode(a), r = n.split(","), (i = {}).employeeUserId = r[0], 
                            o = r[1] || "old", s = new Date().getTime(), (u = U.default.init(o)).changeType(o), 
                            e.next = 13, u.scan(i);

                          case 13:
                            if (!(new Date().getTime() - s < 500)) {
                                e.next = 18;
                                break;
                            }
                            return e.next = 16, p.default.sleep(500);

                          case 16:
                            return e.next = 18, e.sent;

                          case 18:
                            d.default.hideLoading(), e.next = 24;
                            break;

                          case 21:
                            e.prev = 21, e.t0 = e.catch(2), e.t0 && 206 == e.t0.scode ? d.default.error("帐号已存在！") : e.t0 && 436 == e.t0.scode ? d.default.error("你已是业务员！") : 426 == e.t0.errCode ? d.default.error("你已是业务员!") : d.default.alert("添加快递员错误！" + JSON.stringify(e.t0));

                          case 24:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 2, 21 ] ]);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "addPrinter",
            value: function(e, t) {
                var a = this;
                o.default.$instance.globalData.blueManager.addPrinter(e, function(n) {
                    n ? (t && t(!0), a.saveUserSource(e.name)) : t && t(!1);
                });
            }
        }, {
            key: "saveUserSource",
            value: function(e) {
                var t = {
                    fromKey: 101124,
                    scene: 9999
                };
                o.default.$instance.globalData && o.default.$instance.globalData.launchInfo ? (o.default.$instance.globalData.launchInfo.searchAddPrinter = e, 
                t.launchInfo = o.default.$instance.globalData.launchInfo) : t.launchInfo = {
                    searchAddPrinter: e
                }, t.launchInfo = JSON.stringify(t.launchInfo), (0, c.default)("/user/saveUserSource.do", t).then(function(e) {}).catch(function(e) {
                    console.error("saveUserSource error", e);
                });
            }
        }, {
            key: "checkAndRecord",
            value: function(e) {
                if (e && e.indexOf("?") > -1) {
                    var t = e.parseQueryString();
                    t.referrer && this.saveRecommend(t.referrer), t.trace && S.default.uba(null, null, {
                        fid: t.trace
                    });
                }
            }
        }, {
            key: "saveRecommend",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    var a = arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (!(t && t.indexOf("?") > -1)) {
                                e.next = 2;
                                break;
                            }
                            return e.abrupt("return");

                          case 2:
                            o.default.$instance.saveRecommend(t, a);

                          case 3:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "processScanSearchAddPrinter",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(a) {
                    var n, r, i, s = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return this.searchPrinter && (this.searchPrinter = !1, this.$apply()), e.prev = 1, 
                            n = [ "^QR380A-247" ], r = 5e3, e.next = 6, (0, c.default)("/system/getScanPrinterRule.do");

                          case 6:
                            (i = e.sent).data && i.data.deviceName && (n = i.data.deviceName.split(",")), i.data && i.data.timeout && (r = parseInt(i.data.timeout.trim())), 
                            function e() {
                                setTimeout(function() {
                                    d.default.showLoading("搜索打印机", {
                                        mask: !0
                                    });
                                }, 800);
                                var a = s;
                                o.default.$instance.globalData.blueManager.queryPrintersBySearch(function() {
                                    var n = t(regeneratorRuntime.mark(function n(r, i, u) {
                                        var c, l, h, p, f, g, v, y;
                                        return regeneratorRuntime.wrap(function(n) {
                                            for (;;) switch (n.prev = n.next) {
                                              case 0:
                                                if (!r) {
                                                    n.next = 35;
                                                    break;
                                                }
                                                if (!u) {
                                                    n.next = 4;
                                                    break;
                                                }
                                                return d.default.confirm(u, function(t) {
                                                    t && e();
                                                }, {
                                                    confirmText: "重新搜索"
                                                }), n.abrupt("return");

                                              case 4:
                                                if (i && 0 != i.length) {
                                                    n.next = 9;
                                                    break;
                                                }
                                                return d.default.hideLoading(), s.searchPrinter = !0, s.$apply(), n.abrupt("return");

                                              case 9:
                                                if (1 != i.length) {
                                                    n.next = 13;
                                                    break;
                                                }
                                                return c = i[0], d.default.confirm("确认添加" + c.name + "打印机吗？", function(e) {
                                                    e && s.addPrinter(i[0], function(e) {
                                                        e && (a.loadDeviceList(), d.default.confirm("添加打印机成功", function(e) {
                                                            e && o.default.$instance.globalData.printManager.printTest(s.deviceManager.getDevice(c), {
                                                                drawPrintImage: function(e, a) {
                                                                    return new Promise(function() {
                                                                        var n = t(regeneratorRuntime.mark(function t(n, r) {
                                                                            var i;
                                                                            return regeneratorRuntime.wrap(function(t) {
                                                                                for (;;) switch (t.prev = t.next) {
                                                                                  case 0:
                                                                                    return t.next = 2, s.drawImage(e, a);

                                                                                  case 2:
                                                                                    i = t.sent, n(i);

                                                                                  case 4:
                                                                                  case "end":
                                                                                    return t.stop();
                                                                                }
                                                                            }, t, s);
                                                                        }));
                                                                        return function(e, t) {
                                                                            return n.apply(this, arguments);
                                                                        };
                                                                    }());
                                                                }
                                                            });
                                                        }, {
                                                            confirmText: "测试打印",
                                                            cancelText: "关闭"
                                                        }));
                                                    });
                                                }, {
                                                    confirmText: "确认添加"
                                                }), n.abrupt("return");

                                              case 13:
                                                for (d.default.hideLoading(), l = [], h = !0, p = !1, f = void 0, n.prev = 18, g = i[Symbol.iterator](); !(h = (v = g.next()).done); h = !0) y = v.value, 
                                                l.push(y.name);
                                                n.next = 26;
                                                break;

                                              case 22:
                                                n.prev = 22, n.t0 = n.catch(18), p = !0, f = n.t0;

                                              case 26:
                                                n.prev = 26, n.prev = 27, !h && g.return && g.return();

                                              case 29:
                                                if (n.prev = 29, !p) {
                                                    n.next = 32;
                                                    break;
                                                }
                                                throw f;

                                              case 32:
                                                return n.finish(29);

                                              case 33:
                                                return n.finish(26);

                                              case 34:
                                                D.default.showActionSheet(l, i, function(e, n, r, i) {
                                                    e && s.addPrinter(i, function(e) {
                                                        e && (a.loadDeviceList(), d.default.confirm("添加打印机成功", function(e) {
                                                            e && o.default.$instance.globalData.printManager.printTest(s.deviceManager.getDevice(i), {
                                                                drawPrintImage: function(e, a) {
                                                                    return new Promise(function() {
                                                                        var n = t(regeneratorRuntime.mark(function t(n, r) {
                                                                            var i;
                                                                            return regeneratorRuntime.wrap(function(t) {
                                                                                for (;;) switch (t.prev = t.next) {
                                                                                  case 0:
                                                                                    return t.next = 2, s.drawImage(e, a);

                                                                                  case 2:
                                                                                    i = t.sent, n(i);

                                                                                  case 4:
                                                                                  case "end":
                                                                                    return t.stop();
                                                                                }
                                                                            }, t, s);
                                                                        }));
                                                                        return function(e, t) {
                                                                            return n.apply(this, arguments);
                                                                        };
                                                                    }());
                                                                }
                                                            });
                                                        }, {
                                                            confirmText: "测试打印",
                                                            cancelText: "关闭"
                                                        }));
                                                    });
                                                });

                                              case 35:
                                              case "end":
                                                return n.stop();
                                            }
                                        }, n, s, [ [ 18, 22, 26, 34 ], [ 27, , 29, 33 ] ]);
                                    }));
                                    return function(e, t, a) {
                                        return n.apply(this, arguments);
                                    };
                                }(), {
                                    searchDeviceNameRegArr: n,
                                    timeout: r
                                });
                            }(), e.next = 17;
                            break;

                          case 13:
                            e.prev = 13, e.t0 = e.catch(1), d.default.hideLoading(), d.default.error("读取配置错误！");

                          case 17:
                          case "end":
                            return e.stop();
                        }
                    }, e, this, [ [ 1, 13 ] ]);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "getWaybillAccount",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var a = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.abrupt("return", new Promise(function() {
                                var e = t(regeneratorRuntime.mark(function e(t, n) {
                                    var r;
                                    return regeneratorRuntime.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            return e.prev = 0, e.next = 3, o.default.$instance.globalData.printManager.getWaybillAccount();

                                          case 3:
                                            r = e.sent, t(r), e.next = 11;
                                            break;

                                          case 7:
                                            e.prev = 7, e.t0 = e.catch(0), console.error("this.billAccount error", e.t0), n(0);

                                          case 11:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e, a, [ [ 0, 7 ] ]);
                                }));
                                return function(t, a) {
                                    return e.apply(this, arguments);
                                };
                            }()));

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "queryHasScribe",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t) {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            y.default.emit("index/isFollow", t), this.hasScribe = t, this.$apply();

                          case 3:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "hasUserShareFrom",
            value: function() {
                var e = this;
                (0, c.default)("/user/hasUserShareFrom.do").then(function(t) {
                    t.data && !e.userInfo.phoneNumber && (d.default.alert("还未绑定手机号码，给您下单的客户无法联系您，请绑定后继续使用风火递", function(e) {
                        o.default.navigateTo({
                            url: "/sub-staff/pages/profile/profile"
                        });
                    }, {
                        confirmText: "去绑定"
                    }), e.$apply());
                });
            }
        }, {
            key: "loadDeviceList",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t, a = this, n = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (!o.default.$instance.globalData.isLogining) {
                                e.next = 3;
                                break;
                            }
                            return this.loadDeviceListHandler = setTimeout(function() {
                                a.loadDeviceList(n);
                            }, 500), e.abrupt("return");

                          case 3:
                            if (o.default.$instance.globalData.loginSuccess) {
                                e.next = 7;
                                break;
                            }
                            return this.isLoading = !1, this.$apply(), e.abrupt("return");

                          case 7:
                            return this.loginSuccess = o.default.$instance.globalData.loginSuccess, this.$apply(), 
                            this.isLoadingPrinter = !0, o.default.$instance.globalData.autoGetAddress && this.checkNeedShowIcopy(), 
                            this.checkUserType(), this.triggerIndex(), this.hasFhdUserTypeWhite(), this.funNeedShow = o.default.$instance.checkNeedShow(), 
                            this.isLoadingPrinter = !1, this.userInfo = o.default.$instance.globalData.userInfo, 
                            this.deliver = o.default.$instance.globalData.userInfo.deliver, this.expert = "expert" in o.default.$instance.globalData.userInfo ? o.default.$instance.globalData.userInfo.expert : {}, 
                            this.group = o.default.$instance.globalData.userInfo.group || null, this.getGroupApplyInfo(), 
                            this.isCaptain = o.default.$instance.globalData.isCaptain, this.group && this.group.groupId ? (this.group.userId == this.userInfo.userId && (o.default.$instance.globalData.userInfo.userRole = !0), 
                            this.checkModelV2()) : (this.changeUserRole(this.userRole.PERSONAL.value, !1, 1), 
                            wx.setNavigationBarTitle({
                                title: "风火递"
                            })), this.getVip(), t = new Date(), this.nowTime = f.default.nowTime(), this.userInfo.createTime < 1610294400 && t <= 16124544e5 && (this.isShowOpenShopActivityDialog(), 
                            this.showActivities = !0), this.$apply(), this.$invoke("followWechatModel", "init"), 
                            e.next = 31, w.default.ready(function(e) {
                                e && a.getHolidayImage(e);
                            });

                          case 31:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "checkUserType",
            value: function() {
                s.default.getSync("newTypeNotNow"), this.groupModel && !this.isCaptain || (this.userType = o.default.$instance.globalData.userType, 
                R.default.emitAll("updateUserType", this.userType), this.isLoading = !1, this.$apply());
            }
        }, {
            key: "triggerIndex",
            value: function() {
                setTimeout(function() {
                    R.default.emit("indexTabbar/onshow");
                }, 500);
            }
        }, {
            key: "changeToRole",
            value: function() {
                !0 === (arguments.length > 0 && void 0 !== arguments[0] && arguments[0]) ? (this.changeUserRole(this.userRole.TEAM.value, !1, 0), 
                o.default.$instance.globalData.groupModel = !0, this.groupModel = !0) : (this.changeUserRole(this.userRole.PERSONAL.value, !1, 1), 
                o.default.$instance.globalData.groupModel = !1, this.groupModel = !1);
            }
        }, {
            key: "checkModelV2",
            value: function() {
                var e = s.default.getSync("groupModel"), t = o.default.$instance.globalData.userInfo.userRole, a = o.default.$instance.globalData.isCaptain;
                if (o.default.$instance.globalData.userInfo.group && "OPEN" == o.default.$instance.globalData.userInfo.group.status) {
                    if (t === e) return void (!0 === t && !this.teamChanged && a && (this.changeToRole(!0), 
                    this.teamChanged = !0));
                    !0 === e ? this.changeToRole(!0) : !1 === e ? this.changeToRole(!1) : t ? this.changeToRole(!0) : this.changeToRole(!1);
                }
            }
        }, {
            key: "showFloatingWindow",
            value: function() {
                var e = wx.getStorageSync("selectedIdentityBtn"), t = wx.getStorageSync("selectedOldEdition");
                (e || t) && (console.log("用户当前不能展示活动"), this.isShowActivity = !1, this.show_identitySelection = !1, 
                this.show_redEnvelope = !1, this.showRedEnvelope = !1, this.$apply());
            }
        }, {
            key: "fun_date",
            value: function(e, t) {
                var a = new Date(t);
                return a.setDate(a.getDate() + e), a.getFullYear() + "-" + (a.getMonth() + 1) + "-" + a.getDate() + " " + a.getHours() + ":" + a.getMinutes() + ":" + a.getSeconds();
            }
        }, {
            key: "countTime",
            value: function(e) {
                var t = new Date(e), a = new Date(), n = parseInt((t - a) / 1e3);
                this.countDownDay = Math.floor(n / 86400);
                var r = n % 86400;
                this.countDownHour = Math.floor(r / 3600), r %= 3600, this.countDownMinute = Math.floor(r / 60), 
                this.countDownSecond = r % 60, this.$apply();
            }
        }, {
            key: "_showRedEnvelope",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t, a, n, r, i;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (this.userInfo = o.default.$instance.globalData.userInfo, console.log(o.default.$instance.globalData.userInfo), 
                            !(this.userInfo.createTime <= 1608479999)) {
                                e.next = 17;
                                break;
                            }
                            if (o.default.$instance.globalData.canUseBankInfo) {
                                e.next = 17;
                                break;
                            }
                            return e.next = 7, (0, _.getCountByType)({
                                type: "17"
                            }).then(function(e) {
                                return e.data;
                            });

                          case 7:
                            this.userCount = e.sent, t = new Date("2020/12/31 23:59:59").getTime(), (a = wx.getStorageSync("endDay") || null) && (a = a.replace(/-/g, "/")), 
                            a = new Date(a).getTime(), n = new Date().getTime(), r = wx.getStorageSync("userReceived1") || null, 
                            i = [ {
                                from: "2020/12/21 00:00:00",
                                to: "2020/12/31 23:59:59"
                            } ], this.userCount <= 4500 ? r ? n <= a && (this.show_redEnvelope = !0, (0, L.showActivityItem)(i, "#withdrawal_redEnvelope", this, {
                                interval: 1
                            })) : n <= t && (this.show_redEnvelope = !0, (0, L.showActivityItem)(i, "showRedEnvelope", this, {
                                interval: 1
                            })) : this.show_redEnvelope = !1, this.$apply();

                          case 17:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "isShowOpenShopActivityDialog",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var t, a, n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            t = new Date().getMonth() + 1, a = new Date().getDate(), (n = wx.getStorageSync("OpenShopActivityclickTime")).month == t ? (n.day !== a ? (this.$data.isShowActivity = !1, 
                            this.ShowOpenShopActivity = !0, wx.$Uba({
                                fid: "openShopActivity_homePageDialogCount"
                            })()) : this.ShowOpenShopActivity = !1, this.$apply()) : (this.$data.isShowActivity = !1, 
                            this.ShowOpenShopActivity = !0, wx.$Uba({
                                fid: "openShopActivity_homePageDialogCount"
                            })(), this.$apply());

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "isShowNewBusinessActivity",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var a = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.abrupt("return", new Promise(function() {
                                var e = t(regeneratorRuntime.mark(function e(t, n) {
                                    var r, i, o;
                                    return regeneratorRuntime.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            return e.prev = 0, r = new Date("2021/02/26 00:00:00").getTime() / 1e3, i = new Date("2021/05/26 00:00:00").getTime() / 1e3, 
                                            e.next = 5, (0, c.default)("/business/trade/getTradeCount.do", {
                                                startTime: r,
                                                endTime: i
                                            }, {
                                                baseUrl: "https://fhyapi.fhd001.com"
                                            });

                                          case 5:
                                            o = e.sent, t(o.data), e.next = 12;
                                            break;

                                          case 9:
                                            e.prev = 9, e.t0 = e.catch(0), console.error(e.t0);

                                          case 12:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e, a, [ [ 0, 9 ] ]);
                                }));
                                return function(t, a) {
                                    return e.apply(this, arguments);
                                };
                            }()));

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "openShopjudgeToDiffPage",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (wx.getStorageSync("ifClickFhyxButton") || null) {
                                e.next = 9;
                                break;
                            }
                            return e.next = 4, (0, c.default)("/activityV2/ifClickFhyxButton.do");

                          case 4:
                            e.sent.data ? (wx.setStorage({
                                key: "ifClickFhyxButton",
                                data: !0
                            }), this.userifClickFhyxButton = !0, this.ShowOpenShopDialogSwitch = !1) : (this.userifClickFhyxButton = !1, 
                            this.ShowOpenShopDialogSwitch = !0), this.$apply(), e.next = 11;
                            break;

                          case 9:
                            this.userifClickFhyxButton = !0, this.ShowOpenShopDialogSwitch = !1;

                          case 11:
                            this.$apply();

                          case 12:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "getPhoneNumber",
            value: function(e) {
                if (d.default.showLoading(), "getPhoneNumber:ok" == e.detail.errMsg) {
                    var t = {};
                    t.iv = e.detail.iv, t.encryptedData = e.detail.encryptedData, t.sessionKey = o.default.$instance.globalData.sessionKey, 
                    this.getUserPhoneNumber(t);
                } else d.default.hideLoading();
            }
        }, {
            key: "getUserPhoneNumber",
            value: function(e) {
                var t = this;
                (0, c.default)("/user/updatePhoneNumber.do", e).then(function(e) {
                    console.log("updatePhoneNumber", e), e.data && (o.default.$instance.globalData.userInfo.deliver = e.data.deliver, 
                    o.default.$instance.globalData.userInfo.phoneNumber = e.data.phoneNumber, t.userInfo.phoneNumber = e.data.phoneNumber), 
                    d.default.message("号码绑定成功"), t.isShowGetPhoneNumberMask = !1, t.$apply(), setTimeout(function() {
                        d.default.hideLoading();
                    }, 1e3);
                }).catch(function(e) {
                    d.default.hideLoading();
                });
            }
        }, {
            key: "getAntShopSet",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var a, n = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            return e.next = 2, this.getUserShopInfo().then(function(e) {
                                return e;
                            });

                          case 2:
                            return a = e.sent, e.abrupt("return", new Promise(function() {
                                var e = t(regeneratorRuntime.mark(function e(t, r) {
                                    var i, o;
                                    return regeneratorRuntime.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            return e.prev = 0, i = {
                                                baseUrl: "https://fhyapi.fhd001.com"
                                            }, e.next = 4, (0, c.default)("/business/shop/getAntShopSet.do", {
                                                shopId: a[0].shopId
                                            }, i);

                                          case 4:
                                            (o = e.sent).data && t(o.data), e.next = 12;
                                            break;

                                          case 8:
                                            e.prev = 8, e.t0 = e.catch(0), r(!1), console.error(e.t0);

                                          case 12:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e, n, [ [ 0, 8 ] ]);
                                }));
                                return function(t, a) {
                                    return e.apply(this, arguments);
                                };
                            }()));

                          case 4:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "getUserShopInfo",
            value: function() {
                var e = this;
                return new Promise(function() {
                    var a = t(regeneratorRuntime.mark(function t(a, n) {
                        var r, i;
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                              case 0:
                                return e.prev = 0, r = {
                                    baseUrl: "https://fhyapi.fhd001.com"
                                }, e.next = 4, (0, c.default)("/business/shop/getAntShopInfoList.do", {}, r);

                              case 4:
                                (i = e.sent).data && a(i.data), e.next = 11;
                                break;

                              case 8:
                                e.prev = 8, e.t0 = e.catch(0), console.error(e.t0);

                              case 11:
                              case "end":
                                return e.stop();
                            }
                        }, t, e, [ [ 0, 8 ] ]);
                    }));
                    return function(e, t) {
                        return a.apply(this, arguments);
                    };
                }());
            }
        }, {
            key: "onShow",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(a) {
                    var n, r, i = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            this.isClick = !1, this.loadDeviceList(), n = o.default.$instance.getClientInfo(), 
                            this.safeHeight = n && n.safeArea && n.safeArea.top, r = function() {
                                var e = t(regeneratorRuntime.mark(function e() {
                                    var t, a, n, r, s, u, c, l, d, h, p, f;
                                    return regeneratorRuntime.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                          case 0:
                                            if (i.version = o.default.$instance.globalData.Version[o.default.$instance.globalData.userType], 
                                            (t = o.default.$instance.globalData.userInfo).phoneNumber ? i.isShowGetPhoneNumberMask = !1 : i.isShowGetPhoneNumberMask = !0, 
                                            "sale" == i.userType && (a = Date.parse(new Date()) / 1e3, wx.reportEvent && wx.reportEvent("main_coupon_click", {
                                                user_id: t.userId,
                                                fenghuo_id: t.fhdCode,
                                                uesr_lvname: i.generalData.uesr_lvname,
                                                time: a,
                                                xcx_version: i.version
                                            }), S.default.uba(null, null, {
                                                fid: "main_load",
                                                params: JSON.stringify(i.generalData)
                                            }), i.$wxpage.selectComponent(".CUserInfo") && i.$wxpage.selectComponent(".CUserInfo").getShopInfo && i.$wxpage.selectComponent(".CUserInfo").getShopInfo()), 
                                            i.getUserDetailSet(), "sale" !== t.userType) {
                                                e.next = 33;
                                                break;
                                            }
                                            return n = Date.parse(new Date()) / 1e3, r = new Date().getDate(), e.next = 10, 
                                            i.userCheckAccountRightsActivity().then(function(e) {
                                                return e;
                                            });

                                          case 10:
                                            if ("0" !== e.sent.activityStatus) {
                                                e.next = 21;
                                                break;
                                            }
                                            return e.next = 14, i.queryAccountRightsActivity().then(function(e) {
                                                return e;
                                            });

                                          case 14:
                                            (s = e.sent) && ((u = s).tradeAmount = Number.parseFloat(s.tradeAmount / 100).toString().match(/^\d+(?:\.\d{0,2})?/)[0], 
                                            u.subsidies = Number.parseFloat(s.tradeAmount / 1e3).toString().match(/^\d+(?:\.\d{0,2})?/)[0], 
                                            c = new Date(), l = 1e3 * u.endTime - c.getTime(), u.endDay = Math.floor(l / 864e5), 
                                            S.default.uba(null, null, {
                                                fid: "paymentActivities_userInfo",
                                                params: JSON.stringify(u)
                                            }), i.userActivityData = s), (d = wx.getStorageSync("showPaymentActivitiesDialog") || "") ? d.day !== r && d.endDay > r && (h = d.endDay, 
                                            wx.setStorage({
                                                key: "showPaymentActivitiesDialog",
                                                data: {
                                                    endDay: h,
                                                    day: r
                                                }
                                            }), (0, F.indicators)("paymentActivities_PopCount"), i.paymentActivitiesDialogVisible = !0) : (wx.setStorage({
                                                key: "showPaymentActivitiesDialog",
                                                data: {
                                                    endDay: r + 2,
                                                    day: r
                                                }
                                            }), (0, F.indicators)("paymentActivities_PopCount"), i.paymentActivitiesDialogVisible = !0), 
                                            n <= 1626969599 && (i.paymentActivitiesFloat = !0), e.next = 23;
                                            break;

                                          case 21:
                                            i.paymentActivitiesDialogVisible = !1, i.paymentActivitiesFloat = !1;

                                          case 23:
                                            return e.next = 25, i.getAntShopSet().then(function(e) {
                                                return e;
                                            });

                                          case 25:
                                            if (p = e.sent, null, !(wx.getStorageSync("businessInformation_mask") || null)) {
                                                e.next = 32;
                                                break;
                                            }
                                            return e.abrupt("return", 0);

                                          case 32:
                                            p.length > 0 ? p.find(function(e) {
                                                return 1e3 === e.type;
                                            }) ? (console.log("以有信息，不显示"), i.isShopShowMask = !1) : i.isShopShowMask = !0 : i.isShopShowMask = !0;

                                          case 33:
                                            "sale" == i.userType && 0 == i.saleBaseFunctionalArr.length && i.setFunctionalArr(), 
                                            "deliver" == i.userType && 0 == i.deliverFunctionalArr.length && i.setFunctionalArr(), 
                                            i.screenWidth || (f = o.default.$instance.getClientInfo(), i.screenWidth = f.windowWidth), 
                                            i.$apply();

                                          case 37:
                                          case "end":
                                            return e.stop();
                                        }
                                    }, e, i);
                                }));
                                return function() {
                                    return e.apply(this, arguments);
                                };
                            }(), o.default.$instance.globalData.loginSuccess ? r() : o.default.$instance.waitConfig().then(t(regeneratorRuntime.mark(function e() {
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        r();

                                      case 1:
                                      case "end":
                                        return e.stop();
                                    }
                                }, e, i);
                            })));

                          case 6:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "onTabItemTap",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    var a = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            o.default.$instance.waitConfig().then(t(regeneratorRuntime.mark(function e() {
                                var t, n, r, i, s;
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        if (t = o.default.$instance.globalData.Version[o.default.$instance.globalData.userType], 
                                        "sale" !== (n = o.default.$instance.globalData.userInfo).userType) {
                                            e.next = 9;
                                            break;
                                        }
                                        return e.next = 5, a.getUserConfig().then(function(e) {
                                            return e;
                                        });

                                      case 5:
                                        r = e.sent, i = Date.parse(new Date()) / 1e3, s = r.data.value, wx.reportEvent && wx.reportEvent("main_click", {
                                            time: i,
                                            user_id: n.userId,
                                            fenghuo_id: n.fhdCode,
                                            uesr_lvname: s,
                                            xcx_version: t
                                        });

                                      case 9:
                                      case "end":
                                        return e.stop();
                                    }
                                }, e, a);
                            })));

                          case 1:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "onReady",
            value: function() {
                wx.canIUse("reportPerformance") && wx.reportPerformance(2002, this.pageLoadPerfermance), 
                this.loaded = !0, this.isFirstScan = 1 == s.default.getSync("isFirstScan") || "" === s.default.getSync("isFirstScan");
            }
        }, {
            key: "reSetData",
            value: function() {
                this.toMiniModal = !1, this.rePostModalShow = !1, this.shipInfoCount = 0, this.isLoadingPrinter = !1, 
                this.searchPrinter = !1, this.scanAlertModalShow = !1, this.scanInputAlertModalShow = !1, 
                this.wayBillNumber = "", this.chooseEditOrCheck = !1;
            }
        }, {
            key: "showLoginAuth",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function() {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "eventSet",
            value: function() {
                var e = this;
                y.default.on("showScanQr", function() {
                    e.showScanQr();
                }, this);
            }
        }, {
            key: "getAccount",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(t, a) {
                    var n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if ((n = t) && n.length) {
                                e.next = 3;
                                break;
                            }
                            return e.abrupt("return");

                          case 3:
                            this.subpackAccount = a.sms, this.$apply();

                          case 5:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t, a) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "processNavigate",
            value: function(e) {
                if (e && e.q) this.processScan(decodeURIComponent(e.q), !0), this.afterLoginTodo(e); else if (e && e.goto) {
                    if ("mall" == e.goto) {
                        var t = g.ScanTag.MALL;
                        e.discount && (t = t + "?discount=" + decodeURIComponent(e.discount)), e.itemId && (t = t + "?itemId=" + e.itemId), 
                        this.processScan(t);
                    } else if ("mallOrderList" == e.goto) this.toMiniModal = !0, this.thirdAuthAppid = "wx77dec7b930544409", 
                    this.thirdAuthPath = "pages/index?goto=mallOrderList", this.thirdAuthData = {
                        goto: "mallOrderList"
                    }, this.$apply(); else if ("tutorials" == e.goto) o.default.navigateTo({
                        url: "/sub-expert/pages/tutorials"
                    }); else if ("introduction" == e.goto) o.default.navigateTo({
                        url: "/sub-expert/pages/introduction?id=" + e.id + "&index=" + e.index + "&source=" + e.source + "&subTitle=" + (e.subTitle || "")
                    }); else if ("activity20180103" == e.goto) {
                        var a = g.ScanTag.ACTIVITY + "?goto=activity20180103", n = {};
                        e.recommendNickName && (n.recommendNickName = decodeURIComponent(e.recommendNickName)), 
                        e.recommendAvatarUrl && (n.recommendAvatarUrl = decodeURIComponent(e.recommendAvatarUrl)), 
                        e.recommendUserId && (n.recommendUserId = e.recommendUserId), e.togetherId && (n.togetherId = e.togetherId);
                        var r = n;
                        for (var i in r) a += "&" + i + "=" + r[i];
                        this.processScan(a);
                    } else if ("activity20180207" == e.goto) {
                        var s = g.ScanTag.ACTIVITY + "?goto=activity20180207";
                        this.processScan(s);
                    } else if ("activity20180309" == e.goto) this.afterLoginTodo(e); else if ("vipMember" == e.goto) o.default.navigateTo({
                        url: "/subPackages/activity/member"
                    }); else if ("shareAddress" == e.goto) o.default.navigateTo({
                        url: "/pages/packageCreat?shareAddress=1"
                    }); else if ("popularize" == e.goto) S.default.uba(null, null, {
                        fid: "popularize",
                        params: ""
                    }), o.default.navigateTo({
                        url: "/subPackages/activity/popularize"
                    }); else if ("purchase" == e.goto) {
                        var u = "/sub-expert/pages/purchase";
                        "index" in e && (u += "?index=" + e.index), o.default.navigateTo({
                            url: u
                        });
                    }
                } else if (e && e.redirect) {
                    var c = g.ScanTag.PAGE + e.redirect + "?_timestamp=" + Date.now();
                    for (var l in e) "redirect" != l && (c += "&" + l + "=" + e[l]);
                    this.processScan(c);
                } else this.afterLoginTodo(e);
            }
        }, {
            key: "changeTabbarStyle",
            value: function() {
                var e = s.default.getSync("miniEnv") || "release";
                wx.setTabBarStyle({
                    backgroundColor: {
                        alpha: "#FF4500",
                        beta: "#3CB371",
                        preview: "#87CEFA",
                        release: "#FFFFFF"
                    }[e]
                });
            }
        }, {
            key: "getHolidayImage",
            value: function(e) {
                e.posterBannerUrl && (this.holidayImage = e.posterBannerUrl, this.$apply());
            }
        }, {
            key: "onLoad",
            value: function() {
                var e = t(regeneratorRuntime.mark(function e(a) {
                    var n = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            this.isLoading = !0, this.userType = s.default.getSync("lastUserType") || "", R.default.emitAll("updateUserType", this.userType), 
                            w.default.init(), this.eventSet(), o.default.$instance.globalData.forceAuthPageHandle = this, 
                            this.processNavigate(a), this.isFirstCountTask = !0, s.default.getSync("clickedNewQRcode") ? this.clickedNewQRcode = !0 : this.clickedNewQRcode = !1, 
                            this.changeTabbarStyle(), s.default.setSync("visitedPayments", !0), S.default.uba(null, null, {
                                m: "p"
                            }), o.default.$instance.waitConfig().then(t(regeneratorRuntime.mark(function e() {
                                var t, r, i, s, u, c, l;
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        n.getUserDetailSet(), t = o.default.$instance.globalData.hNewPeoplePopUrl, r = o.default.$instance.globalData.hNewPeoplePop;
                                        try {
                                            o.default.$instance.globalData.hNewPeoplePopUrl ? (wx.setStorageSync("hNewPeoplePopUrl", t), 
                                            wx.setStorageSync("hNewPeoplePop", r), n.popUrl = t, n.pop = r) : wx.getStorageSync("hNewPeoplePopUrl") && (n.popUrl = wx.getStorageSync("hNewPeoplePopUrl"), 
                                            n.pop = wx.getStorageSync("hNewPeoplePop"));
                                        } catch (e) {
                                            console.log("err", e);
                                        }
                                        if (i = o.default.$instance.globalData.hPopAdOpen, s = o.default.$instance.globalData.hPopAdIndexOpen, 
                                        u = new Date().format("MM-dd"), c = o.default.$instance.globalData.userInfo.userId >= 47397310, 
                                        l = wx.getStorageSync("newPopShowMark"), c && !l && i && s && (n.newPopShow = !0, 
                                        n.popIndex = Math.round(Math.random()), n.$apply(), wx.$Uba({
                                            fid: "hShowPopIndex",
                                            params: {
                                                popIndex: n.data.popIndex
                                            }
                                        })(), wx.setStorageSync("InsertAdShowData", u), wx.setStorageSync("newPopShowMark", !0)), 
                                        n.$wxpage.selectComponent(".CUserInfo") && n.$wxpage.selectComponent(".CUserInfo").clearShare && n.$wxpage.selectComponent(".CUserInfo").clearShare(), 
                                        !a.advertisingId) {
                                            e.next = 19;
                                            break;
                                        }
                                        return e.next = 14, n.setUserType("sale");

                                      case 14:
                                        n.userType = "sale", o.default.$instance.globalData.userType = "sale", R.default.emitAll("updateUserType", n.userType), 
                                        wx.reportEvent && wx.reportEvent("moonad_moments_source", {}), n.$apply();

                                      case 19:
                                      case "end":
                                        return e.stop();
                                    }
                                }, e, n);
                            }))), R.default.on("changeCustomerStatus", function(e) {
                                n.isChangeToCustomer = "COMPLETE" === e, n.$apply();
                            }, this), R.default.on("changeUesrType", function() {
                                w.default.ready(function(e) {
                                    e && n.getHolidayImage(e);
                                });
                            }, this), R.default.on("userSelectedIdentity", t(regeneratorRuntime.mark(function e() {
                                var t;
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                      case 0:
                                        t = Date.parse(new Date()) / 1e3, wx.setStorage({
                                            key: "NoSelectedIdentityUser",
                                            data: t
                                        });

                                      case 2:
                                      case "end":
                                        return e.stop();
                                    }
                                }, e, n);
                            })), this), R.default.on("LDGetPhone", function() {
                                n.LDCheckPhone();
                            });

                          case 17:
                          case "end":
                            return e.stop();
                        }
                    }, e, this);
                }));
                return function(t) {
                    return e.apply(this, arguments);
                };
            }()
        }, {
            key: "onUnload",
            value: function() {
                y.default.remove("index/followWechatModel/show", "components/followWechatModel"), 
                R.default.remove("changeCustomerStatus", this), R.default.remove("LDGetPhone");
            }
        }, {
            key: "onShareAppMessage",
            value: function(e) {
                var t = o.default.$instance.globalData.userInfo.userId;
                return !e.target || "self" != e.target.dataset.wpyshareselfA && "self" != e.target.dataset.extend ? e.target && "selfTask" == e.target.dataset.wpyshareselfA ? {
                    title: "点击进入风火递小程序",
                    imageUrl: "https://mmbiz.qpic.cn/mmbiz_png/76nM5lBcFPKAjXwFuXAHWyv5SQNgSq7VC7SG3icEKByjJWmICG3gia5ic0zAFqBv8qo39Siabfbd9cuKNynbzOFlbg/0?wx_fmt=png",
                    path: "/pages/index?referrer=user_" + t + "&trace=user_share_clickTaskButton",
                    success: function(e) {
                        s.default.setSync("didSharedByTask", !0);
                    },
                    fail: function(e) {},
                    complete: function(e) {}
                } : e.target && "inviteFriends" == e.target.dataset.wpyshareselfa ? {
                    title: "邀更多好友使用风火递",
                    path: "/pages/index?q=http://t.fhd001.com/referrer/user_" + t,
                    imageUrl: "https://mmbiz.qpic.cn/mmbiz_png/76nM5lBcFPKAjXwFuXAHWyv5SQNgSq7VC7SG3icEKByjJWmICG3gia5ic0zAFqBv8qo39Siabfbd9cuKNynbzOFlbg/0?wx_fmt=png"
                } : "button" != e.from ? {
                    title: "点击进入风火递小程序",
                    imageUrl: "https://mmbiz.qpic.cn/mmbiz_png/76nM5lBcFPKAjXwFuXAHWyv5SQNgSq7VC7SG3icEKByjJWmICG3gia5ic0zAFqBv8qo39Siabfbd9cuKNynbzOFlbg/0?wx_fmt=png",
                    path: "/pages/index?referrer=user_" + t + "&trace=user_share_toprightShare",
                    success: function(e) {},
                    fail: function(e) {},
                    complete: function(e) {}
                } : void 0 : {
                    title: "点击进入风火递小程序",
                    imageUrl: "https://mmbiz.qpic.cn/mmbiz_png/76nM5lBcFPKAjXwFuXAHWyv5SQNgSq7VC7SG3icEKByjJWmICG3gia5ic0zAFqBv8qo39Siabfbd9cuKNynbzOFlbg/0?wx_fmt=png",
                    path: "/pages/index?referrer=user_" + t + "&trace=user_share_clickShareButton",
                    success: function(e) {},
                    fail: function(e) {},
                    complete: function(e) {}
                };
            }
        }, {
            key: "onHide",
            value: function() {
                this.loadDeviceListHandler && clearTimeout(this.loadDeviceListHandler), this.processFhdCodeHandler && clearTimeout(this.processFhdCodeHandler), 
                this.processScanHandler && clearTimeout(this.processScanHandler), this.afterLoginNavigateToHandler && clearTimeout(this.afterLoginNavigateToHandler), 
                this.afterLoginToDoHandler && clearTimeout(this.afterLoginToDoHandler), this.redPackageTimer && clearInterval(this.redPackageTimer), 
                this.reSetData();
            }
        }, {
            key: "onPageScroll",
            value: function(e) {
                var t = e.scrollTop;
                this.holidayImage && (t > 15 && !0 === this.isScrollTop ? (this.isScrollTop = !1, 
                this.$apply()) : t <= 15 && !1 === this.isScrollTop && (this.isScrollTop = !0, this.$apply()));
            }
        } ]), h;
    }(o.default.page);
    Page(require("./../npm/wepy/lib/wepy.js").default.$createPage(V, "pages/index"));
}();
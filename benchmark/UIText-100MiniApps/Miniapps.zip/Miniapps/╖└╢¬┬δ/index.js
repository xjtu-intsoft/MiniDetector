Page({
    data: {
        name: wx.getStorageSync("adress_name"),
        address: wx.getStorageSync("adress_address"),
        mobile: wx.getStorageSync("adress_mobile"),
        totype: 2
    },
    onLoad: function(e) {
        this.setData({
            totype: e.totype
        });
    },
    formSubmit: function(e) {
        var t = e.detail.value, o = t.name, a = t.address, s = t.mobile;
        return o ? s ? a ? this.isPoneAvailable(s) ? (wx.showToast({
            title: "成功",
            icon: "success",
            duration: 2e3
        }), wx.setStorageSync("adress_name", o), wx.setStorageSync("adress_address", a), 
        wx.setStorageSync("adress_mobile", s), void ("2" == this.data.totype ? console.log("e") : this.goToBay())) : (wx.showToast({
            title: "手机号码格式不正确",
            icon: "none",
            duration: 2e3
        }), !1) : (wx.showToast({
            title: "请填写您的详细地址",
            icon: "none",
            duration: 2e3
        }), !1) : (wx.showToast({
            title: "请填写您的手机号",
            icon: "none",
            duration: 2e3
        }), !1) : (wx.showToast({
            title: "请填您的姓名",
            icon: "none",
            duration: 2e3
        }), !1);
    },
    isPoneAvailable: function(e) {
        return !!/^[1][3,4,5,7,8][0-9]{9}$/.test(e);
    },
    goToBay: function() {
        wx.navigateTo({
            url: "../pay/info"
        });
    }
});
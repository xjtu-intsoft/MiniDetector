var t = t || {};

t.webpackJsonp = require("../23AC32F3160713CF45CA5AF4FFB7A505.js"), (t.webpackJsonp = t.webpackJsonp || []).push([ [ 125 ], {
    139: function(t, e, a) {
        var s = a(0), i = a.n(s), n = a(1), r = a.n(n), u = a(4), d = (a(2), a(3)), h = a(5), l = a(13), o = getApp();
        Object(u.b)({
            data: {
                name: "",
                tel: "",
                address: "",
                isIphoneX: !1,
                showLoading: !1,
                originAddress: ""
            },
            computed: {
                curLib: function() {
                    return d.a.getters.getCurrentLibrary;
                },
                disabledBtn: function() {
                    return !(this.name && this.tel && this.address);
                }
            },
            onLoad: function(t) {
                this.isIphoneX = o.globalData.isIphoneX, o.globalData.inputValue = "", this.originAddress = t.address ? JSON.parse(t.address) : "", 
                this.originAddress && (this.name = this.originAddress.name, this.tel = this.originAddress.phoneNumber, 
                this.address = this.originAddress.addr);
            },
            changeValue: function(t, e) {
                var a = e.detail;
                "name" === t ? this.name = a : "tel" === t ? this.tel = a : "address" === t && (this.address = a);
            },
            goBack: function() {
                wx.navigateBack();
            },
            addAddress: function() {
                var t = this;
                return r()(i.a.mark(function e() {
                    var a;
                    return i.a.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                          case 0:
                            if (a = void 0, !t.originAddress) {
                                e.next = 7;
                                break;
                            }
                            return e.next = 4, h.rb(t.originAddress.id, t.name, t.tel, t.address);

                          case 4:
                            a = e.sent, e.next = 10;
                            break;

                          case 7:
                            return e.next = 9, h.b(t.name, t.tel, t.address);

                          case 9:
                            a = e.sent;

                          case 10:
                            a.data ? (t.wuxToast("保存成功", "success", 1e3), setTimeout(function() {
                                wx.navigateBack();
                            }, 1e3)) : t.wuxToast(a.message, "cancel", 2e3);

                          case 11:
                          case "end":
                            return e.stop();
                        }
                    }, e, t);
                }))();
            },
            onShow: function() {
                o.globalData.inputValue && o.globalData.inputValue.name ? this.name = o.globalData.inputValue.name : o.globalData.inputValue && o.globalData.inputValue.tel ? this.tel = o.globalData.inputValue.tel : o.globalData.inputValue && o.globalData.inputValue.address && (this.address = o.globalData.inputValue.address);
            },
            wuxToast: function(t) {
                var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "success", a = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 3e3;
                Object(l.$wuxToast)().show({
                    type: e,
                    duration: a,
                    text: t
                });
            }
        });
    },
    371: function(t, e, a) {
        a.r(e), function(t) {
            t.currentModuleId = "m0d60f7f4", t.currentCtor = Component, t.currentSrcMode = "wx", 
            t.currentInject = {
                moduleId: "m0d60f7f4",
                render: function() {
                    var t = [], e = {};
                    return this.__travel((e.mpxPageStatus = this.mpxPageStatus, this.mpxPageStatus), t, !0), 
                    this.__travel((e.name = this.name, this.name), t, !0), this.__travel({
                        change: [ [ "changeValue", "name", "__mpx_event__" ] ]
                    }, t, !0), this.__travel((e.mpxPageStatus = this.mpxPageStatus, this.mpxPageStatus), t, !0), 
                    this.__travel((e.tel = this.tel, this.tel), t, !0), this.__travel({
                        change: [ [ "changeValue", "tel", "__mpx_event__" ] ]
                    }, t, !0), this.__travel((e.mpxPageStatus = this.mpxPageStatus, this.mpxPageStatus), t, !0), 
                    this.__travel((e.address = this.address, this.address), t, !0), this.__travel({
                        change: [ [ "changeValue", "address", "__mpx_event__" ] ]
                    }, t, !0), this.__travel((e.mpxPageStatus = this.mpxPageStatus, this.mpxPageStatus), t, !0), 
                    this.__travel(!0, t, !0), this.__travel((e.disabledBtn = this.disabledBtn, this.disabledBtn), t, !0), 
                    this.__travel((e.mpxPageStatus = this.mpxPageStatus, this.mpxPageStatus), t, !0), 
                    e.isIphoneX = this.isIphoneX, this.isIphoneX, e.showLoading = this.showLoading, 
                    this.showLoading && this.__travel((e.mpxPageStatus = this.mpxPageStatus, this.mpxPageStatus), t, !0), 
                    this.__travel((e.mpxPageStatus = this.mpxPageStatus, this.mpxPageStatus), t, !0), 
                    e;
                }
            }, a(139), t.currentModuleId;
        }.call(this, a(7));
    }
}, [ [ 371, 0 ] ] ]);
(global.webpackJsonp = global.webpackJsonp || []).push([ [ "pages/user/login" ], {
    "0353": function(n, t, o) {
        (function(n) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            }), t.default = void 0;
            var e = {
                data: function() {
                    return {
                        isShowLogin: !1
                    };
                },
                components: {
                    LoginModal: function() {
                        o.e("component/loginModal").then(function() {
                            return resolve(o("2658"));
                        }.bind(null, o)).catch(o.oe);
                    }
                },
                onLoad: function() {
                    var n = this;
                    this.$getUser().then(function(t) {
                        n.isShowLogin = !1;
                    }).catch(function(t) {
                        494 === t.status && (n.isShowLogin = !0);
                    });
                },
                methods: {
                    onCloseLogin: function() {
                        var t = this;
                        this.$userinfo.user_info_auth ? this.isShowLogin = !1 : this.$getUser().then(function(n) {
                            t.isShowLogin = !1;
                        }).catch(function(t) {
                            494 === t.status && n.navigateBack();
                        });
                    },
                    handlePhone: function(t) {
                        var o = t.detail;
                        n.showLoading({
                            title: "登录中",
                            mask: !0
                        }), "getPhoneNumber:ok" === o.errMsg && this.$userinfo.temporary_token && this.bindingMobile(o);
                    },
                    bindingMobile: function(t) {
                        var o = this;
                        this.$request("/wechat/bindingMobile", {
                            temporary_token: this.$userinfo.temporary_token,
                            encrypted_data: t.encryptedData,
                            iv: t.iv
                        }).then(function(t) {
                            n.hideLoading(), 446 !== t.status ? 0 === t.status && (o.$userinfo.token = t.data.token, 
                            o.$getUser().then(function(t) {
                                n.showToast({
                                    title: "登录成功",
                                    mask: !0
                                }), setTimeout(function() {
                                    n.navigateBack();
                                }, 1500);
                            })) : n.showModal({
                                title: "该手机号已绑定了封面账户",
                                content: "请在封面新闻App中解除绑定",
                                showCancel: !1,
                                confirmColor: "#ff2564"
                            });
                        }).catch(function(t) {
                            n.hideLoading();
                        });
                    }
                }
            };
            t.default = e;
        }).call(this, o("543d").default);
    },
    "03a4": function(n, t, o) {
        var e = function() {
            var n = this;
            n.$createElement;
            n._self._c;
        }, i = [];
        o.d(t, "b", function() {
            return e;
        }), o.d(t, "c", function() {
            return i;
        }), o.d(t, "a", function() {});
    },
    "4b7c": function(n, t, o) {
        var e = o("6f2d");
        o.n(e).a;
    },
    "5f06": function(n, t, o) {
        o.r(t);
        var e = o("0353"), i = o.n(e);
        for (var a in e) "default" !== a && function(n) {
            o.d(t, n, function() {
                return e[n];
            });
        }(a);
        t.default = i.a;
    },
    "6f2d": function(n, t, o) {},
    b28f: function(n, t, o) {
        o.r(t);
        var e = o("03a4"), i = o("5f06");
        for (var a in i) "default" !== a && function(n) {
            o.d(t, n, function() {
                return i[n];
            });
        }(a);
        o("4b7c");
        var u = o("f0c5"), c = Object(u.a)(i.default, e.b, e.c, !1, null, "a17651fc", null, !1, e.a, void 0);
        t.default = c.exports;
    },
    b505: function(n, t, o) {
        (function(n) {
            function t(n) {
                return n && n.__esModule ? n : {
                    default: n
                };
            }
            o("8f9a"), t(o("66fd")), n(t(o("b28f")).default);
        }).call(this, o("543d").createPage);
    }
}, [ [ "b505", "common/runtime", "common/vendor" ] ] ]);
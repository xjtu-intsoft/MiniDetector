require("../../151691521E685ECF7370F955395515B0.js"), require("../../0D0F99C71E685ECF6B69F1C0D66515B0.js"), 
global.webpackJsonpMpvue([ 13 ], {
    B8ed: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var s = n("JGtx"), i = n.n(s), o = n("YjdS"), a = n("ybqe")(i.a, o.a, function(e) {
            n("JRL+");
        }, null, null);
        t.default = a.exports;
    },
    EBUi: function(e, t, n) {
        var s = o(n("5nAL")), i = o(n("B8ed"));
        function o(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        new s.default(i.default).$mount();
    },
    JGtx: function(e, t, n) {
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var s = o(n("MvGc")), i = o(n("x7vk"));
        function o(e) {
            return e && e.__esModule ? e : {
                default: e
            };
        }
        t.default = {
            data: function() {
                return {
                    isLoading: !0,
                    phoneValue: "",
                    yzmValue: "",
                    key: "",
                    isMsg: !1,
                    new: !1,
                    res: {},
                    session: "",
                    openid: "",
                    adviserId: "",
                    zhuanId: "",
                    userId: "",
                    userRole: "",
                    fromPage: ""
                };
            },
            computed: {
                pageHeight: function() {
                    return "min-height:" + (s.default.windowHeight - s.default.footerHeight()) + "px";
                },
                logo: function() {
                    return s.default.$img("logo.png");
                }
            },
            components: {
                sendCode: i.default
            },
            methods: {
                onInputPhone: function(e) {
                    this.phoneValue = e.mp.detail;
                },
                onInputYzm: function(e) {
                    this.yzmValue = e.mp.detail;
                },
                uploadUserInfo: function() {
                    var e = this, t = (s.default.url("uploadUserInfo"), this);
                    s.default.uploadUserInfo(function() {
                        s.default.log("key+++22", t), s.default.log("key+++", t.key), s.default.log("顾问id", t.adviserId), 
                        s.default.hideLoading(), e.new ? s.default.goSelf("../userRegister/main") : (console.log(0x3c02c421f9484000), 
                        console.log(t), "index" == t.key || "ptList" == t.key || "ptList_new" == t.key || "sign" == t.key || "myAdvice" == t.key || "receivedQuestions" == t.key || "userCenter" == t.key ? "index" == t.key || "ptList_new" == t.key || "userCenter" == t.key ? (s.default.isRefresh = !0, 
                        s.default.isIndexRefresh = !0, s.default.isUserCenterRefresh = !0, s.default.isPtRefresh = !0, 
                        wx.switchTab({
                            url: "../" + t.key + "/main"
                        })) : s.default.reLaunch("../" + t.key + "/main") : (console.log(8888888999999), 
                        t.key.includes("$") ? s.default.goSelf("../" + t.key.split("$")[0] + "/main?new=" + t.new + "&src=" + t.key.split("$")[1]) : s.default.goSelf("../" + t.key + "/main?new=" + t.new)), 
                        "consultant_lecturer" == t.key && s.default.goSelf("/pages/consultant/lecturer/main?key=login&adviserId=" + t.adviserId + "&userId=" + t.userId + "&userRole=" + t.userRole), 
                        "columnDetails" == t.key && s.default.goSelf("/pages/consultant/columnDetails/main?key=login&adviserId=" + t.adviserId + "&zhuanId=" + t.zhuanId));
                    });
                },
                getPhoneNumber: function(e) {
                    var t, n = e.mp.detail.iv, i = e.mp.detail.encryptedData, o = this;
                    t = s.default.getLocal("isGuwenLine") ? s.default.getLocal("isGuwenLine") : 0, n && (s.default.setLocal("openid", this.openid), 
                    s.default.$np("/user/miniapp/loginByEncryptedData", {
                        iv: n,
                        encryptedData: i,
                        inviteCode: s.default.getLocal("inviteCode"),
                        is_guwen_line: t,
                        session: this.session
                    }).then(function(e) {
                        e.isError || (wx.setStorage({
                            key: "session",
                            data: e.session
                        }), s.default.isAuthLogin = !0, o.uploadUserInfo(), setTimeout(function() {
                            s.default.isLogin();
                        }, 500));
                    }));
                },
                onMsgLogin: function() {
                    this.isMsg = !0;
                },
                onLogin: function() {
                    var e, t = this, n = this;
                    e = s.default.getLocal("isGuwenLine") ? s.default.getLocal("isGuwenLine") : 0, n.phoneValue ? n.yzmValue ? (s.default.setLocal("session", this.session), 
                    s.default.setLocal("openid", this.openid), s.default.showLoading("请稍候"), s.default.$np("/user/login/sms", {
                        tel: n.phoneValue,
                        verifyCode: n.yzmValue,
                        inviteCode: s.default.getLocal("inviteCode"),
                        channelType: e
                    }).then(function(e) {
                        e.session && (console.log("立即登录:", e), wx.setStorage({
                            key: "session",
                            data: e.session
                        }), "authLogin" == t.fromPage && (s.default.isAuthLogin = !0), t.uploadUserInfo(), 
                        "consultant_lecturer" == t.key && s.default.goSelf("/pages/consultant/lecturer/main?key=login&adviserId=" + n.adviserId + "&userId=" + n.userId + "&userRole=" + n.userRole), 
                        "columnDetails" == n.key && s.default.goSelf("/pages/consultant/columnDetails/main?key=login&adviserId=" + n.adviserId));
                    })) : s.default.tip("请输入验证码") : s.default.tip("请输入手机号");
                }
            },
            onLoad: function(e) {
                var t = this;
                console.log(e), this.fromPage = e.loginType, "authLogin" == this.fromPage && (this.isMsg = !0), 
                e.key ? (this.key = e.key, this.adviserId = e.adviserId, this.zhuanId = e.zhuanId, 
                e.userRole && (this.userRole = e.userRole), e.userId && (this.userId = e.userId)) : this.key = "index", 
                s.default.userLogin(function(e) {
                    t.session = e.session, t.openid = e.openid;
                });
            }
        };
    },
    "JRL+": function(e, t) {},
    YjdS: function(e, t, n) {
        t.a = {
            render: function() {
                var e = this, t = e.$createElement, n = e._self._c || t;
                return n("div", [ n("div", {
                    staticClass: "loginWrap",
                    style: e.pageHeight
                }, [ n("div", {
                    staticClass: "logo"
                }, [ n("img", {
                    staticStyle: {
                        width: "100%"
                    },
                    attrs: {
                        src: e.logo,
                        mode: "widthFix",
                        alt: "logo"
                    }
                }) ]), e._v(" "), e.isMsg ? n("div", {
                    staticClass: "form"
                }, [ n("div", {
                    staticClass: "line"
                }, [ n("van-field", {
                    attrs: {
                        name: "phone",
                        value: e.phoneValue,
                        "input-class": "bt input",
                        maxlength: "25",
                        "placeholder-style": "font-size:16px; color:#ccc;",
                        placeholder: "请输入手机号",
                        border: !1,
                        eventid: "0",
                        mpcomid: "0"
                    },
                    on: {
                        input: e.onInputPhone
                    }
                }) ], 1), e._v(" "), n("div", {
                    staticClass: "line fx"
                }, [ n("div", {
                    staticClass: "fx1"
                }, [ n("van-field", {
                    attrs: {
                        name: "yzm",
                        value: e.yzmValue,
                        "input-class": "yzm input",
                        maxlength: "25",
                        "placeholder-style": "font-size:16px; color:#ccc;",
                        placeholder: "输入验证码",
                        border: !1,
                        "use-button-slot": "",
                        eventid: "1",
                        mpcomid: "1"
                    },
                    on: {
                        input: e.onInputYzm
                    }
                }) ], 1), e._v(" "), n("sendCode", {
                    attrs: {
                        phoneValue: e.phoneValue,
                        mpcomid: "2"
                    }
                }) ], 1) ]) : e._e(), e._v(" "), e.isMsg ? e._e() : n("div", {
                    staticClass: "tips"
                }, [ e._v("\n            如果您还没有用这个手机号注册过财税问诊\n            "), n("br"), e._v("我们将为您创建账号\n        ") ], 1), e._v(" "), n("div", {
                    staticClass: "buttonWrap"
                }, [ e.isMsg ? n("div", [ n("div", {
                    staticStyle: {
                        "margin-top": "50rpx"
                    }
                }), e._v(" "), e.isMsg ? n("button", {
                    staticClass: "btn quick",
                    attrs: {
                        eventid: "2"
                    },
                    on: {
                        click: e.onLogin
                    }
                }, [ e._v("立即登录") ]) : e._e(), e._v(" "), n("div", {
                    staticClass: "fx"
                }, [ n("div", {
                    staticClass: "fx1"
                }), e._v(" "), n("button", {
                    staticClass: "link",
                    attrs: {
                        "open-type": "getPhoneNumber",
                        eventid: "3"
                    },
                    on: {
                        getphonenumber: e.getPhoneNumber
                    }
                }, [ e._v("手机号一键登录") ]) ], 1) ], 1) : n("div", [ n("button", {
                    staticClass: "btn quick",
                    attrs: {
                        "open-type": "getPhoneNumber",
                        eventid: "4"
                    },
                    on: {
                        getphonenumber: e.getPhoneNumber
                    }
                }, [ e._v("手机号一键登录") ]), e._v(" "), n("div", {
                    staticClass: "fx"
                }, [ n("div", {
                    staticClass: "fx1"
                }), e._v(" "), n("div", {
                    staticClass: "link",
                    attrs: {
                        eventid: "5"
                    },
                    on: {
                        click: e.onMsgLogin
                    }
                }, [ e._v("短信验证登录") ]) ]) ], 1) ]), e._v(" "), e._m(0) ]) ]);
            },
            staticRenderFns: [ function() {
                var e = this.$createElement, t = this._self._c || e;
                return t("div", {
                    staticClass: "phoneFixed"
                }, [ this._v("\n            点击登录，即表示已阅读并同意\n            "), t("a", {
                    staticClass: "blue",
                    attrs: {
                        href: "../web/main?src=appShare/registAgee"
                    }
                }, [ this._v("《法律条款与隐私政策》") ]) ]);
            } ]
        };
    }
}, [ "EBUi" ]);
function e(e) {
    return function() {
        var t = e.apply(this, arguments);
        return new Promise(function(e, n) {
            function o(r, a) {
                try {
                    var i = t[r](a), c = i.value;
                } catch (e) {
                    return void n(e);
                }
                if (!i.done) return Promise.resolve(c).then(function(e) {
                    o("next", e);
                }, function(e) {
                    o("throw", e);
                });
                e(c);
            }
            return o("next");
        });
    };
}

var t = require("../../../config/weapp.js");

Page({
    data: {
        staticResourceBase: t.app.domain.staticResourceBase,
        mobileInput: "",
        msgCodeInput: "",
        mobileFlag: !1,
        msgCodeFlag: !1,
        checkFlag: !0,
        openCode: ""
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {
        t.uba.postUserAction(this, !0);
    },
    onHide: function() {
        t.uba.postUserAction(this);
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {},
    risk: function() {
        this.selectComponent("#smb").sendMsgPub();
    },
    getInputMobile: function(e) {
        var t = e.detail.value, n = t.length > 0;
        this.setData({
            mobileInput: t,
            mobileFlag: n
        });
    },
    toCtServicePage: function(e) {
        t.uba.saveUserAction(this, e), wx.navigateTo({
            url: "/pages/other/ctServiceStatement/ctServiceStatement"
        });
    },
    getInputMsgCode: function(e) {
        var t = e.detail.value, n = t.length > 0;
        this.setData({
            msgCodeInput: t,
            msgCodeFlag: n
        });
    },
    checkboxChange: function(e) {
        var t = e.currentTarget.dataset.check;
        this.setData({
            checkFlag: !t
        });
    },
    unionMemberBind: function(n) {
        var o = this;
        return e(t.regeneratorRuntime.mark(function e() {
            var r, a, i, c, s, u, g, d, m, S, l, v, p, f, w, x, y, h, b;
            return t.regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (t.uba.saveUserAction(o, n), !(o.data.mobileFlag && o.data.msgCodeFlag && o.data.checkFlag)) {
                        e.next = 26;
                        break;
                    }
                    return r = wx.getStorageSync("openUserInfo") || {}, a = o.data.mobileInput, i = "1", 
                    c = r.nickName || "", s = "1" == r.gender ? "man" : "lady", u = r.avatarUrl || "", 
                    g = o.data.msgCodeInput, d = wx.getStorageSync("openCode") || "", m = wx.getStorageSync("iv"), 
                    S = wx.getStorageSync("encryptedData"), l = "", v = "", (p = wx.getStorageSync("wechatMiniWord") || "") && (v = wx.getStorageSync("custInviteCode") || "", 
                    l = 10), wx.getStorageSync("driverCode") && (v = wx.getStorageSync("driverCode"), 
                    l = 8), f = {
                        mobile: a,
                        bindFlag: i,
                        openNickName: c,
                        openUserSex: s,
                        openHead: u,
                        verifyCode: g,
                        openCode: d,
                        iv: m,
                        encryptedData: S,
                        inviteUser: v,
                        inviteType: l,
                        custCode: p,
                        recommendUserId: wx.getStorageSync("recommendUserId") || ""
                    }, e.next = 20, t.req.requestSync("unionMemberBind", f);

                  case 20:
                    w = e.sent, x = w.result, y = w.detail, h = w.resultNote, console.log("入参里面的recommendUserId", f.recommendUserId), 
                    "1" == x ? (b = y.userId, wx.setStorageSync("userId", b), wx.removeStorageSync("userInfo"), 
                    wx.removeStorageSync("iv"), wx.removeStorageSync("encryptedData"), wx.removeStorageSync("openUserInfo"), 
                    wx.removeStorageSync("driverCode"), wx.getStorageSync("inviteCode") && o.bindOffLineMember(wx.getStorageSync("inviteCode")), 
                    wx.getStorageSync("recommendUserId") ? (console.log("1推手注册来的"), wx.switchTab({
                        url: "/pages/index/index"
                    }), wx.removeStorageSync("recommendUserId")) : wx.getStorageSync("custInviteCode") && wx.getStorageSync("wechatMiniWord") ? wx.navigateTo({
                        url: "/pages/station/linecustom/linecustom"
                    }) : wx.navigateBack({
                        delta: 2
                    })) : t.wxSync.showToast(h);

                  case 26:
                  case "end":
                    return e.stop();
                }
            }, e, o);
        }))();
    },
    bindOffLineMember: function(n) {
        var o = this;
        return e(t.regeneratorRuntime.mark(function e() {
            var r, a, i, c, s, u;
            return t.regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return r = "2", a = "pages/login/login/login?introduceCode=" + n, i = {
                        inviteCode: n,
                        inviteTypeId: r,
                        inviteLink: a
                    }, e.next = 4, t.req.requestSync("bindOffLineMember", i);

                  case 4:
                    c = e.sent, s = c.result, u = c.detail, "1" == s && t.wxSync.showToast("绑定成功！");

                  case 8:
                  case "end":
                    return e.stop();
                }
            }, e, o);
        }))();
    }
});
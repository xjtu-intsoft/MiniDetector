var e = getApp(), t = require("../../utils/util"), a = require("../../components/components").Components, o = !0;

Page(Object.assign({}, a, {
    data: {
        scene: e.globalData.scene,
        themeId: e.globalData.themeId || 1,
        waitPay: 0,
        waitShip: 0,
        toSignUp: 0,
        toComment: 0,
        refundSize: 0,
        couponOpen: !0,
        integralOpen: !0,
        isOpenIntegralMall: !0,
        isOpenMemberDeposit: !0,
        integralName: "积分",
        depositOpen: !0,
        headPicUrl: "",
        memberName: "",
        memberAcct: "",
        email: "",
        phone: "",
        memberLevelName: "",
        memberLevelIconCusType: 0,
        memberLevelPath: "",
        orderModuleName: "收货人信息",
        promoteSetName: "推广员",
        isOpenGroupBuy: !1,
        openRefund: !1,
        defaultHeadPic: "../../image/xcx-tx.png",
        isLogin: !1,
        isOpenPromote: !1,
        isOpenCutPrice: !1,
        isPromoter: !1,
        isPromoterMinePage: !1,
        allowDist: !1,
        isLoginByMember: !1,
        isShowMemberMobilePop: !1,
        memberBindMobile: "",
        isUseOtherMobile: !1,
        countDown: 60,
        countDownText: "获取验证码",
        mobileNumber: "",
        codeNumber: "",
        getCodeBtnLock: !1,
        countryCode: "86",
        chooseAccount: !1,
        allOrderSize: 0,
        existMemberAcct: "",
        memberLevel: "",
        checkCodeLock: !1,
        recordBindMobileType: "wx",
        isIpx: getApp().globalData.isIpx || !1,
        munuList: [],
        basicInfo: {
            file: ""
        },
        myOrderInfo: {
            name: "我的订单",
            tl: [],
            tabListMap: {},
            cs: 0
        },
        tabListDef: [],
        promoterInfo: {
            name: "推广员中心",
            ns: 0,
            sm: !0,
            ispro: !1
        },
        menuInfo: {
            ss: 1
        },
        memberAssets: {
            deposit: "--",
            currentItg: "--",
            memberCoupon: "--"
        },
        isShowPromoter: !1,
        promoterData: {
            balance: "--",
            income: "--",
            totalCustomers: "--"
        },
        isShowMemberAssets: !0,
        backgroundStyle: {},
        isShowNewAddDot: !1,
        hasToCoupo: !0,
        memberShipCardOpen: !1,
        memberShipCardInfo: {
            memberShipCardList: void 0,
            unBuyMemberShipCardList: [],
            firstUnBuyCard: {}
        },
        previousPageX: 0,
        scrollTransform: 0
    },
    onShow: function() {
        wx.removeStorageSync("mallStarToday"), new e.FooterInit(this), new getApp().InitData(this), 
        t.setPageTitle(11);
        this.loadModuleListSuccess(), this._editTabBar();
    },
    onLoad: function() {
        t.isLogin() ? (this.setData({
            isLogin: !0
        }), getApp().globalData.isLogin = !0, this.getMenuList()) : this.deleteAllData(), 
        t.logDog(201296, 1), getApp().globalData._commDataWithLogin && getApp().globalData._commDataWithLogin.isGiveCoupon && t.logDog(201474, 2), 
        this.getMinePageOrderTabList(), t.isLogin() || this.getNotLoginMinePageData();
    },
    oaLoad: function(e) {
        t.log(e), t.logDog(200753, 5);
    },
    oaErr: function(e) {
        t.log(e), t.logDog(200753, 6);
    },
    catchNull: function() {},
    loginAct: function(e) {
        var a = this, o = (getCurrentPages(), this);
        if (getApp().globalData.isModel) o._showToast("模板小程序仅起效果展示作用，不支持登录", {
            timeout: 3e3,
            showIcon: !1
        }); else {
            var i = {};
            e && e.detail && e.detail.userInfo && (i = e.detail.userInfo), t.wxLogin({
                success: function(e) {
                    var i = e.data, r = i.loginCount || 0, s = i.logined || !1;
                    o.setData({
                        isLogin: !0,
                        loginCount: r,
                        logined: s
                    });
                    var n = new getApp();
                    n.ShowMallCartNum(a), n.InitData(a), o.getMinePageInitData();
                    var m = t.getCookie("promoteMemberId") || 0;
                    m > 0 && (t.log("__promoteMemberId:" + m), t.request({
                        url: "promote_h.jsp?cmd=bindPromoteMember",
                        data: {
                            promoteMemberId: m
                        },
                        success: function(e) {}
                    }));
                },
                fail: function(e) {
                    var t = e.data || {};
                    o.setData({
                        isLogin: !1
                    }), t.msg && wx.showModal({
                        content: t.msg
                    });
                },
                noUserInfoAuth: function(e) {
                    t.navigateTo({
                        url: "/pages/page0/page0"
                    });
                },
                cancelAuthModal: function(e) {
                    t.navigateTo({
                        url: "/pages/page0/page0"
                    });
                }
            }, i);
        }
    },
    loadModuleListSuccess: function() {
        getApp().globalData.isModel || (!t.isLogin() && getApp().globalData.hasLogined ? this.deleteAllData() : (this.loginAct(), 
        this.setData({
            isLogin: !0
        }), null == getApp().globalData.hasLogined && this.getMenuList(), getApp().globalData.isLogin = !0, 
        getApp().globalData.hasLogined = !0));
    },
    getMCenterMemData: function() {
        var a = this;
        o && wx.showLoading({
            title: "加载中"
        }), t.request({
            url: "wxmallapp_h.jsp?cmd=getMCenterPage",
            data: {},
            complete: function() {
                wx.hideLoading();
            },
            success: function(i) {
                var r = i.data || {};
                if (r.success) {
                    o = !1;
                    var s = r.rtData, n = s.waitPay, m = s.waitGroup, c = s.waitShip, l = s.toSignUp, u = s.toComment, d = s.allOrderSize, p = s.refundSize, g = s.memberAcct, b = s.email, h = s.phone, L = s.memberLevel, A = s.memberBindMobile, D = s.memberLevelName, I = s.memberLevelIconCusType, T = s.memberLevelPath, M = s.depositOpen, w = s.isPromoter, f = s.getLoginItgNum, _ = s.loginEarnItg, P = (s.registEarnItg, 
                    s.getRegestItgNum, s.memberId), S = s.aid, C = s.memberShipCardInfo;
                    if (a.setData({
                        waitPay: n,
                        waitGroup: m,
                        waitShip: c,
                        toSignUp: l,
                        toComment: u,
                        allOrderSize: d,
                        refundSize: p,
                        memberAcct: g,
                        email: b,
                        phone: h,
                        memberLevel: L,
                        memberBindMobile: A,
                        memberLevelName: D,
                        memberLevelIconCusType: I,
                        memberLevelPath: T,
                        depositOpen: M,
                        isPromoter: w,
                        memberShipCardInfo: C
                    }), e.globalData.userInfo && "" == a.data.memberBindMobile) a.setData({
                        headPicUrl: e.globalData.userInfo.avatarUrl,
                        memberName: e.globalData.userInfo.nickName
                    }); else {
                        var O = r.rtData.memberName;
                        "" != O && null != O || (O = r.rtData.memberAcct);
                        var v = (r.rtData.headPic || {}).path || "";
                        a.setData({
                            headPicUrl: v,
                            memberName: O
                        });
                    }
                    var N = t.getCookie("loginIntegralTip" + S + P);
                    null != N && "true" == N && _ && (a._showPopup({
                        show: !0,
                        panelText: "+" + (f || 0),
                        showCloseBtn: !0,
                        panelHeight: "540rpx",
                        panelWidth: "562rpx",
                        itgTitle: "登录成功",
                        isItg: !0
                    }), t.setCookie("loginIntegralTip" + S + P, ""), t.logDog(201094, 8));
                }
            }
        });
    },
    toShowMemberInfo: function() {
        var e = "/subPages/memberinfo/memberinfo";
        this.data.isLogin || (e = "../loginAndReg/loginAndReg"), wx.navigateTo({
            url: e
        });
    },
    toMemberShipCard: function(e) {
        t.logDog(201154, 6);
        var a = (e.currentTarget.dataset || {}).id, o = "/subPages/memberShipCardList/memberShipCardList?justUnBuy=true";
        1 == (this.data.memberShipCardInfo.unBuyMemberShipCardList || []).length && (o = "/subPages/memberShipCardDetail/memberShipCardDetail?id=" + a), 
        t.navigateTo({
            url: o
        });
    },
    toMemberShipCardList: function() {
        t.navigateTo({
            url: "/subPages/memberShipCardList/memberShipCardList"
        });
    },
    showBindMemberMobilePop: function(e) {
        var a = (e.currentTarget.dataset || {}).type || "close";
        "open" == a ? (this.data.isShowMemberMobilePop || this.setData({
            isShowMemberMobilePop: !0
        }), t.logDog(200815, 1)) : "otherMobile" == a ? (this.setData({
            isShowMemberMobilePop: !1,
            isUseOtherMobile: !0,
            recordBindMobileType: "otherMobile"
        }), t.logDog(200815, 3)) : this.setData({
            isShowMemberMobilePop: !1,
            isUseOtherMobile: !1,
            chooseAccount: !1,
            recordBindMobileType: "wx"
        });
    },
    itgBtnClick: function(e) {
        t.logDog(200751, 7);
    },
    bindMemberMobile: function(e) {
        var a = this, o = e.detail || {};
        if (-1 != o.errMsg.indexOf("getPhoneNumber:ok")) {
            var i = o.encryptedData, r = o.iv;
            wx.showLoading({
                title: "获取手机号中"
            }), t.request({
                url: "wxmallapp_h.jsp?cmd=decryptDataAndBindMobile",
                data: {
                    encryptedData: i,
                    iv: r
                },
                success: function(o) {
                    var i = o.data || {};
                    if (i.success) {
                        var r = i.mobile || "";
                        i.countryCode;
                        r.length > 8 && r.replace(/^(.{3})(.{5})(.*)$/, "$1*****$3"), a.setData({
                            mobileNumber: r
                        }), t.request({
                            url: "wxmallapp_h.jsp?cmd=isExistMemberInfoSignByMobile",
                            data: {
                                mobile: r
                            },
                            success: function(t) {
                                var o = t.data || {};
                                o.success ? (wx.hideLoading(), o.isExistMemberInfoSignByMobile ? a.data.allOrderSize > 0 ? a.setData({
                                    chooseAccount: !0,
                                    isShowMemberMobilePop: !1,
                                    isUseOtherMobile: !1,
                                    existMemberAcct: o.memberAcct
                                }) : (e.currentTarget.dataset.mode = "mobile", a.bindMemberMobileAjax(e)) : (e.currentTarget.dataset.mode = "wxapp", 
                                a.bindMemberMobileAjax(e))) : a._showToast("系统异常，请稍后重试", {
                                    timeout: 3e3,
                                    showIcon: !1
                                });
                            }
                        });
                    } else wx.hideLoading(), a._showToast(i.msg, {
                        timeout: 3e3,
                        showIcon: !1
                    });
                }
            });
        } else -1 != o.errMsg.indexOf("permission") && a._showToast("暂不支持直接获取微信手机号，请手动输入", {
            timeout: 3e3,
            showIcon: !1
        }), a.setData({
            isShowMemberMobilePop: !1,
            isUseOtherMobile: !0
        });
        t.logDog(200815, 2);
    },
    getCode: function() {
        var e = this;
        e.data.getCodeBtnLock || (t.isMobile(e.data.mobileNumber) ? (e.setData({
            getCodeBtnLock: !0
        }), t.request({
            url: "wxmallapp_h.jsp?cmd=getMobileCode",
            data: {
                mobile: e.data.mobileNumber,
                mobileCt: e.data.countryCode
            },
            success: function(t) {
                var a = t.data || {};
                if (a.success) {
                    e._showToast("验证码发送成功", {
                        timeout: 3e3,
                        showIcon: !1
                    });
                    var o = setInterval(function() {
                        e.data.countDown > 0 ? e.setData({
                            countDownText: e.data.countDown - 1 + "s后重新获取",
                            countDown: e.data.countDown - 1
                        }) : (clearInterval(o), e.setData({
                            countDownText: "获取验证码",
                            countDown: 60,
                            getCodeBtnLock: !1
                        }));
                    }, 1e3);
                } else e._showToast(a.msg, {
                    timeout: 3e3,
                    showIcon: !1
                }), -8 == a.rt && (e.setData({
                    getCodeBtnLock: !0
                }), setTimeout(function() {
                    e.setData({
                        getCodeBtnLock: !1
                    });
                }, 18e5));
            }
        })) : e._showToast("请输入正确的手机号", {
            timeout: 3e3,
            showIcon: !1
        }));
    },
    bindMemberMobileAjax: function(e) {
        var a = this, o = (e.currentTarget.dataset || {}).mode, i = "";
        t.request({
            url: "wxmallapp_h.jsp?cmd=mergeMobiAndMallAppMember",
            data: {
                mode: o,
                mobile: a.data.mobileNumber,
                mobileType: a.data.recordBindMobileType
            },
            success: function(e) {
                var o = e.data || {};
                o.success ? (a._showToast("绑定手机号成功", {
                    timeout: 3e3,
                    showIcon: !1
                }), a.data.mobileNumber.length > 8 && (i = a.data.mobileNumber.replace(/^(.{3})(.{5})(.*)$/, "$1*****$3")), 
                a.setData({
                    isShowMemberMobilePop: !1,
                    isUseOtherMobile: !1,
                    chooseAccount: !1,
                    recordBindMobileType: "wx",
                    memberBindMobile: i
                }), wx.removeStorageSync("_FSESSIONID"), t.wxLoginRefresh(), a.onShow()) : a._showToast(o.msg, {
                    timeout: 3e3,
                    showIcon: !1
                });
            }
        });
    },
    bindKeyInput: function(e) {
        "mobile" == e.target.dataset.type ? this.data.mobileNumber = e.detail.value : this.data.codeNumber = e.detail.value;
    },
    checkValidationCode: function(e) {
        var a = this;
        t.isMobile(a.data.mobileNumber) ? "" != a.data.codeNumber ? a.data.checkCodeLock || (a.data.checkCodeLock = !0, 
        wx.showLoading({
            title: "验证码校验中",
            mask: !0
        }), t.request({
            url: "wxmallapp_h.jsp?cmd=checkValidationCode",
            data: {
                messageAuthCode: a.data.codeNumber,
                mobile: a.data.mobileNumber,
                mobileCt: a.data.countryCode
            },
            success: function(t) {
                var o = t.data || {};
                o.success ? o.isExistMemberInfoSignByMobile ? a.data.allOrderSize > 0 ? a.setData({
                    chooseAccount: !0,
                    isShowMemberMobilePop: !1,
                    isUseOtherMobile: !1,
                    existMemberAcct: o.memberAcct
                }) : (e.currentTarget.dataset.mode = "mobile", a.bindMemberMobileAjax(e)) : (e.currentTarget.dataset.mode = "wxapp", 
                a.bindMemberMobileAjax(e)) : a._showToast("验证码错误", {
                    timeout: 3e3,
                    showIcon: !1
                });
            },
            complete: function() {
                a.data.checkCodeLock = !1, wx.hideLoading();
            }
        })) : a._showToast("请输入验证码", {
            timeout: 3e3,
            showIcon: !1
        }) : a._showToast("请输入正确的手机号", {
            timeout: 3e3,
            showIcon: !1
        });
    },
    toPromote: function() {
        t.logDog(200891, 5);
        var e = "/promote/pages/promotewelcome/promotewelcome";
        this.data.isPromoter && !getApp().globalData.isFirstEnterPromoter && (e = "/promote/pages/promoteindex/promoteindex"), 
        t.navigateTo({
            url: e
        });
    },
    toOrderList: function(e) {
        var a = (e.currentTarget.dataset || {}).selectedid || "";
        getApp().globalData.selectedId = a, getApp().globalData.isOpenGroupBuy = this.data.isOpenGroupBuy, 
        t.navigateTo({
            url: "/subPages/orderlist/orderlist"
        });
    },
    getMinePageOrderTabList: function() {
        var e = this;
        t.request({
            url: "minePage_h.jsp?cmd=getMinePageOrderTabList",
            complete: function() {
                wx.hideLoading();
            },
            fail: function(e) {},
            success: function(t) {
                var a = t.data;
                if (a.success) {
                    var o = a.returnTabList, i = a.tabListDef || [], r = a.cs;
                    if (o && o.length > 0) {
                        for (var s = 0; s < o.length; s++) {
                            var n = o[s];
                            switch (n.id) {
                              case i.NORMAL_WAIT_PAY:
                              case i.VIRTUAL_WAIT_PAY:
                              case i.HOTEL_WAIT_PAY:
                                n.count = 0, n.selectedId = "waitPay";
                                break;

                              case i.NORMAL_WAIT_GROUP:
                              case i.VIRTUAL_WAIT_GROUP:
                              case i.HOTEL_WAIT_GROUP:
                                n.count = 0, n.selectedId = "waitGroup";
                                break;

                              case i.NORMAL_WAIT_SHIP:
                              case i.NORMAL_WAIT_TAKE:
                              case i.NORMAL_WAIT_DELIVER:
                              case i.NORMAL_WAIT_USE:
                              case i.VIRTUAL_WAIT_SHIP:
                              case i.HOTEL_WAIT_ENTER:
                                n.count = 0, n.selectedId = "waitShip";
                                break;

                              case i.NORMAL_SHIP:
                              case i.NORMAL_TAKE:
                              case i.NORMAL_DELIVER:
                              case i.NORMAL_USE:
                              case i.VIRTUAL_SHIP:
                              case i.HOTEL_ENTER:
                                n.count = 0, n.selectedId = "toSignUp";
                                break;

                              case i.NORMAL_PROCESS:
                              case i.VIRTUAL_PROCESS:
                              case i.HOTEL_PROCESS:
                                n.count = 0, n.selectedId = "toComment";
                                break;

                              case i.NORMAL_CANCEL:
                              case i.VIRTUAL_CANCEL:
                              case i.HOTEL_CANCEL:
                                n.count = 0, n.selectedId = "toCancel";
                                break;

                              case i.NORMAL_REFUND:
                              case i.VIRTUAL_REFUND:
                              case i.HOTEL_REFUND:
                                n.count = 0;
                            }
                        }
                        var m = e.data.myOrderInfo;
                        m.tl = o, m.cs = r;
                        var c = m.tl.filter(function(e) {
                            return !e.hidden;
                        }).length;
                        if (m.showCount = c, 1 === m.cs && (c += 1), c > 0) {
                            var l = 20 * c, u = 100 / c;
                            m.maxWidth = l, m.tabWidth = u;
                        }
                        e.setData({
                            tabListDef: i,
                            myOrderInfo: m
                        });
                    }
                }
            }
        });
    },
    getMinePageInitData: function(a) {
        var i = this, r = this;
        o && wx.showLoading({
            title: "加载中"
        }), t.request({
            url: "minePage_h.jsp?cmd=getMinePage",
            isCached: !1,
            complete: function() {
                wx.hideLoading();
            },
            success: function(a) {
                var s = a.data || {};
                if (s.success) {
                    o = !1;
                    var n = s.rtData.tabListDef || [], m = s.rtData.moduleList[0] || {}, c = s.rtData.memberAssets || {}, l = s.rtData.promoterData || {}, u = s.rtData.backgroundStyle || {}, d = s.rtData.waitPay, p = s.rtData.waitGroup, g = s.rtData.waitShip, b = s.rtData.toSignUp, h = s.rtData.toComment, L = s.rtData.toCancel, A = s.rtData.allOrderSize, D = s.rtData.refundSize, I = s.rtData.memberShipCardInfo, T = s.rtData.memberBulletinOpen, M = s.rtData.bulletinContent, w = s.rtData.couponOpen, f = s.rtData.integralOpen, _ = s.rtData.openRefund, P = s.rtData.isOpenGroupBuy, S = s.rtData.wxSubscribe, C = s.rtData.isOpenPromote, O = s.rtData.memberShipCardOpen, v = s.rtData.memberId, N = s.rtData.aid, R = s.rtData.memberLevel, E = s.rtData.memberLevelIconCusType, x = s.rtData.memberLevelPath, U = s.rtData.memberBindMobile, y = s.rtData.memberLevelName, k = s.rtData.loginEarnItg, W = s.rtData.memberAssets.integralName;
                    wx.getStorage({
                        key: "memberCoupon",
                        success: function(e) {
                            c.memberCoupon > e.data && r.setData({
                                hasToCoupo: !1
                            }), r.data.hasToCoupo && wx.setStorage({
                                key: "memberCoupon",
                                data: c.memberCoupon
                            });
                        },
                        fail: function(e) {
                            wx.setStorage({
                                key: "memberCoupon",
                                data: c.memberCoupon
                            });
                        }
                    });
                    var B = "", H = "";
                    if (e.globalData.userInfo && "" == U) B = e.globalData.userInfo.avatarUrl, H = e.globalData.userInfo.nickName; else "" != (H = s.rtData.memberName) && null != H || (H = s.rtData.memberAcct), 
                    B = (s.rtData.headPic || {}).path || "";
                    if (r.setData({
                        memberAssets: c,
                        promoterData: l,
                        isShowPromoter: l.isShowPromoter,
                        isPromoter: l.isPromoter,
                        backgroundStyle: u,
                        headPicUrl: B,
                        memberName: H,
                        waitPay: d,
                        waitGroup: p,
                        waitShip: g,
                        toSignUp: b,
                        toComment: h,
                        allOrderSize: A,
                        refundSize: D,
                        memberShipCardInfo: I,
                        memberBulletinOpen: T,
                        bulletinContent: M,
                        couponOpen: w,
                        integralOpen: f,
                        openRefund: _,
                        isOpenGroupBuy: P,
                        wxSubscribe: S,
                        isOpenPromote: C,
                        memberShipCardOpen: O,
                        memberLevel: R,
                        memberLevelIconCusType: E,
                        memberLevelPath: x,
                        memberBindMobile: U,
                        memberLevelName: y,
                        integralName: W
                    }), r.data.bulletinContent) {
                        var V = r.data.bulletinContent;
                        V = i.decodeHtml(V.replace(/<([^>|\|]+)>|&nbsp;|\s+/g, "")), r.setData({
                            bulletinContent: V
                        });
                    }
                    var G = t.getCookie("loginIntegralTip" + N + v), j = s.rtData.getLoginItgNum;
                    if (null != G && "true" == G && k && (r._showPopup({
                        show: !0,
                        panelText: "+" + (j || 0),
                        showCloseBtn: !0,
                        panelHeight: "540rpx",
                        panelWidth: "562rpx",
                        itgTitle: "登录成功",
                        isItg: !0
                    }), t.setCookie("loginIntegralTip" + N + v, ""), t.logDog(201094, 8)), l.isShowPromoter || r.setData({
                        promoterData: {
                            balance: "--",
                            income: "--",
                            totalCustomers: "--"
                        }
                    }), 0 !== Object.keys(m).length) {
                        var q = m.content.bi || {}, z = m.content.isma, F = m.content.mo || {}, Y = m.content.pt || {}, K = m.content.mu || {};
                        void 0 === q.mie && (q.mie = !0);
                        var $ = K.ml;
                        if (0 == Y.sp ? l.isPromoter || r.setData({
                            isShowPromoter: !0
                        }) : 1 != Y.sp || l.isPromoter || r.setData({
                            promoterData: {
                                balance: "--",
                                income: "--",
                                totalCustomers: "--"
                            }
                        }), F.tl && F.tl.length > 0) {
                            for (var X = F.tl, J = 0; J < X.length; J++) {
                                var Q = X[J];
                                switch (Q.id) {
                                  case n.NORMAL_WAIT_PAY:
                                  case n.VIRTUAL_WAIT_PAY:
                                  case n.HOTEL_WAIT_PAY:
                                    Q.count = d, Q.selectedId = "waitPay";
                                    break;

                                  case n.NORMAL_WAIT_GROUP:
                                  case n.VIRTUAL_WAIT_GROUP:
                                  case n.HOTEL_WAIT_GROUP:
                                    Q.count = p, Q.selectedId = "waitGroup";
                                    break;

                                  case n.NORMAL_WAIT_SHIP:
                                  case n.NORMAL_WAIT_TAKE:
                                  case n.NORMAL_WAIT_DELIVER:
                                  case n.NORMAL_WAIT_USE:
                                  case n.VIRTUAL_WAIT_SHIP:
                                  case n.HOTEL_WAIT_ENTER:
                                    Q.count = g, Q.selectedId = "waitShip";
                                    break;

                                  case n.NORMAL_SHIP:
                                  case n.NORMAL_TAKE:
                                  case n.NORMAL_DELIVER:
                                  case n.NORMAL_USE:
                                  case n.VIRTUAL_SHIP:
                                  case n.HOTEL_ENTER:
                                    Q.count = b, Q.selectedId = "toSignUp";
                                    break;

                                  case n.NORMAL_PROCESS:
                                  case n.VIRTUAL_PROCESS:
                                  case n.HOTEL_PROCESS:
                                    Q.count = h, Q.selectedId = "toComment";
                                    break;

                                  case n.NORMAL_CANCEL:
                                  case n.VIRTUAL_CANCEL:
                                  case n.HOTEL_CANCEL:
                                    Q.count = L, Q.selectedId = "toCancel";
                                    break;

                                  case n.NORMAL_REFUND:
                                  case n.VIRTUAL_REFUND:
                                  case n.HOTEL_REFUND:
                                    Q.count = D;
                                }
                            }
                            var Z = F.tl.filter(function(e) {
                                return !e.hidden;
                            }).length;
                            if (F.showCount = Z, 1 === F.cs && (Z += 1), Z > 0) {
                                var ee = 20 * Z, te = 100 / Z;
                                F.maxWidth = ee, F.tabWidth = te;
                            }
                            for (var ae = [ {
                                id: "all",
                                title: "全部"
                            } ], oe = 0; oe < X.length; oe++) {
                                var ie = X[oe], re = ie.id;
                                if (!ie.hidden && re !== n.NORMAL_REFUND && re !== n.HOTEL_REFUND && re !== n.VIRTUAL_REFUND) {
                                    var se = {
                                        title: ie.sn
                                    };
                                    switch (re) {
                                      case n.NORMAL_WAIT_PAY:
                                      case n.VIRTUAL_WAIT_PAY:
                                      case n.HOTEL_WAIT_PAY:
                                        se.id = "waitPay";
                                        break;

                                      case n.NORMAL_WAIT_GROUP:
                                      case n.VIRTUAL_WAIT_GROUP:
                                      case n.HOTEL_WAIT_GROUP:
                                        se.id = "waitGroup";
                                        break;

                                      case n.NORMAL_WAIT_SHIP:
                                      case n.NORMAL_WAIT_TAKE:
                                      case n.NORMAL_WAIT_DELIVER:
                                      case n.NORMAL_WAIT_USE:
                                      case n.VIRTUAL_WAIT_SHIP:
                                      case n.HOTEL_WAIT_ENTER:
                                        se.id = "waitShip";
                                        break;

                                      case n.NORMAL_SHIP:
                                      case n.NORMAL_TAKE:
                                      case n.NORMAL_DELIVER:
                                      case n.NORMAL_USE:
                                      case n.VIRTUAL_SHIP:
                                      case n.HOTEL_ENTER:
                                        se.id = "toSignUp";
                                        break;

                                      case n.NORMAL_PROCESS:
                                      case n.VIRTUAL_PROCESS:
                                      case n.HOTEL_PROCESS:
                                        se.id = "toComment";
                                        break;

                                      case n.NORMAL_CANCEL:
                                      case n.VIRTUAL_CANCEL:
                                      case n.HOTEL_CANCEL:
                                        se.id = "toCancel";
                                    }
                                    ae.push(se);
                                }
                            }
                            getApp().globalData.orderTabList = ae;
                        }
                        r.setData({
                            tabListDef: n,
                            basicInfo: q,
                            myOrderInfo: F,
                            promoterInfo: Y,
                            isShowMemberAssets: z,
                            isPromoterMinePage: l.isPromoter,
                            menuInfo: K,
                            munuList: $
                        });
                    }
                } else r._showToast(s.msg, {
                    timeout: 3e3,
                    showIcon: !1
                });
            }
        });
    },
    getNotLoginMinePageData: function() {
        var e = this;
        o && wx.showLoading({
            title: "加载中"
        }), t.request({
            url: "minePage_h.jsp?cmd=getMinePage",
            isCached: !1,
            complete: function() {
                wx.hideLoading();
            },
            success: function(t) {
                var a = t.data || {};
                if (a.success) {
                    o = !1;
                    var i = a.rtData.wxSubscribe;
                    e.setData({
                        wxSubscribe: i
                    });
                } else e._showToast(a.msg, {
                    timeout: 3e3,
                    showIcon: !1
                });
            }
        });
    },
    getMenuList: function(e) {
        var a = this;
        t.request({
            url: "minePage_h.jsp?cmd=getMenuList",
            method: "GET",
            isCached: !1,
            success: function(e) {
                var t = e.data || {};
                if (t.success) {
                    var o = t.rtData.menuInfo, i = o.ml, r = t.rtData.isPro, s = t.rtData.promoterName || "推广员中心", n = t.rtData.promoterNs || 0, m = t.rtData.isShowMemberAssets, c = t.rtData.backgroundStyle || {};
                    a.setData({
                        menuInfo: o,
                        munuList: i,
                        promoterInfo: {
                            name: s,
                            ns: n,
                            sm: !0,
                            ispro: r
                        },
                        isShowPromoter: !0,
                        backgroundStyle: c,
                        isShowMemberAssets: m
                    });
                } else a._showToast(t.msg, {
                    timeout: 3e3,
                    showIcon: !1
                });
            }
        });
    },
    toAnotherPage: function(e) {
        e.currentTarget.dataset.id;
        var a = e.currentTarget.dataset.tp, o = e.currentTarget.dataset.url;
        "coupon" == a && getApp().globalData._commDataWithLogin && getApp().globalData._commDataWithLogin.isGiveCoupon && t.logDog(201474, 3), 
        "dist" == a && (getApp().globalData.hasLogined = void 0), "form" == a && t.logDog(201296, 2), 
        "login" == a && this.logout(), "promoter" != a || this.data.isPromoter || (o = "/promote/pages/promotewelcome/promotewelcome"), 
        t.navigateTo({
            url: o
        });
    },
    toWithdraw: function() {
        var e = "/promote/pages/promotewithdraw/promotewithdraw";
        this.data.isPromoter && (1 != this.data.promoterInfo.sp || this.data.isPromoterMinePage) || (e = "/promote/pages/promoteindex/promoteindex"), 
        t.navigateTo({
            url: e
        });
    },
    toFlow: function() {
        var e = "/promote/pages/promoteflow/promoteflow";
        this.data.isPromoter && (1 != this.data.promoterInfo.sp || this.data.isPromoterMinePage) || (e = "/promote/pages/promoteindex/promoteindex"), 
        t.navigateTo({
            url: e
        });
    },
    toCustomers: function() {
        var e = "/promote/pages/promotecustomers/promotecustomers";
        this.data.isPromoter && (1 != this.data.promoterInfo.sp || this.data.isPromoterMinePage) || (e = "/promote/pages/promoteindex/promoteindex"), 
        t.navigateTo({
            url: e
        });
    },
    toMemDeposit: function() {
        t.navigateTo({
            url: "/subPages/memDeposit/memDeposit"
        });
    },
    toItg: function() {
        t.navigateTo({
            url: "/subPages/integral/integral"
        });
    },
    toCoupu: function() {
        this.setData({
            hasToCoupo: !0
        }), wx.setStorage({
            key: "memberCoupon",
            data: this.data.memberAssets.memberCoupon
        });
        t.navigateTo({
            url: "/subPages/profile/profile?type=coupon"
        }), getApp().globalData._commDataWithLogin && getApp().globalData._commDataWithLogin.isGiveCoupon && t.logDog(201474, 3);
    },
    logout: function() {
        var e = this;
        wx.showModal({
            title: "",
            content: "确认要退出登录吗?",
            success: function(a) {
                a.cancel || t.request({
                    url: "login_h.jsp?cmd=logout",
                    success: function(t) {
                        t.data.success ? (e.deleteAllData(), getApp().globalData.isPopupNewGuestPage = !1, 
                        getApp().globalData.hasBeenReLaunch = !1) : e.deleteAllData();
                    }
                });
            }
        });
    },
    deleteAllData: function() {
        getApp().globalData.isLogin = !1, this.getMenuList(), this.setData({
            scene: e.globalData.scene,
            themeId: e.globalData.themeId || 1,
            waitPay: 0,
            waitShip: 0,
            toSignUp: 0,
            toComment: 0,
            refundSize: 0,
            isOpenIntegralMall: !0,
            isOpenMemberDeposit: !0,
            integralName: "积分",
            headPicUrl: "",
            memberName: "",
            memberAcct: "",
            email: "",
            phone: "",
            memberLevelName: "",
            memberLevelIconCusType: 0,
            memberLevelPath: "",
            orderModuleName: "收货人信息",
            promoteSetName: "推广员",
            openRefund: !1,
            defaultHeadPic: "../../image/xcx-tx.png",
            isLogin: !1,
            isPromoter: !1,
            isPromoterMinePage: !1,
            isLoginByMember: !1,
            isShowMemberMobilePop: !1,
            memberBindMobile: "",
            isUseOtherMobile: !1,
            countDown: 60,
            countDownText: "获取验证码",
            mobileNumber: "",
            codeNumber: "",
            getCodeBtnLock: !1,
            countryCode: "86",
            chooseAccount: !1,
            allOrderSize: 0,
            existMemberAcct: "",
            memberLevel: "",
            checkCodeLock: !1,
            recordBindMobileType: "wx",
            isIpx: getApp().globalData.isIpx || !1,
            basicInfo: {
                file: ""
            },
            myOrderInfo: {
                name: "我的订单"
            },
            promoterInfo: {
                name: "推广员中心",
                ns: 0,
                sm: !0,
                ispro: !0
            },
            memberAssets: {
                deposit: "--",
                currentItg: "--",
                memberCoupon: "--"
            },
            isShowPromoter: !1,
            promoterData: {
                balance: "--",
                income: "--",
                totalCustomers: "--"
            },
            isShowMemberAssets: !0,
            backgroundStyle: {},
            isShowNewAddDot: !1,
            hasToCoupo: !0,
            memberShipCardInfo: {
                memberShipCardList: void 0,
                unBuyMemberShipCardList: [],
                firstUnBuyCard: {}
            },
            mallCartNum: 0
        }), this.getMinePageOrderTabList();
    },
    decodeHtml: function(e) {
        return e && e.replace ? e.replace(/&nbsp;/gi, " ").replace(/&lt;/gi, "<").replace(/&gt;/g, ">").replace(/&#92;/gi, "\\").replace(/&#39;/gi, "'").replace(/&quot;/gi, '"').replace(/\<br\/\>/gi, "\n").replace(/&amp;/gi, "&") : e;
    },
    moveStart: function(e) {},
    slide: function(e) {
        var t = e.changedTouches[0].pageX, a = 0;
        a = t < this.data.previousPageX ? 84 : 5, this.setData({
            previousPageX: t,
            scrollTransform: a
        });
    },
    endOfTouch: function(e) {}
}));
function t(t) {
    return t && t.__esModule ? t : {
        default: t
    };
}

var e = t(require("../../utils/util_partner")), a = t(require("../../utils/api_partner"));

Page({
    data: {
        name: "",
        mobile: "",
        code: "",
        gender: "",
        dateVal: "1990-01-01",
        birthday: "",
        wx_num: "",
        is_sub: !1,
        is_CountDown: !1,
        countDownText: "获取验证码"
    },
    onLoad: function(t) {},
    onReady: function() {},
    onShow: function() {
        this.getInfo();
    },
    onHide: function() {},
    onUnload: function() {},
    formatTime: function(t) {
        var e = new Date(1e3 * t);
        return e.getFullYear() + "-" + (e.getMonth() + 1 < 10 ? "0" + (e.getMonth() + 1) : e.getMonth() + 1) + "-" + (e.getDate() < 10 ? "0" + e.getDate() : e.getDate());
    },
    getInfo: function() {
        var t = this;
        e.default.checkToken().then(function(n) {
            wx.showLoading({
                title: "数据加载中",
                mask: !0
            }), e.default.requestGet(a.default.getFansInfo).then(function(e) {
                if (wx.hideLoading(), console.log("res", e), 200 == e.data.code) {
                    var a = e.data.data, n = "";
                    a.birthday > 0 && (n = t.formatTime(a.birthday)), t.setData({
                        name: a.name,
                        mobile: a.mobile,
                        gender: a.gender,
                        dateVal: n,
                        birthday: n,
                        wx_num: a.wx_num
                    }), t.checkFrom();
                } else wx.showToast({
                    title: e.message,
                    icon: "none",
                    duration: 2e3
                });
            });
        });
    },
    bindInputChange: function(t) {
        var e = t.currentTarget.dataset.type;
        "name" == e && this.setData({
            name: t.detail.value
        }), "mobile" == e && this.setData({
            mobile: t.detail.value
        }), "code" == e && this.setData({
            code: t.detail.value
        }), "wx" == e && this.setData({
            wx_num: t.detail.value
        });
    },
    bindInputblur: function(t) {
        var e = t.currentTarget.dataset.type;
        if ("name" == e && ("" == this.data.name || this.data.name.length > 20 || this.data.name.length < 2)) return wx.showToast({
            title: "请输入正确的姓名",
            icon: "none",
            duration: 2e3
        }), !1;
        if ("mobile" == e) {
            var a = /^1[3456789]\d{9}$/;
            if ("" == this.data.mobile || !a.test(this.data.mobile)) return wx.showToast({
                title: "请输入正确的手机号码",
                icon: "none",
                duration: 2e3
            }), !1;
        }
        if ("wx" == e) {
            if ("" == this.data.wx_num) return wx.showToast({
                title: "请填写您的微信号",
                icon: "none",
                duration: 2e3
            }), !1;
            if (this.data.wx_num.length > 20) return wx.showToast({
                title: "请填写正确的微信号，最长20个字符",
                icon: "none",
                duration: 2e3
            }), !1;
        }
        this.checkFrom();
    },
    checkFrom: function() {
        var t = !0;
        if ("" == this.data.name || this.data.name.length > 20 || this.data.name.length < 2) return t = !1, 
        !1;
        var e = /^1[3456789]\d{9}$/;
        return "" != this.data.mobile && e.test(this.data.mobile) ? "" == this.data.code ? (t = !1, 
        !1) : "" == this.data.gender ? (t = !1, !1) : "" == this.data.birthday ? (t = !1, 
        !1) : "" == this.data.wx_num || this.data.wx_num.length > 20 ? (t = !1, !1) : void this.setData({
            is_sub: t
        }) : (t = !1, !1);
    },
    genderClick: function(t) {
        var e = t.currentTarget.dataset.val;
        this.setData({
            gender: e
        }), this.checkFrom();
    },
    bindDateChange: function(t) {
        this.setData({
            birthday: t.detail.value
        }), this.checkFrom();
    },
    sendMsg: function() {
        var t = this;
        if (!this.data.is_CountDown) {
            var n = this;
            if ("" == this.data.mobile) return wx.showToast({
                title: "手机号码不能为空",
                icon: "none",
                duration: 2e3
            }), !1;
            if (!/^1[3456789]\d{9}$/.test(this.data.mobile)) return wx.showToast({
                title: "请填写正确的手机号码",
                icon: "none",
                duration: 2e3
            }), !1;
            wx.showLoading({
                title: "数据提交中",
                mask: !0
            }), e.default.requestGet(a.default.getCheckMobile, {
                mobile: this.data.mobile
            }).then(function(i) {
                200 == i.data.code ? e.default.requestGet(a.default.getSmsSend, {
                    mobile: t.data.mobile
                }).then(function(t) {
                    if (wx.hideLoading(), 200 == t.data.code) {
                        var e = 60;
                        n.setData({
                            is_CountDown: !0,
                            countDownText: e + "s"
                        });
                        var a = setInterval(function() {
                            e--, n.setData({
                                is_CountDown: !0,
                                countDownText: e + "s"
                            }), e <= 0 && (clearInterval(a), n.setData({
                                is_CountDown: !1,
                                countDownText: "获取验证码"
                            }));
                        }, 1e3);
                    } else wx.showToast({
                        title: t.data.message,
                        icon: "none",
                        duration: 2e3
                    });
                }) : (wx.hideLoading(), wx.showToast({
                    title: i.data.message,
                    icon: "none",
                    duration: 2e3
                }));
            });
        }
    },
    send: function() {
        if (this.data.is_sub) {
            var t = this, n = new Date(t.data.birthday), i = Date.parse(n) / 1e3;
            wx.showLoading({
                title: "数据提交中",
                mask: !0
            }), e.default.requestPost(a.default.postEnroll, {
                name: t.data.name,
                mobile: t.data.mobile,
                code: t.data.code,
                gender: t.data.gender,
                birthday: i,
                wx_num: t.data.wx_num
            }).then(function(t) {
                console.log(t), wx.hideLoading(), 200 == t.code ? wx.showModal({
                    title: "提交成功",
                    content: "请点击确定，跳转至伙伴首页。",
                    showCancel: !1,
                    success: function(t) {
                        t.confirm && wx.switchTab({
                            url: "/pages/partner/main"
                        });
                    }
                }) : wx.showToast({
                    title: t.message,
                    icon: "none",
                    duration: 2e3
                });
            });
        }
    }
});
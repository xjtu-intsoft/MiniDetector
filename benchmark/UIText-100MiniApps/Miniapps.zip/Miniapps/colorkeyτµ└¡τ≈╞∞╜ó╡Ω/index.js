require("./../../../webpack-require")("E0Nm", Object.assign({}, require("././../../../vendors.js").modules, require("././../../../commons.js").modules, {
    E0Nm: function(t, e, o) {
        o.r(e);
        var n = o("Fcif"), a = o("NERQ"), i = o("hHpg"), c = o("8B9M"), s = o("HaEp"), r = o("FjcP"), d = o.n(r), u = Object(c.a)();
        Component({
            properties: {
                show: {
                    type: Boolean,
                    value: !1
                },
                title: {
                    type: String,
                    value: "帐号密码登录"
                },
                subTitle: {
                    type: String,
                    value: "为了你的帐号安全，请用手机号登录"
                },
                redirectUrl: {
                    type: String,
                    value: "/packages/account/settings/index"
                }
            },
            data: {
                formData: {
                    countryCode: "+86",
                    mobile: "",
                    wxMobile: "",
                    captcha: "",
                    captchaTime: null,
                    password: ""
                },
                captcha: {
                    text: "获取验证码",
                    code: "",
                    times: 1,
                    countdown: 60,
                    textStyle: "acc-code__btn--enabled",
                    btnStyle: "",
                    timer: null
                },
                loginBtn: {
                    text: "登录",
                    disabled: !0,
                    wxDisabled: !1
                },
                agreement: {
                    text: "《用户使用协议》",
                    url: "https://bbs.youzan.com/forum.php?mod=viewthread&tid=672890&page=1&extra=#pid3837866"
                }
            },
            methods: {
                changeLoginType: function() {
                    this.triggerEvent("changeLoginType", {
                        type: "sms"
                    });
                },
                _checkMobile: function(t) {
                    return /^\d{11}$/.test(t);
                },
                _checkPassword: function(t) {
                    return t && t.length >= 6;
                },
                login: function() {
                    var t = this, e = this.data.loginBtn.disabled, o = this.data.formData, a = o.mobile, c = o.password, r = o.countryCode;
                    if (!e) {
                        if (!this._checkMobile(a)) return wx.showToast({
                            icon: "none",
                            title: "请输入正确的手机号"
                        });
                        if (!this._checkPassword(c)) return wx.showToast({
                            icon: "none",
                            title: "请输入正确的密码"
                        });
                        var l = {
                            countryCode: r,
                            mobile: a,
                            password: c
                        };
                        d()({
                            bizType: 10,
                            onSuccess: function(e) {
                                t._beforeLogin(), s.a.loginByPassword(Object(n.a)({}, l, {
                                    ticket: e
                                }), function() {
                                    return u.login().then(function() {
                                        return t._loginSuccess();
                                    });
                                }, function(e) {
                                    if (135200018 === e.code || 135200019 === e.code) return t.configDialog();
                                    t.setData({
                                        "loginBtn.disabled": !1
                                    }), i.a.clear(), wx.showToast({
                                        icon: "none",
                                        title: e.msg || "服务请求出错，请稍后再试"
                                    });
                                });
                            }
                        });
                    }
                },
                _loginSuccess: function() {
                    return i.a.clear(), this.triggerEvent("loginSuccess", {}, {}), this.setData({
                        show: !1
                    }), wx.showToast({
                        title: "登录成功",
                        icon: "success",
                        mask: !1
                    });
                },
                bindMobileInput: function(t) {
                    this.setData({
                        "formData.mobile": t.detail,
                        "loginBtn.disabled": !(t.detail && this.data.formData.password)
                    });
                },
                bindPasswordInput: function(t) {
                    this.setData({
                        "formData.password": t.detail,
                        "loginBtn.disabled": !(t.detail && this.data.formData.mobile)
                    });
                },
                _beforeLogin: function() {
                    this.loginLoading(), this.setData({
                        "loginBtn.disabled": !0
                    });
                },
                configDialog: function(t, e) {
                    var o, n = this;
                    if (void 0 === t && (t = !1), void 0 === e && (e = {}), t) {
                        if (!e.mobile) return wx.showToast({
                            icon: "none",
                            title: "授权获取手机号码失败，请重启小程序重新授权"
                        });
                        o = e.mobile;
                    } else {
                        if (!this.data.formData.mobile) return wx.showToast({
                            icon: "none",
                            title: "请正确填写手机号码"
                        });
                        o = this.data.formData.mobile;
                    }
                    var i = [];
                    i.push(o.substring(0, 3)), i.push("****"), i.push(o.substring(7));
                    var c = "手机号" + i.join("") + "已与其他微信帐号绑定";
                    a.a.confirm({
                        message: c,
                        confirmButtonText: "继续登录",
                        cancelButtonText: "换个手机号",
                        context: this,
                        zIndex: 99999
                    }).then(function() {
                        n.confirmLogin(e);
                    }).catch(function(t) {});
                },
                confirmLogin: function(t) {
                    void 0 === t && (t = {});
                    var e = t.mobile || this.data.formData.mobile, o = t.countryCode || this.data.formData.countryCode, n = this.data.redirectUrl, a = "/packages/account/to-bind/index?mobile=" + e + "&countryCode=" + encodeURIComponent(o) + "&redirectUrl=" + encodeURIComponent(n);
                    return wx.redirectTo({
                        url: a
                    });
                },
                _countDownForCaptchaCode: function() {
                    var t = this, e = this.data.captcha.countdown;
                    0 !== e ? (e--, this.setData({
                        "captcha.countdown": e,
                        "captcha.text": "已发送(" + e + "s)"
                    }), this.data.captcha.timer = setTimeout(function() {
                        t._countDownForCaptchaCode();
                    }, 1e3)) : this.setData({
                        "captcha.countdown": 60,
                        "captcha.text": "重新发送",
                        "captcha.btnStyle": "",
                        "captcha.textStyle": "acc-code__btn--enabled"
                    });
                },
                loginLoading: function(t) {
                    return void 0 === t && (t = "正在登录..."), i.a.clear(), i.a.loading({
                        mask: !1,
                        context: this,
                        selector: "#login-loading-van-toast",
                        message: t
                    });
                }
            }
        });
    },
    HaEp: function(t, e, o) {
        var n = o("Fcif"), a = o("8B9M"), i = o("sbP3"), c = Object(a.a)();
        e.a = {
            loginByPassword: function(t, e, o) {
                return t.password = i.aes.legacyEncrypt(t.password), void 0 === (a = {
                    origin: "uic",
                    path: "/passport/weapp/login/password.json",
                    data: t,
                    success: function(t) {
                        e(t);
                    },
                    fail: o
                }) && (a = {}), a = Object(n.a)({
                    config: {
                        skipKdtId: !0,
                        skipShopInfo: !0,
                        noQuery: !0
                    },
                    method: "POST",
                    header: {
                        "content-type": "application/x-www-form-urlencoded"
                    },
                    origin: "uic",
                    data: {},
                    success: function() {},
                    fail: function() {}
                }, a), c.request(a);
                var a;
            }
        };
    }
}));
var e = require("../../../utils/constants.js");

getApp();

Page({
    data: {
        inputValue: ""
    },
    carDataChange: function(e) {
        this.setData({
            inputValue: e.detail.value
        });
    },
    checkRate: function(t) {
        /^(\w-*\.*)+@(\w-?)+(\.\w{2,})+$/.test(t) ? (wx.showLoading({
            title: "请稍等..."
        }), console.log("邮箱输入正确"), wx.request({
            url: e.API_SERVER + "/wxUser/updateUserInfo?sessionId=" + getApp().globalData.setCookie + "&key=Email&value=" + t,
            method: "POST",
            data: {},
            header: {
                "Content-Type": "application/json"
            },
            success: function(e) {
                wx.hideLoading(), 200 == e.statusCode && wx.reLaunch({
                    url: "../../homePages/rescources/home"
                });
            },
            fail: function() {
                wx.hideLoading(), wx.showToast({
                    image: "../../../image/tips.png",
                    title: "修改失败，请重试！"
                });
            }
        })) : (console.log("邮箱输入错误"), wx.showToast({
            image: "../../../image/tips.png",
            title: "邮箱输入有误"
        }));
    },
    btnSave: function(e) {
        var t = this, n = this.data.inputValue;
        "" != n && t.checkRate(n);
    },
    onLoad: function(e) {},
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});
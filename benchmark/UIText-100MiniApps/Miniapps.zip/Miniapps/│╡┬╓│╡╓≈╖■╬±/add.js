var t = require("../../utils/cache"), a = require("../../utils/net");

Page({
    data: {
        cartype: "common",
        btnCha: "btn-cha-disable",
        btnChaHover: !1,
        alias: [ "京", "沪", "浙", "苏", "粤", "鲁", "晋", "冀", "豫", "川", "渝", "辽", "吉", "黑", "皖", "鄂", "湘", "赣", "闽", "陕", "甘", "宁", "蒙", "津", "贵", "云", "桂", "琼", "青", "新", "藏", "", "", "", "" ],
        province: "沪",
        showProvinceSel: !1,
        showEngineTip: !1
    },
    onLoad: function(t) {
        var e = this;
        this.longitude = t.longitude, this.latitude = t.latitude, a.net.getProvinceAlias(t.longitude, t.latitude, function(t) {
            var a = "沪";
            0 == t.data.code && "" != t.data.data && e.data.alias.indexOf(t.data.data) >= 0 && (a = t.data.data), 
            e.setData({
                province: a
            });
        });
    },
    setCarType: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "common";
        this.setData({
            cartype: t
        });
    },
    showProSel: function() {
        this.setData({
            showProvinceSel: !0
        });
    },
    closeProSel: function() {
        this.setData({
            showProvinceSel: !1
        });
    },
    onSelPro: function(t) {
        this.setData({
            province: t.target.dataset.value
        });
    },
    carnoInput: function(t) {
        for (var a = t.detail.value, e = -1, n = 0; n < a.length; n++) if (/[a-z]/i.test(a[n])) {
            e = n;
            break;
        }
        var i = "";
        if (e >= 0) for (var o = a.substr(e), s = 0; s < o.length; s++) /[a-z0-9]/i.test(o[s]) && (i += o[s].toUpperCase());
        return i.length > 7 && (i = i.substr(0, 7)), this.carno = i, this.btnEnableCheck(), 
        i;
    },
    carnoBlur: function() {
        var t = void 0, a = void 0;
        this.carno.length >= 7 ? (t = "energy", a = this.carno + " (新能源)") : (t = "common", 
        a = this.carno), this.setData({
            cartype: t,
            carno: a
        });
    },
    carnoFocus: function() {
        this.setData({
            cartype: "common",
            carno: this.carno
        });
    },
    engineInput: function(t) {
        for (var a = String(t.detail.value), e = "", n = 0; n < a.length; n++) /^[a-z0-9]$/i.test(a[n]) && (e += a[n].toUpperCase());
        return this.engine = e, this.btnEnableCheck(), e;
    },
    btnEnableCheck: function() {
        var t = void 0, a = void 0;
        /^[a-z0-9]{6,7}$/i.test(this.carno) && /^[a-z0-9]+$/i.test(this.engine) ? (t = "btn-cha-enable", 
        a = !0) : (t = "btn-cha-disable", a = !1), this.setData({
            btnCha: t,
            btnChaHover: a
        });
    },
    onQueryClick: function() {
        if ("btn-cha-enable" == this.data.btnCha) {
            var e = this.data.province + this.carno, n = this.engine;
            t.cache.car.update({
                carno: e,
                ecode: n
            }), a.net.pushCarList(), wx.redirectTo({
                url: "../list/list?carno=" + e + "&ecode=" + n + "&longitude=" + this.longitude + "&latitude=" + this.latitude
            });
        }
    },
    showEngineTip: function() {
        this.setData({
            showEngineTip: !0
        });
    },
    hideEngineTip: function() {
        this.setData({
            showEngineTip: !1
        });
    },
    carno: "",
    engine: "",
    onShareAppMessage: function() {
        return {
            title: "准确极速、支持全国\n            ",
            desc: "准确极速、覆盖全国、1.4亿车主都在用",
            path: "/pages/car/car"
        };
    }
});
var n = getApp();

require("../../utils/acc.js");

Page({
    data: {
        flag: !1,
        phone: "",
        phoneInput: "",
        phoneOkInput: "",
        disabled: !1
    },
    onLoad: function(o) {
        var t = n.globalData.userInfo.phone.length <= 1;
        console.log(t), this.setData({
            phone: n.globalData.userInfo.phone,
            flag: t
        });
    },
    phoneNumChange: function(n) {
        var o = n.detail.value;
        console.log(o), this.setData({
            phoneInput: o
        });
    },
    phoneNumOKChange: function(n) {
        var o = n.detail.value;
        console.log(o), this.setData({
            phoneOkInput: o
        });
    },
    touchbut: function() {
        var n = this.data.phoneInput, o = this.data.phoneOkInput, t = this;
        t.setData({
            disabled: !0
        }), "" == n ? (t.setData({
            disabled: !1
        }), wx.showToast({
            icon: "none",
            title: "内容不能为空！",
            duration: 2e3
        })) : n != o && (t.setData({
            disabled: !1
        }), wx.showToast({
            icon: "none",
            title: "两次输入的手机号不一致",
            duration: 2e3
        }));
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});
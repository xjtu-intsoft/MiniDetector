function e(t) {
    if (t.setData({
        codeStr: i + "秒后重发"
    }), 0 == i) return t.setData({
        verityButton: "get",
        codeStr: "获取验证码"
    }), void (i = 59);
    i--, r = setTimeout(function() {
        e(t);
    }, 1e3);
}

var t = require("../../../utils/util.js"), s = getApp(), o = s.globalData, a = s.url, i = 59, r = void 0;

Page({
    data: {
        pageName: "login",
        fromType: "",
        verityButton: "get",
        codeStr: "获取验证码",
        regPhone: "",
        regCode: "",
        regPassword: "",
        confirmPassword: "",
        regInviteCode: "",
        message_tips: "messageTips hide"
    },
    onLoad: function(e) {
        var t = this;
        e.fromType && t.setData({
            fromType: e.fromType
        });
    },
    onShow: function() {
        o.User.UserId && wx.switchTab({
            url: "../index/index"
        });
    },
    regPhoneInput: function(e) {
        this.setData({
            regPhone: e.detail.value
        });
    },
    regCodeInput: function(e) {
        this.setData({
            regCode: e.detail.value
        });
    },
    regPasswordInput: function(e) {
        this.setData({
            regPassword: e.detail.value
        });
    },
    confirmPasswordInput: function(e) {
        this.setData({
            confirmPassword: e.detail.value
        });
    },
    regInviteCodeInput: function(e) {
        this.setData({
            regInviteCode: e.detail.value
        });
    },
    verityPhone: function(e) {
        return !!/^1\d{10}$/.test(e);
    },
    verityPassword: function(e) {
        return !!/^[A-Za-z0-9]{6,18}$/.test(e);
    },
    getVerityCode: function(s) {
        var n = this;
        if (n.verityPhone(n.data.regPhone)) {
            n.setData({
                verityButton: "countDown"
            });
            var d = {
                MobileContext: {
                    Version: o.Version,
                    DeviceId: o.DeviceId,
                    Source: o.Source,
                    AppStoreId: o.AppStoreId,
                    Idfa: o.Idfa,
                    SessionId: o.SessionId,
                    PromotionUrl: o.PromotionUrl,
                    PromotionTemplateId: o.PromotionTemplateId,
                    Longitude: o.Longitude,
                    Latitude: o.Latitude,
                    IpAddress: o.IpAddress,
                    PromotionId: o.PromotionId,
                    PhoneIMSI: o.PhoneIMSI,
                    PhoneMAC: o.PhoneMAC,
                    Extend: o.Extend,
                    OperatorId: o.Extend
                },
                RequestParam: {
                    AuthCode: "",
                    Type: 1,
                    MobilePhone: n.data.regPhone
                }
            }, p = t.postParamEncrypt(o.md5_aeskey, d);
            wx.request({
                url: a.GetVerifyCode,
                data: p.des,
                method: "POST",
                header: {
                    "Content-Type": "application/json",
                    Token: o.Token,
                    Remark: "Unchecked",
                    AppVersion: o.Version,
                    AppPlatform: o.Source,
                    Authorization: p.auth,
                    AppIdentity: o.des_identity
                },
                success: function(s) {
                    var o = s.data.Result.toString();
                    o = t.decrypt(o), o = JSON.parse(o), console.log(o), o.IsSuccess ? (clearTimeout(r), 
                    i = 59, e(n)) : (clearTimeout(r), i = 59, n.setData({
                        message_tips: "messageTips",
                        message: o.Message,
                        verityButton: "get",
                        codeStr: "获取验证码"
                    }), setTimeout(function() {
                        n.setData({
                            message_tips: "messageTips hide",
                            message: ""
                        });
                    }, 2e3));
                },
                fail: function() {
                    clearTimeout(r), i = 59, n.setData({
                        verityButton: "get",
                        codeStr: "获取验证码"
                    });
                }
            });
        } else n.setData({
            message_tips: "messageTips",
            message: "请输入正确手机号",
            verityButton: "get",
            codeStr: "获取验证码"
        }), setTimeout(function() {
            n.setData({
                message_tips: "messageTips hide",
                message: ""
            });
        }, 2e3);
    },
    registerButton: function(e) {
        var i = this, n = i.data.regPhone, d = i.data.regCode, p = i.data.regPassword, u = i.data.confirmPassword;
        if ("" != n && "" != d && "" != p && i.verityPhone(n) && i.verityPassword(p) && p == u) {
            var m = {
                MobileContext: {
                    SessionId: o.SessionId,
                    AppStoreId: o.AppStoreId,
                    Version: o.Version,
                    Source: o.Source,
                    Latitude: o.Latitude,
                    DeviceId: o.DeviceId,
                    PhoneMAC: o.PhoneMAC,
                    TimeStamp: new Date(),
                    Idfa: o.Idfa,
                    Extend: o.Extend,
                    Longitude: o.Longitude,
                    IpAddress: o.IpAddress,
                    PhoneIMSI: o.PhoneIMSI,
                    promotionUrl: o.promotionUrl
                },
                RequestParam: {
                    AuthCode: d,
                    Type: 1,
                    MobilePhone: n
                }
            }, g = t.postParamEncrypt(o.md5_aeskey, m);
            wx.showLoading({
                title: "加载中",
                mask: !0
            }), wx.request({
                url: a.CheckAuthCode,
                data: g.des,
                method: "POST",
                header: {
                    "Content-Type": "application/json",
                    Token: o.Token,
                    Remark: "Unchecked",
                    AppVersion: o.Version,
                    AppPlatform: o.Source,
                    Authorization: g.auth,
                    AppIdentity: o.des_identity
                },
                success: function(e) {
                    var n = e.data.Result.toString();
                    if (n = t.decrypt(n), (n = JSON.parse(n)).IsSuccess) {
                        console.log("验证码验证成功");
                        var d = {
                            MobileContext: {
                                SessionId: o.SessionId,
                                AppStoreId: o.AppStoreId,
                                Version: o.Version,
                                Source: o.Source,
                                Latitude: o.Latitude,
                                DeviceId: o.DeviceId,
                                PhoneMAC: o.PhoneMAC,
                                TimeStamp: new Date(),
                                Idfa: o.Idfa,
                                Extend: o.Extend,
                                Longitude: o.Longitude,
                                IpAddress: o.IpAddress,
                                PhoneIMSI: o.PhoneIMSI,
                                promotionUrl: o.PromotionUrl
                            },
                            RequestParam: {
                                MobilePhoneNo: i.data.regPhone,
                                Password: i.data.regPassword,
                                ConfirmPassword: i.data.confirmPassword,
                                TrueName: "",
                                AuthCode: i.data.regCode,
                                InviteCode: i.data.regInviteCode,
                                CorpId: o.ChannelId,
                                IP: "",
                                Drkey: "",
                                Email: "",
                                ContactAddress: ""
                            }
                        }, p = t.postParamEncrypt(o.md5_aeskey, d);
                        wx.showLoading({
                            title: "加载中",
                            mask: !0
                        }), wx.request({
                            url: a.Register,
                            data: p.des,
                            method: "POST",
                            header: {
                                "Content-Type": "application/json",
                                Token: o.Token,
                                Remark: "Unchecked",
                                AppVersion: o.Version,
                                AppPlatform: o.Source,
                                Authorization: p.auth,
                                AppIdentity: o.des_identity
                            },
                            success: function(e) {
                                var a = e.data.Result.toString();
                                a = t.decrypt(a), a = JSON.parse(a), console.log(a), a.IsSuccess ? (console.log("注册成功"), 
                                wx.setStorage({
                                    key: "User",
                                    data: a.Result,
                                    success: function() {}
                                }), o.User = a.Result, o.Token = a.Result.Token, clearTimeout(r), "stockPriceList" == i.data.fromType ? wx.redirectTo({
                                    url: "../../booking/orderConfirm/orderConfirm"
                                }) : "receivePromotion" == i.data.fromType ? wx.redirectTo({
                                    url: "../promotionReceive/promotionReceive"
                                }) : "inviteReward" == i.data.fromType ? wx.redirectTo({
                                    url: "../../booking/invitePromotion/invitePromotion"
                                }) : "orderList" == i.data.fromType ? wx.redirectTo({
                                    url: "../orderList/orderList"
                                }) : "illegallyList" == i.data.fromType ? wx.redirectTo({
                                    url: "../illegally/illegally"
                                }) : "vipCenter" == i.data.fromType ? wx.redirectTo({
                                    url: "../vipCenter/vipCenter"
                                }) : wx.switchTab({
                                    url: "../index/index"
                                }), s.ehiSensors.track("signUp", {
                                    cell_phone: a.Result.PhoneNumber,
                                    signupType: "注册",
                                    vip_no: o.User.UserId || ""
                                })) : (i.setData({
                                    message_tips: "messageTips",
                                    message: a.Message
                                }), setTimeout(function() {
                                    i.setData({
                                        message_tips: "messageTips hide",
                                        message: ""
                                    });
                                }, 2e3));
                            },
                            fail: function() {
                                i.setData({
                                    message_tips: "messageTips",
                                    message: "注册失败，请稍候再试"
                                }), setTimeout(function() {
                                    i.setData({
                                        message_tips: "messageTips hide",
                                        message: ""
                                    });
                                }, 2e3);
                            },
                            complete: function() {
                                wx.hideLoading({
                                    fail: function() {}
                                });
                            }
                        });
                    } else i.setData({
                        message_tips: "messageTips",
                        message: n.Message
                    }), setTimeout(function() {
                        i.setData({
                            message_tips: "messageTips hide",
                            message: ""
                        });
                    }, 2e3);
                },
                fail: function() {},
                complete: function() {
                    wx.hideLoading({
                        fail: function() {}
                    });
                }
            });
        } else "" == n ? i.setData({
            message_tips: "messageTips",
            message: "手机号码不能为空"
        }) : i.verityPhone(n) ? "" == d ? i.setData({
            message_tips: "messageTips",
            message: "验证码不能为空"
        }) : "" == p ? i.setData({
            message_tips: "messageTips",
            message: "密码不能为空"
        }) : i.verityPassword(p) ? p != u && i.setData({
            message_tips: "messageTips",
            message: "两次密码输入不一致，请重新输入"
        }) : i.setData({
            message_tips: "messageTips",
            message: "密码格式有误，请重新输入"
        }) : i.setData({
            message_tips: "messageTips",
            message: "请输入正确手机号"
        }), setTimeout(function() {
            i.setData({
                message_tips: "messageTips hide",
                message: ""
            });
        }, 2e3);
    }
});
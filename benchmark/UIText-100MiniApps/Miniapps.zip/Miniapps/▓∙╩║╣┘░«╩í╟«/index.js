var e = getApp(), t = require("../../../utils/httpclient.js"), a = require("../../../libs/underscore.js"), s = require("../../../utils/dialog.js");

Page({
    data: {
        photo: "",
        genderSelect: [ {
            key: "1",
            value: "男"
        }, {
            key: "2",
            value: "女"
        } ],
        castrateSelect: [ {
            key: "1",
            value: "已绝育"
        }, {
            key: "2",
            value: "未绝育"
        } ],
        petList: [],
        castrateSel: 0,
        genderSel: 0,
        dateSel: "",
        tags: [],
        breed: [],
        showAdd: 0,
        petListLen: 0
    },
    castrateSel: 0,
    genderSel: 0,
    dateSel: "",
    breedSel: 0,
    tagsSel: [],
    idxObj: {},
    idxKv: {},
    photo: "",
    addLock: !1,
    updateLock: !1,
    petIdSel: 0,
    showAdd: 0,
    onLoad: function(a) {
        var s = this;
        e.initCfgData(), e.cfgDataReadyCallback = function() {
            var e = s.getBreeds();
            s.idxObj = e.idx, s.idxKv = e.kv, s.setData({
                breed: e.data,
                tags: s.getTags()
            });
        }, a.photo && (s.photo = a.photo);
        var o = new Date(), i = o.getFullYear(), d = i + "-" + (o.getMonth() + 1) + "-" + o.getDate(), n = i - 30 + "-" + (o.getMonth() + 1) + "-" + o.getDate();
        s.setData({
            start: n,
            end: d
        }), t.getPetList({
            master_id: e.globalData.userId,
            success: function(e) {
                e.data.list && s.setData({
                    petList: e.data.list,
                    petListLen: e.data.list.length || 0
                });
            }
        });
        var l = s.getBreeds();
        s.idxObj = l.idx, s.idxKv = l.kv, s.setData({
            breed: l.data,
            tags: s.getTags()
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareTimeline: function() {},
    onShareAppMessage: function() {},
    infoSubmit: function(o) {
        var i = this, d = o.detail.value.nickname;
        o.detail.formId;
        if (d) if (i.genderSel) if (o.detail.value.birth) if (o.detail.value.weight && "0" != o.detail.value.weight) if (o.detail.value.weight > 100) wx.showModal({
            title: "提示",
            content: "体重不能超过100Kg",
            showCancel: !1
        }); else if (i.castrateSel) if (i.breedSel) if (!a.isArray(i.tagsSel) || i.tagsSel.length <= 0) wx.showModal({
            title: "提示",
            content: "请选择标签",
            showCancel: !1
        }); else {
            if (i.addLock) return !1;
            i.addLock = !0, wx.showLoading({
                title: "提交中"
            }), t.addPhoto({
                user_id: e.globalData.userId,
                pet_name: d,
                photo: i.photo,
                gender: i.genderSel,
                birth: o.detail.value.birth,
                weight: o.detail.value.weight,
                is_castrated: i.castrateSel,
                breed: i.breedSel,
                tags: i.tagsSel,
                appname: e.globalData.appname,
                success: function(t) {
                    i.addLock = !1, t.data.petId > 0 ? wx.redirectTo({
                        url: "/pages/meng/photo/detail?photo_id=" + t.data.photoId + "&master_id=" + e.globalData.userId + "&pet_id=" + t.data.petId
                    }) : s.note("服务器繁忙", {
                        success: function() {}
                    });
                },
                complete: function() {
                    i.addLock = !1, wx.hideLoading();
                }
            });
        } else wx.showModal({
            title: "提示",
            content: "请选择爱宠的品种",
            showCancel: !1
        }); else wx.showModal({
            title: "提示",
            content: "请选择是否绝育",
            showCancel: !1
        }); else wx.showModal({
            title: "提示",
            content: "请填写体重",
            showCancel: !1
        }); else wx.showModal({
            title: "提示",
            content: "请选择生日",
            showCancel: !1
        }); else wx.showModal({
            title: "提示",
            content: "请选择性别",
            showCancel: !1
        }); else wx.showModal({
            title: "提示",
            content: "请填写昵称",
            showCancel: !1
        });
    },
    selectPet: function(e) {
        var t = e.currentTarget.dataset;
        if (!t.id) return !1;
        this.petIdSel = t.id, this.setData({
            petIdSel: this.petIdSel
        });
    },
    submitPetPhoto: function() {
        var a = this;
        return !a.updateLock && (a.updateLock = !0, a.petIdSel ? void t.UpdatePhoto({
            user_id: e.globalData.userId,
            photo: a.photo,
            pet_id: a.petIdSel,
            appname: e.globalData.dbappname,
            success: function(t) {
                a.updateLock = !1, t.data.petId > 0 ? wx.redirectTo({
                    url: "/pages/meng/photo/detail?photo_id=" + t.data.photoId + "&master_id=" + e.globalData.userId + "&pet_id=" + t.data.petId
                }) : s.note("服务器繁忙", {
                    success: function() {}
                });
            },
            complete: function() {
                a.updateLock = !1;
            }
        }) : (wx.showToast({
            title: "请选择爱宠",
            icon: "none",
            duration: 2e3
        }), a.updateLock = !1, !1));
    },
    genderChange: function(e) {
        console.log("genderSelect", e);
        var t = e.currentTarget.dataset.key;
        this.genderSel = t, this.setData({
            genderSel: t
        });
    },
    castrateChange: function(e) {
        console.log("castrateSelect", e);
        var t = e.currentTarget.dataset.key;
        this.castrateSel = t, this.setData({
            castrateSel: t
        });
    },
    dateChange: function(e) {
        console.log("dateChange", e);
        var t = e.detail.value;
        this.dateSel = t, this.setData({
            dateSel: t
        });
    },
    breedChange: function(e) {
        var t = e.detail.value, a = this.idxKv;
        this.breedSel = this.idxObj[t], t = parseInt(t), console.log("breedChange", e, "selKey = " + t), 
        this.setData({
            breedSelName: a[this.idxObj[t]] || "请选择爱宠的品种"
        });
    },
    selectTags: function(e) {
        var t = e.currentTarget.dataset.id, o = this.tagsSel, i = this.getSelTagKey(o, t);
        if (1 == i.isAdd && a.isArray(this.tagsSel) && this.tagsSel.length >= 5) s.note("最多只能选择5个标签", {
            success: function() {}
        }), this.tagsSel = o; else {
            this.tagsSel = i.data;
            var d = this.getTags(this.tagsSel);
            this.setData({
                tags: d
            });
        }
    },
    getBreeds: function() {
        var t = e.globalData.catBreedCfg, a = {}, s = {};
        if (!t) return !1;
        var o = 0;
        for (var i in t) s[o++] = t[i].id, a[t[i].id] = t[i].name;
        return {
            data: t,
            kv: a,
            idx: s
        };
    },
    getTags: function(t) {
        var s = e.globalData.catTagCfg, o = [];
        if (!s) return !1;
        for (var i in s) o.push({
            id: i,
            name: s[i],
            selected: a.lastIndexOf(t || [], i) > -1 ? 1 : 0
        });
        return o;
    },
    getSelTagKey: function(e, t) {
        var s = e;
        if (!a.isArray(s) || s.length <= 0) return {
            data: [ t ],
            isAdd: 1
        };
        var o = 1;
        if (a.indexOf(s, t) > -1) {
            for (var i = s.length, d = [], n = 0; n < i; n++) s[n] != t && d.push(s[n]);
            s = d, o = 0;
        } else {
            for (i = s.length, d = [], n = 0; n < i; n++) d.push(s[n]);
            d.push(t), s = d, o = 1;
        }
        return {
            data: s,
            isAdd: o
        };
    },
    showAddWrap: function() {
        this.setData({
            showAdd: 1
        });
    }
});